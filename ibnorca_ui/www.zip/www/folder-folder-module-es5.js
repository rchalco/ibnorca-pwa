(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["folder-folder-module"], {
    /***/
    "+nqB":
    /*!**********************************************!*\
      !*** ./src/app/interfaces/Test/data-test.ts ***!
      \**********************************************/

    /*! exports provided: DataTest */

    /***/
    function nqB(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "DataTest", function () {
        return DataTest;
      });

      var DataTest = function DataTest() {
        _classCallCheck(this, DataTest);
      };
      /***/

    },

    /***/
    "FJ2Q":
    /*!*****************************************!*\
      !*** ./src/app/folder/folder.page.scss ***!
      \*****************************************/

    /*! exports provided: default */

    /***/
    function FJ2Q(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-menu-button {\n  color: var(--ion-color-primary);\n}\n\n#container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n\n.container-detail-certificacion {\n  margin-bottom: 15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXGZvbGRlci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSwrQkFBQTtBQUNGOztBQUVBO0VBQ0Usa0JBQUE7RUFDQSxrQkFBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0EsUUFBQTtFQUNBLDJCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7QUFDRjs7QUFFQTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxTQUFBO0FBQ0Y7O0FBRUE7RUFDRSxxQkFBQTtBQUNGOztBQUNBO0VBQ0UsbUJBQUE7QUFFRiIsImZpbGUiOiJmb2xkZXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLW1lbnUtYnV0dG9uIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbn1cblxuI2NvbnRhaW5lciB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBsZWZ0OiAwO1xuICByaWdodDogMDtcbiAgdG9wOiA1MCU7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtNTAlKTtcbn1cblxuI2NvbnRhaW5lciBzdHJvbmcge1xuICBmb250LXNpemU6IDIwcHg7XG4gIGxpbmUtaGVpZ2h0OiAyNnB4O1xufVxuXG4jY29udGFpbmVyIHAge1xuICBmb250LXNpemU6IDE2cHg7XG4gIGxpbmUtaGVpZ2h0OiAyMnB4O1xuICBjb2xvcjogIzhjOGM4YztcbiAgbWFyZ2luOiAwO1xufVxuXG4jY29udGFpbmVyIGEge1xuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG59XG4uY29udGFpbmVyLWRldGFpbC1jZXJ0aWZpY2FjaW9ue1xuICBtYXJnaW4tYm90dG9tOiAxNXB4O1xufSJdfQ== */";
      /***/
    },

    /***/
    "QRE9":
    /*!*************************************************!*\
      !*** ./src/app/folder/folder-routing.module.ts ***!
      \*************************************************/

    /*! exports provided: FolderPageRoutingModule */

    /***/
    function QRE9(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "FolderPageRoutingModule", function () {
        return FolderPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "iInd");
      /* harmony import */


      var _folder_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./folder.page */
      "wlos");

      var routes = [{
        path: '',
        component: _folder_page__WEBPACK_IMPORTED_MODULE_3__["FolderPage"]
      }];

      var FolderPageRoutingModule = function FolderPageRoutingModule() {
        _classCallCheck(this, FolderPageRoutingModule);
      };

      FolderPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], FolderPageRoutingModule);
      /***/
    },

    /***/
    "s9za":
    /*!*******************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/folder/folder.page.html ***!
      \*******************************************************************************/

    /*! exports provided: default */

    /***/
    function s9za(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>{{ folder }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <form [formGroup]=\"ionicForm\" (ngSubmit)=\"enviarForm()\" #form=\"ngForm\">\n    <app-custom-input\n      label=\"nombre\"\n      name=\"nombre\"\n      type=\"text\"\n      [formGruop]=\"ionicForm\"\n      [form]=\"form\"\n      [Validations]=\"nombreValidation\"\n    ></app-custom-input>\n\n    <app-custom-input\n      label=\"e-mail\"\n      name=\"mail\"\n      type=\"text\"\n      [formGruop]=\"ionicForm\"\n      [form]=\"form\"\n      [Validations]=\"mailValidation\"\n      [brmasker]=\"{userCaracters: true, type:'text', len:40}\"\n      defaultValue=\"mail@outlool.com\"\n    ></app-custom-input>\n\n    <app-custom-input\n      label=\"fecha de nacimiento\"\n      name=\"fechaNacimiento\"\n      type=\"datetime\"\n      [formGruop]=\"ionicForm\"\n      [form]=\"form\"\n      (_ionChange)=\"getDate($event)\"\n      [defaultValue]=\"defaultDate\"\n    ></app-custom-input>\n\n    <app-custom-input\n      label=\"telefono celular\"\n      name=\"celular\"\n      type=\"text\"\n      [formGruop]=\"ionicForm\"\n      [form]=\"form\"\n      [Validations]=\"celularValidation\"\n      [brmasker]=\"{mask: '00000000', type:'num', len:8}\"\n    ></app-custom-input>\n\n    <ion-row>\n      <ion-col>\n        <ion-button type=\"submit\" color=\"danger\" expand=\"block\"\n          >Submit</ion-button\n        >\n      </ion-col>\n    </ion-row>\n  </form>\n</ion-content>\n";
      /***/
    },

    /***/
    "wlos":
    /*!***************************************!*\
      !*** ./src/app/folder/folder.page.ts ***!
      \***************************************/

    /*! exports provided: FolderPage */

    /***/
    function wlos(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "FolderPage", function () {
        return FolderPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_folder_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./folder.page.html */
      "s9za");
      /* harmony import */


      var _folder_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./folder.page.scss */
      "FJ2Q");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/router */
      "iInd");
      /* harmony import */


      var _services_database_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../services/database.service */
      "ZJFI");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var _interfaces_cross_ui_ValidationControl__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../interfaces/cross-ui/ValidationControl */
      "ya7+");
      /* harmony import */


      var _interfaces_Test_data_test__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ../interfaces/Test/data-test */
      "+nqB");
      /* harmony import */


      var _interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! ../interfaces/cross-ui/ConvertFormToObject */
      "GeA3");

      var FolderPage = /*#__PURE__*/function () {
        function FolderPage(activatedRoute, databaseService, formBuilder) {
          _classCallCheck(this, FolderPage);

          this.activatedRoute = activatedRoute;
          this.databaseService = databaseService;
          this.formBuilder = formBuilder;
          this.defaultDate = "1987-07-30";
          this.nombreValidation = [new _interfaces_cross_ui_ValidationControl__WEBPACK_IMPORTED_MODULE_7__["ValidationControl"](_angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].required, "El nombre es requerido"), new _interfaces_cross_ui_ValidationControl__WEBPACK_IMPORTED_MODULE_7__["ValidationControl"](_angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].minLength(2), "El nombre debe tener al menos dos caracteres")];
          this.mailValidation = [new _interfaces_cross_ui_ValidationControl__WEBPACK_IMPORTED_MODULE_7__["ValidationControl"](_angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].required, "El e-mail es requerido"), new _interfaces_cross_ui_ValidationControl__WEBPACK_IMPORTED_MODULE_7__["ValidationControl"](_angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$'), "El mail no tiene el formato correcto")];
          this.celularValidation = [new _interfaces_cross_ui_ValidationControl__WEBPACK_IMPORTED_MODULE_7__["ValidationControl"](_angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].required, "El celular es requerido"), new _interfaces_cross_ui_ValidationControl__WEBPACK_IMPORTED_MODULE_7__["ValidationControl"](_angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].pattern('^[0-9]+$'), "El celular no tiene el formato correcto")];
          this.data = {
            name: '',
            mail: ''
          };
        }

        _createClass(FolderPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.folder = this.activatedRoute.snapshot.paramMap.get("id");
            this.databaseService.testDB();
            this.ionicForm = this.formBuilder.group({});
          }
        }, {
          key: "enviarForm",
          value: function enviarForm() {
            if (!this.ionicForm.valid) {
              console.log('datos invalidos!');
              return false;
            } else {
              console.log(this.ionicForm.value);
              var dataTest = new _interfaces_Test_data_test__WEBPACK_IMPORTED_MODULE_8__["DataTest"]();

              _interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_9__["ConvertFormToObject"].convert(this.ionicForm, dataTest);

              console.log(dataTest);
            }
          }
        }, {
          key: "getDate",
          value: function getDate(e) {
            console.log("se llamo la funcion de cambio", e);
          }
        }, {
          key: "errorControl",
          get: function get() {
            return this.ionicForm.controls;
          }
        }]);

        return FolderPage;
      }();

      FolderPage.ctorParameters = function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"]
        }, {
          type: _services_database_service__WEBPACK_IMPORTED_MODULE_5__["DatabaseService"]
        }, {
          type: _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormBuilder"]
        }];
      };

      FolderPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: "app-folder",
        template: _raw_loader_folder_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_folder_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], FolderPage);
      /***/
    },

    /***/
    "yIOV":
    /*!*****************************************!*\
      !*** ./src/app/folder/folder.module.ts ***!
      \*****************************************/

    /*! exports provided: FolderPageModule */

    /***/
    function yIOV(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "FolderPageModule", function () {
        return FolderPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "SVse");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "sZkV");
      /* harmony import */


      var _folder_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./folder-routing.module */
      "QRE9");
      /* harmony import */


      var _folder_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./folder.page */
      "wlos");
      /* harmony import */


      var _components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../components/components.module */
      "j1ZV");
      /* harmony import */


      var br_mask__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! br-mask */
      "mzEM");

      var FolderPageModule = function FolderPageModule() {
        _classCallCheck(this, FolderPageModule);
      };

      FolderPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _folder_routing_module__WEBPACK_IMPORTED_MODULE_5__["FolderPageRoutingModule"], _components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"], br_mask__WEBPACK_IMPORTED_MODULE_8__["BrMaskerModule"]],
        declarations: [_folder_page__WEBPACK_IMPORTED_MODULE_6__["FolderPage"]]
      })], FolderPageModule);
      /***/
    },

    /***/
    "ya7+":
    /*!**********************************************************!*\
      !*** ./src/app/interfaces/cross-ui/ValidationControl.ts ***!
      \**********************************************************/

    /*! exports provided: ValidationControl */

    /***/
    function ya7(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ValidationControl", function () {
        return ValidationControl;
      });

      var ValidationControl = function ValidationControl(_validator, _message) {
        _classCallCheck(this, ValidationControl);

        this.validator = _validator;
        this.message = _message;
      };
      /***/

    }
  }]);
})();
//# sourceMappingURL=folder-folder-module-es5.js.map