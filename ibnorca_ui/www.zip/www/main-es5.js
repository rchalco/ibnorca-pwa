(function () {
  function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

  function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

  function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

  function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

  function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

  function _possibleConstructorReturn(self, call) { if (call && (typeof call === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

  function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

  function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

  function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"], {
    /***/
    "/AVN":
    /*!*************************************************************************!*\
      !*** ./src/app/components/ela-cronograma/ela-cronograma.component.scss ***!
      \*************************************************************************/

    /*! exports provided: default */

    /***/
    function AVN(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".container-product {\n  width: 80%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxlbGEtY3Jvbm9ncmFtYS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFVBQUE7QUFDSiIsImZpbGUiOiJlbGEtY3Jvbm9ncmFtYS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXItcHJvZHVjdHtcclxuICAgIHdpZHRoOiA4MCU7XHJcbn1cclxuIl19 */";
      /***/
    },

    /***/
    "/BRC":
    /*!*************************************************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/tcs-lista-verificacion-reunion-cierre/tcs-lista-verificacion-reunion-cierre.component.html ***!
      \*************************************************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function BRC(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<app-custom-header\r\n  title=\"TCS-LISTA DE VERIFICACION DE CIERRE\"\r\n  icon_name=\"list\"\r\n></app-custom-header>\r\n<ion-content>\r\n \r\n  <ion-list>\r\n    <ion-item>\r\n      <ion-label><strong>Todo</strong></ion-label>\r\n      <ion-checkbox slot=\"end\" \r\n      [(ngModel)]=\"masterCheck\"\r\n      [indeterminate]=\"isIndeterminate\"\r\n        (click)=\"checkMaster($event)\"></ion-checkbox>\r\n    </ion-item>\r\n  </ion-list>\r\n  <ion-list>\r\n    <ion-item *ngFor=\"let item of pParamitemselect\">\r\n      <ion-label class=\"ion-text-wrap\"> {{item.itemSelect}}</ion-label>\r\n      <ion-checkbox slot=\"end\" \r\n      [(ngModel)]=\"item.isChecked\" \r\n      (ionChange)=\"checkEvent()\"></ion-checkbox>\r\n    </ion-item>\r\n  </ion-list>\r\n\r\n</ion-content>";
      /***/
    },

    /***/
    "/GCU":
    /*!*****************************************************************************!*\
      !*** ./src/app/components/ela-plan-muestreo/ela-plan-muestreo.component.ts ***!
      \*****************************************************************************/

    /*! exports provided: ElaPlanMuestreoComponent */

    /***/
    function GCU(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ElaPlanMuestreoComponent", function () {
        return ElaPlanMuestreoComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_ela_plan_muestreo_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./ela-plan-muestreo.component.html */
      "5p1h");
      /* harmony import */


      var _ela_plan_muestreo_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./ela-plan-muestreo.component.scss */
      "b6b0");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var src_app_interfaces_elaboracion_auditoria_PlanAuditoriaDTO__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! src/app/interfaces/elaboracion_auditoria/PlanAuditoriaDTO */
      "6GDD");

      var ElaPlanMuestreoComponent = /*#__PURE__*/function () {
        function ElaPlanMuestreoComponent() {
          _classCallCheck(this, ElaPlanMuestreoComponent);

          this.listaContenido = [];
          this.nemotico = "";
          this.titulo = "";
          this.currentContenido = new src_app_interfaces_elaboracion_auditoria_PlanAuditoriaDTO__WEBPACK_IMPORTED_MODULE_4__["Elacontenidoauditorium"]();
          this.guardarPlanMuestreo = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        }

        _createClass(ElaPlanMuestreoComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this = this;

            this.currentContenido = this.listaContenido.find(function (x) {
              return x.nemotico === _this.nemotico;
            });
            console.log(this.listaContenido);
          }
        }, {
          key: "guardarMuestreo",
          value: function guardarMuestreo() {
            var _this2 = this;

            this.listaContenido.map(function (obj) {
              return _this2.listaContenido.find(function (o) {
                return o.nemotico === _this2.currentContenido.nemotico;
              }) || obj;
            });
            console.log("ingresa a guardar muestreo");

            if (this.guardarPlanMuestreo) {
              this.guardarPlanMuestreo.emit(this.listaContenido);
            }
          }
        }]);

        return ElaPlanMuestreoComponent;
      }();

      ElaPlanMuestreoComponent.ctorParameters = function () {
        return [];
      };

      ElaPlanMuestreoComponent.propDecorators = {
        listaContenido: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        nemotico: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        titulo: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        guardarPlanMuestreo: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }]
      };
      ElaPlanMuestreoComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-ela-plan-muestreo',
        template: _raw_loader_ela_plan_muestreo_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_ela_plan_muestreo_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], ElaPlanMuestreoComponent);
      /***/
    },

    /***/
    "/h6z":
    /*!***************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/plan-auditoria/plan-auditoria.component.html ***!
      \***************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function h6z(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = " <ion-card *ngIf=\"currentPlanAuditoriaDTO &&\r\n    currentPlanAuditoriaDTO.cliente\">\r\n    <ion-card-header color=\"primary\">\r\n        <ion-card-subtitle>ID CLIENTE:\r\n            {{ currentPlanAuditoriaDTO.cliente[\"idCliente\"] }}</ion-card-subtitle>\r\n        <ion-item color=\"primary\">\r\n            <ion-icon color=\"light\" name=\"server-outline\" slot=\"start\"></ion-icon>\r\n            <ion-label>CLIENTE:\r\n                {{ currentPlanAuditoriaDTO.cliente[\"nombreRazon\"] }}</ion-label>\r\n        </ion-item>\r\n    </ion-card-header>\r\n    <ion-card-content class=\"ion-content-small-font\">\r\n        <ion-row>\r\n            <ion-col size=\"6\" size-lg=\"6\" size-md=\"6\" size-sm=\"12\"\r\n                size-xs=\"12\">\r\n                <ion-card mode=\"ios\">\r\n                    <ion-item color=\"medium\" color=\"title-small\">\r\n                        <ion-icon name=\"person\" slot=\"start\"></ion-icon>\r\n                        <ion-label>DATOS DE DESIGNACION</ion-label>\r\n                    </ion-item>\r\n                    <ion-card-content class=\"ion-content-small-font\">\r\n                        <ion-list>\r\n                            <ion-item class=\"ion-no-padding small-item\">\r\n                                Código del servicio:\r\n                                <ion-label>\r\n                                    {{currentPlanAuditoriaDTO.designacion.codigoServicio}}\r\n                                </ion-label>\r\n                            </ion-item>\r\n                            <ion-item class=\"ion-no-padding small-item\">\r\n                                Tipo de Auditoría:\r\n                                <ion-label>\r\n                                    {{currentPlanAuditoriaDTO.designacion.tipoAuditroria}}\r\n                                </ion-label>\r\n                            </ion-item>\r\n                            <ion-item class=\"ion-no-padding small-item\">\r\n                                Fecha de Auditoría:\r\n                                <ion-label>\r\n                                    {{currentPlanAuditoriaDTO.designacion.fechaAuditoria}}\r\n                                </ion-label>\r\n                            </ion-item>\r\n                        </ion-list>\r\n                    </ion-card-content>\r\n                </ion-card>\r\n            </ion-col>\r\n            <ion-col size=\"6\" size-lg=\"6\" size-md=\"6\"\r\n                size-sm=\"12\" size-xs=\"12\">\r\n                <app-ciclo-participante allowEdit=\"false\"\r\n                    *ngIf=\"currentPlanAuditoriaDTO\"\r\n                    [currentPracicloparticipantes]=\"currentPlanAuditoriaDTO.pracicloparticipante\"></app-ciclo-participante>\r\n            </ion-col>\r\n        </ion-row>\r\n\r\n        <app-tcp-list-products\r\n            [productList]=\"currentPlanAuditoriaDTO.pradireccionespaproducto\"\r\n            [addCronograma]=\"true\" [allowDelete]=\"false\"\r\n            *ngIf=\"mode === 'TCP'\"\r\n            [listaParticipantes]=\"listaParticipantes\"\r\n            (guardarCronogramaEmitter)=\"guardarCronograma($event)\"\r\n            (eliminarCronogramaEmitter)=\"eliminarCronograma($event)\"></app-tcp-list-products>\r\n        <app-tcs-list-systems\r\n            [direccionesSistema]=\"currentPlanAuditoriaDTO.pradireccionespasistema\"\r\n            [normasSistema]=\"currentPlanAuditoriaDTO.praciclonormassistema\"\r\n            [nombreOrganizacion]=\"currentPlanAuditoriaDTO.nombreClienteCertificado\"\r\n            *ngIf=\"mode === 'TCS'\" [allowHorario]=\"true\"\r\n            [addCronograma]=\"true\" [allowDelete]=\"false\"\r\n            [isAuditor]=\"true\"\r\n            [listaParticipantes]=\"listaParticipantes\"\r\n            (guardarCronogramaEmitter)=\"guardarCronograma($event)\"\r\n            (eliminarCronogramaEmitter)=\"eliminarCronograma($event)\"></app-tcs-list-systems>\r\n    </ion-card-content>\r\n</ion-card>\r\n";
      /***/
    },

    /***/
    0:
    /*!***************************!*\
      !*** multi ./src/main.ts ***!
      \***************************/

    /*! no static exports found */

    /***/
    function _(module, exports, __webpack_require__) {
      module.exports = __webpack_require__(
      /*! D:\BckDell  15 5500\e\PROYECTOS\ibnorca\ibnorca-pwa\ibnorca-pwa\ibnorca_ui\src\main.ts */
      "zUnb");
      /***/
    },

    /***/
    "0xoF":
    /*!***********************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/buscar-norma/buscar-norma.component.html ***!
      \***********************************************************************************************************/

    /*! exports provided: default */

    /***/
    function xoF(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header translucent>\n  <ion-toolbar>\n    <ion-radio-group [(ngModel)]=\"tipoNorma\">\n      <ion-item>\n        <ion-label>Nacional</ion-label>\n        <ion-radio slot=\"start\" color=\"success\" value=\"nacional\"></ion-radio>\n      </ion-item>\n      <ion-item>\n        <ion-label>Internacional</ion-label>\n        <ion-radio slot=\"start\" color=\"success\" value=\"internacional\"></ion-radio>\n      </ion-item>\n    </ion-radio-group>\n    <ion-searchbar\n      placeholder=\"Código de Norma\"\n      animated=\"true\"\n      (ionChange)=\"buscar($event)\"\n    ></ion-searchbar>\n  </ion-toolbar>  \n</ion-header>\n<ion-list>\n  <ion-item>\n    <ion-select\n      interface=\"alert\"\n      placeholder=\"Norma\"\n      class=\"cargo-select\"\n      okText=\"Ok\"\n      cancelText=\"Cancelar\"\n      (ionChange)=\"seleccionarNorma($event)\"\n      [value]=\"currentNorma\"\n    >\n      <ion-select-option\n        *ngFor=\"let norma of listaNormas\"\n        [value]=\"norma\"\n        class=\"cargo-select\"\n        >{{ norma.codigoNorma }} - {{ norma.nombreNorma }}\n      </ion-select-option>\n    </ion-select>\n  </ion-item>\n</ion-list>\n";
      /***/
    },

    /***/
    "1JxX":
    /*!***********************************************************************!*\
      !*** ./src/app/components/custom-header/custom-header.component.scss ***!
      \***********************************************************************/

    /*! exports provided: default */

    /***/
    function JxX(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjdXN0b20taGVhZGVyLmNvbXBvbmVudC5zY3NzIn0= */";
      /***/
    },

    /***/
    "1iny":
    /*!***********************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/param-paises/param-paises.component.html ***!
      \***********************************************************************************************************/

    /*! exports provided: default */

    /***/
    function iny(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header translucent>\r\n  <ion-toolbar>\r\n    <ion-searchbar\r\n      placeholder=\"Código de País\"\r\n      animated=\"true\"\r\n      (ionChange)=\"buscarPais($event)\"\r\n      [value] = \"defaulValue\"\r\n    ></ion-searchbar>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-list>\r\n  <ion-item>\r\n    <ion-select\r\n      interface=\"alert\"\r\n      placeholder=\"Pais\"\r\n      class=\"cargo-select\"\r\n      okText=\"Ok\"\r\n      cancelText=\"Cancelar\"\r\n      (ionChange)=\"seleccionarPais($event)\"\r\n      [value]=\"currentPais\"\r\n    >\r\n      <ion-select-option\r\n        *ngFor=\"let norma of listaPaises\"\r\n        [value]=\"norma\"\r\n        class=\"cargo-select\"\r\n        >{{ norma.idPais }} - {{ norma.paisNombre }}\r\n      </ion-select-option>\r\n    </ion-select>\r\n  </ion-item>\r\n\r\n  <ion-item>\r\n    <ion-select\r\n      interface=\"alert\"\r\n      placeholder=\"Estados - Departamentos\"\r\n      class=\"cargo-select\"\r\n      okText=\"Ok\"\r\n      cancelText=\"Cancelar\"\r\n      (ionChange)=\"seleccionarEstado($event)\"\r\n      [value]=\"currentEstado\"\r\n    >\r\n      <ion-select-option\r\n        *ngFor=\"let norma of listaEstados\"\r\n        [value]=\"norma\"\r\n        class=\"cargo-select\"\r\n        >{{ norma.idEstado }} - {{ norma.estNombre }}\r\n      </ion-select-option>\r\n    </ion-select>\r\n  </ion-item>\r\n  <ion-item>\r\n    <ion-select\r\n      interface=\"alert\"\r\n      placeholder=\"Ciudad\"\r\n      class=\"cargo-select\"\r\n      okText=\"Ok\"\r\n      cancelText=\"Cancelar\"\r\n      (ionChange)=\"seleccionarCiudad($event)\"\r\n      [value]=\"currentCiudad\"\r\n    >\r\n      <ion-select-option\r\n        *ngFor=\"let norma of listaCiudades\"\r\n        [value]=\"norma\"\r\n        class=\"cargo-select\"\r\n        >{{ norma.idCiudad }} - {{ norma.nomCiudad }}\r\n      </ion-select-option>\r\n    </ion-select>\r\n  </ion-item>\r\n\r\n</ion-list>\r\n";
      /***/
    },

    /***/
    "23o3":
    /*!*****************************************************************************!*\
      !*** ./src/app/components/tcs-list-systems/tcs-list-systems.component.scss ***!
      \*****************************************************************************/

    /*! exports provided: default */

    /***/
    function o3(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".normas {\n  font-size: 12px;\n  color: #1b192c;\n}\n\n.title-normas {\n  color: #0b480f;\n  font-size: 1em;\n  text-align: left;\n}\n\n.norma-block {\n  background-color: #c6e8e6;\n  padding: 10px;\n  margin: 1.5px;\n  min-width: 100%;\n}\n\n.big-icon {\n  font-size: 1.2em;\n  margin-left: 3px;\n  cursor: -webkit-grab;\n  cursor: grab;\n}\n\n.detail-paragraph {\n  font-size: 11px;\n  color: #3d3c44;\n}\n\n.sub-title {\n  /*font-style: italic;*/\n  font-size: 13px;\n  color: #055a0f;\n  font-family: sans-serif;\n}\n\n.direccion-block {\n  background-color: #c1ebd6;\n  padding: 10px;\n  margin: 1.5px;\n  min-width: 100%;\n}\n\n.horario-block {\n  background-color: #1c1118;\n  padding: 20px;\n  margin: 0.5px;\n  min-width: 100%;\n}\n\n.horario-block p {\n  color: #c6e8e6;\n}\n\n.titles {\n  font-style: italic;\n  font-weight: 300;\n  font-size: 18px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFx0Y3MtbGlzdC1zeXN0ZW1zLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZUFBQTtFQUNBLGNBQUE7QUFDRjs7QUFDQTtFQUNFLGNBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7QUFFRjs7QUFBQTtFQUNFLHlCQUFBO0VBQ0EsYUFBQTtFQUNBLGFBQUE7RUFDQSxlQUFBO0FBR0Y7O0FBREE7RUFDRSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0Esb0JBQUE7RUFBQSxZQUFBO0FBSUY7O0FBRkE7RUFDRSxlQUFBO0VBQ0EsY0FBQTtBQUtGOztBQUhBO0VBQ0Usc0JBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLHVCQUFBO0FBTUY7O0FBSkE7RUFDRSx5QkFBQTtFQUNBLGFBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtBQU9GOztBQUxBO0VBQ0UseUJBQUE7RUFDQSxhQUFBO0VBQ0EsYUFBQTtFQUNBLGVBQUE7QUFRRjs7QUFOQTtFQUNFLGNBQUE7QUFTRjs7QUFQQTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBVUYiLCJmaWxlIjoidGNzLWxpc3Qtc3lzdGVtcy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5ub3JtYXMge1xyXG4gIGZvbnQtc2l6ZTogMTJweDtcclxuICBjb2xvcjogIzFiMTkyYztcclxufVxyXG4udGl0bGUtbm9ybWFzIHtcclxuICBjb2xvcjogIzBiNDgwZjtcclxuICBmb250LXNpemU6IDFlbTtcclxuICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG59XHJcbi5ub3JtYS1ibG9jayB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2M2ZThlNjtcclxuICBwYWRkaW5nOiAxMHB4O1xyXG4gIG1hcmdpbjogMS41cHg7XHJcbiAgbWluLXdpZHRoOiAxMDAlO1xyXG59XHJcbi5iaWctaWNvbiB7XHJcbiAgZm9udC1zaXplOiAxLjJlbTtcclxuICBtYXJnaW4tbGVmdDogM3B4O1xyXG4gIGN1cnNvcjogZ3JhYjtcclxufVxyXG4uZGV0YWlsLXBhcmFncmFwaCB7XHJcbiAgZm9udC1zaXplOiAxMXB4O1xyXG4gIGNvbG9yOiAjM2QzYzQ0O1xyXG59XHJcbi5zdWItdGl0bGUge1xyXG4gIC8qZm9udC1zdHlsZTogaXRhbGljOyovXHJcbiAgZm9udC1zaXplOiAxM3B4O1xyXG4gIGNvbG9yOiAjMDU1YTBmO1xyXG4gIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xyXG59XHJcbi5kaXJlY2Npb24tYmxvY2sge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNjMWViZDY7XHJcbiAgcGFkZGluZzogMTBweDtcclxuICBtYXJnaW46IDEuNXB4O1xyXG4gIG1pbi13aWR0aDogMTAwJTtcclxufVxyXG4uaG9yYXJpby1ibG9jayB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzFjMTExODtcclxuICBwYWRkaW5nOiAyMHB4O1xyXG4gIG1hcmdpbjogMC41cHg7XHJcbiAgbWluLXdpZHRoOiAxMDAlO1xyXG59XHJcbi5ob3JhcmlvLWJsb2NrIHB7XHJcbiAgY29sb3I6ICNjNmU4ZTY7XHJcbn1cclxuLnRpdGxlcyB7XHJcbiAgZm9udC1zdHlsZTogaXRhbGljO1xyXG4gIGZvbnQtd2VpZ2h0OiAzMDA7XHJcbiAgZm9udC1zaXplOiAxOHB4O1xyXG59XHJcbiJdfQ== */";
      /***/
    },

    /***/
    "2BO+":
    /*!*****************************************************************************************************!*\
      !*** ./src/app/components/ela-registro-areapreocupacion/ela-registro-areapreocupacion.component.ts ***!
      \*****************************************************************************************************/

    /*! exports provided: ElaRegistroAreapreocupacionComponent */

    /***/
    function BO(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ElaRegistroAreapreocupacionComponent", function () {
        return ElaRegistroAreapreocupacionComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_ela_registro_areapreocupacion_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./ela-registro-areapreocupacion.component.html */
      "LK1H");
      /* harmony import */


      var _ela_registro_areapreocupacion_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./ela-registro-areapreocupacion.component.scss */
      "g5wf");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var src_app_interfaces_elaboracion_auditoria_PlanAuditoriaDTO__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! src/app/interfaces/elaboracion_auditoria/PlanAuditoriaDTO */
      "6GDD");

      var ElaRegistroAreapreocupacionComponent = /*#__PURE__*/function () {
        function ElaRegistroAreapreocupacionComponent() {
          _classCallCheck(this, ElaRegistroAreapreocupacionComponent);

          this.guardarAdpEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
          this.mode = "LIST";
          this.operacion = "";
          this.currentIndex = -1;
        }

        _createClass(ElaRegistroAreapreocupacionComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            if (!this.listaAdp) {
              this.listaAdp = new Array();
            }
          }
        }, {
          key: "eliminarAdp",
          value: function eliminarAdp(i) {
            this.listaAdp.splice(i, 1);

            if (this.guardarAdpEmitter) {
              this.guardarAdpEmitter.emit(this.listaAdp);
            }
          }
        }, {
          key: "editarAdp",
          value: function editarAdp(i) {
            this.mode = "EDIT";
            this.operacion = "UPD";
            console.log("Guardar Adp", this.listaAdp[i]);
            this.currentAdp = this.listaAdp[i];
            this.currentIndex = i;
          }
        }, {
          key: "adicionarAdp",
          value: function adicionarAdp() {
            this.mode = "EDIT";
            this.operacion = "ADD";
            this.currentAdp = new src_app_interfaces_elaboracion_auditoria_PlanAuditoriaDTO__WEBPACK_IMPORTED_MODULE_4__["Elaadp"]();
          }
        }, {
          key: "guardarAreaDePreocupacion",
          value: function guardarAreaDePreocupacion(event) {
            this.mode = "LIST";
            if (this.operacion === "UPD") this.listaAdp[this.currentIndex] = event;else this.listaAdp.push(event);

            if (this.guardarAdpEmitter) {
              this.guardarAdpEmitter.emit(this.listaAdp);
            }
          }
        }, {
          key: "cancelarAreaDePreocupacion",
          value: function cancelarAreaDePreocupacion() {
            this.mode = "LIST";
          }
        }]);

        return ElaRegistroAreapreocupacionComponent;
      }();

      ElaRegistroAreapreocupacionComponent.ctorParameters = function () {
        return [];
      };

      ElaRegistroAreapreocupacionComponent.propDecorators = {
        listaAdp: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        guardarAdpEmitter: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }]
      };
      ElaRegistroAreapreocupacionComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: "app-ela-registro-areapreocupacion",
        template: _raw_loader_ela_registro_areapreocupacion_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_ela_registro_areapreocupacion_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], ElaRegistroAreapreocupacionComponent);
      /***/
    },

    /***/
    "2TV0":
    /*!***********************************************************************************************!*\
      !*** ./src/app/components/ela-edit-areapreocupacion/ela-edit-areapreocupacion.component.scss ***!
      \***********************************************************************************************/

    /*! exports provided: default */

    /***/
    function TV0(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlbGEtZWRpdC1hcmVhcHJlb2N1cGFjaW9uLmNvbXBvbmVudC5zY3NzIn0= */";
      /***/
    },

    /***/
    "2nKn":
    /*!*************************************************************************!*\
      !*** ./src/app/components/tm-acta-reunion/tm-acta-reunion.component.ts ***!
      \*************************************************************************/

    /*! exports provided: TmActaReunionComponent */

    /***/
    function nKn(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "TmActaReunionComponent", function () {
        return TmActaReunionComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_tm_acta_reunion_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./tm-acta-reunion.component.html */
      "qvR5");
      /* harmony import */


      var _tm_acta_reunion_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./tm-acta-reunion.component.scss */
      "kSin");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/common */
      "SVse");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");

      var TmActaReunionComponent = /*#__PURE__*/function () {
        function TmActaReunionComponent(datepipe, formBuilder) {
          _classCallCheck(this, TmActaReunionComponent);

          this.datepipe = datepipe;
          this.formBuilder = formBuilder;
          this.consideracion = "";
          this.revison = "";
          this.varios = "";
          this.fecha = this.datepipe.transform(new Date(), "dd/MM/yyyy");
          this.reglamentos = [{
            nombre: "Reglamento particular de Cemento",
            norma_base: "ASTM C 150",
            descripcion: "xxxxxxxxxxxxxxxxxxxxxxxx xxxxxxxxxxxxx xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
            decision: "Aprobado"
          }, {
            nombre: "Reglamento particular de Cemento",
            norma_base: "ASTM C 150",
            descripcion: "xxxxxxxxxxxxxxxxxxxxxxxx xxxxxxxxxxxxx xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
            decision: "Aprobado"
          }, {
            nombre: "Reglamento particular de Cemento",
            norma_base: "ASTM C 150",
            descripcion: "xxxxxxxxxxxxxxxxxxxxxxxx xxxxxxxxxxxxx xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
            decision: "Aprobado"
          }];
          this.productos = [{
            proceso: "RENOVACIÓN ",
            empresa: "113 A",
            producto: "Agua de mesa no carbonatada (sin gas) marca 1  ",
            norma: "NB 325002:2004",
            desc_revision: "ZZZZZZZZZZZZZZZZZZZZZZZZ ZZZZZZZZZZZ",
            confirmacion: "SI",
            recomendacion: "Positiva/Negativa/Pendiente"
          }, {
            proceso: "RENOVACIÓN ",
            empresa: "113 A",
            producto: "Agua de mesa no carbonatada (sin gas) marca 1  ",
            norma: "NB 325002:2004",
            desc_revision: "ZZZZZZZZZZZZZZZZZZZZZZZZ ZZZZZZZZZZZ",
            confirmacion: "SI",
            recomendacion: "Positiva/Negativa/Pendiente"
          }, {
            proceso: "RENOVACIÓN ",
            empresa: "113 A",
            producto: "Agua de mesa no carbonatada (sin gas) marca 1  ",
            norma: "NB 325002:2004",
            desc_revision: "ZZZZZZZZZZZZZZZZZZZZZZZZ ZZZZZZZZZZZ",
            confirmacion: "SI",
            recomendacion: "Positiva/Negativa/Pendiente"
          }];
          this.lConsideracione = ["Se realizó la lectura del acta anterior para considerar los temas pendientes en la reunión del día de hoy", "No se tienen pendientes de la reunión anterior."];
          this.lRevision = ["N/A", "Se realizó la revisión y la toma de decisión respecto a los siguientes reglamentos particulares:"];
          this.lVarios = ["N/A", "Describir los criterios y comentarios más importantes, vertidos a cerca de otros temas de interés del Área de Certificación de Producto, por los miembros del CONCER y/o auditores"];
        }

        _createClass(TmActaReunionComponent, [{
          key: "seleccionarConsideraciones",
          value: function seleccionarConsideraciones(event) {
            this.consideracion = event.detail.value;
          }
        }, {
          key: "seleccionarRevision",
          value: function seleccionarRevision(event) {
            this.revison = event.detail.value;
          }
        }, {
          key: "seleccionarVarios",
          value: function seleccionarVarios(event) {
            this.varios = event.detail.value;
          }
        }, {
          key: "ngOnInit",
          value: function ngOnInit() {
            this.ionicForm = this.formBuilder.group({});
          }
        }]);

        return TmActaReunionComponent;
      }();

      TmActaReunionComponent.ctorParameters = function () {
        return [{
          type: _angular_common__WEBPACK_IMPORTED_MODULE_3__["DatePipe"]
        }, {
          type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"]
        }];
      };

      TmActaReunionComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: "app-tm-acta-reunion",
        template: _raw_loader_tm_acta_reunion_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_tm_acta_reunion_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], TmActaReunionComponent);
      /***/
    },

    /***/
    "34tN":
    /*!*********************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/meses/meses.component.html ***!
      \*********************************************************************************************/

    /*! exports provided: default */

    /***/
    function tN(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-list>\n  <ion-item\n    *ngFor=\"let item of items; let i = index;\"\n    (click)=\"selectMes(item.value)\"\n    detail=\"true\"\n  >\n    <ion-label>{{item.label}}</ion-label>\n  </ion-item>\n</ion-list>";
      /***/
    },

    /***/
    "3Xjl":
    /*!*************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/ela-cronograma-list/ela-cronograma-list.component.html ***!
      \*************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function Xjl(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-list *ngIf=\"mode === 'LIST'\">\n  <ion-list-header lines=\"full\">\n    <ion-item>\n      <ion-icon\n        name=\"add-circle\"\n        slot=\"start\"\n        (click)=\"addCronograma()\"\n        class=\"big-icon\"></ion-icon>\n      <ion-text color=\"secondary\"> Cronograma </ion-text>\n    </ion-item>\n  </ion-list-header>\n  <ion-item *ngFor=\"let cronograma of listCronograma; let i= index\">\n    <ion-icon\n      name=\"pencil-sharp\"\n      slot=\"start\"\n      (click)=\"editarCronograma(i)\"\n      class=\"big-icon\"></ion-icon>\n    <ion-icon\n      name=\"trash\"\n      slot=\"start\"\n      (click)=\"eliminarCronograma(i)\"\n      class=\"big-icon\"></ion-icon>\n    <div class=\"row-cronogama\">\n      Fecha:\n      <span class=\"sub-title-horario\">{{ cronograma.fechaInicio }}</span> |\n      Hora: <span class=\"sub-title-horario\">{{ cronograma.horario }}</span>\n      <br />\n      Requisito:\n      <span class=\"paragraph-horario\">{{ cronograma.requisitosEsquema }}</span>\n      Responsable:\n      <span class=\"paragraph-horario\">{{\n        cronograma.personaEntrevistadaCargo\n        }}</span>\n      Proceso:\n      <span class=\"paragraph-horario\">{{ cronograma.procesoArea }}</span>\n      Equipo:\n      <span class=\"paragraph-horario\">{{ cronograma.auditor }}</span>\n      Direccion:\n      <span class=\"paragraph-horario\">{{ cronograma.direccion }}</span>\n    </div>\n  </ion-item>\n</ion-list>\n<app-ela-cronograma\n  *ngIf=\"mode === 'EDIT'\"\n  [currentElacronogama]=\"currentCrongrama\"\n  [listaParticipantes]=\"listaParticipantes\"\n  [listaDirecciones]=\"listaDirecciones\"\n  (guardarCronogramaEmitter)=\"guardarCronograma($event)\"\n  (cancelarCronogramaEmitter)=\"cancelarCronograma()\"></app-ela-cronograma>\n";
      /***/
    },

    /***/
    "4JdM":
    /*!*********************************************************************************!*\
      !*** ./src/app/components/ciclo-participante/ciclo-participante.component.scss ***!
      \*********************************************************************************/

    /*! exports provided: default */

    /***/
    function JdM(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".label-cronograma {\n  font-weight: bold;\n  font-size: 12px;\n}\n\n.data-cronograma {\n  font-style: italic;\n  font-size: 13px;\n}\n\n.ion-content-small-font {\n  font-family: \"Calibri Light\";\n  font-size: 12px;\n  color: #093537;\n}\n\n.title-medium-font {\n  font-family: \"Courier New\";\n  font-weight: bold;\n}\n\nion-card-content {\n  text-align: left;\n}\n\n.box-click {\n  min-width: 100px;\n  min-height: 20px;\n  border-bottom: solid;\n  border-color: #778e8f;\n  border-width: 1px;\n  padding: 2px;\n  margin-left: 3px;\n  display: inline-block;\n}\n\n.edit-item {\n  cursor: -webkit-grab;\n  cursor: grab;\n}\n\n.edit-item:hover {\n  background-color: #9dd8dc;\n}\n\n.item-cronograma {\n  display: block;\n  margin-bottom: 4px;\n}\n\n.big-icon {\n  font-size: 1.2em;\n  margin-left: 3px;\n  cursor: -webkit-grab;\n  cursor: grab;\n}\n\n.bigger-icon {\n  font-size: 2em;\n  margin-left: 3px;\n  cursor: -webkit-grab;\n  cursor: grab;\n}\n\n.cargo-select {\n  width: 100%;\n  font-size: 13px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjaWNsby1wYXJ0aWNpcGFudGUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxpQkFBQTtFQUNBLGVBQUE7QUFDRjs7QUFDQTtFQUNFLGtCQUFBO0VBQ0EsZUFBQTtBQUVGOztBQUFBO0VBQ0UsNEJBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtBQUdGOztBQURBO0VBQ0UsMEJBQUE7RUFDQSxpQkFBQTtBQUlGOztBQUZBO0VBQ0UsZ0JBQUE7QUFLRjs7QUFIQTtFQUNFLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxvQkFBQTtFQUNBLHFCQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxxQkFBQTtBQU1GOztBQUpBO0VBQ0Usb0JBQUE7RUFBQSxZQUFBO0FBT0Y7O0FBTEE7RUFDRSx5QkFBQTtBQVFGOztBQU5BO0VBQ0UsY0FBQTtFQUNBLGtCQUFBO0FBU0Y7O0FBUEE7RUFDRSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0Esb0JBQUE7RUFBQSxZQUFBO0FBVUY7O0FBUkE7RUFDRSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxvQkFBQTtFQUFBLFlBQUE7QUFXRjs7QUFUQTtFQUNJLFdBQUE7RUFDQSxlQUFBO0FBWUoiLCJmaWxlIjoiY2ljbG8tcGFydGljaXBhbnRlLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmxhYmVsLWNyb25vZ3JhbWEge1xyXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gIGZvbnQtc2l6ZTogMTJweDtcclxufVxyXG4uZGF0YS1jcm9ub2dyYW1hIHtcclxuICBmb250LXN0eWxlOiBpdGFsaWM7XHJcbiAgZm9udC1zaXplOiAxM3B4O1xyXG59XHJcbi5pb24tY29udGVudC1zbWFsbC1mb250IHtcclxuICBmb250LWZhbWlseTogXCJDYWxpYnJpIExpZ2h0XCI7XHJcbiAgZm9udC1zaXplOiAxMnB4O1xyXG4gIGNvbG9yOiAjMDkzNTM3O1xyXG59XHJcbi50aXRsZS1tZWRpdW0tZm9udCB7XHJcbiAgZm9udC1mYW1pbHk6IFwiQ291cmllciBOZXdcIjtcclxuICBmb250LXdlaWdodDogYm9sZDtcclxufVxyXG5pb24tY2FyZC1jb250ZW50IHtcclxuICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG59XHJcbi5ib3gtY2xpY2sge1xyXG4gIG1pbi13aWR0aDogMTAwcHg7XHJcbiAgbWluLWhlaWdodDogMjBweDtcclxuICBib3JkZXItYm90dG9tOiBzb2xpZDtcclxuICBib3JkZXItY29sb3I6ICM3NzhlOGY7XHJcbiAgYm9yZGVyLXdpZHRoOiAxcHg7XHJcbiAgcGFkZGluZzogMnB4O1xyXG4gIG1hcmdpbi1sZWZ0OiAzcHg7XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG59XHJcbi5lZGl0LWl0ZW0ge1xyXG4gIGN1cnNvcjogZ3JhYjtcclxufVxyXG4uZWRpdC1pdGVtOmhvdmVyIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjOWRkOGRjO1xyXG59XHJcbi5pdGVtLWNyb25vZ3JhbWEge1xyXG4gIGRpc3BsYXk6IGJsb2NrO1xyXG4gIG1hcmdpbi1ib3R0b206IDRweDtcclxufVxyXG4uYmlnLWljb24ge1xyXG4gIGZvbnQtc2l6ZTogMS4yZW07XHJcbiAgbWFyZ2luLWxlZnQ6IDNweDtcclxuICBjdXJzb3I6IGdyYWI7XHJcbn1cclxuLmJpZ2dlci1pY29uIHtcclxuICBmb250LXNpemU6IDJlbTtcclxuICBtYXJnaW4tbGVmdDogM3B4O1xyXG4gIGN1cnNvcjogZ3JhYjtcclxufVxyXG4uY2FyZ28tc2VsZWN0e1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBmb250LXNpemU6IDEzcHg7XHJcbn0iXX0= */";
      /***/
    },

    /***/
    "4RPC":
    /*!***************************************************************************!*\
      !*** ./src/app/components/tcs-list-systems/tcs-list-systems.component.ts ***!
      \***************************************************************************/

    /*! exports provided: TcsListSystemsComponent */

    /***/
    function RPC(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "TcsListSystemsComponent", function () {
        return TcsListSystemsComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_tcs_list_systems_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./tcs-list-systems.component.html */
      "75Lq");
      /* harmony import */


      var _tcs_list_systems_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./tcs-list-systems.component.scss */
      "23o3");
      /* harmony import */


      var _interfaces_apertura_auditoria_Praprogramasdeauditorium__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./../../interfaces/apertura_auditoria/Praprogramasdeauditorium */
      "Z1IW");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/angular */
      "sZkV");

      var TcsListSystemsComponent = /*#__PURE__*/function () {
        function TcsListSystemsComponent(popoverController, formBuilder) {
          _classCallCheck(this, TcsListSystemsComponent);

          this.popoverController = popoverController;
          this.formBuilder = formBuilder;
          this.mode = "list";
          this.currentIndex = -1;
          this.currentIndexNorma = -1; //currentDireccion: Pradireccionespasistema;

          this.operacion = "";
          this.direccionesSistema = [];
          this.normasSistema = [];
          this.allowHorario = false;
          this.allowDelete = true;
          this.isAuditor = false;
          this.guardarCronogramaEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"]();
          this.eliminarCronogramaEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"]();
          this.addCronograma = false;
          this.display = false;
        }

        _createClass(TcsListSystemsComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.ionicForm = this.formBuilder.group({});
          }
        }, {
          key: "toggle",
          value: function toggle() {
            console.log("se expande");
            this.display = !this.display;
          }
        }, {
          key: "guardarDireccion",
          value: function guardarDireccion(event) {
            this.mode = "list";
            console.log("guardar direccion");
            if (this.operacion === "UPD") this.direccionesSistema[this.currentIndex] = event;else this.direccionesSistema.push(event);
          }
        }, {
          key: "cancelarDireccion",
          value: function cancelarDireccion(event) {
            this.mode = "list";
          }
        }, {
          key: "editarDireccion",
          value: function editarDireccion(item, i) {
            console.log("item", item);
            this.mode = "EDIT";
            this.operacion = "UPD";
            this.currentdireccionesSistema = item;
            this.currentIndex = i;
          }
        }, {
          key: "editarHorario",
          value: function editarHorario(item, i) {
            this.mode = "EDIT_HORARIO";
            this.operacion = "UPD";
          }
        }, {
          key: "eliminarDireccion",
          value: function eliminarDireccion(index) {
            console.log("evento eliminar", index);
            this.direccionesSistema.splice(index, 1);
          }
        }, {
          key: "adicionarDireccion",
          value: function adicionarDireccion() {
            this.mode = "EDIT";
            this.operacion = "ADD";
            this.currentdireccionesSistema = new _interfaces_apertura_auditoria_Praprogramasdeauditorium__WEBPACK_IMPORTED_MODULE_3__["Pradireccionespasistema"]();
            this.currentdireccionesSistema.pais = "Bolivia";
          }
        }, {
          key: "adicionarNorma",
          value: function adicionarNorma() {
            this.mode = "EDIT1";
            this.operacion = "ADD";
            this.currentnormaSistema = new _interfaces_apertura_auditoria_Praprogramasdeauditorium__WEBPACK_IMPORTED_MODULE_3__["Praciclonormassistema"](); //this.currentnormaSistema.pais = "Bolivia";
          }
        }, {
          key: "editarNorma",
          value: function editarNorma(item, i) {
            console.log("editar norma", item);
            this.mode = "EDIT1";
            this.operacion = "UPD";
            this.currentnormaSistema = item;
            this.currentIndexNorma = i;
          }
        }, {
          key: "cancelarNorma",
          value: function cancelarNorma(event) {
            this.mode = "list";
          }
        }, {
          key: "guardarNorma",
          value: function guardarNorma(event) {
            this.mode = "list";
            console.log("guardar norma");
            if (this.operacion === "UPD") this.normasSistema[this.currentIndex] = event;else this.normasSistema.push(event);
          }
        }, {
          key: "eliminarNorma",
          value: function eliminarNorma(index) {
            console.log("evento eliminar norma", index);
            this.normasSistema.splice(index, 1);
          }
        }, {
          key: "cancelarCronograma",
          value: function cancelarCronograma(event) {
            this.mode = "list";
          }
        }, {
          key: "guardarCronograma",
          value: function guardarCronograma(event) {
            this.mode = "list";

            if (this.guardarCronogramaEmitter) {
              this.guardarCronogramaEmitter.emit(event);
            }
          }
        }, {
          key: "eliminarCronograma",
          value: function eliminarCronograma(event) {
            if (this.eliminarCronogramaEmitter) {
              this.eliminarCronogramaEmitter.emit(event);
            }
          }
        }, {
          key: "getLlaves",
          value: function getLlaves(sistema) {
            var llave = {
              idDireccionPaproducto: null,
              idDireccionPasistema: sistema.idDireccionPasistema
            };
            return llave;
          }
        }]);

        return TcsListSystemsComponent;
      }();

      TcsListSystemsComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["PopoverController"]
        }, {
          type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"]
        }];
      };

      TcsListSystemsComponent.propDecorators = {
        nombreOrganizacion: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"]
        }],
        direccionesSistema: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"]
        }],
        normasSistema: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"]
        }],
        allowHorario: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"]
        }],
        allowDelete: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"]
        }],
        isAuditor: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"]
        }],
        listaParticipantes: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"]
        }],
        guardarCronogramaEmitter: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Output"]
        }],
        eliminarCronogramaEmitter: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Output"]
        }],
        addCronograma: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"]
        }]
      };
      TcsListSystemsComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: "app-tcs-list-systems",
        template: _raw_loader_tcs_list_systems_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_tcs_list_systems_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], TcsListSystemsComponent);
      /***/
    },

    /***/
    "4qXw":
    /*!***********************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/ciclo-participante/ciclo-participante.component.html ***!
      \***********************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function qXw(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-content>\r\n  <ion-card mode=\"ios\">\r\n    <ion-item color=\"medium\" color=\"title-small\">\r\n      <ion-icon name=\"people\" slot=\"start\"></ion-icon>\r\n      <ion-label>PARTICIPANTES</ion-label>\r\n      <ion-icon\r\n        name=\"add-circle\"\r\n        slot=\"start\"\r\n        (click)=\"adicionarParticipante()\"\r\n        *ngIf=\"allowEdit === true\"\r\n        class=\"bigger-icon\"\r\n      ></ion-icon>\r\n    </ion-item>\r\n    <ion-card-content\r\n      class=\"ion-content-small-font\"\r\n      *ngIf=\"visibleAdd === 'NO'\"\r\n    >\r\n      <ion-row>\r\n        <ion-col size=\"4\">Cargo</ion-col>\r\n        <ion-col size=\"6\">Personal</ion-col>\r\n        <ion-col size=\"1\">Situ</ion-col>\r\n        <ion-col size=\"1\">Rem</ion-col>\r\n      </ion-row>\r\n      <ion-row *ngFor=\"let item of currentPracicloparticipantes; let i = index\">\r\n        <ion-col size=\"4\">\r\n          <ion-label>\r\n            <ion-icon\r\n              name=\"pencil-sharp\"\r\n              slot=\"start\"\r\n              (click)=\"editar(item, i)\"\r\n              class=\"big-icon\"\r\n              *ngIf=\"allowEdit === true\"\r\n            ></ion-icon>\r\n            <ion-icon\r\n              name=\"trash\"\r\n              slot=\"start\"\r\n              (click)=\"eliminar(i)\"\r\n              class=\"big-icon\"\r\n              *ngIf=\"allowEdit === true\"\r\n            ></ion-icon>\r\n            {{ item._cargo.cargoPuesto }}\r\n          </ion-label>\r\n        </ion-col>\r\n        <ion-col size=\"6\">\r\n          <ion-label *ngIf=\"item._personal\">\r\n            {{ item._personal.nombreCompleto }}\r\n          </ion-label>\r\n        </ion-col>\r\n        <ion-col size=\"1\">\r\n          <ion-label *ngIf=\"item._personal\">\r\n            {{ item.diasInsistu }}\r\n          </ion-label>\r\n        </ion-col>\r\n        <ion-col size=\"1\">\r\n          <ion-label *ngIf=\"item._personal\">\r\n            {{ item.diasRemoto }}\r\n          </ion-label>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-card-content>\r\n\r\n    <ion-card-content\r\n      class=\"ion-content-small-font\"\r\n      *ngIf=\"visibleAdd === 'SI' && allowEdit === true\"\r\n    >\r\n      <ion-list>\r\n        <ion-item>\r\n          <ion-icon\r\n            name=\"arrow-undo\"\r\n            class=\"big-icon\"\r\n            (click)=\"cancelar()\"\r\n          ></ion-icon>\r\n        </ion-item>\r\n        <ion-item>\r\n          <ion-select\r\n            interface=\"alert\"\r\n            placeholder=\"Cargo\"\r\n            class=\"cargo-select\"\r\n            okText=\"Ok\"\r\n            cancelText=\"Cancelar\"\r\n            (ionChange)=\"ObtenerPersonalXCargos($event)\"\r\n            [value]=\"selectParticipante._cargo\"\r\n          >\r\n            <ion-select-option\r\n              *ngFor=\"let cargo of ListaCargoItem\"\r\n              [value]=\"cargo\"\r\n              class=\"cargo-select\"\r\n              >{{ cargo.cargoPuesto }}</ion-select-option\r\n            >\r\n          </ion-select>\r\n        </ion-item>\r\n        <ion-item>\r\n          <ion-label position=\"fixed\">Dias Insitu</ion-label>\r\n          <ion-input\r\n            type=\"number\"\r\n            placeholder=\"0\"\r\n            [(ngModel)]=\"selectParticipante.diasInsistu\"\r\n            name=\"cantidadDias\"\r\n          ></ion-input>\r\n        </ion-item>\r\n        <ion-item>\r\n          <ion-label position=\"fixed\">Dias Remoto</ion-label>\r\n          <ion-input\r\n            type=\"number\"\r\n            placeholder=\"0\"\r\n            [(ngModel)]=\"selectParticipante.diasRemoto\"\r\n            name=\"cantidadDias\"\r\n          ></ion-input>\r\n        </ion-item>\r\n        <ion-item>\r\n          <ion-select\r\n            interface=\"alert\"\r\n            placeholder=\"Personal\"\r\n            class=\"cargo-select\"\r\n            okText=\"Ok\"\r\n            cancelText=\"Cancelar\"\r\n            (ionChange)=\"seleccionarPersonal($event)\"\r\n            [value]=\"selectParticipante._personal\"\r\n          >\r\n            <ion-select-option\r\n              *ngFor=\"let personal of ListaPersonal\"\r\n              [value]=\"personal\"\r\n              class=\"cargo-select\"\r\n              >{{ personal.nombreCompleto }}</ion-select-option\r\n            >\r\n          </ion-select>\r\n        </ion-item>\r\n      </ion-list>\r\n    </ion-card-content>\r\n  </ion-card>\r\n</ion-content>\r\n";
      /***/
    },

    /***/
    "5e0s":
    /*!*****************************************************************************!*\
      !*** ./src/app/components/editor-documento/editor-documento.component.scss ***!
      \*****************************************************************************/

    /*! exports provided: default */

    /***/
    function e0s(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlZGl0b3ItZG9jdW1lbnRvLmNvbXBvbmVudC5zY3NzIn0= */";
      /***/
    },

    /***/
    "5j7N":
    /*!*******************************************************************************!*\
      !*** ./src/app/components/ciclo-participante/ciclo-participante.component.ts ***!
      \*******************************************************************************/

    /*! exports provided: CicloParticipanteComponent */

    /***/
    function j7N(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CicloParticipanteComponent", function () {
        return CicloParticipanteComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_ciclo_participante_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./ciclo-participante.component.html */
      "4qXw");
      /* harmony import */


      var _ciclo_participante_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./ciclo-participante.component.scss */
      "4JdM");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var src_app_interfaces_apertura_auditoria_Praprogramasdeauditorium__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! src/app/interfaces/apertura_auditoria/Praprogramasdeauditorium */
      "Z1IW");
      /* harmony import */


      var src_app_services_apertura_auditoria_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! src/app/services/apertura-auditoria.service */
      "Aoky");

      var CicloParticipanteComponent = /*#__PURE__*/function () {
        function CicloParticipanteComponent(aperturaAuditoriaService) {
          _classCallCheck(this, CicloParticipanteComponent);

          this.aperturaAuditoriaService = aperturaAuditoriaService;
          this.allowEdit = true;
          this.visibleAdd = "NO";
          this.operacion = "";
          this.currentIndex = 0;
        }

        _createClass(CicloParticipanteComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.selectParticipante = new src_app_interfaces_apertura_auditoria_Praprogramasdeauditorium__WEBPACK_IMPORTED_MODULE_4__["Pracicloparticipante"]();
            this.ObtenerCargos();
          }
        }, {
          key: "adicionarParticipante",
          value: function adicionarParticipante() {
            this.visibleAdd = "SI";
            this.operacion = "ADD";
            this.selectParticipante = new src_app_interfaces_apertura_auditoria_Praprogramasdeauditorium__WEBPACK_IMPORTED_MODULE_4__["Pracicloparticipante"]();
          }
        }, {
          key: "editar",
          value: function editar(item, index) {
            var _this3 = this;

            this.currentIndex = index;
            this.selectParticipante = item;
            this.selectParticipante._cargo = this.ListaCargoItem.filter(function (x) {
              return x.idCargoPuesto === _this3.selectParticipante._cargo.idCargoPuesto;
            })[0];
            this.ObtenerPersonalXIdCargos(this.selectParticipante._cargo.idCargoPuesto);
            this.visibleAdd = "SI";
            this.operacion = "UPD";
          }
        }, {
          key: "eliminar",
          value: function eliminar(index) {
            console.log("item eliminado");
            this.operacion = "DEL";
            this.currentPracicloparticipantes.splice(index, 1);
          }
        }, {
          key: "ObtenerCargos",
          value: function ObtenerCargos() {
            var _this4 = this;

            this.aperturaAuditoriaService.ObtenerCargos().subscribe(function (resul) {
              _this4.ListaCargoItem = resul.listEntities;
            });
          }
        }, {
          key: "ObtenerPersonalXCargos",
          value: function ObtenerPersonalXCargos(event) {
            var _this5 = this;

            var IdCargo = event.detail.value.idCargoPuesto;
            this.selectParticipante._cargo = event.detail.value;
            this.aperturaAuditoriaService.ObtenerParticipanteXCargos(IdCargo).subscribe(function (resul) {
              _this5.ListaPersonal = resul.listEntities;
            });
          }
        }, {
          key: "ObtenerPersonalXIdCargos",
          value: function ObtenerPersonalXIdCargos(idCargo) {
            var _this6 = this;

            this.aperturaAuditoriaService.ObtenerParticipanteXCargos(idCargo).subscribe(function (resul) {
              _this6.ListaPersonal = resul.listEntities;
            });
          }
        }, {
          key: "ObtenerPersonalXIdCargo",
          value: function ObtenerPersonalXIdCargo(IdCargo) {
            var _this7 = this;

            this.aperturaAuditoriaService.ObtenerParticipanteXCargos(IdCargo).subscribe(function (resul) {
              _this7.ListaPersonal = resul.listEntities;
            });
          }
        }, {
          key: "seleccionarPersonal",
          value: function seleccionarPersonal(event) {
            this.selectParticipante._personal = event.detail.value;
            this.selectParticipante.cargoDetalleWs = JSON.stringify(this.selectParticipante._cargo);
            this.selectParticipante.idCargoWs = Number(this.selectParticipante._cargo.idCargoPuesto);
            this.selectParticipante.idParticipanteWs = Number(this.selectParticipante._personal.idCliente);
            this.selectParticipante.participanteDetalleWs = JSON.stringify(this.selectParticipante._personal);
            this.visibleAdd = "NO";
            console.log(this.selectParticipante);

            if (this.operacion == "UPD") {
              this.currentPracicloparticipantes[this.currentIndex] = this.selectParticipante;
            }

            if (this.operacion == "ADD") {
              this.currentPracicloparticipantes.push(this.selectParticipante);
            }
          }
        }, {
          key: "cancelar",
          value: function cancelar() {
            this.visibleAdd = "NO";
          }
        }]);

        return CicloParticipanteComponent;
      }();

      CicloParticipanteComponent.ctorParameters = function () {
        return [{
          type: src_app_services_apertura_auditoria_service__WEBPACK_IMPORTED_MODULE_5__["AperturaAuditoriaService"]
        }];
      };

      CicloParticipanteComponent.propDecorators = {
        currentPracicloparticipantes: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        allowEdit: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }]
      };
      CicloParticipanteComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: "app-ciclo-participante",
        template: _raw_loader_ciclo_participante_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_ciclo_participante_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], CicloParticipanteComponent);
      /***/
    },

    /***/
    "5p1h":
    /*!*********************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/ela-plan-muestreo/ela-plan-muestreo.component.html ***!
      \*********************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function p1h(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-list>\n  <ion-item>\n    <ion-button\n      size=\"small\"\n      fill=\"outline\"\n      color=\"success\"\n      (click)=\"guardarMuestreo()\">\n      <ion-icon slot=\"start\" name=\"caret-up-outline\"></ion-icon>\n      Guardar\n    </ion-button>\n  </ion-item>\n  <ion-list-header lines=\"full\">\n    <ion-text color=\"primary\">\n      <h3>{{titulo}}</h3>\n    </ion-text>\n  </ion-list-header>\n  <ion-item>\n    <ion-textarea [(ngModel)]=\"currentContenido.contenido\" rows=\"15\"></ion-textarea>\n  </ion-item>\n</ion-list>";
      /***/
    },

    /***/
    "6DlI":
    /*!***********************************************************************!*\
      !*** ./src/app/components/pra-cronograma/pra-cronograma.component.ts ***!
      \***********************************************************************/

    /*! exports provided: PraCronogramaComponent */

    /***/
    function DlI(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PraCronogramaComponent", function () {
        return PraCronogramaComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_pra_cronograma_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./pra-cronograma.component.html */
      "q7BG");
      /* harmony import */


      var _pra_cronograma_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./pra-cronograma.component.scss */
      "grjr");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/common */
      "SVse");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/angular */
      "sZkV");
      /* harmony import */


      var _custom_input_custom_input_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../custom-input/custom-input.component */
      "P85u");
      /* harmony import */


      var _param_horarios_param_horarios_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ../param-horarios/param-horarios.component */
      "7UGa");

      var PraCronogramaComponent = /*#__PURE__*/function () {
        function PraCronogramaComponent(popoverController, datepipe, formBuilder) {
          _classCallCheck(this, PraCronogramaComponent);

          this.popoverController = popoverController;
          this.datepipe = datepipe;
          this.formBuilder = formBuilder;
        }

        _createClass(PraCronogramaComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.cronogramaForm = this.formBuilder.group({});
            console.log("currentPraciclocronogramas", this.currentPraciclocronogramas);
          }
        }, {
          key: "mostrarMesesProgramado",
          value: function mostrarMesesProgramado(event) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var popover, info;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.popoverController.create({
                        component: _custom_input_custom_input_component__WEBPACK_IMPORTED_MODULE_7__["CustomInputComponent"],
                        componentProps: {
                          formGruop: this.cronogramaForm,
                          label: "Mes Programado",
                          name: "FechaEjecucion",
                          type: "datetime",
                          form: "form",
                          formatDate: "MM/YYYY",
                          defaultValue: Date()
                        },
                        event: event,
                        mode: "ios",
                        backdropDismiss: false
                      });

                    case 2:
                      popover = _context.sent;
                      _context.next = 5;
                      return popover.present();

                    case 5:
                      _context.next = 7;
                      return popover.onDidDismiss();

                    case 7:
                      info = _context.sent;
                      console.log("Padre", info);
                      this.currentPraciclocronogramas.mesProgramado = info.data.item;

                    case 10:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "mostrarMesesReprogamado",
          value: function mostrarMesesReprogamado(event) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var popover, info;
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return this.popoverController.create({
                        component: _custom_input_custom_input_component__WEBPACK_IMPORTED_MODULE_7__["CustomInputComponent"],
                        componentProps: {
                          formGruop: this.cronogramaForm,
                          label: "Mes Reprogramado",
                          name: "FechaEjecucion",
                          type: "datetime",
                          form: "form",
                          formatDate: "MM/YYYY",
                          defaultValue: Date()
                        },
                        event: event,
                        mode: "ios",
                        backdropDismiss: false
                      });

                    case 2:
                      popover = _context2.sent;
                      _context2.next = 5;
                      return popover.present();

                    case 5:
                      _context2.next = 7;
                      return popover.onDidDismiss();

                    case 7:
                      info = _context2.sent;
                      console.log("Padre", info);
                      this.currentPraciclocronogramas.mesReprogramado = info.data.item;

                    case 10:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }, {
          key: "mostrarFechaEjecucion",
          value: function mostrarFechaEjecucion(event) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
              var popover, info;
              return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      _context3.next = 2;
                      return this.popoverController.create({
                        component: _custom_input_custom_input_component__WEBPACK_IMPORTED_MODULE_7__["CustomInputComponent"],
                        componentProps: {
                          formGruop: this.cronogramaForm,
                          label: "Fecha Eejcucion",
                          name: "FechaEjecucion",
                          type: "datetime",
                          form: "form",
                          defaultValue: Date()
                        },
                        event: event,
                        mode: "ios",
                        backdropDismiss: false
                      });

                    case 2:
                      popover = _context3.sent;
                      _context3.next = 5;
                      return popover.present();

                    case 5:
                      _context3.next = 7;
                      return popover.onDidDismiss();

                    case 7:
                      info = _context3.sent;
                      console.log("Padre", info);
                      this.currentPraciclocronogramas.fechaInicioDeEjecucionDeAuditoria = info.data.item;

                    case 10:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3, this);
            }));
          }
        }, {
          key: "mostrarFechaFin",
          value: function mostrarFechaFin(event) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
              var popover, info;
              return regeneratorRuntime.wrap(function _callee4$(_context4) {
                while (1) {
                  switch (_context4.prev = _context4.next) {
                    case 0:
                      _context4.next = 2;
                      return this.popoverController.create({
                        component: _custom_input_custom_input_component__WEBPACK_IMPORTED_MODULE_7__["CustomInputComponent"],
                        componentProps: {
                          formGruop: this.cronogramaForm,
                          label: "Fecha Fin Eejcucion",
                          name: "FechaEjecucion",
                          type: "datetime",
                          form: "form",
                          defaultValue: Date()
                        },
                        event: event,
                        mode: "ios",
                        backdropDismiss: false
                      });

                    case 2:
                      popover = _context4.sent;
                      _context4.next = 5;
                      return popover.present();

                    case 5:
                      _context4.next = 7;
                      return popover.onDidDismiss();

                    case 7:
                      info = _context4.sent;
                      console.log("Padre", info);
                      this.currentPraciclocronogramas.fechaDeFinDeEjecucionAuditoria = info.data.item;

                    case 10:
                    case "end":
                      return _context4.stop();
                  }
                }
              }, _callee4, this);
            }));
          }
        }, {
          key: "mostrarDiasInsituCronograma",
          value: function mostrarDiasInsituCronograma(event) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
              var popover, info;
              return regeneratorRuntime.wrap(function _callee5$(_context5) {
                while (1) {
                  switch (_context5.prev = _context5.next) {
                    case 0:
                      _context5.next = 2;
                      return this.popoverController.create({
                        component: _custom_input_custom_input_component__WEBPACK_IMPORTED_MODULE_7__["CustomInputComponent"],
                        componentProps: {
                          formGruop: this.cronogramaForm,
                          label: "CANTIDAD DE DIAS",
                          name: "cantidad_dias",
                          type: "number",
                          form: "form",
                          defaultValue: Date()
                        },
                        event: event,
                        mode: "ios",
                        backdropDismiss: false
                      });

                    case 2:
                      popover = _context5.sent;
                      _context5.next = 5;
                      return popover.present();

                    case 5:
                      _context5.next = 7;
                      return popover.onDidDismiss();

                    case 7:
                      info = _context5.sent;
                      console.log("Padre", info);
                      this.currentPraciclocronogramas.diasInsitu = info.data.item;

                    case 10:
                    case "end":
                      return _context5.stop();
                  }
                }
              }, _callee5, this);
            }));
          }
        }, {
          key: "mostrarDiasRemotoCronograma",
          value: function mostrarDiasRemotoCronograma(event) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
              var popover, info;
              return regeneratorRuntime.wrap(function _callee6$(_context6) {
                while (1) {
                  switch (_context6.prev = _context6.next) {
                    case 0:
                      _context6.next = 2;
                      return this.popoverController.create({
                        component: _custom_input_custom_input_component__WEBPACK_IMPORTED_MODULE_7__["CustomInputComponent"],
                        componentProps: {
                          formGruop: this.cronogramaForm,
                          label: "CANTIDAD DE DIAS",
                          name: "cantidad_dias",
                          type: "number",
                          form: "form",
                          defaultValue: Date()
                        },
                        event: event,
                        mode: "ios",
                        backdropDismiss: false
                      });

                    case 2:
                      popover = _context6.sent;
                      _context6.next = 5;
                      return popover.present();

                    case 5:
                      _context6.next = 7;
                      return popover.onDidDismiss();

                    case 7:
                      info = _context6.sent;
                      console.log("Padre", info);
                      this.currentPraciclocronogramas.diasRemoto = info.data.item;

                    case 10:
                    case "end":
                      return _context6.stop();
                  }
                }
              }, _callee6, this);
            }));
          }
        }, {
          key: "mostrarHorarioCronograma",
          value: function mostrarHorarioCronograma(event) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
              var popover, info;
              return regeneratorRuntime.wrap(function _callee7$(_context7) {
                while (1) {
                  switch (_context7.prev = _context7.next) {
                    case 0:
                      _context7.next = 2;
                      return this.popoverController.create({
                        component: _param_horarios_param_horarios_component__WEBPACK_IMPORTED_MODULE_8__["ParamHorariosComponent"],
                        componentProps: {
                          horario: this.currentPraciclocronogramas.horarioTrabajo
                        },
                        event: event,
                        mode: "ios",
                        backdropDismiss: false
                      });

                    case 2:
                      popover = _context7.sent;
                      _context7.next = 5;
                      return popover.present();

                    case 5:
                      _context7.next = 7;
                      return popover.onDidDismiss();

                    case 7:
                      info = _context7.sent;
                      console.log("Padre", info);
                      this.currentPraciclocronogramas.horarioTrabajo = info.data.item;

                    case 10:
                    case "end":
                      return _context7.stop();
                  }
                }
              }, _callee7, this);
            }));
          }
        }]);

        return PraCronogramaComponent;
      }();

      PraCronogramaComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["PopoverController"]
        }, {
          type: _angular_common__WEBPACK_IMPORTED_MODULE_3__["DatePipe"]
        }, {
          type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"]
        }];
      };

      PraCronogramaComponent.propDecorators = {
        currentPraciclocronogramas: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"]
        }]
      };
      PraCronogramaComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: "app-pra-cronograma",
        template: _raw_loader_pra_cronograma_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_pra_cronograma_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], PraCronogramaComponent);
      /***/
    },

    /***/
    "6GDD":
    /*!**********************************************************************!*\
      !*** ./src/app/interfaces/elaboracion_auditoria/PlanAuditoriaDTO.ts ***!
      \**********************************************************************/

    /*! exports provided: PlanAuditoriaDTO, Designacion, Elaauditorium, Elaadp, Elacontenidoauditorium, Elahallazgo, Elacronogama */

    /***/
    function GDD(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PlanAuditoriaDTO", function () {
        return PlanAuditoriaDTO;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Designacion", function () {
        return Designacion;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Elaauditorium", function () {
        return Elaauditorium;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Elaadp", function () {
        return Elaadp;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Elacontenidoauditorium", function () {
        return Elacontenidoauditorium;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Elahallazgo", function () {
        return Elahallazgo;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Elacronogama", function () {
        return Elacronogama;
      });

      var PlanAuditoriaDTO = function PlanAuditoriaDTO() {
        _classCallCheck(this, PlanAuditoriaDTO);
      };

      var Designacion = function Designacion() {
        _classCallCheck(this, Designacion);
      };

      var Elaauditorium = function Elaauditorium() {
        _classCallCheck(this, Elaauditorium);
      };

      var Elaadp = function Elaadp() {
        _classCallCheck(this, Elaadp);
      };

      var Elacontenidoauditorium = function Elacontenidoauditorium() {
        _classCallCheck(this, Elacontenidoauditorium);
      };

      var Elahallazgo = function Elahallazgo() {
        _classCallCheck(this, Elahallazgo);
      };

      var Elacronogama = function Elacronogama() {
        _classCallCheck(this, Elacronogama);
      };
      /***/

    },

    /***/
    "6V/C":
    /*!***********************************************************!*\
      !*** ./src/app/services/elaboracion-auditoria.service.ts ***!
      \***********************************************************/

    /*! exports provided: ElaboracionAuditoriaService */

    /***/
    function VC(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ElaboracionAuditoriaService", function () {
        return ElaboracionAuditoriaService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/common/http */
      "IheW");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @ionic/angular */
      "sZkV");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! rxjs */
      "qCKp");
      /* harmony import */


      var rxjs_internal_operators_finalize__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! rxjs/internal/operators/finalize */
      "44p1");
      /* harmony import */


      var rxjs_internal_operators_finalize__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(rxjs_internal_operators_finalize__WEBPACK_IMPORTED_MODULE_5__);
      /* harmony import */


      var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! rxjs/operators */
      "kU1M");
      /* harmony import */


      var src_environments_environment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! src/environments/environment */
      "AytR");
      /* harmony import */


      var _interfaces_seguridad_usuario__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ../interfaces/seguridad/usuario */
      "PI2N");
      /* harmony import */


      var _baseService__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! ./baseService */
      "zrJw");
      /* harmony import */


      var _database_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! ./database.service */
      "ZJFI");

      var headers = src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["HEADERS_SERVICE"];
      var url_elaboracion = src_environments_environment__WEBPACK_IMPORTED_MODULE_7__["URL_ELABORACION"];

      var ElaboracionAuditoriaService = /*#__PURE__*/function (_baseService__WEBPACK) {
        _inherits(ElaboracionAuditoriaService, _baseService__WEBPACK);

        var _super = _createSuper(ElaboracionAuditoriaService);

        function ElaboracionAuditoriaService(databaseService, httpClient, loadingController, toastController) {
          var _this8;

          _classCallCheck(this, ElaboracionAuditoriaService);

          _this8 = _super.call(this, databaseService, httpClient, loadingController, toastController);
          _this8.databaseService = databaseService;
          _this8.httpClient = httpClient;
          _this8.loadingController = loadingController;
          _this8.toastController = toastController;
          return _this8;
        }

        _createClass(ElaboracionAuditoriaService, [{
          key: "ObtenerCiclosPorIdAuditor",
          value: function ObtenerCiclosPorIdAuditor(IdAuditor) {
            var _this9 = this;

            var url_query = url_elaboracion + "ObtenerCiclosPorIdAuditor";
            var dataRequest = {
              IdAuditor: IdAuditor
            };
            this.presentLoader();
            return this.httpClient.post(url_query, JSON.stringify(dataRequest), {
              headers: headers
            }).pipe(Object(rxjs_internal_operators_finalize__WEBPACK_IMPORTED_MODULE_5__["finalize"])(function () {
              console.log("**se termino la llamada ObtenerCiclosPorIdAuditor");

              _this9.dismissLoader();
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["catchError"])(function (error) {
              _this9.showMessageError("No se tiene comunicacion con el servidor");

              return rxjs__WEBPACK_IMPORTED_MODULE_4__["Observable"]["throw"](new Error(error.status));
            }));
          }
        }, {
          key: "ObtenerPlanAuditoria",
          value: function ObtenerPlanAuditoria(IdCicloPrograma) {
            var _this10 = this;

            var url_query = url_elaboracion + "ObtenerPlanAuditoria";
            var dataRequest = {
              IdCicloPrograma: IdCicloPrograma,
              usuario: _interfaces_seguridad_usuario__WEBPACK_IMPORTED_MODULE_8__["usuario"].currentUser.nick
            };
            this.presentLoader();
            return this.httpClient.post(url_query, JSON.stringify(dataRequest), {
              headers: headers
            }).pipe(Object(rxjs_internal_operators_finalize__WEBPACK_IMPORTED_MODULE_5__["finalize"])(function () {
              console.log("**se termino la llamada ObtenerCiclosPorIdAuditor");

              _this10.dismissLoader();
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["catchError"])(function (error) {
              _this10.showMessageError("No se tiene comunicacion con el servidor");

              return rxjs__WEBPACK_IMPORTED_MODULE_4__["Observable"]["throw"](new Error(error.status));
            }));
          }
        }, {
          key: "RegistrarPlanAuditoria",
          value: function RegistrarPlanAuditoria(planAuditoriaDTO) {
            var _this11 = this;

            var url_query = url_elaboracion + "RegistrarPlanAuditoria";
            var dataRequest = planAuditoriaDTO;
            this.presentLoader();
            return this.httpClient.post(url_query, JSON.stringify(dataRequest), {
              headers: headers
            }).pipe(Object(rxjs_internal_operators_finalize__WEBPACK_IMPORTED_MODULE_5__["finalize"])(function () {
              console.log("**se termino la llamada RegistrarPlanAuditoria");

              _this11.dismissLoader();
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["catchError"])(function (error) {
              _this11.showMessageError("No se tiene comunicacion con el servidor");

              return rxjs__WEBPACK_IMPORTED_MODULE_4__["Observable"]["throw"](new Error(error.status));
            }));
          }
        }, {
          key: "GetListasPredefinidas",
          value: function GetListasPredefinidas(area) {
            var _this12 = this;

            var url_query = url_elaboracion + "GetListasPredefinidas";
            var dataRequest = {
              area: area
            };
            this.presentLoader();
            return this.httpClient.post(url_query, JSON.stringify(dataRequest), {
              headers: headers
            }).pipe(Object(rxjs_internal_operators_finalize__WEBPACK_IMPORTED_MODULE_5__["finalize"])(function () {
              console.log("**se termino la llamada GetListasPredefinidas");

              _this12.dismissLoader();
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["catchError"])(function (error) {
              _this12.showMessageError("No se tiene comunicacion con el servidor");

              return rxjs__WEBPACK_IMPORTED_MODULE_4__["Observable"]["throw"](new Error(error.status));
            }));
          }
        }, {
          key: "GetListasVerificacion",
          value: function GetListasVerificacion(IdLista) {
            var url_query = url_elaboracion + "GetListasVerificacion";
            var dataRequest = {
              IdLista: IdLista
            };
            return this.httpClient.post(url_query, JSON.stringify(dataRequest), {
              headers: headers
            });
          }
        }, {
          key: "GetListasDocumetos",
          value: function GetListasDocumetos(area, proceso) {
            var url_query = url_elaboracion + "GetListasDocumetos";
            var dataRequest = {
              area: area,
              proceso: proceso
            };
            return this.httpClient.post(url_query, JSON.stringify(dataRequest), {
              headers: headers
            });
          }
        }]);

        return ElaboracionAuditoriaService;
      }(_baseService__WEBPACK_IMPORTED_MODULE_9__["BaseService"]);

      ElaboracionAuditoriaService.ctorParameters = function () {
        return [{
          type: _database_service__WEBPACK_IMPORTED_MODULE_10__["DatabaseService"]
        }, {
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"]
        }];
      };

      ElaboracionAuditoriaService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: "root"
      })], ElaboracionAuditoriaService);
      /***/
    },

    /***/
    "6vZm":
    /*!*************************************************************************!*\
      !*** ./src/app/components/registro-ciclo/registro-ciclo.component.scss ***!
      \*************************************************************************/

    /*! exports provided: default */

    /***/
    function vZm(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyZWdpc3Ryby1jaWNsby5jb21wb25lbnQuc2NzcyJ9 */";
      /***/
    },

    /***/
    "75Lq":
    /*!*******************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/tcs-list-systems/tcs-list-systems.component.html ***!
      \*******************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function Lq(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<div class=\"container-product-list\">\r\n  <ion-item color=\"medium\" color=\"title-small\" (click)=\"toggle()\">\r\n    <ion-icon name=\"menu\" slot=\"start\"></ion-icon>\r\n    <ion-label>ALCANCE / NORMAS / DIRECCIONES</ion-label>\r\n  </ion-item>\r\n  <div *ngIf=\"display\">\r\n    <ion-list *ngIf=\"mode === 'list'\">\r\n      <ion-item>\r\n        <ion-label position=\"stacked\">\r\n          Nombre del cliente para el Certificado\r\n        </ion-label>\r\n        <ion-textarea [(ngModel)]=\"nombreOrganizacion\"></ion-textarea>\r\n      </ion-item>\r\n      <ion-list-header class=\"title-normas\">\r\n        <ion-item>\r\n          <ion-icon name=\"add-circle\" slot=\"end\" (click)=\"adicionarNorma(item,\r\n            i)\" class=\"big-icon\"></ion-icon>\r\n          Normas y Alcances\r\n        </ion-item>\r\n      </ion-list-header>\r\n      <ion-item *ngFor=\"let norma of normasSistema; let i= index\">\r\n        <ion-icon name=\"pencil-sharp\" slot=\"start\" (click)=\"editarNorma(norma,\r\n          i)\" class=\"big-icon\"></ion-icon>\r\n        <ion-icon name=\"trash\" slot=\"start\" (click)=\"eliminarNorma(i)\"\r\n          class=\"big-icon\"></ion-icon>\r\n        <div class=\"norma-block\">\r\n          <h2>Norma: {{ norma.norma }}</h2>\r\n          <p>\r\n            Alcance: <span class=\"sub-title\">{{ norma.alcance }}</span>\r\n          </p>\r\n          <p class=\"detail-paragraph\">\r\n            Fecha Emision Cert. {{ norma.fechaEmisionPrimerCertificado }} |\r\n            Fecha Vencimiento Cert.\r\n            {{ norma.fechaVencimientoUltimoCertificado }} | Nro. Cert.\r\n            {{ norma.numeroDeCertificacion }}\r\n          </p>\r\n        </div>\r\n      </ion-item>\r\n      <ion-list-header class=\"title-normas\">\r\n        <ion-item>\r\n          <ion-icon name=\"add-circle\" slot=\"end\"\r\n            (click)=\"adicionarDireccion(item, i)\" class=\"big-icon\"></ion-icon>\r\n          Programación de direcciones\r\n        </ion-item>\r\n      </ion-list-header>\r\n      <ion-item *ngFor=\"let direccion of direccionesSistema; let i= index\">\r\n        <ion-icon name=\"pencil-sharp\" slot=\"start\"\r\n          (click)=\"editarDireccion(direccion, i)\" class=\"big-icon\"></ion-icon>\r\n        <ion-icon name=\"trash\" slot=\"start\" (click)=\"eliminarDireccion(i)\"\r\n          class=\"big-icon\" *ngIf=\"allowDelete\">\r\n        </ion-icon>\r\n        <div class=\"direccion-block\">\r\n          <!-- <h2>{{ direccion.nombre }} - Diás Insitu: {{ direccion.dias }}</h2> -->\r\n          <h2>Diás Insitu: {{ direccion.dias }}</h2>\r\n          <p>\r\n            Dirección:\r\n            <span class=\"sub-title\">{{ direccion.direccion }}</span>\r\n          </p>\r\n          <!-- <p class=\"detail-paragraph\">\r\n            Pais: {{ direccion.pais }} | Departamento:\r\n            {{ direccion.departamento }} | Ciudad: {{ direccion.ciudad }}\r\n          </p> -->\r\n        </div>\r\n      </ion-item>\r\n    </ion-list>\r\n    <app-pra-direccion-sistema *ngIf=\"mode === 'EDIT'\"\r\n      [pradireccionespasistema]=\"currentdireccionesSistema\"\r\n      (guardarDireccionEmitter)=\"guardarDireccion($event)\"\r\n      (cancelarDireccionEmitter)=\"cancelarDireccion($event)\">\r\n    </app-pra-direccion-sistema>\r\n    <app-pra-edit-norma-sistema *ngIf=\"mode === 'EDIT1'\"\r\n      [praciclonormassistema]=\"currentnormaSistema\"\r\n      (guardarNormaEmitter)=\"guardarNorma($event)\"\r\n      (cancelarNormaEmitter)=\"cancelarNorma($event)\">\r\n    </app-pra-edit-norma-sistema>\r\n  </div>\r\n</div>";
      /***/
    },

    /***/
    "7KC4":
    /*!*****************************************************************************************!*\
      !*** ./src/app/components/pra-edit-norma-sistema/pra-edit-norma-sistema.component.scss ***!
      \*****************************************************************************************/

    /*! exports provided: default */

    /***/
    function KC4(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwcmEtZWRpdC1ub3JtYS1zaXN0ZW1hLmNvbXBvbmVudC5zY3NzIn0= */";
      /***/
    },

    /***/
    "7UGa":
    /*!***********************************************************************!*\
      !*** ./src/app/components/param-horarios/param-horarios.component.ts ***!
      \***********************************************************************/

    /*! exports provided: ParamHorariosComponent */

    /***/
    function UGa(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ParamHorariosComponent", function () {
        return ParamHorariosComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_param_horarios_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./param-horarios.component.html */
      "kktw");
      /* harmony import */


      var _param_horarios_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./param-horarios.component.scss */
      "zMu+");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "sZkV");

      var ParamHorariosComponent = /*#__PURE__*/function () {
        function ParamHorariosComponent(popoverController) {
          _classCallCheck(this, ParamHorariosComponent);

          this.popoverController = popoverController;
          this.seleccionarHorarioEmit = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
          this.horarioIni = new Date();
          this.horarioFin = new Date();
        }

        _createClass(ParamHorariosComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            if (this.horario) {
              var horaIniAux = this.horario.substring(0, 5);
              var horaFinAux = this.horario.substring(5, 5);
              var time = horaIniAux.split(":");
              this.horarioIni.setHours(parseInt(time[0]));
              this.horarioIni.setMinutes(parseInt(time[1]));
              time = horaFinAux.split(":");
              this.horarioFin.setHours(parseInt(time[0]));
              this.horarioFin.setMinutes(parseInt(time[1]));
            }
          }
        }, {
          key: "selectionarHorarioIni",
          value: function selectionarHorarioIni(event) {
            console.log("hora ini", event);
            this.horarioIni = new Date(event.detail.value);
          }
        }, {
          key: "selectionarHorarioFin",
          value: function selectionarHorarioFin(event) {
            this.horarioFin = new Date(event.detail.value);
            console.log("horarioIni", this.horarioIni);
            console.log("horarioFin", this.horarioFin);
            var horarioFormat = this.pad(this.horarioIni.getHours(), 2) + ":" + this.pad(this.horarioIni.getMinutes(), 2) + "-" + this.pad(this.horarioFin.getHours(), 2) + ":" + this.pad(this.horarioFin.getMinutes(), 2);
            console.log("horario sleccionado", horarioFormat);

            if (this.seleccionarHorarioEmit) {
              this.seleccionarHorarioEmit.emit(horarioFormat);
            }

            if (this.popoverController) {
              this.popoverController.dismiss({
                item: horarioFormat
              });
            }
          }
        }, {
          key: "pad",
          value: function pad(num, size) {
            num = num.toString();

            while (num.length < size) {
              num = "0" + num;
            }

            return num;
          }
        }]);

        return ParamHorariosComponent;
      }();

      ParamHorariosComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["PopoverController"]
        }];
      };

      ParamHorariosComponent.propDecorators = {
        horario: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        seleccionarHorarioEmit: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }]
      };
      ParamHorariosComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: "app-param-horarios",
        template: _raw_loader_param_horarios_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_param_horarios_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], ParamHorariosComponent);
      /***/
    },

    /***/
    "8y1b":
    /*!*********************************************************************************************!*\
      !*** ./src/app/components/ela-edit-areapreocupacion/ela-edit-areapreocupacion.component.ts ***!
      \*********************************************************************************************/

    /*! exports provided: ElaEditAreapreocupacionComponent */

    /***/
    function y1b(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ElaEditAreapreocupacionComponent", function () {
        return ElaEditAreapreocupacionComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_ela_edit_areapreocupacion_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./ela-edit-areapreocupacion.component.html */
      "w90L");
      /* harmony import */


      var _ela_edit_areapreocupacion_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./ela-edit-areapreocupacion.component.scss */
      "2TV0");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/angular */
      "sZkV");
      /* harmony import */


      var src_app_interfaces_elaboracion_auditoria_PlanAuditoriaDTO__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! src/app/interfaces/elaboracion_auditoria/PlanAuditoriaDTO */
      "6GDD");
      /* harmony import */


      var src_app_interfaces_seguridad_usuario__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! src/app/interfaces/seguridad/usuario */
      "PI2N");
      /* harmony import */


      var _interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ../../interfaces/cross-ui/ConvertFormToObject */
      "GeA3");

      var ElaEditAreapreocupacionComponent = /*#__PURE__*/function () {
        function ElaEditAreapreocupacionComponent(toastController, formBuilder) {
          _classCallCheck(this, ElaEditAreapreocupacionComponent);

          this.toastController = toastController;
          this.formBuilder = formBuilder;
          this.guardarAdpEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
          this.cancelarAdpEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
          this.currentAdp = new src_app_interfaces_elaboracion_auditoria_PlanAuditoriaDTO__WEBPACK_IMPORTED_MODULE_6__["Elaadp"]();
        }

        _createClass(ElaEditAreapreocupacionComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.ionicFormAdp = this.formBuilder.group({});
          }
        }, {
          key: "cancelarAreaDePreocupacion",
          value: function cancelarAreaDePreocupacion() {
            if (this.cancelarAdpEmitter) {
              this.cancelarAdpEmitter.emit();
            }
          }
        }, {
          key: "guardarAreaDePreocupacion",
          value: function guardarAreaDePreocupacion() {
            _interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_8__["ConvertFormToObject"].convert(this.ionicFormAdp, this.currentAdp);

            this.currentAdp.fecha = this.getStringFromDate(new Date());
            this.currentAdp.usuario = src_app_interfaces_seguridad_usuario__WEBPACK_IMPORTED_MODULE_7__["usuario"].currentUser.nick;

            if (this.guardarAdpEmitter) {
              this.guardarAdpEmitter.emit(this.currentAdp);
            }
          }
        }, {
          key: "valorDescripcion",
          value: function valorDescripcion(event) {
            this.currentAdp.descripcion = event.detail.value;
          }
        }, {
          key: "getStringFromDate",
          value: function getStringFromDate(date) {
            return (date.getDate() > 9 ? date.getDate() : "0" + date.getDate()) + "/" + (date.getMonth() > 8 ? date.getMonth() + 1 : "0" + (date.getMonth() + 1)) + "/" + date.getFullYear();
          }
        }]);

        return ElaEditAreapreocupacionComponent;
      }();

      ElaEditAreapreocupacionComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"]
        }, {
          type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
        }];
      };

      ElaEditAreapreocupacionComponent.propDecorators = {
        guardarAdpEmitter: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }],
        cancelarAdpEmitter: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }],
        currentAdp: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }]
      };
      ElaEditAreapreocupacionComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: "app-ela-edit-areapreocupacion",
        template: _raw_loader_ela_edit_areapreocupacion_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_ela_edit_areapreocupacion_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], ElaEditAreapreocupacionComponent);
      /***/
    },

    /***/
    "A7yl":
    /*!*****************************************************************************!*\
      !*** ./src/app/components/param-documentos/param-documentos.component.scss ***!
      \*****************************************************************************/

    /*! exports provided: default */

    /***/
    function A7yl(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".icon {\n  margin: 1px;\n  cursor: -webkit-grab;\n  cursor: grab;\n  color: #0e12d1;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxwYXJhbS1kb2N1bWVudG9zLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksV0FBQTtFQUNBLG9CQUFBO0VBQUEsWUFBQTtFQUNBLGNBQUE7QUFDSiIsImZpbGUiOiJwYXJhbS1kb2N1bWVudG9zLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmljb24geyAgICBcclxuICAgIG1hcmdpbjogMXB4O1xyXG4gICAgY3Vyc29yOiBncmFiO1xyXG4gICAgY29sb3I6IHJnYigxNCwgMTgsIDIwOSk7XHJcbiAgfSJdfQ== */";
      /***/
    },

    /***/
    "AKsB":
    /*!***************************************************************************************!*\
      !*** ./src/app/components/ela-registro-hallazgos/ela-registro-hallazgos.component.ts ***!
      \***************************************************************************************/

    /*! exports provided: ElaRegistroHallazgosComponent */

    /***/
    function AKsB(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ElaRegistroHallazgosComponent", function () {
        return ElaRegistroHallazgosComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_ela_registro_hallazgos_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./ela-registro-hallazgos.component.html */
      "Nc5Q");
      /* harmony import */


      var _ela_registro_hallazgos_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./ela-registro-hallazgos.component.scss */
      "Totv");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var src_app_interfaces_elaboracion_auditoria_PlanAuditoriaDTO__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! src/app/interfaces/elaboracion_auditoria/PlanAuditoriaDTO */
      "6GDD");

      var ElaRegistroHallazgosComponent = /*#__PURE__*/function () {
        function ElaRegistroHallazgosComponent() {
          _classCallCheck(this, ElaRegistroHallazgosComponent);

          this.lNormas = ["ISO:2007", "ISO:9001", "ISO:4427", "ISO:1334"];
          this.guardarHallazgoEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
          this.mode = "LIST";
          this.operacion = "";
          this.currentIndex = -1;
        }

        _createClass(ElaRegistroHallazgosComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            if (!this.listaHallazgos) {
              this.listaHallazgos = new Array();
            }
          }
        }, {
          key: "eliminarHallazgo",
          value: function eliminarHallazgo(i) {
            this.listaHallazgos.splice(i, 1);

            if (this.guardarHallazgoEmitter) {
              this.guardarHallazgoEmitter.emit(this.listaHallazgos);
            }
          }
        }, {
          key: "editarHallazgo",
          value: function editarHallazgo(i) {
            this.mode = "EDIT";
            this.operacion = "UPD";
            console.log("Guardar Hallazgo", this.listaHallazgos[i]);
            this.currentHallazgo = this.listaHallazgos[i];
            this.currentIndex = i;
          }
        }, {
          key: "guardarHallazgo",
          value: function guardarHallazgo(event) {
            this.mode = "LIST";
            if (this.operacion === "UPD") this.listaHallazgos[this.currentIndex] = event;else this.listaHallazgos.push(event);

            if (this.guardarHallazgoEmitter) {
              this.guardarHallazgoEmitter.emit(this.listaHallazgos);
            }
          }
        }, {
          key: "cancelarHallazo",
          value: function cancelarHallazo() {
            this.mode = "LIST";
          }
        }, {
          key: "adicionarHallazgo",
          value: function adicionarHallazgo() {
            this.mode = "EDIT";
            this.operacion = "ADD";
            this.currentHallazgo = new src_app_interfaces_elaboracion_auditoria_PlanAuditoriaDTO__WEBPACK_IMPORTED_MODULE_4__["Elahallazgo"]();
          }
        }]);

        return ElaRegistroHallazgosComponent;
      }();

      ElaRegistroHallazgosComponent.ctorParameters = function () {
        return [];
      };

      ElaRegistroHallazgosComponent.propDecorators = {
        listaHallazgos: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        lNormas: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        guardarHallazgoEmitter: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }]
      };
      ElaRegistroHallazgosComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: "app-ela-registro-hallazgos",
        template: _raw_loader_ela_registro_hallazgos_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_ela_registro_hallazgos_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], ElaRegistroHallazgosComponent);
      /***/
    },

    /***/
    "Aoky":
    /*!********************************************************!*\
      !*** ./src/app/services/apertura-auditoria.service.ts ***!
      \********************************************************/

    /*! exports provided: AperturaAuditoriaService */

    /***/
    function Aoky(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AperturaAuditoriaService", function () {
        return AperturaAuditoriaService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/common/http */
      "IheW");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! src/environments/environment */
      "AytR");
      /* harmony import */


      var _baseService__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ./baseService */
      "zrJw");
      /* harmony import */


      var _database_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./database.service */
      "ZJFI");
      /* harmony import */


      var _interfaces_seguridad_usuario__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../interfaces/seguridad/usuario */
      "PI2N");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @ionic/angular */
      "sZkV");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! rxjs */
      "qCKp");
      /* harmony import */


      var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! rxjs/operators */
      "kU1M");

      var headers = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["HEADERS_SERVICE"];
      var headers_file = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["HEADERS_FILE"];
      var url_apertura = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["URL_APERTURA"];

      var AperturaAuditoriaService = /*#__PURE__*/function (_baseService__WEBPACK2) {
        _inherits(AperturaAuditoriaService, _baseService__WEBPACK2);

        var _super2 = _createSuper(AperturaAuditoriaService);

        function AperturaAuditoriaService(databaseService, httpClient, loadingController, toastController) {
          var _this13;

          _classCallCheck(this, AperturaAuditoriaService);

          _this13 = _super2.call(this, databaseService, httpClient, loadingController, toastController);
          _this13.databaseService = databaseService;
          _this13.httpClient = httpClient;
          _this13.loadingController = loadingController;
          _this13.toastController = toastController;
          return _this13;
        }

        _createClass(AperturaAuditoriaService, [{
          key: "ObtenerProgramaAuditoria",
          value: function ObtenerProgramaAuditoria(IdServicio) {
            var _this14 = this;

            var url_query = url_apertura + "ObtenerProgramaAuditoria";
            var dataRequest = {
              IdServicio: IdServicio,
              Usuario: _interfaces_seguridad_usuario__WEBPACK_IMPORTED_MODULE_6__["usuario"].currentUser.nick
            };
            this.presentLoader();
            return this.httpClient.post(url_query, JSON.stringify(dataRequest), {
              headers: headers
            }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["finalize"])(function () {
              console.log("**se termino la llamada ObtenerProgramaAuditoria");

              _this14.dismissLoader();
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["catchError"])(function (error) {
              _this14.showMessageError("No se tiene comunicacion con el servidor");

              return rxjs__WEBPACK_IMPORTED_MODULE_8__["Observable"]["throw"](new Error(error.status));
            }));
          }
        }, {
          key: "ObtenerCargos",
          value: function ObtenerCargos() {
            var _this15 = this;

            var url_query = url_apertura + "ObtenerCargos";
            var dataRequest = {};
            this.presentLoader();
            return this.httpClient.post(url_query, JSON.stringify(dataRequest), {
              headers: headers
            }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["finalize"])(function () {
              console.log("se termino la llamada ObtenerCargos");

              _this15.dismissLoader();
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["catchError"])(function (error) {
              _this15.showMessageError("No se tiene comunicacion con el servidor");

              return rxjs__WEBPACK_IMPORTED_MODULE_8__["Observable"]["throw"](new Error(error.status));
            }));
          }
        }, {
          key: "ObtenerParticipanteXCargos",
          value: function ObtenerParticipanteXCargos(IdCargoCalificado) {
            var _this16 = this;

            var url_query = url_apertura + "BuscarPersonalCargos";
            var dataRequest = {
              IdCargoCalificado: IdCargoCalificado
            };
            this.presentLoader();
            return this.httpClient.post(url_query, JSON.stringify(dataRequest), {
              headers: headers
            }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["finalize"])(function () {
              console.log("se termino la llamada");

              _this16.dismissLoader();
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["catchError"])(function (error) {
              _this16.showMessageError("No se tiene comunicacion con el servidor");

              return rxjs__WEBPACK_IMPORTED_MODULE_8__["Observable"]["throw"](new Error(error.status));
            }));
          }
        }, {
          key: "BuscarNormas",
          value: function BuscarNormas(Codigo) {
            var _this17 = this;

            var url_query = url_apertura + "BuscarNormas";
            var dataRequest = {
              Codigo: Codigo
            };
            this.presentLoader();
            return this.httpClient.post(url_query, JSON.stringify(dataRequest), {
              headers: headers
            }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["finalize"])(function () {
              console.log("se termino la llamada BuscarNormas");

              _this17.dismissLoader();
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["catchError"])(function (error) {
              _this17.showMessageError("No se tiene comunicacion con el servidor");

              return rxjs__WEBPACK_IMPORTED_MODULE_8__["Observable"]["throw"](new Error(error.status));
            }));
          }
        }, {
          key: "BuscarNormasInternacionales",
          value: function BuscarNormasInternacionales(Codigo) {
            var _this18 = this;

            var url_query = url_apertura + "BuscarNormasInternacionales";
            var dataRequest = {
              Codigo: Codigo
            };
            this.presentLoader();
            return this.httpClient.post(url_query, JSON.stringify(dataRequest), {
              headers: headers
            }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["finalize"])(function () {
              console.log("se termino la llamada BuscarNormasInternacionales");

              _this18.dismissLoader();
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["catchError"])(function (error) {
              _this18.showMessageError("No se tiene comunicacion con el servidor");

              return rxjs__WEBPACK_IMPORTED_MODULE_8__["Observable"]["throw"](new Error(error.status));
            }));
          }
        }, {
          key: "BuscarPais",
          value: function BuscarPais(pais) {
            var _this19 = this;

            var url_query = url_apertura + "BuscarPais";
            var dataRequest = {
              pais: pais
            };
            this.presentLoader();
            return this.httpClient.post(url_query, JSON.stringify(dataRequest), {
              headers: headers
            }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["finalize"])(function () {
              console.log("se termino la llamada BuscarPais");

              _this19.dismissLoader();
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["catchError"])(function (error) {
              _this19.showMessageError("No se tiene comunicacion con el servidor");

              return rxjs__WEBPACK_IMPORTED_MODULE_8__["Observable"]["throw"](new Error(error.status));
            }));
          }
        }, {
          key: "BuscarEstado",
          value: function BuscarEstado(IdPais) {
            var _this20 = this;

            var url_query = url_apertura + "BuscarEstado";
            var dataRequest = {
              IdPais: IdPais
            };
            this.presentLoader();
            return this.httpClient.post(url_query, JSON.stringify(dataRequest), {
              headers: headers
            }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["finalize"])(function () {
              console.log("se termino la llamada BuscarEstado");

              _this20.dismissLoader();
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["catchError"])(function (error) {
              _this20.showMessageError("No se tiene comunicacion con el servidor");

              return rxjs__WEBPACK_IMPORTED_MODULE_8__["Observable"]["throw"](new Error(error.status));
            }));
          }
        }, {
          key: "BuscarCiudad",
          value: function BuscarCiudad(IdEstado) {
            var _this21 = this;

            var url_query = url_apertura + "BuscarCiudad";
            var dataRequest = {
              IdEstado: IdEstado
            };
            this.presentLoader();
            return this.httpClient.post(url_query, JSON.stringify(dataRequest), {
              headers: headers
            }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["finalize"])(function () {
              console.log("se termino la llamada BuscarCiudad");

              _this21.dismissLoader();
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["catchError"])(function (error) {
              _this21.showMessageError("No se tiene comunicacion con el servidor");

              return rxjs__WEBPACK_IMPORTED_MODULE_8__["Observable"]["throw"](new Error(error.status));
            }));
          }
        }, {
          key: "RegisterProgramaAuditoria",
          value: function RegisterProgramaAuditoria(programa) {
            var _this22 = this;

            var url_query = url_apertura + "RegisterProgramaAuditoria";
            this.presentLoader();
            return this.httpClient.post(url_query, JSON.stringify(programa), {
              headers: headers
            }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["finalize"])(function () {
              console.log("se termino la llamada RegisterProgramaAuditoria");

              _this22.dismissLoader();
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["catchError"])(function (error) {
              _this22.showMessageError("No se tiene comunicacion con el servidor");

              return rxjs__WEBPACK_IMPORTED_MODULE_8__["Observable"]["throw"](new Error(error.status));
            }));
          }
        }, {
          key: "GenerarDesignacion",
          value: function GenerarDesignacion(IdCiclo, Plantilla) {
            var _this23 = this;

            var url_query = url_apertura + "GenerarDesignacion";
            var dataRequest = {
              IdCiclo: IdCiclo,
              pathPlantilla: Plantilla
            };
            this.presentLoader();
            return this.httpClient.post(url_query, JSON.stringify(dataRequest), {
              headers: headers
            }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["finalize"])(function () {
              console.log("se termino la llamada GenerarDesignacion");

              _this23.dismissLoader();
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["catchError"])(function (error) {
              _this23.showMessageError("No se tiene comunicacion con el servidor");

              return rxjs__WEBPACK_IMPORTED_MODULE_8__["Observable"]["throw"](new Error(error.status));
            }));
          }
        }, {
          key: "ObtenerArchivoDesignacion",
          value: function ObtenerArchivoDesignacion(fileName) {
            var _this24 = this;

            var url_query = url_apertura + "ObtenerArchivoDesignacion?fileName=" + fileName;
            this.httpClient.get(url_query, {
              responseType: "arraybuffer",
              headers: headers
            }) //.subscribe((response) => this.downLoadFile(response, "application/pdf"));
            .subscribe(function (response) {
              return _this24.downLoadFileWord(response, "Desginacion.doc");
            });
          }
        }, {
          key: "downLoadFile",
          value: function downLoadFile(data, type) {
            var blob = new Blob([data], {
              type: type
            });
            var url = window.URL.createObjectURL(blob);
            var pwa = window.open(url);

            if (!pwa || pwa.closed || typeof pwa.closed == "undefined") {
              alert("Por favor deshabilite los bloqueadores de descarga para continuar.");
            }
          }
        }, {
          key: "downLoadFileWord",
          value: function downLoadFileWord(data, fileName) {
            var blob = new Blob([data], {
              type: "application/octet-stream"
            });
            var link = document.createElement("a");
            link.href = URL.createObjectURL(blob); // set the name of the file

            link.download = fileName; // clicking the anchor element will download the file

            link.click();
          }
        }, {
          key: "BuscarOrganismosCertificadores",
          value: function BuscarOrganismosCertificadores() {
            var _this25 = this;

            var url_query = url_apertura + "BuscarOrganismosCertificadores";
            var dataRequest = {};
            this.presentLoader();
            return this.httpClient.post(url_query, JSON.stringify(dataRequest), {
              headers: headers
            }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["finalize"])(function () {
              console.log("se termino la llamada GenerarDesignacion");

              _this25.dismissLoader();
            }));
          }
        }, {
          key: "CargarSolicitud",
          value: function CargarSolicitud(fileToUpload) {
            var _this26 = this;

            var url_query = url_apertura + "CargarSolcitud";
            this.presentLoader();
            var formData = new FormData();
            formData.append('fileKey', fileToUpload, fileToUpload.name);
            return this.httpClient.post(url_query, formData).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["finalize"])(function () {
              console.log("se termino la llamada CargarSolicitud");

              _this26.dismissLoader();
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["catchError"])(function (error) {
              console.error(error);

              _this26.showMessageError("Error al cargar el archivo " + error.error);

              return rxjs__WEBPACK_IMPORTED_MODULE_8__["Observable"]["throw"](new Error(error.status));
            }));
          }
        }]);

        return AperturaAuditoriaService;
      }(_baseService__WEBPACK_IMPORTED_MODULE_4__["BaseService"]);

      AperturaAuditoriaService.ctorParameters = function () {
        return [{
          type: _database_service__WEBPACK_IMPORTED_MODULE_5__["DatabaseService"]
        }, {
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["LoadingController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ToastController"]
        }];
      };

      AperturaAuditoriaService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: "root"
      })], AperturaAuditoriaService);
      /***/
    },

    /***/
    "AytR":
    /*!*****************************************!*\
      !*** ./src/environments/environment.ts ***!
      \*****************************************/

    /*! exports provided: environment, HEADERS_SERVICE, HEADERS_FILE, URL_GLOBAL, URL_APERTURA, URL_ELABORACION */

    /***/
    function AytR(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "environment", function () {
        return environment;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HEADERS_SERVICE", function () {
        return HEADERS_SERVICE;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HEADERS_FILE", function () {
        return HEADERS_FILE;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "URL_GLOBAL", function () {
        return URL_GLOBAL;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "URL_APERTURA", function () {
        return URL_APERTURA;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "URL_ELABORACION", function () {
        return URL_ELABORACION;
      });
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/common/http */
      "IheW"); // This file can be replaced during build by using the `fileReplacements` array.
      // `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
      // The list of file replacements can be found in `angular.json`.


      var environment = {
        production: false
      };
      var HEADERS_SERVICE = new _angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HttpHeaders"]({
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, GET, OPTIONS, PUT",
        Accept: "*/*",
        "content-type": "application/json"
      });
      var HEADERS_FILE = new _angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HttpHeaders"]({
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, GET, OPTIONS, PUT",
        Accept: "*/*"
      }); //export const URL_GLOBAL = "http://localhost:8001/api/";

      var URL_GLOBAL = "http://200.105.199.164/api/";
      var URL_APERTURA = URL_GLOBAL + "AperturaAuditoria/";
      var URL_ELABORACION = URL_GLOBAL + "ElaboracionAuditoria/";
      /*
       * For easier debugging in development mode, you can import the following file
       * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
       *
       * This import should be commented out in production mode because it will have a negative impact
       * on performance if an error is thrown.
       */
      // import 'zone.js/dist/zone-error';  // Included with Angular CLI.

      /***/
    },

    /***/
    "Buy6":
    /*!***********************************************************************************************************************!*\
      !*** ./src/app/components/tcs-lista-verificacion-reunion-cierre/tcs-lista-verificacion-reunion-cierre.component.scss ***!
      \***********************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function Buy6(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0Y3MtbGlzdGEtdmVyaWZpY2FjaW9uLXJldW5pb24tY2llcnJlLmNvbXBvbmVudC5zY3NzIn0= */";
      /***/
    },

    /***/
    "EpQ6":
    /*!*********************************************************************************************************************!*\
      !*** ./src/app/components/tcs-lista-verificacion-reunion-cierre/tcs-lista-verificacion-reunion-cierre.component.ts ***!
      \*********************************************************************************************************************/

    /*! exports provided: TcsListaVerificacionReunionCierreComponent */

    /***/
    function EpQ6(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "TcsListaVerificacionReunionCierreComponent", function () {
        return TcsListaVerificacionReunionCierreComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_tcs_lista_verificacion_reunion_cierre_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./tcs-lista-verificacion-reunion-cierre.component.html */
      "/BRC");
      /* harmony import */


      var _tcs_lista_verificacion_reunion_cierre_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./tcs-lista-verificacion-reunion-cierre.component.scss */
      "Buy6");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var src_app_services_elaboracion_auditoria_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! src/app/services/elaboracion-auditoria.service */
      "6V/C");

      var TcsListaVerificacionReunionCierreComponent = /*#__PURE__*/function () {
        function TcsListaVerificacionReunionCierreComponent(elaboracionAuditoriaService) {
          _classCallCheck(this, TcsListaVerificacionReunionCierreComponent);

          this.elaboracionAuditoriaService = elaboracionAuditoriaService;
          this.checkBoxList = [{
            item: '1.',
            value: "Agradecimiento.",
            isChecked: false
          }, {
            item: '2.',
            value: "Confirmación del alcance y objetivos de la auditoría, alcance de la certificación y norma auditada.",
            isChecked: false
          }, {
            item: '3.',
            value: "Informar que las evidencias de auditoría reunidas se basan en un muestreo por lo tanto se introduce un elemento de incertidumbre.",
            isChecked: false
          }, {
            item: '4.',
            value: "Lectura y hallazgos de auditoría indicando su categorización .",
            isChecked: false
          }, {
            item: '5.',
            value: "Lectura de conclusión de auditoría.",
            isChecked: false
          }, {
            item: '6.',
            value: "Informar sobre el plazo máximo de 15 días calendario a partir de la culminación de la auditoría para él envió de las correcciones y acciones correctivas al auditor líder de las No conformidades menores y/o mayores identificadas para posterior aprobación por el auditor líder. En el caso de no conformidades mayores la organización debe de enviar las evidencias en un plazo de 90 días calendario a partir de la auditoría, para posterior aprobación por el auditor líder.",
            isChecked: false
          }, {
            item: '7.',
            value: "Fecha estimada de la próxima auditoría.",
            isChecked: false
          }, {
            item: '8.',
            value: "Informar acerca de los procesos que tienen IBNORCA, para el tratamiento de quejas y de apelaciones.",
            isChecked: false
          }, {
            item: '9.',
            value: "Aclaraciones.",
            isChecked: false
          }, {
            item: '10 .',
            value: "Firma del informe de auditoría.",
            isChecked: false
          }, {
            item: '11.',
            value: "Revisión del alcance en el informe y el formulario de Datos de la organización.",
            isChecked: false
          }];
        }

        _createClass(TcsListaVerificacionReunionCierreComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this27 = this;

            this.elaboracionAuditoriaService.GetListasVerificacion(2).subscribe(function (resul) {
              _this27.pParamitemselect = resul.listEntities;
            });
          }
        }, {
          key: "checkMaster",
          value: function checkMaster() {
            var _this28 = this;

            setTimeout(function () {
              _this28.checkBoxList.forEach(function (obj) {
                obj.isChecked = _this28.masterCheck;
              });
            });
          }
        }, {
          key: "checkEvent",
          value: function checkEvent() {
            var totalItems = this.checkBoxList.length;
            var checked = 0;
            this.checkBoxList.map(function (obj) {
              if (obj.isChecked) checked++;
            });

            if (checked > 0 && checked < totalItems) {
              //If even one item is checked but not all
              this.isIndeterminate = true;
              this.masterCheck = false;
            } else if (checked == totalItems) {
              //If all are checked
              this.masterCheck = true;
              this.isIndeterminate = false;
            } else {
              //If none is checked
              this.isIndeterminate = false;
              this.masterCheck = false;
            }
          }
        }]);

        return TcsListaVerificacionReunionCierreComponent;
      }();

      TcsListaVerificacionReunionCierreComponent.ctorParameters = function () {
        return [{
          type: src_app_services_elaboracion_auditoria_service__WEBPACK_IMPORTED_MODULE_4__["ElaboracionAuditoriaService"]
        }];
      };

      TcsListaVerificacionReunionCierreComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-tcs-lista-verificacion-reunion-cierre',
        template: _raw_loader_tcs_lista_verificacion_reunion_cierre_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_tcs_lista_verificacion_reunion_cierre_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], TcsListaVerificacionReunionCierreComponent);
      /***/
    },

    /***/
    "GB8g":
    /*!*****************************************************!*\
      !*** ./src/app/components/meses/meses.component.ts ***!
      \*****************************************************/

    /*! exports provided: MesesComponent */

    /***/
    function GB8g(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "MesesComponent", function () {
        return MesesComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_meses_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./meses.component.html */
      "34tN");
      /* harmony import */


      var _meses_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./meses.component.scss */
      "W7oR");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "sZkV");

      var MesesComponent = /*#__PURE__*/function () {
        function MesesComponent(popoverController) {
          _classCallCheck(this, MesesComponent);

          this.popoverController = popoverController;
          this.items = [{
            value: 1,
            label: "Enero"
          }, {
            value: 2,
            label: "Febrero"
          }, {
            value: 3,
            label: "Marzo"
          }, {
            value: 4,
            label: "Abril"
          }, {
            value: 5,
            label: "Mayo"
          }, {
            value: 6,
            label: "Junio"
          }, {
            value: 7,
            label: "Julio"
          }, {
            value: 8,
            label: "Agosto"
          }, {
            value: 9,
            label: "Septiembre"
          }, {
            value: 10,
            label: "Octubre"
          }, {
            value: 11,
            label: "Noviembre"
          }, {
            value: 12,
            label: "Diciembre"
          }];
        }

        _createClass(MesesComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "selectMes",
          value: function selectMes(value) {
            console.log(this.items.find(function (x) {
              return x.value == value;
            }));
            return this.popoverController.dismiss({
              item: this.items.find(function (x) {
                return x.value == value;
              })
            });
          }
        }]);

        return MesesComponent;
      }();

      MesesComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["PopoverController"]
        }];
      };

      MesesComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: "app-meses",
        template: _raw_loader_meses_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_meses_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], MesesComponent);
      /***/
    },

    /***/
    "GPF9":
    /*!*****************************************************************************!*\
      !*** ./src/app/components/tcp-list-products/tcp-list-products.component.ts ***!
      \*****************************************************************************/

    /*! exports provided: TcpListProductsComponent */

    /***/
    function GPF9(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "TcpListProductsComponent", function () {
        return TcpListProductsComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_tcp_list_products_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./tcp-list-products.component.html */
      "Psgn");
      /* harmony import */


      var _tcp_list_products_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./tcp-list-products.component.scss */
      "ej6O");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/angular */
      "sZkV");
      /* harmony import */


      var src_app_interfaces_apertura_auditoria_Praprogramasdeauditorium__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! src/app/interfaces/apertura_auditoria/Praprogramasdeauditorium */
      "Z1IW");

      var TcpListProductsComponent = /*#__PURE__*/function () {
        function TcpListProductsComponent(popoverController, formBuilder, modalController) {
          _classCallCheck(this, TcpListProductsComponent);

          this.popoverController = popoverController;
          this.formBuilder = formBuilder;
          this.modalController = modalController;
          this.productList = [];
          this.addCronograma = false;
          this.allowDelete = true;
          this.guardarCronogramaEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
          this.eliminarCronogramaEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
          this.mode = "LIST";
          this.operacion = "";
          this.currentIndex = -1;
          this.display = false;
        }

        _createClass(TcpListProductsComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "toggle",
          value: function toggle() {
            this.display = !this.display;
          }
        }, {
          key: "editar",
          value: function editar(product, i) {
            this.mode = "EDIT";
            this.operacion = "UPD";
            this.currentProduct = product;
            this.currentIndex = i;
          }
        }, {
          key: "eliminar",
          value: function eliminar(index) {
            console.log("evento eliminar", index);
            this.productList.splice(index, 1);
          }
        }, {
          key: "adicionar",
          value: function adicionar() {
            this.mode = "EDIT";
            this.operacion = "ADD";
            this.currentProduct = new src_app_interfaces_apertura_auditoria_Praprogramasdeauditorium__WEBPACK_IMPORTED_MODULE_6__["Pradireccionespaproducto"]();
          }
        }, {
          key: "guardarProducto",
          value: function guardarProducto(event) {
            this.mode = "LIST";
            if (this.operacion === "UPD") this.productList[this.currentIndex] = event;else this.productList.push(event);
          }
        }, {
          key: "guardarCronograma",
          value: function guardarCronograma(event) {
            if (this.guardarCronogramaEmitter) {
              this.guardarCronogramaEmitter.emit(event);
            }
          }
        }, {
          key: "cancelarProducto",
          value: function cancelarProducto(event) {
            this.mode = "LIST";
          }
        }, {
          key: "getLlaves",
          value: function getLlaves(producto) {
            var llave = {
              idDireccionPaproducto: producto.idDireccionPaproducto,
              idDireccionPasistema: null
            };
            return llave;
          }
        }, {
          key: "eliminarCronograma",
          value: function eliminarCronograma(event) {
            if (this.eliminarCronogramaEmitter) {
              this.eliminarCronogramaEmitter.emit(event);
            }
          }
        }]);

        return TcpListProductsComponent;
      }();

      TcpListProductsComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["PopoverController"]
        }, {
          type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"]
        }];
      };

      TcpListProductsComponent.propDecorators = {
        productList: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        nombreOrganizacion: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        addCronograma: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        listaParticipantes: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        allowDelete: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        guardarCronogramaEmitter: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }],
        eliminarCronogramaEmitter: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }]
      };
      TcpListProductsComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: "app-tcp-list-products",
        template: _raw_loader_tcp_list_products_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_tcp_list_products_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], TcpListProductsComponent);
      /***/
    },

    /***/
    "GYtA":
    /*!***********************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/custom-input/custom-input.component.html ***!
      \***********************************************************************************************************/

    /*! exports provided: default */

    /***/
    function GYtA(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<div [formGroup]=\"formGruop\">\n  <ion-item lines=\"full\">\n    <ion-label position=\"floating\">{{ label }}</ion-label>\n    <ion-input\n      class=\"margin-top\"\n      *ngIf=\"type != 'datetime'\"\n      [formControlName]=\"name\"\n      [type]=\"type\"\n      [readonly]=\"readonly\"\n      (keyup.enter)=\"eventKeyEnter($event)\"\n    ></ion-input>\n    <ion-datetime\n      class=\"margin-top\"\n      [formControlName]=\"name\"\n      [pickerOptions]=\"customPickerOption\"\n      *ngIf=\"type === 'datetime'\"\n      [displayFormat]=\"formatDate\"\n      [max]=\"maxDate\"\n    ></ion-datetime>\n  </ion-item>\n  <div *ngIf=\"Validations\">\n    <div *ngFor=\"let validation of Validations\">\n      <app-message-error\n        [error]=\"validation.message\"\n        *ngIf=\"form.submitted && ExistsError(validation.validator)\"\n      >\n      </app-message-error>\n    </div>\n  </div>\n</div>\n";
      /***/
    },

    /***/
    "GeA3":
    /*!************************************************************!*\
      !*** ./src/app/interfaces/cross-ui/ConvertFormToObject.ts ***!
      \************************************************************/

    /*! exports provided: ConvertFormToObject, ConvertObjectToForm */

    /***/
    function GeA3(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ConvertFormToObject", function () {
        return ConvertFormToObject;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ConvertObjectToForm", function () {
        return ConvertObjectToForm;
      });

      var ConvertFormToObject = /*#__PURE__*/function () {
        function ConvertFormToObject() {
          _classCallCheck(this, ConvertFormToObject);
        }

        _createClass(ConvertFormToObject, null, [{
          key: "convert",
          value: function convert(formGroup, customObject) {
            for (var prop in formGroup.controls) {
              customObject[prop] = formGroup.controls[prop]["valueDate"] ? formGroup.controls[prop]["valueDate"] : formGroup.controls[prop].value;
            }
          }
        }]);

        return ConvertFormToObject;
      }();

      var ConvertObjectToForm = /*#__PURE__*/function () {
        function ConvertObjectToForm() {
          _classCallCheck(this, ConvertObjectToForm);
        }

        _createClass(ConvertObjectToForm, null, [{
          key: "convert",
          value: function convert(formGroup, customObject) {
            for (var prop in formGroup.controls) {
              if (customObject[prop] instanceof Date) {
                formGroup.controls[prop]["valueDate"] = customObject[prop];
              } else {
                formGroup.controls[prop].setValue(customObject[prop]);
              }
            }
          }
        }]);

        return ConvertObjectToForm;
      }();
      /***/

    },

    /***/
    "ILT1":
    /*!***********************************************************************!*\
      !*** ./src/app/components/plan-auditoria/plan-auditoria.component.ts ***!
      \***********************************************************************/

    /*! exports provided: PlanAuditoriaComponent */

    /***/
    function ILT1(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PlanAuditoriaComponent", function () {
        return PlanAuditoriaComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_plan_auditoria_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./plan-auditoria.component.html */
      "/h6z");
      /* harmony import */


      var _plan_auditoria_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./plan-auditoria.component.scss */
      "T21K");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/common */
      "SVse");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/angular */
      "sZkV");
      /* harmony import */


      var src_app_services_elaboracion_auditoria_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! src/app/services/elaboracion-auditoria.service */
      "6V/C");

      var PlanAuditoriaComponent = /*#__PURE__*/function () {
        function PlanAuditoriaComponent(formBuilder, popoverController, datepipe, elaboracionAuditoriaService) {
          _classCallCheck(this, PlanAuditoriaComponent);

          this.formBuilder = formBuilder;
          this.popoverController = popoverController;
          this.datepipe = datepipe;
          this.elaboracionAuditoriaService = elaboracionAuditoriaService;
          this.mode = "TCP";
          this.guardarCronogramaEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"]();
          this.eliminarCronogramaEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"]();
          this.listaDirecciones = [];
          this.DocumentacionReferencia = "Norma NAG E 210 (2005) Sistema de tubería compuesta de acero-Polietileno unidos por termo fusión para conducción de gas natural y gases licuados de petróleo en instalaciones internas.  \n" + "Sistema de Gestión conforme a los requisitos del Anexo 1 de la Especificación Esquema 5 para la certificación de productos con Sello IBNORCA. \n" + "Reglamento Particular de Producto RP-TCP - 65 \n" + "Procedimientos y otra documentación de la organización. \n";
        }

        _createClass(PlanAuditoriaComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this29 = this;

            this.listaParticipantes = this.currentPlanAuditoriaDTO["listaParticipantes"];
            this.mode = this.currentPlanAuditoriaDTO.area;
            this.currentPlanAuditoriaDTO.pradireccionespaproducto.forEach(function (x) {
              if (_this29.listaDirecciones.indexOf(x.direccion) === -1) {
                _this29.listaDirecciones.push(x.direccion);
              }
            });
            this.currentPlanAuditoriaDTO.pradireccionespasistema.forEach(function (x) {
              if (x.dias > 0 && _this29.listaDirecciones.indexOf(x.direccion) === -1) {
                _this29.listaDirecciones.push(x.direccion);
              }
            });
          }
        }, {
          key: "guardarCronograma",
          value: function guardarCronograma(event) {
            if (this.guardarCronogramaEmitter) {
              this.guardarCronogramaEmitter.emit(event);
            }
          }
        }, {
          key: "eliminarCronograma",
          value: function eliminarCronograma(event) {
            if (this.eliminarCronogramaEmitter) {
              this.eliminarCronogramaEmitter.emit(event);
            }
          }
        }]);

        return PlanAuditoriaComponent;
      }();

      PlanAuditoriaComponent.ctorParameters = function () {
        return [{
          type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["PopoverController"]
        }, {
          type: _angular_common__WEBPACK_IMPORTED_MODULE_3__["DatePipe"]
        }, {
          type: src_app_services_elaboracion_auditoria_service__WEBPACK_IMPORTED_MODULE_7__["ElaboracionAuditoriaService"]
        }];
      };

      PlanAuditoriaComponent.propDecorators = {
        currentPlanAuditoriaDTO: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"]
        }],
        guardarCronogramaEmitter: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Output"]
        }],
        eliminarCronogramaEmitter: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Output"]
        }],
        listaDirecciones: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"]
        }]
      };
      PlanAuditoriaComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: "app-plan-auditoria",
        template: _raw_loader_plan_auditoria_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_plan_auditoria_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], PlanAuditoriaComponent);
      /***/
    },

    /***/
    "J43g":
    /*!*********************************************************************!*\
      !*** ./src/app/components/buscar-norma/buscar-norma.component.scss ***!
      \*********************************************************************/

    /*! exports provided: default */

    /***/
    function J43g(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".cargo-select {\n  width: 100%;\n  font-size: 13px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxidXNjYXItbm9ybWEuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxXQUFBO0VBQ0EsZUFBQTtBQUNKIiwiZmlsZSI6ImJ1c2Nhci1ub3JtYS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jYXJnby1zZWxlY3R7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGZvbnQtc2l6ZTogMTNweDtcclxufSJdfQ== */";
      /***/
    },

    /***/
    "KzMd":
    /*!*************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/custom-header/custom-header.component.html ***!
      \*************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function KzMd(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header translucent=\"true\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button>\n        <ion-icon [name]=\"icon_name\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title class=\"ion-text-capitalize\">\n      {{ title }}\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n";
      /***/
    },

    /***/
    "LK1H":
    /*!*********************************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/ela-registro-areapreocupacion/ela-registro-areapreocupacion.component.html ***!
      \*********************************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function LK1H(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-list *ngIf=\"mode === 'LIST'\">\r\n  <ion-list-header class=\"title-normas\">\r\n    <ion-item>\r\n      <ion-icon\r\n        name=\"add-circle\"\r\n        slot=\"end\"\r\n        (click)=\"adicionarAdp()\"\r\n        class=\"big-icon\"\r\n      ></ion-icon>\r\n      Registro Areas de Preocupación\r\n    </ion-item>\r\n  </ion-list-header>\r\n  <ion-item *ngFor=\"let adp of listaAdp; let i = index\">\r\n    <ion-icon\r\n      name=\"pencil-sharp\"\r\n      slot=\"start\"\r\n      (click)=\"editarAdp(i)\"\r\n      class=\"big-icon\"\r\n    ></ion-icon>\r\n    <ion-icon\r\n      name=\"trash\"\r\n      slot=\"start\"\r\n      (click)=\"eliminarAdp(i)\"\r\n      class=\"big-icon\"\r\n    ></ion-icon>\r\n    <div class=\"norma-block\">\r\n      <h2>Area: {{ adp.area }}</h2>\r\n      <p>\r\n        Descripción:\r\n        <span class=\"sub-title\">{{ adp.descripcion }}</span>\r\n      </p>\r\n      <p class=\"detail-paragraph\">\r\n        Fecha {{adp.fecha}} | Auditor: {{adp.usuario}}\r\n      </p>\r\n    </div>\r\n  </ion-item>\r\n</ion-list>\r\n<app-ela-edit-areapreocupacion\r\n  *ngIf=\"mode === 'EDIT'\"\r\n  (guardarAdpEmitter)=\"guardarAreaDePreocupacion($event)\"\r\n  (cancelarAdpEmitter)=\"cancelarAreaDePreocupacion($event)\"\r\n  [currentAdp]=\"currentAdp\"\r\n></app-ela-edit-areapreocupacion>\r\n";
      /***/
    },

    /***/
    "Lrlg":
    /*!*********************************************************************!*\
      !*** ./src/app/components/ela-objetivos/ela-objetivos.component.ts ***!
      \*********************************************************************/

    /*! exports provided: ElaObjetivosComponent */

    /***/
    function Lrlg(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ElaObjetivosComponent", function () {
        return ElaObjetivosComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_ela_objetivos_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./ela-objetivos.component.html */
      "Wcuq");
      /* harmony import */


      var _ela_objetivos_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./ela-objetivos.component.scss */
      "qQ6a");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var src_app_services_elaboracion_auditoria_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! src/app/services/elaboracion-auditoria.service */
      "6V/C");

      var ElaObjetivosComponent = /*#__PURE__*/function () {
        function ElaObjetivosComponent(elaboracionAuditoriaService) {
          _classCallCheck(this, ElaObjetivosComponent);

          this.elaboracionAuditoriaService = elaboracionAuditoriaService;
          this.area = "";
          this.guardarContenidoEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
          this.listSubtitulos = new Array();
        }

        _createClass(ElaObjetivosComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this30 = this;

            if (this.listContenido) {
              this.listContenido.forEach(function (contenido) {
                if (_this30.listSubtitulos.filter(function (hh) {
                  return hh.nemotico === contenido.nemotico;
                }).length === 0) {
                  _this30.listSubtitulos.push(contenido);
                }
              });
            }
          }
        }, {
          key: "ListByCategoria",
          value: function ListByCategoria(nemotico) {
            if (this.listContenido) {
              return this.listContenido.filter(function (x) {
                return x.nemotico == nemotico;
              });
            } else return null;
          }
        }, {
          key: "guardarContenido",
          value: function guardarContenido() {
            this.listContenido.forEach(function (x) {
              x.seleccionado = x["select"] ? 1 : 0;
            });

            if (this.guardarContenidoEmitter) {
              this.guardarContenidoEmitter.emit(this.listContenido);
            }
          }
        }]);

        return ElaObjetivosComponent;
      }();

      ElaObjetivosComponent.ctorParameters = function () {
        return [{
          type: src_app_services_elaboracion_auditoria_service__WEBPACK_IMPORTED_MODULE_4__["ElaboracionAuditoriaService"]
        }];
      };

      ElaObjetivosComponent.propDecorators = {
        listContenido: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        area: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        guardarContenidoEmitter: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }]
      };
      ElaObjetivosComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: "app-ela-objetivos",
        template: _raw_loader_ela_objetivos_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_ela_objetivos_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], ElaObjetivosComponent);
      /***/
    },

    /***/
    "Nc5Q":
    /*!*******************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/ela-registro-hallazgos/ela-registro-hallazgos.component.html ***!
      \*******************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function Nc5Q(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-list *ngIf=\"mode === 'LIST'\">\r\n  <ion-list-header class=\"title-normas\">\r\n    <ion-item>\r\n      <ion-icon\r\n        name=\"add-circle\"\r\n        slot=\"end\"\r\n        (click)=\"adicionarHallazgo()\"\r\n        class=\"big-icon\"></ion-icon>\r\n      Registro de Hallazgos\r\n    </ion-item>\r\n  </ion-list-header>\r\n  <ion-item *ngFor=\"let hallazgos of listaHallazgos; let i= index\">\r\n    <ion-icon\r\n      name=\"pencil-sharp\"\r\n      slot=\"start\"\r\n      (click)=\"editarHallazgo(i)\"\r\n      class=\"big-icon\"></ion-icon>\r\n    <ion-icon\r\n      name=\"trash\"\r\n      slot=\"start\"\r\n      (click)=\"eliminarHallazgo(i)\"\r\n      class=\"big-icon\"></ion-icon>\r\n    <div class=\"norma-block\">\r\n      <h2>\r\n        Tipo: {{ hallazgos.tipo }} [Normas: {{ hallazgos.normas }}]\r\n      </h2>\r\n      <h3>Requisito: {{ hallazgos.proceso }}</h3>\r\n      <!-- <h3>Hallazgo: {{ hallazgos.proceso }}</h3> -->\r\n      <p>\r\n        Hallazgo:\r\n        <span class=\"sub-title\">\r\n          {{ hallazgos.hallazgo }}\r\n          <!-- A tomar en consideración: - en el caso de las auditorías\r\n          multisitio, la columna F permite vincular los resultados con el\r\n          \"sitio\". llene la hoja de Excel \"sitios\" para que sólo tenga que\r\n          introducir los nombres de los sitios una vez y pueda encontrarlos en\r\n          forma de menú desplegable en la columna \"sitio en cuestión\" para\r\n          cada auditoría. Para auditorías de un solo sitio, oculte esta\r\n          columna. Ocultar las columnas de las normas que no necesita y así\r\n          hacer el informe más legible para el cliente. -->\r\n        </span>\r\n      </p>\r\n      <p class=\"detail-paragraph\">\r\n        Sitio.{{ hallazgos.sitio }} | Fecha {{ hallazgos.fecha }} | Auditor: {{\r\n        hallazgos.usuario }}\r\n      </p>\r\n    </div>\r\n  </ion-item>\r\n</ion-list>\r\n<app-ela-edit-hallazago\r\n  *ngIf=\"mode === 'EDIT'\"\r\n  [elahallazgo]=\"currentHallazgo\"\r\n  (guardarHallazgoEmitter)=\"guardarHallazgo($event)\"\r\n  (cancelarHallazgoEmitter)=\"cancelarHallazo($event)\"\r\n  [lNormas]=\"lNormas\"></app-ela-edit-hallazago>";
      /***/
    },

    /***/
    "NiF9":
    /*!**************************************************************************!*\
      !*** ./src/app/interfaces/toma_decisiones/tmddocumentacionauditorium.ts ***!
      \**************************************************************************/

    /*! exports provided: Tmddocumentacionauditorium */

    /***/
    function NiF9(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Tmddocumentacionauditorium", function () {
        return Tmddocumentacionauditorium;
      });

      var Tmddocumentacionauditorium = function Tmddocumentacionauditorium() {
        _classCallCheck(this, Tmddocumentacionauditorium);
      };
      /***/

    },

    /***/
    "NyE1":
    /*!*********************************************************************************!*\
      !*** ./src/app/components/ela-cronograma-list/ela-cronograma-list.component.ts ***!
      \*********************************************************************************/

    /*! exports provided: ElaCronogramaListComponent */

    /***/
    function NyE1(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ElaCronogramaListComponent", function () {
        return ElaCronogramaListComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_ela_cronograma_list_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./ela-cronograma-list.component.html */
      "3Xjl");
      /* harmony import */


      var _ela_cronograma_list_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./ela-cronograma-list.component.scss */
      "ZiYc");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var src_app_interfaces_elaboracion_auditoria_PlanAuditoriaDTO__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! src/app/interfaces/elaboracion_auditoria/PlanAuditoriaDTO */
      "6GDD");

      var ElaCronogramaListComponent = /*#__PURE__*/function () {
        function ElaCronogramaListComponent() {
          _classCallCheck(this, ElaCronogramaListComponent);

          this.guardarCronogramaEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
          this.eliminarCronogramaEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
          this.currentCrongramaIndex = -1;
          this.mode = "LIST";
          this.operation = "UPDATE";
        }

        _createClass(ElaCronogramaListComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            if (!this.listCronograma) {
              this.listCronograma = new Array();
            }
          }
        }, {
          key: "addCronograma",
          value: function addCronograma() {
            this.currentCrongrama = new src_app_interfaces_elaboracion_auditoria_PlanAuditoriaDTO__WEBPACK_IMPORTED_MODULE_4__["Elacronogama"]();
            this.mode = "EDIT";
            this.operation = "ADD";
          }
        }, {
          key: "editarCronograma",
          value: function editarCronograma(index) {
            this.currentCrongrama = this.listCronograma[index];
            this.currentCrongramaIndex = index;
            this.mode = "EDIT";
            this.operation = "UPDATE";
          }
        }, {
          key: "eliminarCronograma",
          value: function eliminarCronograma(index) {
            var idElacronograma = this.listCronograma[index].idElAcronograma;
            this.listCronograma.splice(index, 1);

            if (this.eliminarCronogramaEmitter) {
              this.eliminarCronogramaEmitter.emit(idElacronograma);
            }
          }
        }, {
          key: "guardarCronograma",
          value: function guardarCronograma(event) {
            console.log("*** se guarda en lista", event);
            /*event.idDireccionPaproducto = this.llaves.idDireccionPaproducto;
            event.idDireccionPasistema = this.llaves.idDireccionPasistema;*/

            if (this.operation === "UPDATE") {
              this.listCronograma[this.currentCrongramaIndex] = event;
            } else {
              this.listCronograma.push(event);
            }

            if (this.guardarCronogramaEmitter) {
              this.guardarCronogramaEmitter.emit(this.listCronograma);
            }

            console.log("*** listCronograma", this.listCronograma);
            this.mode = "LIST";
          }
        }, {
          key: "cancelarCronograma",
          value: function cancelarCronograma() {
            this.mode = "LIST";
          }
        }]);

        return ElaCronogramaListComponent;
      }();

      ElaCronogramaListComponent.ctorParameters = function () {
        return [];
      };

      ElaCronogramaListComponent.propDecorators = {
        listCronograma: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        listaParticipantes: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        guardarCronogramaEmitter: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }],
        eliminarCronogramaEmitter: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }],
        listaDirecciones: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        llaves: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }]
      };
      ElaCronogramaListComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: "app-ela-cronograma-list",
        template: _raw_loader_ela_cronograma_list_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_ela_cronograma_list_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], ElaCronogramaListComponent);
      /***/
    },

    /***/
    "P85u":
    /*!*******************************************************************!*\
      !*** ./src/app/components/custom-input/custom-input.component.ts ***!
      \*******************************************************************/

    /*! exports provided: CustomInputComponent */

    /***/
    function P85u(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CustomInputComponent", function () {
        return CustomInputComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_custom_input_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./custom-input.component.html */
      "GYtA");
      /* harmony import */


      var _custom_input_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./custom-input.component.scss */
      "cMJF");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/angular */
      "sZkV");

      var CustomInputComponent = /*#__PURE__*/function () {
        function CustomInputComponent(popoverController) {
          _classCallCheck(this, CustomInputComponent);

          this.popoverController = popoverController;
          this.readonly = false;
          this._ionChange = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
          this.brmasker = {}; //https://github.com/amarkes/br-mask

          this.currentDate = new Date();
          this.formatDate = "DD/MM/YYYY";
          this.maxDate = this.currentDate.getUTCFullYear() + 10;
          this.eventKeyEnterEmiiter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
          console.log("maxDate", this.maxDate);
        }

        _createClass(CustomInputComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this31 = this;

            if (this.formGruop && !this.formGruop.get(this.name)) {
              this.formGruop.addControl(this.name, new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"](this.defaultValue));
              var validators = [];

              if (this.Validations) {
                var _iterator = _createForOfIteratorHelper(this.Validations),
                    _step;

                try {
                  for (_iterator.s(); !(_step = _iterator.n()).done;) {
                    var val = _step.value;
                    validators.push(val.validator);
                  }
                } catch (err) {
                  _iterator.e(err);
                } finally {
                  _iterator.f();
                }

                this.formGruop.controls[this.name].setValidators(validators);
              }
            }

            this.customPickerOption = {
              buttons: [{
                text: "Confirmar",
                handler: function handler(event) {
                  console.log(event);
                  var day = 1;
                  if (event.day) day = event.day.value;
                  _this31.customDate = new Date(event.year.value, event.month.value - 1, day, 0, 0, 0, 0);

                  if (_this31.type === "datetime") {
                    _this31.formGruop.controls[_this31.name]["valueDate"] = _this31.customDate;
                  }

                  if (_this31._ionChange) {
                    if (_this31.popoverController) {
                      _this31.popoverController.dismiss({
                        item: _this31.formGruop.controls[_this31.name]["valueDate"]
                      });
                    }

                    _this31._ionChange.emit(event);
                  }
                }
              }]
            };

            if (this.type === "datetime" && this.defaultValue) {
              var date = new Date(this.defaultValue);
              date.setDate(date.getDate() + 1);
              this.formGruop.controls[this.name]["valueDate"] = date;
            }
          }
        }, {
          key: "ExistsError",
          value: function ExistsError(validator) {
            return validator(this.formGruop.controls[this.name]);
          }
        }, {
          key: "eventKeyEnter",
          value: function eventKeyEnter(event) {
            if (this.popoverController) {
              this.popoverController.dismiss({
                item: this.formGruop.controls[this.name]["value"]
              });
            }

            if (this.eventKeyEnterEmiiter) {
              this.eventKeyEnterEmiiter.emit(event);
            }
          }
        }, {
          key: "Control",
          get: function get() {
            console.log("solicitando el control");
            console.log(this.formGruop.controls[this.name].errors);
            return this.formGruop.controls[this.name];
          }
        }]);

        return CustomInputComponent;
      }();

      CustomInputComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["PopoverController"]
        }];
      };

      CustomInputComponent.propDecorators = {
        readonly: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        label: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        name: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        type: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        formGruop: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        Validations: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        form: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        defaultValue: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        _ionChange: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }],
        brmasker: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        formatDate: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        maxDate: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        eventKeyEnterEmiiter: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }]
      };
      CustomInputComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: "app-custom-input",
        template: _raw_loader_custom_input_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_custom_input_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], CustomInputComponent);
      /***/
    },

    /***/
    "PI2N":
    /*!*************************************************!*\
      !*** ./src/app/interfaces/seguridad/usuario.ts ***!
      \*************************************************/

    /*! exports provided: usuario */

    /***/
    function PI2N(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "usuario", function () {
        return usuario;
      });

      var usuario = function usuario() {
        _classCallCheck(this, usuario);
      };

      usuario.currentUser = {
        nombre: "RUBEN",
        apellidos: "CHALCO",
        oficina: "LA PAZ",
        nick: "ruben.chalco"
      };
      /***/
    },

    /***/
    "Psgn":
    /*!*********************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/tcp-list-products/tcp-list-products.component.html ***!
      \*********************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function Psgn(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<div class=\"container-product-list\">\r\n  <ion-item color=\"medium\" color=\"title-small\" (click)=\"toggle()\">\r\n    <ion-icon name=\"menu\" slot=\"start\"></ion-icon>\r\n    <ion-label> PRODUCTOS / NORMAS / DIRECCIONES</ion-label>\r\n  </ion-item>\r\n  <div *ngIf=\"display\">\r\n    <ion-list *ngIf=\"mode == 'LIST'\">\r\n      <ion-item>\r\n        <ion-label position=\"stacked\">\r\n          Nombre del cliente para el Certificado\r\n        </ion-label>\r\n        <ion-textarea [(ngModel)]=\"nombreOrganizacion\"></ion-textarea>\r\n      </ion-item>\r\n      <ion-list-header class=\"title-normas\">\r\n        <ion-item>\r\n          <ion-icon name=\"add-circle\" slot=\"end\" (click)=\"adicionar()\" class=\"big-icon\"></ion-icon>\r\n          Productos\r\n        </ion-item>\r\n      </ion-list-header>\r\n      <ion-item *ngFor=\"let product of productList; let i = index\">\r\n        <ion-icon name=\"pencil-sharp\" slot=\"start\" (click)=\"editar(product, i)\" class=\"big-icon\"></ion-icon>\r\n        <ion-icon name=\"trash\" slot=\"start\" (click)=\"eliminar(i)\" *ngIf=\"allowDelete\" class=\"big-icon\"></ion-icon>\r\n        <div class=\"norma-block\">\r\n          <h2>\r\n            Nombre: {{ product.nombre }} [Marca: {{ product.marca }}] [Norma:\r\n            {{ product.norma }}]\r\n          </h2>\r\n          <p>\r\n            Dirección <span class=\"sub-title\">{{ product.direccion }}</span> |\r\n            Sello {{ product.sello }}\r\n          </p>\r\n          <!-- <p>\r\n            Sello {{ product.sello }} | Pais: {{ product.pais }} | Departamento:\r\n            {{ product.estado }} | Ciudad: {{ product.ciudad }}\r\n          </p> -->\r\n          <p class=\"detail-paragraph\">\r\n            Fecha Emision Cert. {{ product.fechaEmisionPrimerCertificado }} |\r\n            Fecha Vencimiento Cert. {{ product.fechaVencimientoCertificado }} |\r\n            Nro. Cert.\r\n            {{ product.numeroDeCertificacion }}\r\n          </p>\r\n        </div>\r\n      </ion-item>\r\n    </ion-list>\r\n    <app-product-detail *ngIf=\"mode == 'EDIT'\" [pradireccionespaproducto]=\"currentProduct\"\r\n      (guardarProductEmitter)=\"guardarProducto($event)\" (cancelarProductEmitter)=\"cancelarProducto($event)\">\r\n    </app-product-detail>\r\n  </div>\r\n</div>";
      /***/
    },

    /***/
    "QyFm":
    /*!***********************************************************************************************************!*\
      !*** ./src/app/components/param-organismos-certificadores/param-organismos-certificadores.component.scss ***!
      \***********************************************************************************************************/

    /*! exports provided: default */

    /***/
    function QyFm(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".cargo-select {\n  width: 100%;\n  font-size: 13px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxwYXJhbS1vcmdhbmlzbW9zLWNlcnRpZmljYWRvcmVzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksV0FBQTtFQUNBLGVBQUE7QUFDSiIsImZpbGUiOiJwYXJhbS1vcmdhbmlzbW9zLWNlcnRpZmljYWRvcmVzLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNhcmdvLXNlbGVjdHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgZm9udC1zaXplOiAxM3B4O1xyXG59Il19 */";
      /***/
    },

    /***/
    "R3PH":
    /*!*******************************************************************!*\
      !*** ./src/app/components/param-paises/param-paises.component.ts ***!
      \*******************************************************************/

    /*! exports provided: ParamPaisesComponent */

    /***/
    function R3PH(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ParamPaisesComponent", function () {
        return ParamPaisesComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_param_paises_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./param-paises.component.html */
      "1iny");
      /* harmony import */


      var _param_paises_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./param-paises.component.scss */
      "oNGt");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var src_app_interfaces_General_Localizacion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! src/app/interfaces/General/Localizacion */
      "uBMp");
      /* harmony import */


      var src_app_services_apertura_auditoria_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! src/app/services/apertura-auditoria.service */
      "Aoky");

      var ParamPaisesComponent = /*#__PURE__*/function () {
        function ParamPaisesComponent(aperturaAuditoriaService) {
          _classCallCheck(this, ParamPaisesComponent);

          this.aperturaAuditoriaService = aperturaAuditoriaService;
          this.currentLocalizacion = new src_app_interfaces_General_Localizacion__WEBPACK_IMPORTED_MODULE_4__["Localizacion"]();
          this.selectLocalizacionEmit = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        }

        _createClass(ParamPaisesComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.buscarPaisInit(this.defaulValue);
          }
        }, {
          key: "buscarPais",
          value: function buscarPais(event) {
            var _this32 = this;

            var codigoPais = event.detail.value;

            if (codigoPais.length > 3) {
              console.log("buscamos el pais");
              this.aperturaAuditoriaService.BuscarPais(codigoPais).subscribe(function (x) {
                console.log(x);
                _this32.listaPaises = x.listEntities;
              });
            }
          }
        }, {
          key: "buscarPaisInit",
          value: function buscarPaisInit(_pais) {
            var _this33 = this;

            this.aperturaAuditoriaService.BuscarPais(_pais).subscribe(function (x) {
              _this33.listaPaises = x.listEntities;
              if (_this33.listaPaises && _this33.listaPaises.length > 0) _this33.currentPais = _this33.listaPaises[0];
            });
          }
        }, {
          key: "seleccionarPais",
          value: function seleccionarPais(event) {
            console.log("seleccionar pais", event);
            this.currentPais = event.detail.value;
            this.buscarEstados(event.detail.value.idPais);
          }
        }, {
          key: "buscarEstados",
          value: function buscarEstados(IdPais) {
            var _this34 = this;

            console.log("buscamos el estado");
            this.aperturaAuditoriaService.BuscarEstado(IdPais).subscribe(function (x) {
              console.log(x);
              _this34.listaEstados = x.listEntities;
            });
          }
        }, {
          key: "seleccionarEstado",
          value: function seleccionarEstado(event) {
            console.log("Estado Seleccionado", event);
            this.currentEstado = event.detail.value;
            this.buscarCiudad(event.detail.value.idEstado);
          }
        }, {
          key: "buscarCiudad",
          value: function buscarCiudad(iDEstado) {
            var _this35 = this;

            this.aperturaAuditoriaService.BuscarCiudad(iDEstado).subscribe(function (x) {
              console.log(x);
              _this35.listaCiudades = x.listEntities;
            });
          }
        }, {
          key: "seleccionarCiudad",
          value: function seleccionarCiudad(event) {
            this.currentCiudad = event.detail.value;
            this.currentLocalizacion.ciudad = this.currentCiudad;
            this.currentLocalizacion.estado = this.currentEstado;
            this.currentLocalizacion.pais = this.currentPais;

            if (this.selectLocalizacionEmit) {
              this.selectLocalizacionEmit.emit(this.currentLocalizacion);
            }
          }
        }]);

        return ParamPaisesComponent;
      }();

      ParamPaisesComponent.ctorParameters = function () {
        return [{
          type: src_app_services_apertura_auditoria_service__WEBPACK_IMPORTED_MODULE_5__["AperturaAuditoriaService"]
        }];
      };

      ParamPaisesComponent.propDecorators = {
        defaulValue: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        selectLocalizacionEmit: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }]
      };
      ParamPaisesComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: "app-param-paises",
        template: _raw_loader_param_paises_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_param_paises_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], ParamPaisesComponent);
      /***/
    },

    /***/
    "RA6F":
    /*!***********************************************************************!*\
      !*** ./src/app/components/message-error/message-error.component.scss ***!
      \***********************************************************************/

    /*! exports provided: default */

    /***/
    function RA6F(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".error-message {\n  color: #fcfcfc;\n}\n\n.container-error {\n  background-color: rgba(221, 19, 19, 0.953) !important;\n  display: block;\n  padding-left: 2em;\n  padding-top: 2px;\n  padding-bottom: 2px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxtZXNzYWdlLWVycm9yLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksY0FBQTtBQUNKOztBQUNBO0VBQ0kscURBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FBRUoiLCJmaWxlIjoibWVzc2FnZS1lcnJvci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5lcnJvci1tZXNzYWdle1xyXG4gICAgY29sb3I6IHJnYigyNTIsIDI1MiwgMjUyKTtcclxufVxyXG4uY29udGFpbmVyLWVycm9ye1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogcmdiYSgyMjEsIDE5LCAxOSwgMC45NTMpICFpbXBvcnRhbnQ7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIHBhZGRpbmctbGVmdDogMmVtOyAgICBcclxuICAgIHBhZGRpbmctdG9wOiAycHg7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMnB4O1xyXG59XHJcbiJdfQ== */";
      /***/
    },

    /***/
    "RWpN":
    /*!********************************************************!*\
      !*** ./src/app/services/docmentos-services.service.ts ***!
      \********************************************************/

    /*! exports provided: DocmentosServicesService */

    /***/
    function RWpN(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "DocmentosServicesService", function () {
        return DocmentosServicesService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/common/http */
      "IheW");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @ionic/angular */
      "sZkV");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! rxjs */
      "qCKp");
      /* harmony import */


      var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! rxjs/operators */
      "kU1M");
      /* harmony import */


      var src_environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! src/environments/environment */
      "AytR");
      /* harmony import */


      var _baseService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./baseService */
      "zrJw");
      /* harmony import */


      var _database_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ./database.service */
      "ZJFI");

      var headers = src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["HEADERS_SERVICE"];
      var url_elaboracion = src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["URL_ELABORACION"];

      var DocmentosServicesService = /*#__PURE__*/function (_baseService__WEBPACK3) {
        _inherits(DocmentosServicesService, _baseService__WEBPACK3);

        var _super3 = _createSuper(DocmentosServicesService);

        function DocmentosServicesService(databaseService, httpClient, loadingController, toastController) {
          var _this36;

          _classCallCheck(this, DocmentosServicesService);

          _this36 = _super3.call(this, databaseService, httpClient, loadingController, toastController);
          _this36.databaseService = databaseService;
          _this36.httpClient = httpClient;
          _this36.loadingController = loadingController;
          _this36.toastController = toastController;
          return _this36;
        }

        _createClass(DocmentosServicesService, [{
          key: "GenerarDocumento",
          value: function GenerarDocumento(IdCiclo, Plantilla) {
            var _this37 = this;

            var url_query = url_elaboracion + "GenerarDocumento";
            var dataRequest = {
              idCicloAuditoria: IdCiclo,
              nombrePlantilla: Plantilla
            };
            this.presentLoader();
            this.httpClient.post(url_query, JSON.stringify(dataRequest), {
              headers: headers
            }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["finalize"])(function () {
              console.log("se termino la llamada GenerarDocumento");

              _this37.dismissLoader();
            }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["catchError"])(function (error) {
              _this37.showMessageError("No se tiene comunicacion con el servidor");

              return rxjs__WEBPACK_IMPORTED_MODULE_4__["Observable"]["throw"](new Error(error.status));
            })).subscribe(function (x) {
              if (x.state !== 1) {
                _this37.showMessageError("Error en la plantilla: " + x.message);

                return;
              }

              _this37.ObtenerArchivo(x.message, Plantilla);
            });
          }
        }, {
          key: "ObtenerArchivo",
          value: function ObtenerArchivo(fileName, nombrePlantilla) {
            var _this38 = this;

            var url_query = url_elaboracion + "ObtenerArchivo?fileName=" + fileName;
            this.httpClient.get(url_query, {
              responseType: "arraybuffer",
              headers: headers
            }) //.subscribe((response) => this.downLoadFile(response, "application/pdf"));
            .subscribe(function (response) {
              return _this38.downLoadFileWord(response, nombrePlantilla + ".doc");
            });
          }
        }, {
          key: "downLoadFile",
          value: function downLoadFile(data, type) {
            var blob = new Blob([data], {
              type: type
            });
            var url = window.URL.createObjectURL(blob);
            var pwa = window.open(url);

            if (!pwa || pwa.closed || typeof pwa.closed == "undefined") {
              alert("Por favor deshabilite los bloqueadores de descarga para continuar.");
            }
          }
        }, {
          key: "downLoadFileWord",
          value: function downLoadFileWord(data, fileName) {
            var blob = new Blob([data], {
              type: "application/octet-stream"
            });
            var link = document.createElement("a");
            link.href = URL.createObjectURL(blob);
            link.download = fileName;
            link.click();
          }
        }]);

        return DocmentosServicesService;
      }(_baseService__WEBPACK_IMPORTED_MODULE_7__["BaseService"]);

      DocmentosServicesService.ctorParameters = function () {
        return [{
          type: _database_service__WEBPACK_IMPORTED_MODULE_8__["DatabaseService"]
        }, {
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"]
        }];
      };

      DocmentosServicesService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: "root"
      })], DocmentosServicesService);
      /***/
    },

    /***/
    "Sy1n":
    /*!**********************************!*\
      !*** ./src/app/app.component.ts ***!
      \**********************************/

    /*! exports provided: AppComponent */

    /***/
    function Sy1n(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppComponent", function () {
        return AppComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./app.component.html */
      "VzVu");
      /* harmony import */


      var _app_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./app.component.scss */
      "ynWL");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "sZkV");
      /* harmony import */


      var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic-native/splash-screen/ngx */
      "y2f/");
      /* harmony import */


      var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic-native/status-bar/ngx */
      "p74H");

      var AppComponent = /*#__PURE__*/function () {
        function AppComponent(platform, splashScreen, statusBar) {
          _classCallCheck(this, AppComponent);

          this.platform = platform;
          this.splashScreen = splashScreen;
          this.statusBar = statusBar;
          this.selectedIndex = 0;
          this.appPages = [{
            title: 'Inbox',
            url: '/folder/Inbox',
            icon: 'mail'
          }, {
            title: 'Outbox',
            url: '/folder/Outbox',
            icon: 'paper-plane'
          }, {
            title: 'Favorites',
            url: '/folder/Favorites',
            icon: 'heart'
          }, {
            title: 'Archived',
            url: '/folder/Archived',
            icon: 'archive'
          }, {
            title: 'Trash',
            url: '/folder/Trash',
            icon: 'trash'
          }, {
            title: 'Spam',
            url: '/folder/Spam',
            icon: 'warning'
          }];
          this.labels = ['Family', 'Friends', 'Notes', 'Work', 'Travel', 'Reminders'];
          this.initializeApp();
        }

        _createClass(AppComponent, [{
          key: "initializeApp",
          value: function initializeApp() {
            var _this39 = this;

            this.platform.ready().then(function () {
              _this39.statusBar.styleDefault();

              _this39.splashScreen.hide();
            });
          }
        }, {
          key: "ngOnInit",
          value: function ngOnInit() {
            var path = window.location.pathname.split('folder/')[1];

            if (path !== undefined) {
              this.selectedIndex = this.appPages.findIndex(function (page) {
                return page.title.toLowerCase() === path.toLowerCase();
              });
            }
          }
        }]);

        return AppComponent;
      }();

      AppComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"]
        }, {
          type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"]
        }, {
          type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"]
        }];
      };

      AppComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-root',
        template: _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_app_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], AppComponent);
      /***/
    },

    /***/
    "T21K":
    /*!*************************************************************************!*\
      !*** ./src/app/components/plan-auditoria/plan-auditoria.component.scss ***!
      \*************************************************************************/

    /*! exports provided: default */

    /***/
    function T21K(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".ciclo-header {\n  background-color: #3bb8bd;\n  color: #e626d6;\n  font-weight: 300;\n  font-size: 16px;\n}\n\n.slider .slider-pager {\n  color: blue;\n}\n\n.slide-full {\n  width: 100% !important;\n}\n\n.avatar {\n  width: 50px;\n  display: block;\n  margin-left: auto;\n  margin-right: auto;\n}\n\nion-card-content {\n  text-align: left;\n}\n\n.ion-content-small-font {\n  font-family: \"Calibri Light\";\n  font-size: 12px;\n  color: #093537;\n}\n\n.container-detail-auditoria {\n  width: 100%;\n}\n\n.container-detail-certificacion {\n  margin-bottom: 15px;\n}\n\n.buttons-group {\n  margin-top: 5px;\n}\n\n.title-medium-font {\n  font-family: \"Courier New\";\n  font-weight: bold;\n}\n\n.big-icon {\n  font-size: 1.2em;\n  margin-left: 3px;\n  cursor: -webkit-grab;\n  cursor: grab;\n}\n\n.box-click {\n  min-width: 100px;\n  min-height: 20px;\n  border-bottom: solid;\n  border-color: #778e8f;\n  border-width: 1px;\n  padding: 2px;\n  margin-left: 3px;\n  display: inline-block;\n}\n\n.edit-item {\n  cursor: -webkit-grab;\n  cursor: grab;\n}\n\n.edit-item:hover {\n  background-color: #9dd8dc;\n}\n\n.small-item {\n  font-size: 13px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxwbGFuLWF1ZGl0b3JpYS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHlCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQUNGOztBQUNBO0VBQ0UsV0FBQTtBQUVGOztBQUFBO0VBQ0Usc0JBQUE7QUFHRjs7QUFBQTtFQUNFLFdBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtBQUdGOztBQURBO0VBQ0UsZ0JBQUE7QUFJRjs7QUFEQTtFQUNFLDRCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUFJRjs7QUFGQTtFQUNFLFdBQUE7QUFLRjs7QUFIQTtFQUNFLG1CQUFBO0FBTUY7O0FBSkE7RUFDRSxlQUFBO0FBT0Y7O0FBTEE7RUFDRSwwQkFBQTtFQUNBLGlCQUFBO0FBUUY7O0FBTkE7RUFDRSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0Esb0JBQUE7RUFBQSxZQUFBO0FBU0Y7O0FBUEE7RUFDRSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0Esb0JBQUE7RUFDQSxxQkFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EscUJBQUE7QUFVRjs7QUFSQTtFQUNFLG9CQUFBO0VBQUEsWUFBQTtBQVdGOztBQVRBO0VBQ0UseUJBQUE7QUFZRjs7QUFUQTtFQUNFLGVBQUE7QUFZRiIsImZpbGUiOiJwbGFuLWF1ZGl0b3JpYS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jaWNsby1oZWFkZXIge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICMzYmI4YmQ7XHJcbiAgY29sb3I6ICNlNjI2ZDY7XHJcbiAgZm9udC13ZWlnaHQ6IDMwMDtcclxuICBmb250LXNpemU6IDE2cHg7XHJcbn1cclxuLnNsaWRlciAuc2xpZGVyLXBhZ2VyIHtcclxuICBjb2xvcjogYmx1ZTtcclxufVxyXG4uc2xpZGUtZnVsbCB7XHJcbiAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmF2YXRhciB7XHJcbiAgd2lkdGg6IDUwcHg7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgbWFyZ2luLWxlZnQ6IGF1dG87XHJcbiAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xyXG59XHJcbmlvbi1jYXJkLWNvbnRlbnQge1xyXG4gIHRleHQtYWxpZ246IGxlZnQ7XHJcbn1cclxuXHJcbi5pb24tY29udGVudC1zbWFsbC1mb250IHtcclxuICBmb250LWZhbWlseTogXCJDYWxpYnJpIExpZ2h0XCI7XHJcbiAgZm9udC1zaXplOiAxMnB4O1xyXG4gIGNvbG9yOiAjMDkzNTM3O1xyXG59XHJcbi5jb250YWluZXItZGV0YWlsLWF1ZGl0b3JpYSB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbn1cclxuLmNvbnRhaW5lci1kZXRhaWwtY2VydGlmaWNhY2lvbiB7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTVweDtcclxufVxyXG4uYnV0dG9ucy1ncm91cCB7XHJcbiAgbWFyZ2luLXRvcDogNXB4O1xyXG59XHJcbi50aXRsZS1tZWRpdW0tZm9udCB7XHJcbiAgZm9udC1mYW1pbHk6IFwiQ291cmllciBOZXdcIjtcclxuICBmb250LXdlaWdodDogYm9sZDtcclxufVxyXG4uYmlnLWljb24ge1xyXG4gIGZvbnQtc2l6ZTogMS4yZW07XHJcbiAgbWFyZ2luLWxlZnQ6IDNweDtcclxuICBjdXJzb3I6IGdyYWI7XHJcbn1cclxuLmJveC1jbGljayB7XHJcbiAgbWluLXdpZHRoOiAxMDBweDtcclxuICBtaW4taGVpZ2h0OiAyMHB4O1xyXG4gIGJvcmRlci1ib3R0b206IHNvbGlkO1xyXG4gIGJvcmRlci1jb2xvcjogIzc3OGU4ZjtcclxuICBib3JkZXItd2lkdGg6IDFweDtcclxuICBwYWRkaW5nOiAycHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDNweDtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbn1cclxuLmVkaXQtaXRlbSB7XHJcbiAgY3Vyc29yOiBncmFiO1xyXG59XHJcbi5lZGl0LWl0ZW06aG92ZXIge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICM5ZGQ4ZGM7XHJcbn1cclxuXHJcbi5zbWFsbC1pdGVtIHtcclxuICBmb250LXNpemU6IDEzcHg7XHJcbn1cclxuIl19 */";
      /***/
    },

    /***/
    "Totv":
    /*!*****************************************************************************************!*\
      !*** ./src/app/components/ela-registro-hallazgos/ela-registro-hallazgos.component.scss ***!
      \*****************************************************************************************/

    /*! exports provided: default */

    /***/
    function Totv(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".normas {\n  font-size: 12px;\n  color: #1b192c;\n}\n\n.title-normas {\n  color: #0b480f;\n  font-size: 1em;\n  text-align: left;\n}\n\n.norma-block {\n  background-color: #c6e8e6;\n  padding: 10px;\n  margin: 1.5px;\n  min-width: 100%;\n}\n\n.big-icon {\n  font-size: 2em;\n  margin-left: 3px;\n  cursor: -webkit-grab;\n  cursor: grab;\n}\n\n.detail-paragraph {\n  font-size: 11px;\n  color: #3d3c44;\n}\n\n.sub-title {\n  /*font-style: italic;*/\n  font-size: 13px;\n  color: #055a0f;\n  font-family: sans-serif;\n}\n\n.sub-title-horario {\n  /*font-style: italic;*/\n  font-size: 13px;\n  color: #dfd0f2;\n  font-family: sans-serif;\n}\n\n.direccion-block {\n  background-color: #c1ebd6;\n  padding: 10px;\n  margin: 1.5px;\n  min-width: 100%;\n}\n\n.horario-block {\n  background-color: #1c1118;\n  padding: 20px;\n  margin: 0.5px;\n  min-width: 100%;\n}\n\n.horario-block p {\n  color: #c6e8e6;\n}\n\n.titles {\n  font-style: italic;\n  font-weight: 300;\n  font-size: 18px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxlbGEtcmVnaXN0cm8taGFsbGF6Z29zLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZUFBQTtFQUNBLGNBQUE7QUFDSjs7QUFDRTtFQUNFLGNBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7QUFFSjs7QUFBRTtFQUNFLHlCQUFBO0VBQ0EsYUFBQTtFQUNBLGFBQUE7RUFDQSxlQUFBO0FBR0o7O0FBREU7RUFDRSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxvQkFBQTtFQUFBLFlBQUE7QUFJSjs7QUFGRTtFQUNFLGVBQUE7RUFDQSxjQUFBO0FBS0o7O0FBSEU7RUFDRSxzQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsdUJBQUE7QUFNSjs7QUFIRTtFQUNFLHNCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSx1QkFBQTtBQU1KOztBQUpFO0VBQ0UseUJBQUE7RUFDQSxhQUFBO0VBQ0EsYUFBQTtFQUNBLGVBQUE7QUFPSjs7QUFMRTtFQUNFLHlCQUFBO0VBQ0EsYUFBQTtFQUNBLGFBQUE7RUFDQSxlQUFBO0FBUUo7O0FBTkU7RUFDRSxjQUFBO0FBU0o7O0FBUEU7RUFDRSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQVVKIiwiZmlsZSI6ImVsYS1yZWdpc3Ryby1oYWxsYXpnb3MuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubm9ybWFzIHtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIGNvbG9yOiAjMWIxOTJjO1xyXG4gIH1cclxuICAudGl0bGUtbm9ybWFzIHtcclxuICAgIGNvbG9yOiAjMGI0ODBmO1xyXG4gICAgZm9udC1zaXplOiAxZW07XHJcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gIH1cclxuICAubm9ybWEtYmxvY2sge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2M2ZThlNjtcclxuICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICBtYXJnaW46IDEuNXB4O1xyXG4gICAgbWluLXdpZHRoOiAxMDAlO1xyXG4gIH1cclxuICAuYmlnLWljb24ge1xyXG4gICAgZm9udC1zaXplOiAyZW07XHJcbiAgICBtYXJnaW4tbGVmdDogM3B4O1xyXG4gICAgY3Vyc29yOiBncmFiO1xyXG4gIH1cclxuICAuZGV0YWlsLXBhcmFncmFwaCB7XHJcbiAgICBmb250LXNpemU6IDExcHg7XHJcbiAgICBjb2xvcjogIzNkM2M0NDtcclxuICB9XHJcbiAgLnN1Yi10aXRsZSB7XHJcbiAgICAvKmZvbnQtc3R5bGU6IGl0YWxpYzsqL1xyXG4gICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgY29sb3I6ICMwNTVhMGY7XHJcbiAgICBmb250LWZhbWlseTogc2Fucy1zZXJpZjtcclxuICB9XHJcbiAgXHJcbiAgLnN1Yi10aXRsZS1ob3JhcmlvIHtcclxuICAgIC8qZm9udC1zdHlsZTogaXRhbGljOyovXHJcbiAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICBjb2xvcjogI2RmZDBmMjtcclxuICAgIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xyXG4gIH1cclxuICAuZGlyZWNjaW9uLWJsb2NrIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNjMWViZDY7XHJcbiAgICBwYWRkaW5nOiAxMHB4O1xyXG4gICAgbWFyZ2luOiAxLjVweDtcclxuICAgIG1pbi13aWR0aDogMTAwJTtcclxuICB9XHJcbiAgLmhvcmFyaW8tYmxvY2sge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzFjMTExODtcclxuICAgIHBhZGRpbmc6IDIwcHg7XHJcbiAgICBtYXJnaW46IDAuNXB4O1xyXG4gICAgbWluLXdpZHRoOiAxMDAlO1xyXG4gIH1cclxuICAuaG9yYXJpby1ibG9jayBwe1xyXG4gICAgY29sb3I6ICNjNmU4ZTY7XHJcbiAgfVxyXG4gIC50aXRsZXMge1xyXG4gICAgZm9udC1zdHlsZTogaXRhbGljO1xyXG4gICAgZm9udC13ZWlnaHQ6IDMwMDtcclxuICAgIGZvbnQtc2l6ZTogMThweDtcclxuICB9XHJcbiAgIl19 */";
      /***/
    },

    /***/
    "VzVu":
    /*!**************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
      \**************************************************************************/

    /*! exports provided: default */

    /***/
    function VzVu(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-app>\n  <ion-split-pane contentId=\"main-content\">\n    <!--<ion-menu contentId=\"main-content\" type=\"overlay\">\n      <ion-content>\n        <ion-list id=\"inbox-list\">\n          <ion-list-header>Inbox</ion-list-header>\n          <ion-note>hi@ionicframework.com</ion-note>\n\n            <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages; let i = index\">\n            <ion-item (click)=\"selectedIndex = i\" routerDirection=\"root\" [routerLink]=\"[p.url]\" lines=\"none\" detail=\"false\" [class.selected]=\"selectedIndex == i\">\n              <ion-icon slot=\"start\" [ios]=\"p.icon + '-outline'\" [md]=\"p.icon + '-sharp'\"></ion-icon>\n              <ion-label>{{ p.title }}</ion-label>\n            </ion-item>\n          </ion-menu-toggle>\n        </ion-list>\n\n        <ion-list id=\"labels-list\">\n          <ion-list-header>Labels</ion-list-header>\n\n          <ion-item *ngFor=\"let label of labels\" lines=\"none\">\n            <ion-icon\n              slot=\"start\"\n              ios=\"bookmark-outline\"\n              md=\"bookmark-sharp\"\n            ></ion-icon>\n            <ion-label>{{ label }}</ion-label>\n          </ion-item>\n        </ion-list>\n      </ion-content>\n    </ion-menu>-->\n    <ion-router-outlet id=\"main-content\"></ion-router-outlet>\n  </ion-split-pane>\n</ion-app>\n";
      /***/
    },

    /***/
    "W7oR":
    /*!*******************************************************!*\
      !*** ./src/app/components/meses/meses.component.scss ***!
      \*******************************************************/

    /*! exports provided: default */

    /***/
    function W7oR(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtZXNlcy5jb21wb25lbnQuc2NzcyJ9 */";
      /***/
    },

    /***/
    "WD1i":
    /*!*************************************************************************************************************************!*\
      !*** ./src/app/components/tcs-lista-verificacion-reunion-apertura/tcs-lista-verificacion-reunion-apertura.component.ts ***!
      \*************************************************************************************************************************/

    /*! exports provided: TcsListaVerificacionReunionAperturaComponent */

    /***/
    function WD1i(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "TcsListaVerificacionReunionAperturaComponent", function () {
        return TcsListaVerificacionReunionAperturaComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_tcs_lista_verificacion_reunion_apertura_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./tcs-lista-verificacion-reunion-apertura.component.html */
      "gfLP");
      /* harmony import */


      var _tcs_lista_verificacion_reunion_apertura_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./tcs-lista-verificacion-reunion-apertura.component.scss */
      "u2kC");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var src_app_services_elaboracion_auditoria_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! src/app/services/elaboracion-auditoria.service */
      "6V/C");

      var TcsListaVerificacionReunionAperturaComponent = /*#__PURE__*/function () {
        function TcsListaVerificacionReunionAperturaComponent(elaboracionAuditoriaService) {
          _classCallCheck(this, TcsListaVerificacionReunionAperturaComponent);

          this.elaboracionAuditoriaService = elaboracionAuditoriaService;
          this.checkBoxList = [{
            item: '1.',
            value: "Presentación del equipo auditor, incluyendo una breve descripción de funciones.",
            isChecked: false
          }, {
            item: '2.',
            value: "Confirmación del idioma que se utilizará durante la auditoría.",
            isChecked: false
          }, {
            item: '3.',
            value: "Confirmación de los temas relativos a la confidencialidad.",
            isChecked: false
          }, {
            item: '4.',
            value: "Confirmación del alcance y objetivos de la auditoría, norma auditada.",
            isChecked: false
          }, {
            item: '5.',
            value: "Confirmación del plan de auditoría (incluye tipo y alcance de auditoría los objetivos y los criterios), cualquier cambio, y otros acuerdos pertinentes con el cliente.",
            isChecked: false
          }, {
            item: '6.',
            value: "Confirmación de los canales comunicación formal.",
            isChecked: false
          }, {
            item: '7.',
            value: "Confirmación del estado de los hallazgos de la revisión o auditoría anterior cuando corresponda.",
            isChecked: false
          }, {
            item: '8.',
            value: "Confirmación de la disponibilidad, de las funciones y de la identidad de los guías y observadores.",
            isChecked: false
          }, {
            item: '9.',
            value: "El método para presentar la información, incluyendo cualquier categorización de los hallazgos de la auditoría.",
            isChecked: false
          }, {
            item: '10 .',
            value: "Información sobre las condiciones bajo las cuales la auditoría puede darse por terminada prematuramente.",
            isChecked: false
          }, {
            item: '11.',
            value: "Confirmación que durante la auditoría se mantendrá informada a la organización sobre el proceso de la auditoría y cualquier problema.",
            isChecked: false
          }, {
            item: '12.',
            value: "Confirmación de que el líder y los miembros del equipo auditor, que representan a IBNORCA, son responsables de la auditoría y que deben controlar la ejecución del plan de auditoría, incluyendo las actividades y las líneas de investigación de la auditoría.",
            isChecked: false
          }, {
            item: '13.',
            value: "Los métodos y procedimientos a utilizar para llevar a cabo la auditoría sobre la base de un muestreo.",
            isChecked: false
          }, {
            item: '14.',
            value: "Confirmación de que están disponibles los recursos y la logística necesaria para el equipo auditor.",
            isChecked: false
          }, {
            item: '15.',
            value: "Confirmación de los procedimientos de protección, emergencia y seguridad en el trabajo pertinentes para el equipo auditor.",
            isChecked: false
          }, {
            item: '16.',
            value: "Confirmación de las TICs a aplicar y su disponibilidad.",
            isChecked: false
          }, {
            item: '17.',
            value: "Aclaraciones.",
            isChecked: false
          }];
        }

        _createClass(TcsListaVerificacionReunionAperturaComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this40 = this;

            this.elaboracionAuditoriaService.GetListasVerificacion(1).subscribe(function (resul) {
              _this40.pParamitemselect = resul.listEntities;
            });
          }
        }, {
          key: "checkMaster",
          value: function checkMaster() {
            var _this41 = this;

            setTimeout(function () {
              _this41.checkBoxList.forEach(function (obj) {
                obj.isChecked = _this41.masterCheck;
              });
            });
          }
        }, {
          key: "checkEvent",
          value: function checkEvent() {
            var totalItems = this.checkBoxList.length;
            var checked = 0;
            this.checkBoxList.map(function (obj) {
              if (obj.isChecked) checked++;
            });

            if (checked > 0 && checked < totalItems) {
              //If even one item is checked but not all
              this.isIndeterminate = true;
              this.masterCheck = false;
            } else if (checked == totalItems) {
              //If all are checked
              this.masterCheck = true;
              this.isIndeterminate = false;
            } else {
              //If none is checked
              this.isIndeterminate = false;
              this.masterCheck = false;
            }
          }
        }]);

        return TcsListaVerificacionReunionAperturaComponent;
      }();

      TcsListaVerificacionReunionAperturaComponent.ctorParameters = function () {
        return [{
          type: src_app_services_elaboracion_auditoria_service__WEBPACK_IMPORTED_MODULE_4__["ElaboracionAuditoriaService"]
        }];
      };

      TcsListaVerificacionReunionAperturaComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-tcs-lista-verificacion-reunion-apertura',
        template: _raw_loader_tcs_lista_verificacion_reunion_apertura_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_tcs_lista_verificacion_reunion_apertura_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], TcsListaVerificacionReunionAperturaComponent);
      /***/
    },

    /***/
    "Wcuq":
    /*!*************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/ela-objetivos/ela-objetivos.component.html ***!
      \*************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function Wcuq(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-list>\r\n  <ion-item>\r\n    <ion-button\r\n      size=\"small\"\r\n      fill=\"outline\"\r\n      color=\"success\"\r\n      (click)=\"guardarContenido()\"    >\r\n      <ion-icon slot=\"start\" name=\"caret-up-outline\"></ion-icon>\r\n      Guardar\r\n    </ion-button>\r\n  </ion-item>\r\n  <div *ngFor=\"let subtitulo of listSubtitulos; let i = index\">\r\n    <ion-list-header lines=\"full\">\r\n      <ion-text color=\"primary\">\r\n        <h3>{{ i + 1 }}. {{ subtitulo.titulo }}</h3>\r\n      </ion-text>\r\n    </ion-list-header>\r\n    <ion-item *ngFor=\"let contenido of ListByCategoria(subtitulo.nemotico)\">\r\n      <ion-label position=\"floating\" color=\"secondary\">{{\r\n        contenido.label\r\n      }}</ion-label>\r\n      <ion-textarea [(ngModel)]=\"contenido.contenido\" rows=\"4\"></ion-textarea>\r\n      <ion-checkbox slot=\"end\" [(ngModel)]=\"contenido['select']\"></ion-checkbox>\r\n    </ion-item>\r\n  </div>\r\n</ion-list>\r\n";
      /***/
    },

    /***/
    "Yp8f":
    /*!*************************************************************************!*\
      !*** ./src/app/components/product-detail/product-detail.component.scss ***!
      \*************************************************************************/

    /*! exports provided: default */

    /***/
    function Yp8f(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".container-product {\n  width: 80%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxwcm9kdWN0LWRldGFpbC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFVBQUE7QUFDSiIsImZpbGUiOiJwcm9kdWN0LWRldGFpbC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXItcHJvZHVjdHtcclxuICAgIHdpZHRoOiA4MCU7XHJcbn1cclxuIl19 */";
      /***/
    },

    /***/
    "Z1IW":
    /*!***************************************************************************!*\
      !*** ./src/app/interfaces/apertura_auditoria/Praprogramasdeauditorium.ts ***!
      \***************************************************************************/

    /*! exports provided: Praprogramasdeauditorium, Praciclosprogauditorium, Praciclocronograma, Praciclonormassistema, Pracicloparticipante, Pradireccionespaproducto, Pradireccionespasistema */

    /***/
    function Z1IW(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Praprogramasdeauditorium", function () {
        return Praprogramasdeauditorium;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Praciclosprogauditorium", function () {
        return Praciclosprogauditorium;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Praciclocronograma", function () {
        return Praciclocronograma;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Praciclonormassistema", function () {
        return Praciclonormassistema;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Pracicloparticipante", function () {
        return Pracicloparticipante;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Pradireccionespaproducto", function () {
        return Pradireccionespaproducto;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Pradireccionespasistema", function () {
        return Pradireccionespasistema;
      });

      var Praprogramasdeauditorium = function Praprogramasdeauditorium() {
        _classCallCheck(this, Praprogramasdeauditorium);
      };

      var Praciclosprogauditorium = function Praciclosprogauditorium() {
        _classCallCheck(this, Praciclosprogauditorium);
      };

      var Praciclocronograma = function Praciclocronograma() {
        _classCallCheck(this, Praciclocronograma);
      };

      var Praciclonormassistema = function Praciclonormassistema() {
        _classCallCheck(this, Praciclonormassistema);
      };

      var Pracicloparticipante = function Pracicloparticipante() {
        _classCallCheck(this, Pracicloparticipante);
      };

      var Pradireccionespaproducto = function Pradireccionespaproducto() {
        _classCallCheck(this, Pradireccionespaproducto);
      };

      var Pradireccionespasistema = function Pradireccionespasistema() {
        _classCallCheck(this, Pradireccionespasistema);
      };
      /***/

    },

    /***/
    "ZAI4":
    /*!*******************************!*\
      !*** ./src/app/app.module.ts ***!
      \*******************************/

    /*! exports provided: AppModule */

    /***/
    function ZAI4(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppModule", function () {
        return AppModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/platform-browser */
      "cUpR");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      "iInd");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "sZkV");
      /* harmony import */


      var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic-native/splash-screen/ngx */
      "y2f/");
      /* harmony import */


      var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic-native/status-bar/ngx */
      "p74H");
      /* harmony import */


      var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./app.component */
      "Sy1n");
      /* harmony import */


      var _app_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ./app-routing.module */
      "vY5A");
      /* harmony import */


      var _ionic_storage__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! @ionic/storage */
      "xgBC");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! @angular/common/http */
      "IheW");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var br_mask__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! br-mask */
      "mzEM");
      /* harmony import */


      var _components_components_module__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! ./components/components.module */
      "j1ZV");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
      /*! @angular/common */
      "SVse");

      var AppModule = function AppModule() {
        _classCallCheck(this, AppModule);
      };

      AppModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]],
        entryComponents: [],
        imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot(), _ionic_storage__WEBPACK_IMPORTED_MODULE_9__["IonicStorageModule"].forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_8__["AppRoutingModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_10__["HttpClientModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_11__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_11__["ReactiveFormsModule"], br_mask__WEBPACK_IMPORTED_MODULE_12__["BrMaskerModule"], _components_components_module__WEBPACK_IMPORTED_MODULE_13__["ComponentsModule"]],
        providers: [_ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"], _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"], _angular_common__WEBPACK_IMPORTED_MODULE_14__["DatePipe"], {
          provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"],
          useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"]
        }],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]]
      })], AppModule);
      /***/
    },

    /***/
    "ZJFI":
    /*!**********************************************!*\
      !*** ./src/app/services/database.service.ts ***!
      \**********************************************/

    /*! exports provided: DatabaseService */

    /***/
    function ZJFI(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "DatabaseService", function () {
        return DatabaseService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _ionic_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic/storage */
      "xgBC");

      var DatabaseService = /*#__PURE__*/function () {
        function DatabaseService(storage) {
          _classCallCheck(this, DatabaseService);

          this.storage = storage;
        }

        _createClass(DatabaseService, [{
          key: "testDB",
          value: function testDB() {
            this.storage.set("persona", {
              nombre: "ruben",
              apellido: "chalco"
            });
            console.log("dato rescatado", this.storage.get("persona"));
          }
        }, {
          key: "setItem",
          value: function setItem(key, _object) {
            this.storage.set(key, _object);
          }
        }, {
          key: "getItem",
          value: function getItem(key) {
            return this.storage.get(key);
          }
        }, {
          key: "removeItem",
          value: function removeItem(key) {
            return this.storage.remove(key);
          }
        }]);

        return DatabaseService;
      }();

      DatabaseService.ctorParameters = function () {
        return [{
          type: _ionic_storage__WEBPACK_IMPORTED_MODULE_2__["Storage"]
        }];
      };

      DatabaseService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: "root"
      })], DatabaseService);
      /***/
    },

    /***/
    "ZiYc":
    /*!***********************************************************************************!*\
      !*** ./src/app/components/ela-cronograma-list/ela-cronograma-list.component.scss ***!
      \***********************************************************************************/

    /*! exports provided: default */

    /***/
    function ZiYc(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".sub-title-horario {\n  font-size: 14px;\n  font-family: sans-serif;\n}\n\n.paragraph-horario {\n  font-style: italic;\n  font-size: 13px;\n  color: #05022e;\n  display: block;\n  padding: 1px;\n}\n\n.row-cronogama {\n  width: 100%;\n  background-color: #f5d6d6;\n  padding: 3px;\n  margin: 2px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxlbGEtY3Jvbm9ncmFtYS1saXN0LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZUFBQTtFQUNBLHVCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7QUFFRjs7QUFBQTtFQUNFLFdBQUE7RUFDQSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0FBR0YiLCJmaWxlIjoiZWxhLWNyb25vZ3JhbWEtbGlzdC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zdWItdGl0bGUtaG9yYXJpbyB7XHJcbiAgZm9udC1zaXplOiAxNHB4O1xyXG4gIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xyXG59XHJcbi5wYXJhZ3JhcGgtaG9yYXJpbyB7XHJcbiAgZm9udC1zdHlsZTogaXRhbGljO1xyXG4gIGZvbnQtc2l6ZTogMTNweDtcclxuICBjb2xvcjogcmdiKDUsIDIsIDQ2KTtcclxuICBkaXNwbGF5OiBibG9jaztcclxuICBwYWRkaW5nOiAxcHg7XHJcbn1cclxuLnJvdy1jcm9ub2dhbWEge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHJnYigyNDUsIDIxNCwgMjE0KTtcclxuICBwYWRkaW5nOiAzcHg7XHJcbiAgbWFyZ2luOiAycHg7XHJcbn1cclxuIl19 */";
      /***/
    },

    /***/
    "b6b0":
    /*!*******************************************************************************!*\
      !*** ./src/app/components/ela-plan-muestreo/ela-plan-muestreo.component.scss ***!
      \*******************************************************************************/

    /*! exports provided: default */

    /***/
    function b6b0(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlbGEtcGxhbi1tdWVzdHJlby5jb21wb25lbnQuc2NzcyJ9 */";
      /***/
    },

    /***/
    "bkIZ":
    /*!***************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/ela-cronograma/ela-cronograma.component.html ***!
      \***************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function bkIZ(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<div class=\"container-product\">\r\n    <form [formGroup]=\"ionicFormHorario\" (ngSubmit)=\"guardarCronograma()\"\r\n        #form=\"ngForm\">\r\n        <app-custom-input label=\"Fecha\" name=\"fechaInicio\" type=\"date\"\r\n            [formGruop]=\"ionicFormHorario\" [form]=\"form\"\r\n            [defaultValue]=\"currentElacronogama.fechaInicio\"></app-custom-input>\r\n        <app-custom-input label=\"Horario\" name=\"horario\" type=\"text\"\r\n            [formGruop]=\"ionicFormHorario\" [form]=\"form\"\r\n            [defaultValue]=\"currentElacronogama.horario\"></app-custom-input>\r\n        <app-custom-input label=\"Requisitos\" name=\"requisitosEsquema\"\r\n            type=\"text\" [formGruop]=\"ionicFormHorario\"\r\n            [form]=\"form\"\r\n            [defaultValue]=\"currentElacronogama.requisitosEsquema\"></app-custom-input>\r\n        <app-custom-input label=\"Persona Entrevistada\"\r\n            name=\"personaEntrevistadaCargo\" type=\"text\"\r\n            [formGruop]=\"ionicFormHorario\" [form]=\"form\"\r\n            [defaultValue]=\"currentElacronogama.personaEntrevistadaCargo\">\r\n        </app-custom-input>\r\n        <app-custom-input label=\"Proceso/Area\" name=\"procesoArea\" type=\"text\"\r\n            [formGruop]=\"ionicFormHorario\"\r\n            [form]=\"form\" [defaultValue]=\"currentElacronogama.procesoArea\"></app-custom-input>\r\n        <ion-item>\r\n            <ion-label position=\"floating\">Participante</ion-label>\r\n            <ion-select interface=\"alert\" placeholder=\"Participante\"\r\n                class=\"cargo-select\" okText=\"Ok\"\r\n                cancelText=\"Cancelar\"\r\n                (ionChange)=\"seleccionarParticipante($event)\" multiple=\"true\"\r\n                [value]=\"selectedParticipantes\">\r\n                <ion-select-option *ngFor=\"let participante of\r\n                    listaParticipantes\" [value]=\"participante\"\r\n                    class=\"cargo-select\">\r\n                    {{ participante.nombreCompleto }}\r\n                </ion-select-option>\r\n            </ion-select>\r\n        </ion-item>\r\n        <ion-item>\r\n            <ion-label position=\"floating\">Direccion</ion-label>\r\n            <ion-select interface=\"popover\" placeholder=\"direccion\"\r\n                class=\"cargo-select\" okText=\"Ok\"\r\n                cancelText=\"Cancelar\" (ionChange)=\"seleccionarDireccion($event)\"\r\n                [value]=\"selectedParticipantes\">\r\n                <ion-select-option *ngFor=\"let direccion of listaDirecciones\"\r\n                    [value]=\"direccion\"\r\n                    class=\"cargo-select\">{{ direccion }}\r\n                </ion-select-option>\r\n            </ion-select>\r\n        </ion-item>\r\n\r\n        <p class=\"detail-paragraph\">\r\n            Fecha 21/03/2021 | Usuario: Rubén | Auditor: Jorge | Cargo: Jefe de\r\n            Producción\r\n        </p>\r\n        <section>\r\n            <ion-button size=\"small\" type=\"submit\">Guardar</ion-button>\r\n            <ion-button size=\"small\" color=\"secondary\" (click)=\"cancelar()\">Cancelar</ion-button>\r\n        </section>\r\n    </form>\r\n</div>";
      /***/
    },

    /***/
    "cMJF":
    /*!*********************************************************************!*\
      !*** ./src/app/components/custom-input/custom-input.component.scss ***!
      \*********************************************************************/

    /*! exports provided: default */

    /***/
    function cMJF(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".margin-top {\n  margin-top: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjdXN0b20taW5wdXQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxnQkFBQTtBQUNKIiwiZmlsZSI6ImN1c3RvbS1pbnB1dC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tYXJnaW4tdG9we1xyXG4gICAgbWFyZ2luLXRvcDogMTBweDtcclxufSJdfQ== */";
      /***/
    },

    /***/
    "ceam":
    /*!***********************************************************************!*\
      !*** ./src/app/components/ela-cronograma/ela-cronograma.component.ts ***!
      \***********************************************************************/

    /*! exports provided: ElaCronogramaComponent */

    /***/
    function ceam(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ElaCronogramaComponent", function () {
        return ElaCronogramaComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_ela_cronograma_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./ela-cronograma.component.html */
      "bkIZ");
      /* harmony import */


      var _ela_cronograma_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./ela-cronograma.component.scss */
      "/AVN");
      /* harmony import */


      var _interfaces_elaboracion_auditoria_PlanAuditoriaDTO__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./../../interfaces/elaboracion_auditoria/PlanAuditoriaDTO */
      "6GDD");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/angular */
      "sZkV");
      /* harmony import */


      var src_app_interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! src/app/interfaces/cross-ui/ConvertFormToObject */
      "GeA3");

      var ElaCronogramaComponent = /*#__PURE__*/function () {
        function ElaCronogramaComponent(toastController, formBuilder) {
          _classCallCheck(this, ElaCronogramaComponent);

          this.toastController = toastController;
          this.formBuilder = formBuilder;
          this.guardarCronogramaEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"]();
          this.cancelarCronogramaEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"]();
          this.participantes = "";
        }

        _createClass(ElaCronogramaComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this42 = this;

            var _a;

            if (!this.currentElacronogama) this.currentElacronogama = new _interfaces_elaboracion_auditoria_PlanAuditoriaDTO__WEBPACK_IMPORTED_MODULE_3__["Elacronogama"]();
            this.ionicFormHorario = this.formBuilder.group({});
            this.selectedParticipantes = new Array();
            (_a = this.currentElacronogama.auditor) === null || _a === void 0 ? void 0 : _a.split(";").forEach(function (x) {
              _this42.selectedParticipantes.push(x);
            });
          }
        }, {
          key: "seleccionarParticipante",
          value: function seleccionarParticipante(event) {
            var _this43 = this;

            console.log("se selecciono particiapante", event);
            console.log("valor actual de la lista", this.selectedParticipantes);

            if (event.detail) {
              event.detail.value.forEach(function (element) {
                _this43.participantes = _this43.participantes + element.nombreCompleto + ";";
              });
            }
          }
        }, {
          key: "seleccionarDireccion",
          value: function seleccionarDireccion(event) {
            console.log("se selecciono direccion", event);
            this.currentElacronogama.direccion = event.detail.value;
          }
        }, {
          key: "cancelar",
          value: function cancelar() {
            if (this.cancelarCronogramaEmitter) {
              this.cancelarCronogramaEmitter.emit(this.currentElacronogama);
            }
          }
        }, {
          key: "guardarCronograma",
          value: function guardarCronograma() {
            src_app_interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_7__["ConvertFormToObject"].convert(this.ionicFormHorario, this.currentElacronogama);
            this.currentElacronogama.auditor = this.participantes;
            console.log("seleccionarParticipante", this.currentElacronogama);

            if (this.guardarCronogramaEmitter) {
              this.guardarCronogramaEmitter.emit(this.currentElacronogama);
            }
          }
        }]);

        return ElaCronogramaComponent;
      }();

      ElaCronogramaComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"]
        }, {
          type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"]
        }];
      };

      ElaCronogramaComponent.propDecorators = {
        currentElacronogama: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"]
        }],
        guardarCronogramaEmitter: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Output"]
        }],
        cancelarCronogramaEmitter: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Output"]
        }],
        listaParticipantes: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"]
        }],
        listaDirecciones: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"]
        }]
      };
      ElaCronogramaComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: "app-ela-cronograma",
        template: _raw_loader_ela_cronograma_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_ela_cronograma_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], ElaCronogramaComponent);
      /***/
    },

    /***/
    "dOiU":
    /*!***************************************************************************************!*\
      !*** ./src/app/components/pra-edit-norma-sistema/pra-edit-norma-sistema.component.ts ***!
      \***************************************************************************************/

    /*! exports provided: PraEditNormaSistemaComponent */

    /***/
    function dOiU(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PraEditNormaSistemaComponent", function () {
        return PraEditNormaSistemaComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_pra_edit_norma_sistema_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./pra-edit-norma-sistema.component.html */
      "xl0N");
      /* harmony import */


      var _pra_edit_norma_sistema_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./pra-edit-norma-sistema.component.scss */
      "7KC4");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/angular */
      "sZkV");
      /* harmony import */


      var src_app_interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! src/app/interfaces/cross-ui/ConvertFormToObject */
      "GeA3");

      var PraEditNormaSistemaComponent = /*#__PURE__*/function () {
        function PraEditNormaSistemaComponent(toastController, formBuilder) {
          _classCallCheck(this, PraEditNormaSistemaComponent);

          this.toastController = toastController;
          this.formBuilder = formBuilder;
          this.showBuscadorNormas = false;
          this.guardarNormaEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
          this.cancelarNormaEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        }

        _createClass(PraEditNormaSistemaComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.ionicForm = this.formBuilder.group({});
          }
        }, {
          key: "guardarNorma",
          value: function guardarNorma() {
            var _this44 = this;

            src_app_interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_6__["ConvertFormToObject"].convert(this.ionicForm, this.praciclonormassistema);
            this.presentToast("Norma guardada correctamente").then(function (resul) {
              if (_this44.guardarNormaEmitter) {
                _this44.guardarNormaEmitter.emit(_this44.praciclonormassistema);
              }
            });
          }
        }, {
          key: "cancelarNorma",
          value: function cancelarNorma() {
            if (this.cancelarNormaEmitter) {
              this.cancelarNormaEmitter.emit(this.praciclonormassistema);
            }
          }
        }, {
          key: "mostrarBuscadorNorma",
          value: function mostrarBuscadorNorma() {
            console.log("ingreso al evento");
            this.showBuscadorNormas = true;
          }
        }, {
          key: "cambiarNorma",
          value: function cambiarNorma(norma) {
            console.log("cambiarNorma", norma);
            this.praciclonormassistema.norma = norma.codigoNorma;
            this.showBuscadorNormas = false;
          }
        }, {
          key: "presentToast",
          value: function presentToast(mensaje) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee8() {
              var toast;
              return regeneratorRuntime.wrap(function _callee8$(_context8) {
                while (1) {
                  switch (_context8.prev = _context8.next) {
                    case 0:
                      _context8.next = 2;
                      return this.toastController.create({
                        message: mensaje,
                        duration: 2000
                      });

                    case 2:
                      toast = _context8.sent;
                      toast.present();

                    case 4:
                    case "end":
                      return _context8.stop();
                  }
                }
              }, _callee8, this);
            }));
          }
        }]);

        return PraEditNormaSistemaComponent;
      }();

      PraEditNormaSistemaComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"]
        }, {
          type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
        }];
      };

      PraEditNormaSistemaComponent.propDecorators = {
        praciclonormassistema: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        guardarNormaEmitter: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }],
        cancelarNormaEmitter: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }]
      };
      PraEditNormaSistemaComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: "app-pra-edit-norma-sistema",
        template: _raw_loader_pra_edit_norma_sistema_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_pra_edit_norma_sistema_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], PraEditNormaSistemaComponent);
      /***/
    },

    /***/
    "eiTQ":
    /*!***********************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/ela-edit-hallazago/ela-edit-hallazago.component.html ***!
      \***********************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function eiTQ(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<div class=\"container-product\">\r\n  <form\r\n    [formGroup]=\"ionicFormHallazgo\"\r\n    (ngSubmit)=\"guardarHallazgo()\"\r\n    #form=\"ngForm\">\r\n    <ion-select\r\n      interface=\"alert\"\r\n      placeholder=\"Tipo de hallazgo\"\r\n      class=\"cargo-select\"\r\n      okText=\"Ok\"\r\n      cancelText=\"Cancelar\"\r\n      (ionChange)=\"seleccionarTipo($event)\"\r\n      [value]=\"tipoObservacion\">\r\n      <ion-select-option\r\n        *ngFor=\"let tipo of ltiposObervacion\"\r\n        [value]=\"tipo\"\r\n        class=\"cargo-select\">\r\n        {{ tipo.descripcion }}\r\n      </ion-select-option>\r\n    </ion-select>\r\n    <app-custom-input\r\n      label=\"Requisito\"\r\n      name=\"proceso\"\r\n      type=\"text\"\r\n      [formGruop]=\"ionicFormHallazgo\"\r\n      [form]=\"form\"\r\n      [defaultValue]=\"elahallazgo.proceso\"></app-custom-input>\r\n\r\n    <!-- <app-custom-input\r\n      label=\"Hallazgo\"\r\n      name=\"sitio\"\r\n      type=\"text\"\r\n      [formGruop]=\"ionicFormHallazgo\"\r\n      [form]=\"form\"\r\n      [defaultValue]=\"elahallazgo.sitio\"\r\n    ></app-custom-input> -->\r\n    <!-- <ion-select\r\n      interface=\"alert\"\r\n      placeholder=\"Normas\"\r\n      class=\"cargo-select\"\r\n      okText=\"Ok\"\r\n      cancelText=\"Cancelar\"\r\n      (ionChange)=\"seleccionarNorma($event)\"\r\n      [value]=\"elahallazgo.normas\"\r\n    >\r\n      <ion-select-option\r\n        *ngFor=\"let norma of lNormas\"\r\n        [value]=\"norma\"\r\n        class=\"cargo-select\"\r\n      >\r\n        {{ norma }}\r\n      </ion-select-option>\r\n    </ion-select> -->\r\n    <ion-item>\r\n      <ion-label position=\"floating\">Hallazgo</ion-label>\r\n      <ion-textarea\r\n        clearOnEdit=\"true\"\r\n        rows=\"10\"\r\n        (ionChange)=\"valorHallazagos($event)\"\r\n        cols=\"20\"\r\n        [value]=\"elahallazgo.hallazgo\"></ion-textarea>\r\n    </ion-item>\r\n\r\n    <section>\r\n      <ion-button size=\"small\" type=\"submit\">Guardar</ion-button>\r\n      <ion-button size=\"small\" color=\"secondary\" (click)=\"cancelarHallazo()\">Cancelar</ion-button>\r\n    </section>\r\n  </form>\r\n</div>\r\n";
      /***/
    },

    /***/
    "ej6O":
    /*!*******************************************************************************!*\
      !*** ./src/app/components/tcp-list-products/tcp-list-products.component.scss ***!
      \*******************************************************************************/

    /*! exports provided: default */

    /***/
    function ej6O(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".container-product-list {\n  margin-top: 0em;\n}\n\n.popover-content.sc-ion-popover-md {\n  width: 500px !important;\n}\n\n.my-custom-modal-css .modal-wrapper {\n  width: 600px;\n  height: 650px !important;\n}\n\n.normas {\n  font-size: 12px;\n  color: #1b192c;\n}\n\n.title-normas {\n  color: #0b480f;\n  font-size: 1em;\n  text-align: left;\n}\n\n.norma-block {\n  background-color: #c6e8e6;\n  padding: 10px;\n  margin: 1.5px;\n  min-width: 100%;\n}\n\n.big-icon {\n  font-size: 1.2em;\n  margin-left: 3px;\n  cursor: -webkit-grab;\n  cursor: grab;\n}\n\n.detail-paragraph {\n  font-size: 11px;\n  color: #3d3c44;\n}\n\n.sub-title {\n  /*font-style: italic;*/\n  font-size: 13px;\n  color: #055a0f;\n  font-family: sans-serif;\n}\n\n.direccion-block {\n  background-color: #c1ebd6;\n  padding: 10px;\n  margin: 1.5px;\n  min-width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFx0Y3AtbGlzdC1wcm9kdWN0cy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGVBQUE7QUFDRjs7QUFDQTtFQUNJLHVCQUFBO0FBRUo7O0FBQ0E7RUFDRSxZQUFBO0VBQ0Esd0JBQUE7QUFFRjs7QUFBQTtFQUNFLGVBQUE7RUFDQSxjQUFBO0FBR0Y7O0FBREE7RUFDRSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0FBSUY7O0FBRkE7RUFDRSx5QkFBQTtFQUNBLGFBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtBQUtGOztBQUhBO0VBQ0UsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLG9CQUFBO0VBQUEsWUFBQTtBQU1GOztBQUpBO0VBQ0UsZUFBQTtFQUNBLGNBQUE7QUFPRjs7QUFMQTtFQUNFLHNCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSx1QkFBQTtBQVFGOztBQU5BO0VBQ0UseUJBQUE7RUFDQSxhQUFBO0VBQ0EsYUFBQTtFQUNBLGVBQUE7QUFTRiIsImZpbGUiOiJ0Y3AtbGlzdC1wcm9kdWN0cy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXItcHJvZHVjdC1saXN0IHtcclxuICBtYXJnaW4tdG9wOiAwZW07XHJcbn1cclxuLnBvcG92ZXItY29udGVudC5zYy1pb24tcG9wb3Zlci1tZCB7XHJcbiAgICB3aWR0aDogNTAwcHggIWltcG9ydGFudDtcclxufVxyXG5cclxuLm15LWN1c3RvbS1tb2RhbC1jc3MgLm1vZGFsLXdyYXBwZXIge1xyXG4gIHdpZHRoOiA2MDBweDtcclxuICBoZWlnaHQ6IDY1MHB4ICFpbXBvcnRhbnQ7XHJcbn0gXHJcbi5ub3JtYXMge1xyXG4gIGZvbnQtc2l6ZTogMTJweDtcclxuICBjb2xvcjogIzFiMTkyYztcclxufVxyXG4udGl0bGUtbm9ybWFzIHtcclxuICBjb2xvcjogIzBiNDgwZjtcclxuICBmb250LXNpemU6IDFlbTtcclxuICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG59XHJcbi5ub3JtYS1ibG9jayB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2M2ZThlNjtcclxuICBwYWRkaW5nOiAxMHB4O1xyXG4gIG1hcmdpbjogMS41cHg7XHJcbiAgbWluLXdpZHRoOiAxMDAlO1xyXG59XHJcbi5iaWctaWNvbiB7XHJcbiAgZm9udC1zaXplOiAxLjJlbTtcclxuICBtYXJnaW4tbGVmdDogM3B4O1xyXG4gIGN1cnNvcjogZ3JhYjtcclxufVxyXG4uZGV0YWlsLXBhcmFncmFwaCB7XHJcbiAgZm9udC1zaXplOiAxMXB4O1xyXG4gIGNvbG9yOiAjM2QzYzQ0O1xyXG59XHJcbi5zdWItdGl0bGUge1xyXG4gIC8qZm9udC1zdHlsZTogaXRhbGljOyovXHJcbiAgZm9udC1zaXplOiAxM3B4O1xyXG4gIGNvbG9yOiAjMDU1YTBmO1xyXG4gIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xyXG59XHJcbi5kaXJlY2Npb24tYmxvY2sge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNjMWViZDY7XHJcbiAgcGFkZGluZzogMTBweDtcclxuICBtYXJnaW46IDEuNXB4O1xyXG4gIG1pbi13aWR0aDogMTAwJTtcclxufSJdfQ== */";
      /***/
    },

    /***/
    "g5wf":
    /*!*******************************************************************************************************!*\
      !*** ./src/app/components/ela-registro-areapreocupacion/ela-registro-areapreocupacion.component.scss ***!
      \*******************************************************************************************************/

    /*! exports provided: default */

    /***/
    function g5wf(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".normas {\n  font-size: 12px;\n  color: #1b192c;\n}\n\n.title-normas {\n  color: #0b480f;\n  font-size: 1em;\n  text-align: left;\n}\n\n.norma-block {\n  background-color: #c6e8e6;\n  padding: 10px;\n  margin: 1.5px;\n  min-width: 100%;\n}\n\n.big-icon {\n  font-size: 2em;\n  margin-left: 3px;\n  cursor: -webkit-grab;\n  cursor: grab;\n}\n\n.detail-paragraph {\n  font-size: 11px;\n  color: #3d3c44;\n}\n\n.sub-title {\n  /*font-style: italic;*/\n  font-size: 13px;\n  color: #055a0f;\n  font-family: sans-serif;\n}\n\n.sub-title-horario {\n  /*font-style: italic;*/\n  font-size: 13px;\n  color: #dfd0f2;\n  font-family: sans-serif;\n}\n\n.direccion-block {\n  background-color: #c1ebd6;\n  padding: 10px;\n  margin: 1.5px;\n  min-width: 100%;\n}\n\n.horario-block {\n  background-color: #1c1118;\n  padding: 20px;\n  margin: 0.5px;\n  min-width: 100%;\n}\n\n.horario-block p {\n  color: #c6e8e6;\n}\n\n.titles {\n  font-style: italic;\n  font-weight: 300;\n  font-size: 18px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxlbGEtcmVnaXN0cm8tYXJlYXByZW9jdXBhY2lvbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGVBQUE7RUFDQSxjQUFBO0FBQ0o7O0FBQ0U7RUFDRSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0FBRUo7O0FBQUU7RUFDRSx5QkFBQTtFQUNBLGFBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtBQUdKOztBQURFO0VBQ0UsY0FBQTtFQUNBLGdCQUFBO0VBQ0Esb0JBQUE7RUFBQSxZQUFBO0FBSUo7O0FBRkU7RUFDRSxlQUFBO0VBQ0EsY0FBQTtBQUtKOztBQUhFO0VBQ0Usc0JBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLHVCQUFBO0FBTUo7O0FBSEU7RUFDRSxzQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsdUJBQUE7QUFNSjs7QUFKRTtFQUNFLHlCQUFBO0VBQ0EsYUFBQTtFQUNBLGFBQUE7RUFDQSxlQUFBO0FBT0o7O0FBTEU7RUFDRSx5QkFBQTtFQUNBLGFBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtBQVFKOztBQU5FO0VBQ0UsY0FBQTtBQVNKOztBQVBFO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUFVSiIsImZpbGUiOiJlbGEtcmVnaXN0cm8tYXJlYXByZW9jdXBhY2lvbi5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5ub3JtYXMge1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgY29sb3I6ICMxYjE5MmM7XHJcbiAgfVxyXG4gIC50aXRsZS1ub3JtYXMge1xyXG4gICAgY29sb3I6ICMwYjQ4MGY7XHJcbiAgICBmb250LXNpemU6IDFlbTtcclxuICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgfVxyXG4gIC5ub3JtYS1ibG9jayB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjYzZlOGU2O1xyXG4gICAgcGFkZGluZzogMTBweDtcclxuICAgIG1hcmdpbjogMS41cHg7XHJcbiAgICBtaW4td2lkdGg6IDEwMCU7XHJcbiAgfVxyXG4gIC5iaWctaWNvbiB7XHJcbiAgICBmb250LXNpemU6IDJlbTtcclxuICAgIG1hcmdpbi1sZWZ0OiAzcHg7XHJcbiAgICBjdXJzb3I6IGdyYWI7XHJcbiAgfVxyXG4gIC5kZXRhaWwtcGFyYWdyYXBoIHtcclxuICAgIGZvbnQtc2l6ZTogMTFweDtcclxuICAgIGNvbG9yOiAjM2QzYzQ0O1xyXG4gIH1cclxuICAuc3ViLXRpdGxlIHtcclxuICAgIC8qZm9udC1zdHlsZTogaXRhbGljOyovXHJcbiAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICBjb2xvcjogIzA1NWEwZjtcclxuICAgIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xyXG4gIH1cclxuICBcclxuICAuc3ViLXRpdGxlLWhvcmFyaW8ge1xyXG4gICAgLypmb250LXN0eWxlOiBpdGFsaWM7Ki9cclxuICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgIGNvbG9yOiAjZGZkMGYyO1xyXG4gICAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XHJcbiAgfVxyXG4gIC5kaXJlY2Npb24tYmxvY2sge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2MxZWJkNjtcclxuICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICBtYXJnaW46IDEuNXB4O1xyXG4gICAgbWluLXdpZHRoOiAxMDAlO1xyXG4gIH1cclxuICAuaG9yYXJpby1ibG9jayB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMWMxMTE4O1xyXG4gICAgcGFkZGluZzogMjBweDtcclxuICAgIG1hcmdpbjogMC41cHg7XHJcbiAgICBtaW4td2lkdGg6IDEwMCU7XHJcbiAgfVxyXG4gIC5ob3JhcmlvLWJsb2NrIHB7XHJcbiAgICBjb2xvcjogI2M2ZThlNjtcclxuICB9XHJcbiAgLnRpdGxlcyB7XHJcbiAgICBmb250LXN0eWxlOiBpdGFsaWM7XHJcbiAgICBmb250LXdlaWdodDogMzAwO1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG4gIH1cclxuICAiXX0= */";
      /***/
    },

    /***/
    "gfLP":
    /*!*****************************************************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/tcs-lista-verificacion-reunion-apertura/tcs-lista-verificacion-reunion-apertura.component.html ***!
      \*****************************************************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function gfLP(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<p>\r\n  tcs-lista-verificacion-reunion-apertura works!\r\n</p>\r\n\r\n<app-custom-header\r\n  title=\"TCS - LISTA DE VERIFICACION DE APERTURA\"\r\n  icon_name=\"list\"\r\n></app-custom-header>\r\n<ion-content>\r\n \r\n  <ion-list>\r\n    <ion-item>\r\n      <ion-label><strong>Todo</strong></ion-label>\r\n      <ion-checkbox slot=\"end\" \r\n      [(ngModel)]=\"masterCheck\"\r\n      [indeterminate]=\"isIndeterminate\"\r\n        (click)=\"checkMaster($event)\"></ion-checkbox>\r\n    </ion-item>\r\n  </ion-list>\r\n  <ion-list>\r\n    <ion-item *ngFor=\"let item of pParamitemselect\">\r\n      <ion-label class=\"ion-text-wrap\">{{item.itemSelect}}</ion-label>\r\n      <ion-checkbox slot=\"end\" \r\n      [(ngModel)]=\"item.isChecked\" \r\n      (ionChange)=\"checkEvent()\"></ion-checkbox>\r\n    </ion-item>\r\n  </ion-list>\r\n\r\n</ion-content>\r\n\r\n";
      /***/
    },

    /***/
    "grjr":
    /*!*************************************************************************!*\
      !*** ./src/app/components/pra-cronograma/pra-cronograma.component.scss ***!
      \*************************************************************************/

    /*! exports provided: default */

    /***/
    function grjr(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".label-cronograma {\n  font-weight: bold;\n  font-size: 12px;\n}\n\n.data-cronograma {\n  font-style: italic;\n  font-size: 13px;\n}\n\n.ion-content-small-font {\n  font-family: \"Calibri Light\";\n  font-size: 12px;\n  color: #093537;\n}\n\n.title-medium-font {\n  font-family: \"Courier New\";\n  font-weight: bold;\n}\n\nion-card-content {\n  text-align: left;\n}\n\n.box-click {\n  min-width: 100px;\n  min-height: 20px;\n  border-bottom: solid;\n  border-color: #778e8f;\n  border-width: 1px;\n  padding: 2px;\n  margin-left: 3px;\n  display: inline-block;\n}\n\n.edit-item {\n  cursor: -webkit-grab;\n  cursor: grab;\n}\n\n.edit-item:hover {\n  background-color: #9dd8dc;\n}\n\n.item-cronograma {\n  display: block;\n  margin-bottom: 4px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxwcmEtY3Jvbm9ncmFtYS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGlCQUFBO0VBQ0EsZUFBQTtBQUNGOztBQUNBO0VBQ0Usa0JBQUE7RUFDQSxlQUFBO0FBRUY7O0FBQUE7RUFDRSw0QkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0FBR0Y7O0FBREE7RUFDRSwwQkFBQTtFQUNBLGlCQUFBO0FBSUY7O0FBRkE7RUFDRSxnQkFBQTtBQUtGOztBQUhBO0VBQ0UsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLG9CQUFBO0VBQ0EscUJBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLHFCQUFBO0FBTUY7O0FBSkE7RUFDRSxvQkFBQTtFQUFBLFlBQUE7QUFPRjs7QUFMQTtFQUNFLHlCQUFBO0FBUUY7O0FBTkE7RUFDRSxjQUFBO0VBQ0Esa0JBQUE7QUFTRiIsImZpbGUiOiJwcmEtY3Jvbm9ncmFtYS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5sYWJlbC1jcm9ub2dyYW1hIHtcclxuICBmb250LXdlaWdodDogYm9sZDtcclxuICBmb250LXNpemU6IDEycHg7XHJcbn1cclxuLmRhdGEtY3Jvbm9ncmFtYSB7XHJcbiAgZm9udC1zdHlsZTogaXRhbGljO1xyXG4gIGZvbnQtc2l6ZTogMTNweDtcclxufVxyXG4uaW9uLWNvbnRlbnQtc21hbGwtZm9udCB7XHJcbiAgZm9udC1mYW1pbHk6IFwiQ2FsaWJyaSBMaWdodFwiO1xyXG4gIGZvbnQtc2l6ZTogMTJweDtcclxuICBjb2xvcjogIzA5MzUzNztcclxufVxyXG4udGl0bGUtbWVkaXVtLWZvbnQge1xyXG4gIGZvbnQtZmFtaWx5OiBcIkNvdXJpZXIgTmV3XCI7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxuaW9uLWNhcmQtY29udGVudCB7XHJcbiAgdGV4dC1hbGlnbjogbGVmdDtcclxufVxyXG4uYm94LWNsaWNrIHtcclxuICBtaW4td2lkdGg6IDEwMHB4O1xyXG4gIG1pbi1oZWlnaHQ6IDIwcHg7XHJcbiAgYm9yZGVyLWJvdHRvbTogc29saWQ7XHJcbiAgYm9yZGVyLWNvbG9yOiAjNzc4ZThmO1xyXG4gIGJvcmRlci13aWR0aDogMXB4O1xyXG4gIHBhZGRpbmc6IDJweDtcclxuICBtYXJnaW4tbGVmdDogM3B4O1xyXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxufVxyXG4uZWRpdC1pdGVtIHtcclxuICBjdXJzb3I6IGdyYWI7XHJcbn1cclxuLmVkaXQtaXRlbTpob3ZlciB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzlkZDhkYztcclxufVxyXG4uaXRlbS1jcm9ub2dyYW1hIHtcclxuICBkaXNwbGF5OiBibG9jaztcclxuICBtYXJnaW4tYm90dG9tOiA0cHg7XHJcbn1cclxuIl19 */";
      /***/
    },

    /***/
    "hCss":
    /*!*******************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/editor-documento/editor-documento.component.html ***!
      \*******************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function hCss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-list>\n  <ion-item>\n    <ion-label position=\"stacked\">{{ titulo }}</ion-label>\n    <ion-textarea\n      [(ngModel)]=\"tmddocumentacionauditorium.tmdDocumentoAuditoria\"\n      placeholder=\"contenido\"\n      rows=\"20\"\n    ></ion-textarea>\n  </ion-item>\n  <ion-item>\n    <ion-button\n      size=\"small\"\n      fill=\"outline\"\n      color=\"success\"\n      (click)=\"guardarContenido()\"\n    >\n      <ion-icon slot=\"start\" name=\"caret-up-outline\"></ion-icon>\n      Guardar\n    </ion-button>\n  </ion-item>\n</ion-list>\n";
      /***/
    },

    /***/
    "i3mW":
    /*!*************************************************************************************************!*\
      !*** ./src/app/components/lista-verificacion-apertura/lista-verificacion-apertura.component.ts ***!
      \*************************************************************************************************/

    /*! exports provided: ListaVerificacionAperturaComponent */

    /***/
    function i3mW(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ListaVerificacionAperturaComponent", function () {
        return ListaVerificacionAperturaComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_lista_verificacion_apertura_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./lista-verificacion-apertura.component.html */
      "kWn8");
      /* harmony import */


      var _lista_verificacion_apertura_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./lista-verificacion-apertura.component.scss */
      "zDHk");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");

      var ListaVerificacionAperturaComponent = /*#__PURE__*/function () {
        function ListaVerificacionAperturaComponent() {
          _classCallCheck(this, ListaVerificacionAperturaComponent);

          this.data = [{
            name: 'Presentación del Equipo Auditor y de los representantes del auditado',
            selected: true
          }, {
            name: 'Confirmar propósito y alcance de la auditoría',
            selected: false
          }, {
            name: 'Mencionar la(s) norma(s) de referencia de la auditoría para establecer la conformidad del producto',
            selected: true
          }, {
            name: 'Hacer énfasis en el compromiso de confidencialidad',
            selected: false
          }, {
            name: 'Definir canales de comunicación',
            selected: false
          }, {
            name: 'Confirmar la disponibilidad de recursos y medios necesarios',
            selected: false
          }, {
            name: 'Revisar el plan de auditoría y confirmar los horarios del cronograma, reunión de cierre y reuniones intermedias',
            selected: false
          }, {
            name: 'Arreglos',
            selected: false
          }, {
            name: 'Preguntas y respuestas',
            selected: false
          }, {
            name: 'Agradecer a los participantes por asistir',
            selected: false
          }];
        }

        _createClass(ListaVerificacionAperturaComponent, [{
          key: "clickCheck",
          value: function clickCheck(check) {
            console.log(check);
          }
        }, {
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return ListaVerificacionAperturaComponent;
      }();

      ListaVerificacionAperturaComponent.ctorParameters = function () {
        return [];
      };

      ListaVerificacionAperturaComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-lista-verificacion-apertura',
        template: _raw_loader_lista_verificacion_apertura_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_lista_verificacion_apertura_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], ListaVerificacionAperturaComponent);
      /***/
    },

    /***/
    "iRyo":
    /*!*****************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/pra-direccion-sistema/pra-direccion-sistema.component.html ***!
      \*****************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function iRyo(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<div class=\"container-product\">\r\n  <form [formGroup]=\"ionicForm\" (ngSubmit)=\"guardarDireccion()\" #form=\"ngForm\">\r\n    <!-- <app-custom-input\r\n      label=\"Oficina\"\r\n      name=\"nombre\"\r\n      type=\"text\"\r\n      [formGruop]=\"ionicForm\"\r\n      [form]=\"form\"\r\n      [defaultValue]=\"pradireccionespasistema.nombre\"\r\n    ></app-custom-input> -->\r\n    <app-custom-input\r\n      label=\"Direccion\"\r\n      name=\"direccion\"\r\n      type=\"text\"\r\n      [formGruop]=\"ionicForm\"\r\n      [form]=\"form\"\r\n      [defaultValue]=\"pradireccionespasistema.direccion\"\r\n    ></app-custom-input>\r\n    <!-- <div *ngIf=\"mode === 'default-pais'\">\r\n      <app-custom-input\r\n        label=\"PAIS\"\r\n        name=\"pais\"\r\n        type=\"text\"\r\n        [formGruop]=\"ionicForm\"\r\n        readonly=\"true\"\r\n        [form]=\"form\"\r\n        [defaultValue]=\"pradireccionespasistema.pais\"\r\n        (click)=\"cambiarModoPais()\"\r\n      ></app-custom-input>\r\n      <app-custom-input\r\n        label=\"Departamento\"\r\n        name=\"departamento\"\r\n        type=\"text\"\r\n        [formGruop]=\"ionicForm\"\r\n        [form]=\"form\"\r\n        readonly=\"true\"\r\n        [defaultValue]=\"pradireccionespasistema.departamento\"\r\n      ></app-custom-input>\r\n      <app-custom-input\r\n        label=\"Ciudad\"\r\n        name=\"ciudad\"\r\n        type=\"text\"\r\n        [formGruop]=\"ionicForm\"\r\n        [form]=\"form\"\r\n        readonly=\"true\"\r\n        [defaultValue]=\"pradireccionespasistema.ciudad\"\r\n      ></app-custom-input>\r\n    </div>\r\n    <app-param-paises\r\n      *ngIf=\"mode === 'edit-pais'\"\r\n      [defaulValue]=\"pradireccionespasistema.pais\"\r\n      (selectLocalizacionEmit) = \"localizacionSeleccionda($event)\"\r\n    ></app-param-paises> -->\r\n    <app-custom-input\r\n      label=\"Dias\"\r\n      name=\"dias\"\r\n      type=\"number\"\r\n      [formGruop]=\"ionicForm\"\r\n      [form]=\"form\"\r\n      readonly=\"false\"\r\n      [defaultValue]=\"pradireccionespasistema.dias\"\r\n    ></app-custom-input>    \r\n    <section>\r\n      <ion-button size=\"small\" type=\"submit\">Guardar</ion-button>\r\n      <ion-button size=\"small\" (click)=\"cancelar()\" color=\"secondary\"\r\n        >Cancelar</ion-button\r\n      >\r\n     \r\n    </section>\r\n  </form>\r\n</div>\r\n";
      /***/
    },

    /***/
    "iYeb":
    /*!*************************************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/param-organismos-certificadores/param-organismos-certificadores.component.html ***!
      \*************************************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function iYeb(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-list>\r\n  <ion-item>\r\n    <ion-select\r\n      interface=\"alert\"\r\n      placeholder=\"Organismo\"\r\n      class=\"cargo-select\"\r\n      okText=\"Ok\"\r\n      cancelText=\"Cancelar\"\r\n      (ionChange)=\"seleccionarOrganismo($event)\"\r\n      [value]=\"currentOrganismo\"\r\n      multiple=\"true\"\r\n    >\r\n      <ion-select-option\r\n        *ngFor=\"let organismo of listaOrganismos\"\r\n        [value]=\"organismo\"\r\n        class=\"cargo-select\"        \r\n        >{{ organismo.descripcion }}\r\n      </ion-select-option>\r\n    </ion-select>\r\n  </ion-item>\r\n</ion-list>";
      /***/
    },

    /***/
    "iZ9a":
    /*!***************************************************************************!*\
      !*** ./src/app/components/param-documentos/param-documentos.component.ts ***!
      \***************************************************************************/

    /*! exports provided: ParamDocumentosComponent */

    /***/
    function iZ9a(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ParamDocumentosComponent", function () {
        return ParamDocumentosComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_param_documentos_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./param-documentos.component.html */
      "yRs8");
      /* harmony import */


      var _param_documentos_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./param-documentos.component.scss */
      "A7yl");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var src_app_services_docmentos_services_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! src/app/services/docmentos-services.service */
      "RWpN");
      /* harmony import */


      var src_app_services_elaboracion_auditoria_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! src/app/services/elaboracion-auditoria.service */
      "6V/C");

      var ParamDocumentosComponent = /*#__PURE__*/function () {
        function ParamDocumentosComponent(elaboracionAuditoriaService, docmentosServicesService) {
          _classCallCheck(this, ParamDocumentosComponent);

          this.elaboracionAuditoriaService = elaboracionAuditoriaService;
          this.docmentosServicesService = docmentosServicesService;
          this.area = "TCS";
          this.IdCiclo = 0;
          this.proceso = "ELABORACION";
        }

        _createClass(ParamDocumentosComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this45 = this;

            this.elaboracionAuditoriaService.GetListasDocumetos(this.area, this.proceso).subscribe(function (x) {
              _this45.listDocumentos = x.listEntities;
            });
          }
        }, {
          key: "descargarDocumento",
          value: function descargarDocumento(nombrePlantilla) {
            this.docmentosServicesService.GenerarDocumento(this.IdCiclo, nombrePlantilla);
          }
        }]);

        return ParamDocumentosComponent;
      }();

      ParamDocumentosComponent.ctorParameters = function () {
        return [{
          type: src_app_services_elaboracion_auditoria_service__WEBPACK_IMPORTED_MODULE_5__["ElaboracionAuditoriaService"]
        }, {
          type: src_app_services_docmentos_services_service__WEBPACK_IMPORTED_MODULE_4__["DocmentosServicesService"]
        }];
      };

      ParamDocumentosComponent.propDecorators = {
        area: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        IdCiclo: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        proceso: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }]
      };
      ParamDocumentosComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: "app-param-documentos",
        template: _raw_loader_param_documentos_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_param_documentos_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], ParamDocumentosComponent);
      /***/
    },

    /***/
    "j1ZV":
    /*!*************************************************!*\
      !*** ./src/app/components/components.module.ts ***!
      \*************************************************/

    /*! exports provided: ComponentsModule */

    /***/
    function j1ZV(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ComponentsModule", function () {
        return ComponentsModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _tcs_list_systems_tcs_list_systems_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./tcs-list-systems/tcs-list-systems.component */
      "4RPC");
      /* harmony import */


      var _tcp_list_products_tcp_list_products_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./tcp-list-products/tcp-list-products.component */
      "GPF9");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/common */
      "SVse");
      /* harmony import */


      var _message_error_message_error_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./message-error/message-error.component */
      "u5Bp");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/angular */
      "sZkV");
      /* harmony import */


      var _custom_input_custom_input_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./custom-input/custom-input.component */
      "P85u");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var br_mask__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! br-mask */
      "mzEM");
      /* harmony import */


      var _custom_header_custom_header_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! ./custom-header/custom-header.component */
      "uuHY");
      /* harmony import */


      var _meses_meses_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! ./meses/meses.component */
      "GB8g");
      /* harmony import */


      var _product_detail_product_detail_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! ./product-detail/product-detail.component */
      "lUYT");
      /* harmony import */


      var _lista_verificacion_apertura_lista_verificacion_apertura_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! ./lista-verificacion-apertura/lista-verificacion-apertura.component */
      "i3mW");
      /* harmony import */


      var _registro_ciclo_registro_ciclo_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
      /*! ./registro-ciclo/registro-ciclo.component */
      "jvAi");
      /* harmony import */


      var _plan_auditoria_plan_auditoria_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
      /*! ./plan-auditoria/plan-auditoria.component */
      "ILT1");
      /* harmony import */


      var _ciclo_participante_ciclo_participante_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
      /*! ./ciclo-participante/ciclo-participante.component */
      "5j7N");
      /* harmony import */


      var _tcs_lista_verificacion_reunion_apertura_tcs_lista_verificacion_reunion_apertura_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(
      /*! ./tcs-lista-verificacion-reunion-apertura/tcs-lista-verificacion-reunion-apertura.component */
      "WD1i");
      /* harmony import */


      var _tcs_lista_verificacion_reunion_cierre_tcs_lista_verificacion_reunion_cierre_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(
      /*! ./tcs-lista-verificacion-reunion-cierre/tcs-lista-verificacion-reunion-cierre.component */
      "EpQ6");
      /* harmony import */


      var _pra_cronograma_pra_cronograma_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(
      /*! ./pra-cronograma/pra-cronograma.component */
      "6DlI");
      /* harmony import */


      var _buscar_norma_buscar_norma_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(
      /*! ./buscar-norma/buscar-norma.component */
      "vRCE");
      /* harmony import */


      var _pra_direccion_sistema_pra_direccion_sistema_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(
      /*! ./pra-direccion-sistema/pra-direccion-sistema.component */
      "qaNy");
      /* harmony import */


      var _param_paises_param_paises_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(
      /*! ./param-paises/param-paises.component */
      "R3PH");
      /* harmony import */


      var _pra_edit_norma_sistema_pra_edit_norma_sistema_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(
      /*! ./pra-edit-norma-sistema/pra-edit-norma-sistema.component */
      "dOiU");
      /* harmony import */


      var _param_organismos_certificadores_param_organismos_certificadores_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(
      /*! ./param-organismos-certificadores/param-organismos-certificadores.component */
      "w0e+");
      /* harmony import */


      var _ela_cronograma_ela_cronograma_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(
      /*! ./ela-cronograma/ela-cronograma.component */
      "ceam");
      /* harmony import */


      var _ela_edit_hallazago_ela_edit_hallazago_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(
      /*! ./ela-edit-hallazago/ela-edit-hallazago.component */
      "lrqV");
      /* harmony import */


      var _ela_registro_hallazgos_ela_registro_hallazgos_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(
      /*! ./ela-registro-hallazgos/ela-registro-hallazgos.component */
      "AKsB");
      /* harmony import */


      var _ela_objetivos_ela_objetivos_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(
      /*! ./ela-objetivos/ela-objetivos.component */
      "Lrlg");
      /* harmony import */


      var _ela_registro_areapreocupacion_ela_registro_areapreocupacion_component__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(
      /*! ./ela-registro-areapreocupacion/ela-registro-areapreocupacion.component */
      "2BO+");
      /* harmony import */


      var _param_documentos_param_documentos_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(
      /*! ./param-documentos/param-documentos.component */
      "iZ9a");
      /* harmony import */


      var _ela_cronograma_list_ela_cronograma_list_component__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(
      /*! ./ela-cronograma-list/ela-cronograma-list.component */
      "NyE1");
      /* harmony import */


      var _ela_edit_areapreocupacion_ela_edit_areapreocupacion_component__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(
      /*! ./ela-edit-areapreocupacion/ela-edit-areapreocupacion.component */
      "8y1b");
      /* harmony import */


      var _editor_documento_editor_documento_component__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(
      /*! ./editor-documento/editor-documento.component */
      "u10Q");
      /* harmony import */


      var _tm_acta_reunion_tm_acta_reunion_component__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(
      /*! ./tm-acta-reunion/tm-acta-reunion.component */
      "2nKn");
      /* harmony import */


      var _ela_plan_muestreo_ela_plan_muestreo_component__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(
      /*! ./ela-plan-muestreo/ela-plan-muestreo.component */
      "/GCU");

      var ComponentsModule = function ComponentsModule() {
        _classCallCheck(this, ComponentsModule);
      };

      ComponentsModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
        declarations: [_message_error_message_error_component__WEBPACK_IMPORTED_MODULE_5__["MessageErrorComponent"], _custom_input_custom_input_component__WEBPACK_IMPORTED_MODULE_7__["CustomInputComponent"], _custom_header_custom_header_component__WEBPACK_IMPORTED_MODULE_10__["CustomHeaderComponent"], _tcp_list_products_tcp_list_products_component__WEBPACK_IMPORTED_MODULE_2__["TcpListProductsComponent"], _tcs_list_systems_tcs_list_systems_component__WEBPACK_IMPORTED_MODULE_1__["TcsListSystemsComponent"], _meses_meses_component__WEBPACK_IMPORTED_MODULE_11__["MesesComponent"], _product_detail_product_detail_component__WEBPACK_IMPORTED_MODULE_12__["ProductDetailComponent"], _lista_verificacion_apertura_lista_verificacion_apertura_component__WEBPACK_IMPORTED_MODULE_13__["ListaVerificacionAperturaComponent"], _plan_auditoria_plan_auditoria_component__WEBPACK_IMPORTED_MODULE_15__["PlanAuditoriaComponent"], _registro_ciclo_registro_ciclo_component__WEBPACK_IMPORTED_MODULE_14__["RegistroCicloComponent"], _ciclo_participante_ciclo_participante_component__WEBPACK_IMPORTED_MODULE_16__["CicloParticipanteComponent"], _tcs_lista_verificacion_reunion_apertura_tcs_lista_verificacion_reunion_apertura_component__WEBPACK_IMPORTED_MODULE_17__["TcsListaVerificacionReunionAperturaComponent"], _tcs_lista_verificacion_reunion_cierre_tcs_lista_verificacion_reunion_cierre_component__WEBPACK_IMPORTED_MODULE_18__["TcsListaVerificacionReunionCierreComponent"], _pra_cronograma_pra_cronograma_component__WEBPACK_IMPORTED_MODULE_19__["PraCronogramaComponent"], _buscar_norma_buscar_norma_component__WEBPACK_IMPORTED_MODULE_20__["BuscarNormaComponent"], _pra_direccion_sistema_pra_direccion_sistema_component__WEBPACK_IMPORTED_MODULE_21__["PraDireccionSistemaComponent"], _param_paises_param_paises_component__WEBPACK_IMPORTED_MODULE_22__["ParamPaisesComponent"], _pra_edit_norma_sistema_pra_edit_norma_sistema_component__WEBPACK_IMPORTED_MODULE_23__["PraEditNormaSistemaComponent"], _param_organismos_certificadores_param_organismos_certificadores_component__WEBPACK_IMPORTED_MODULE_24__["ParamOrganismosCertificadoresComponent"], _ela_cronograma_ela_cronograma_component__WEBPACK_IMPORTED_MODULE_25__["ElaCronogramaComponent"], _ela_edit_hallazago_ela_edit_hallazago_component__WEBPACK_IMPORTED_MODULE_26__["ElaEditHallazagoComponent"], _ela_registro_hallazgos_ela_registro_hallazgos_component__WEBPACK_IMPORTED_MODULE_27__["ElaRegistroHallazgosComponent"], _ela_objetivos_ela_objetivos_component__WEBPACK_IMPORTED_MODULE_28__["ElaObjetivosComponent"], _ela_registro_areapreocupacion_ela_registro_areapreocupacion_component__WEBPACK_IMPORTED_MODULE_29__["ElaRegistroAreapreocupacionComponent"], _param_documentos_param_documentos_component__WEBPACK_IMPORTED_MODULE_30__["ParamDocumentosComponent"], _ela_cronograma_list_ela_cronograma_list_component__WEBPACK_IMPORTED_MODULE_31__["ElaCronogramaListComponent"], _ela_edit_areapreocupacion_ela_edit_areapreocupacion_component__WEBPACK_IMPORTED_MODULE_32__["ElaEditAreapreocupacionComponent"], _editor_documento_editor_documento_component__WEBPACK_IMPORTED_MODULE_33__["EditorDocumentoComponent"], _tm_acta_reunion_tm_acta_reunion_component__WEBPACK_IMPORTED_MODULE_34__["TmActaReunionComponent"], _ela_plan_muestreo_ela_plan_muestreo_component__WEBPACK_IMPORTED_MODULE_35__["ElaPlanMuestreoComponent"]],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__["ReactiveFormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_8__["FormsModule"], br_mask__WEBPACK_IMPORTED_MODULE_9__["BrMaskerModule"]],
        exports: [_message_error_message_error_component__WEBPACK_IMPORTED_MODULE_5__["MessageErrorComponent"], _custom_input_custom_input_component__WEBPACK_IMPORTED_MODULE_7__["CustomInputComponent"], _custom_header_custom_header_component__WEBPACK_IMPORTED_MODULE_10__["CustomHeaderComponent"], _custom_header_custom_header_component__WEBPACK_IMPORTED_MODULE_10__["CustomHeaderComponent"], _tcp_list_products_tcp_list_products_component__WEBPACK_IMPORTED_MODULE_2__["TcpListProductsComponent"], _tcs_list_systems_tcs_list_systems_component__WEBPACK_IMPORTED_MODULE_1__["TcsListSystemsComponent"], _meses_meses_component__WEBPACK_IMPORTED_MODULE_11__["MesesComponent"], _product_detail_product_detail_component__WEBPACK_IMPORTED_MODULE_12__["ProductDetailComponent"], _lista_verificacion_apertura_lista_verificacion_apertura_component__WEBPACK_IMPORTED_MODULE_13__["ListaVerificacionAperturaComponent"], _plan_auditoria_plan_auditoria_component__WEBPACK_IMPORTED_MODULE_15__["PlanAuditoriaComponent"], _registro_ciclo_registro_ciclo_component__WEBPACK_IMPORTED_MODULE_14__["RegistroCicloComponent"], _ciclo_participante_ciclo_participante_component__WEBPACK_IMPORTED_MODULE_16__["CicloParticipanteComponent"], _tcs_lista_verificacion_reunion_apertura_tcs_lista_verificacion_reunion_apertura_component__WEBPACK_IMPORTED_MODULE_17__["TcsListaVerificacionReunionAperturaComponent"], _tcs_lista_verificacion_reunion_cierre_tcs_lista_verificacion_reunion_cierre_component__WEBPACK_IMPORTED_MODULE_18__["TcsListaVerificacionReunionCierreComponent"], _pra_cronograma_pra_cronograma_component__WEBPACK_IMPORTED_MODULE_19__["PraCronogramaComponent"], _buscar_norma_buscar_norma_component__WEBPACK_IMPORTED_MODULE_20__["BuscarNormaComponent"], _pra_direccion_sistema_pra_direccion_sistema_component__WEBPACK_IMPORTED_MODULE_21__["PraDireccionSistemaComponent"], _param_paises_param_paises_component__WEBPACK_IMPORTED_MODULE_22__["ParamPaisesComponent"], _pra_edit_norma_sistema_pra_edit_norma_sistema_component__WEBPACK_IMPORTED_MODULE_23__["PraEditNormaSistemaComponent"], _param_organismos_certificadores_param_organismos_certificadores_component__WEBPACK_IMPORTED_MODULE_24__["ParamOrganismosCertificadoresComponent"], _ela_cronograma_ela_cronograma_component__WEBPACK_IMPORTED_MODULE_25__["ElaCronogramaComponent"], _ela_edit_hallazago_ela_edit_hallazago_component__WEBPACK_IMPORTED_MODULE_26__["ElaEditHallazagoComponent"], _ela_registro_hallazgos_ela_registro_hallazgos_component__WEBPACK_IMPORTED_MODULE_27__["ElaRegistroHallazgosComponent"], _ela_objetivos_ela_objetivos_component__WEBPACK_IMPORTED_MODULE_28__["ElaObjetivosComponent"], _ela_registro_areapreocupacion_ela_registro_areapreocupacion_component__WEBPACK_IMPORTED_MODULE_29__["ElaRegistroAreapreocupacionComponent"], _param_documentos_param_documentos_component__WEBPACK_IMPORTED_MODULE_30__["ParamDocumentosComponent"], _ela_cronograma_list_ela_cronograma_list_component__WEBPACK_IMPORTED_MODULE_31__["ElaCronogramaListComponent"], _ela_edit_areapreocupacion_ela_edit_areapreocupacion_component__WEBPACK_IMPORTED_MODULE_32__["ElaEditAreapreocupacionComponent"], _editor_documento_editor_documento_component__WEBPACK_IMPORTED_MODULE_33__["EditorDocumentoComponent"], _tm_acta_reunion_tm_acta_reunion_component__WEBPACK_IMPORTED_MODULE_34__["TmActaReunionComponent"], _ela_plan_muestreo_ela_plan_muestreo_component__WEBPACK_IMPORTED_MODULE_35__["ElaPlanMuestreoComponent"]]
      })], ComponentsModule);
      /***/
    },

    /***/
    "jvAi":
    /*!***********************************************************************!*\
      !*** ./src/app/components/registro-ciclo/registro-ciclo.component.ts ***!
      \***********************************************************************/

    /*! exports provided: RegistroCicloComponent */

    /***/
    function jvAi(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RegistroCicloComponent", function () {
        return RegistroCicloComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_registro_ciclo_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./registro-ciclo.component.html */
      "sG/3");
      /* harmony import */


      var _registro_ciclo_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./registro-ciclo.component.scss */
      "6vZm");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");

      var RegistroCicloComponent = /*#__PURE__*/function () {
        function RegistroCicloComponent(formBuilder) {
          _classCallCheck(this, RegistroCicloComponent);

          this.formBuilder = formBuilder;
        }

        _createClass(RegistroCicloComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.ionicForm = this.formBuilder.group({});
          }
        }, {
          key: "guardarCiclo",
          value: function guardarCiclo() {
            console.log("ciclo guardado correctamente");
          }
        }, {
          key: "cancelar",
          value: function cancelar() {
            console.log("cancelamdo");
          }
        }]);

        return RegistroCicloComponent;
      }();

      RegistroCicloComponent.ctorParameters = function () {
        return [{
          type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
        }];
      };

      RegistroCicloComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-registro-ciclo',
        template: _raw_loader_registro_ciclo_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_registro_ciclo_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], RegistroCicloComponent);
      /***/
    },

    /***/
    "kEXP":
    /*!***************************************************************************************!*\
      !*** ./src/app/components/pra-direccion-sistema/pra-direccion-sistema.component.scss ***!
      \***************************************************************************************/

    /*! exports provided: default */

    /***/
    function kEXP(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwcmEtZGlyZWNjaW9uLXNpc3RlbWEuY29tcG9uZW50LnNjc3MifQ== */";
      /***/
    },

    /***/
    "kLfG":
    /*!*****************************************************************************************************************************************!*\
      !*** ./node_modules/@ionic/core/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
      \*****************************************************************************************************************************************/

    /*! no static exports found */

    /***/
    function kLfG(module, exports, __webpack_require__) {
      var map = {
        "./ion-action-sheet.entry.js": ["dUtr", "common", 0],
        "./ion-alert.entry.js": ["Q8AI", "common", 1],
        "./ion-app_8.entry.js": ["hgI1", "common", 2],
        "./ion-avatar_3.entry.js": ["CfoV", "common", 3],
        "./ion-back-button.entry.js": ["Nt02", "common", 4],
        "./ion-backdrop.entry.js": ["Q2Bp", 5],
        "./ion-button_2.entry.js": ["0Pbj", "common", 6],
        "./ion-card_5.entry.js": ["ydQj", "common", 7],
        "./ion-checkbox.entry.js": ["4fMi", "common", 8],
        "./ion-chip.entry.js": ["czK9", "common", 9],
        "./ion-col_3.entry.js": ["/CAe", 10],
        "./ion-datetime_3.entry.js": ["WgF3", "common", 11],
        "./ion-fab_3.entry.js": ["uQcF", "common", 12],
        "./ion-img.entry.js": ["wHD8", 13],
        "./ion-infinite-scroll_2.entry.js": ["2lz6", 14],
        "./ion-input.entry.js": ["ercB", "common", 15],
        "./ion-item-option_3.entry.js": ["MGMP", "common", 16],
        "./ion-item_8.entry.js": ["9bur", "common", 17],
        "./ion-loading.entry.js": ["cABk", "common", 18],
        "./ion-menu_3.entry.js": ["kyFE", "common", 19],
        "./ion-modal.entry.js": ["TvZU", "common", 20],
        "./ion-nav_2.entry.js": ["vnES", "common", 21],
        "./ion-popover.entry.js": ["qCuA", "common", 22],
        "./ion-progress-bar.entry.js": ["0tOe", "common", 23],
        "./ion-radio_2.entry.js": ["h11V", "common", 24],
        "./ion-range.entry.js": ["XGij", "common", 25],
        "./ion-refresher_2.entry.js": ["nYbb", "common", 26],
        "./ion-reorder_2.entry.js": ["smMY", "common", 27],
        "./ion-ripple-effect.entry.js": ["STjf", 28],
        "./ion-route_4.entry.js": ["k5eQ", "common", 29],
        "./ion-searchbar.entry.js": ["OR5t", "common", 30],
        "./ion-segment_2.entry.js": ["fSgp", "common", 31],
        "./ion-select_3.entry.js": ["lfGF", "common", 32],
        "./ion-slide_2.entry.js": ["5xYT", 33],
        "./ion-spinner.entry.js": ["nI0H", "common", 34],
        "./ion-split-pane.entry.js": ["NAQR", 35],
        "./ion-tab-bar_2.entry.js": ["knkW", "common", 36],
        "./ion-tab_2.entry.js": ["TpdJ", "common", 37],
        "./ion-text.entry.js": ["ISmu", "common", 38],
        "./ion-textarea.entry.js": ["U7LX", "common", 39],
        "./ion-toast.entry.js": ["L3sA", "common", 40],
        "./ion-toggle.entry.js": ["IUOf", "common", 41],
        "./ion-virtual-scroll.entry.js": ["8Mb5", 42]
      };

      function webpackAsyncContext(req) {
        if (!__webpack_require__.o(map, req)) {
          return Promise.resolve().then(function () {
            var e = new Error("Cannot find module '" + req + "'");
            e.code = 'MODULE_NOT_FOUND';
            throw e;
          });
        }

        var ids = map[req],
            id = ids[0];
        return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function () {
          return __webpack_require__(id);
        });
      }

      webpackAsyncContext.keys = function webpackAsyncContextKeys() {
        return Object.keys(map);
      };

      webpackAsyncContext.id = "kLfG";
      module.exports = webpackAsyncContext;
      /***/
    },

    /***/
    "kSin":
    /*!***************************************************************************!*\
      !*** ./src/app/components/tm-acta-reunion/tm-acta-reunion.component.scss ***!
      \***************************************************************************/

    /*! exports provided: default */

    /***/
    function kSin(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".container-product-list {\n  margin-top: 0em;\n}\n\n.popover-content.sc-ion-popover-md {\n  width: 500px !important;\n}\n\n.my-custom-modal-css .modal-wrapper {\n  width: 600px;\n  height: 650px !important;\n}\n\n.normas {\n  font-size: 12px;\n  color: #1b192c;\n}\n\n.title-normas {\n  color: #0b480f;\n  font-size: 1em;\n  text-align: left;\n}\n\n.norma-block {\n  background-color: #c6e8e6;\n  padding: 10px;\n  margin: 1.5px;\n  min-width: 100%;\n}\n\n.big-icon {\n  font-size: 1.2em;\n  margin-left: 3px;\n  cursor: -webkit-grab;\n  cursor: grab;\n}\n\n.detail-paragraph {\n  font-size: 11px;\n  color: #3d3c44;\n}\n\n.sub-title {\n  /*font-style: italic;*/\n  font-size: 13px;\n  color: #055a0f;\n  font-family: sans-serif;\n}\n\n.direccion-block {\n  background-color: #c1ebd6;\n  padding: 10px;\n  margin: 1.5px;\n  min-width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFx0bS1hY3RhLXJldW5pb24uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxlQUFBO0FBQ0o7O0FBQ0U7RUFDSSx1QkFBQTtBQUVOOztBQUNFO0VBQ0UsWUFBQTtFQUNBLHdCQUFBO0FBRUo7O0FBQUU7RUFDRSxlQUFBO0VBQ0EsY0FBQTtBQUdKOztBQURFO0VBQ0UsY0FBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBQUlKOztBQUZFO0VBQ0UseUJBQUE7RUFDQSxhQUFBO0VBQ0EsYUFBQTtFQUNBLGVBQUE7QUFLSjs7QUFIRTtFQUNFLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxvQkFBQTtFQUFBLFlBQUE7QUFNSjs7QUFKRTtFQUNFLGVBQUE7RUFDQSxjQUFBO0FBT0o7O0FBTEU7RUFDRSxzQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsdUJBQUE7QUFRSjs7QUFORTtFQUNFLHlCQUFBO0VBQ0EsYUFBQTtFQUNBLGFBQUE7RUFDQSxlQUFBO0FBU0oiLCJmaWxlIjoidG0tYWN0YS1yZXVuaW9uLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRhaW5lci1wcm9kdWN0LWxpc3Qge1xyXG4gICAgbWFyZ2luLXRvcDogMGVtO1xyXG4gIH1cclxuICAucG9wb3Zlci1jb250ZW50LnNjLWlvbi1wb3BvdmVyLW1kIHtcclxuICAgICAgd2lkdGg6IDUwMHB4ICFpbXBvcnRhbnQ7XHJcbiAgfVxyXG4gIFxyXG4gIC5teS1jdXN0b20tbW9kYWwtY3NzIC5tb2RhbC13cmFwcGVyIHtcclxuICAgIHdpZHRoOiA2MDBweDtcclxuICAgIGhlaWdodDogNjUwcHggIWltcG9ydGFudDtcclxuICB9IFxyXG4gIC5ub3JtYXMge1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgY29sb3I6ICMxYjE5MmM7XHJcbiAgfVxyXG4gIC50aXRsZS1ub3JtYXMge1xyXG4gICAgY29sb3I6ICMwYjQ4MGY7XHJcbiAgICBmb250LXNpemU6IDFlbTtcclxuICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgfVxyXG4gIC5ub3JtYS1ibG9jayB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjYzZlOGU2O1xyXG4gICAgcGFkZGluZzogMTBweDtcclxuICAgIG1hcmdpbjogMS41cHg7XHJcbiAgICBtaW4td2lkdGg6IDEwMCU7XHJcbiAgfVxyXG4gIC5iaWctaWNvbiB7XHJcbiAgICBmb250LXNpemU6IDEuMmVtO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDNweDtcclxuICAgIGN1cnNvcjogZ3JhYjtcclxuICB9XHJcbiAgLmRldGFpbC1wYXJhZ3JhcGgge1xyXG4gICAgZm9udC1zaXplOiAxMXB4O1xyXG4gICAgY29sb3I6ICMzZDNjNDQ7XHJcbiAgfVxyXG4gIC5zdWItdGl0bGUge1xyXG4gICAgLypmb250LXN0eWxlOiBpdGFsaWM7Ki9cclxuICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgIGNvbG9yOiAjMDU1YTBmO1xyXG4gICAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XHJcbiAgfVxyXG4gIC5kaXJlY2Npb24tYmxvY2sge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2MxZWJkNjtcclxuICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICBtYXJnaW46IDEuNXB4O1xyXG4gICAgbWluLXdpZHRoOiAxMDAlO1xyXG4gIH0iXX0= */";
      /***/
    },

    /***/
    "kWn8":
    /*!*****************************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/lista-verificacion-apertura/lista-verificacion-apertura.component.html ***!
      \*****************************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function kWn8(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<app-custom-header\r\n  title=\"LISTA DE VERIFICACION DE APERTURA\"\r\n  icon_name=\"list\"\r\n></app-custom-header>\r\n<ion-content>\r\n  <ion-list>\r\n    <ion-item *ngFor=\"let entry of data\" (click)=\"clickCheck(entry)\">\r\n      <ion-checkbox\r\n        slot=\"start\"\r\n        [(ngModel)]=\"entry.selected\"\r\n      ></ion-checkbox>\r\n      <ion-label>{{ entry.name }}</ion-label>\r\n    </ion-item>\r\n  </ion-list>\r\n</ion-content>\r\n";
      /***/
    },

    /***/
    "kktw":
    /*!***************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/param-horarios/param-horarios.component.html ***!
      \***************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function kktw(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-ilst>\n  <ion-item>\n    <ion-label>Inicio</ion-label>\n    <ion-datetime\n      display-format=\"H:mm\"\n      picker-format=\"H:mm\"\n      cancelText=\"Cancelar\"\n      doneText=\"Confirmar\"\n      [ngModel]=\"horarioIni\"\n      (ionChange)=\"selectionarHorarioIni($event)\"\n    ></ion-datetime>\n  </ion-item>\n  <ion-item>\n    <ion-label>Fin</ion-label>\n    <ion-datetime\n      display-format=\"H:mm\"\n      picker-format=\"H:mm\"\n      cancelText=\"Cancelar\"\n      doneText=\"Confirmar\"\n      [ngModel]=\"horarioFin\"\n      (ionChange)=\"selectionarHorarioFin($event)\"\n    ></ion-datetime>\n  </ion-item>\n</ion-ilst>\n";
      /***/
    },

    /***/
    "lUYT":
    /*!***********************************************************************!*\
      !*** ./src/app/components/product-detail/product-detail.component.ts ***!
      \***********************************************************************/

    /*! exports provided: ProductDetailComponent */

    /***/
    function lUYT(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ProductDetailComponent", function () {
        return ProductDetailComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_product_detail_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./product-detail.component.html */
      "wELF");
      /* harmony import */


      var _product_detail_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./product-detail.component.scss */
      "Yp8f");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/angular */
      "sZkV");
      /* harmony import */


      var src_app_interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! src/app/interfaces/cross-ui/ConvertFormToObject */
      "GeA3");

      var ProductDetailComponent = /*#__PURE__*/function () {
        function ProductDetailComponent(toastController, formBuilder) {
          _classCallCheck(this, ProductDetailComponent);

          this.toastController = toastController;
          this.formBuilder = formBuilder;
          this.showBuscadorNormas = false;
          this.guardarProductEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
          this.cancelarProductEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
          this.mode = "default-pais";
        }

        _createClass(ProductDetailComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.ionicForm = this.formBuilder.group({});
          }
        }, {
          key: "guardarProduct",
          value: function guardarProduct() {
            var _this46 = this;

            src_app_interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_6__["ConvertFormToObject"].convert(this.ionicForm, this.pradireccionespaproducto);
            this.presentToast("Producto guardado correctamente").then(function (resul) {
              if (_this46.guardarProductEmitter) {
                _this46.guardarProductEmitter.emit(_this46.pradireccionespaproducto);
              }
            });
          }
        }, {
          key: "presentToast",
          value: function presentToast(mensaje) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee9() {
              var toast;
              return regeneratorRuntime.wrap(function _callee9$(_context9) {
                while (1) {
                  switch (_context9.prev = _context9.next) {
                    case 0:
                      _context9.next = 2;
                      return this.toastController.create({
                        message: mensaje,
                        duration: 2000
                      });

                    case 2:
                      toast = _context9.sent;
                      toast.present();

                    case 4:
                    case "end":
                      return _context9.stop();
                  }
                }
              }, _callee9, this);
            }));
          }
        }, {
          key: "cambiarNorma",
          value: function cambiarNorma(norma) {
            console.log("cambiarNorma", norma);
            this.pradireccionespaproducto.norma = norma.codigoNorma;
            this.showBuscadorNormas = false;
          }
        }, {
          key: "mostrarBuscadorNorma",
          value: function mostrarBuscadorNorma() {
            console.log("ingreso al evento");
            this.showBuscadorNormas = true;
          }
        }, {
          key: "cancelar",
          value: function cancelar() {
            this.showBuscadorNormas = false;

            if (this.cancelarProductEmitter) {
              this.cancelarProductEmitter.emit(this.pradireccionespaproducto);
            }
          }
        }, {
          key: "cambiarModoPais",
          value: function cambiarModoPais() {
            this.mode = "edit-pais";
          }
        }, {
          key: "localizacionSeleccionda",
          value: function localizacionSeleccionda(localizacion) {
            src_app_interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_6__["ConvertFormToObject"].convert(this.ionicForm, this.pradireccionespaproducto);
            this.pradireccionespaproducto.pais = localizacion.pais.paisNombre;
            this.pradireccionespaproducto.estado = localizacion.estado.estNombre;
            this.pradireccionespaproducto.ciudad = localizacion.ciudad.nomCiudad;
            src_app_interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_6__["ConvertObjectToForm"].convert(this.ionicForm, this.pradireccionespaproducto);
            this.mode = "default-pais";
          }
        }]);

        return ProductDetailComponent;
      }();

      ProductDetailComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"]
        }, {
          type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
        }];
      };

      ProductDetailComponent.propDecorators = {
        pradireccionespaproducto: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        guardarProductEmitter: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }],
        cancelarProductEmitter: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }]
      };
      ProductDetailComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: "app-product-detail",
        template: _raw_loader_product_detail_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_product_detail_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], ProductDetailComponent);
      /***/
    },

    /***/
    "lrqV":
    /*!*******************************************************************************!*\
      !*** ./src/app/components/ela-edit-hallazago/ela-edit-hallazago.component.ts ***!
      \*******************************************************************************/

    /*! exports provided: ElaEditHallazagoComponent */

    /***/
    function lrqV(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ElaEditHallazagoComponent", function () {
        return ElaEditHallazagoComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_ela_edit_hallazago_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./ela-edit-hallazago.component.html */
      "eiTQ");
      /* harmony import */


      var _ela_edit_hallazago_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./ela-edit-hallazago.component.scss */
      "xy4t");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/angular */
      "sZkV");
      /* harmony import */


      var src_app_interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! src/app/interfaces/cross-ui/ConvertFormToObject */
      "GeA3");
      /* harmony import */


      var src_app_interfaces_elaboracion_auditoria_PlanAuditoriaDTO__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! src/app/interfaces/elaboracion_auditoria/PlanAuditoriaDTO */
      "6GDD");
      /* harmony import */


      var src_app_interfaces_seguridad_usuario__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! src/app/interfaces/seguridad/usuario */
      "PI2N");

      var ElaEditHallazagoComponent = /*#__PURE__*/function () {
        function ElaEditHallazagoComponent(toastController, formBuilder) {
          _classCallCheck(this, ElaEditHallazagoComponent);

          this.toastController = toastController;
          this.formBuilder = formBuilder; //@Input() lNormas: string[];
          //@Input() ltiposObervacion: string[];

          this.tipoObservacion = null;
          this.guardarHallazgoEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
          this.cancelarHallazgoEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
          this.ltiposObervacion = [{
            nemotico: "NCM",
            descripcion: "No-Conformidad Mayor"
          }, {
            nemotico: "OM",
            descripcion: "Oportunidad de mejora"
          }, {
            nemotico: "NCm",
            descripcion: "No Conformidad Menor"
          }, {
            nemotico: "F",
            descripcion: "Fortaleza"
          }];
          this.lNormas = ["ISO:2007", "ISO:9001", "ISO:4427", "ISO:1334"];
        }

        _createClass(ElaEditHallazagoComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this47 = this;

            this.ionicFormHallazgo = this.formBuilder.group({});

            if (this.elahallazgo) {
              this.tipoObservacion = this.ltiposObervacion.filter(function (x) {
                return x.nemotico === _this47.elahallazgo.tipoNemotico;
              })[0];
            }

            if (!this.elahallazgo) this.elahallazgo = new src_app_interfaces_elaboracion_auditoria_PlanAuditoriaDTO__WEBPACK_IMPORTED_MODULE_7__["Elahallazgo"]();
          }
        }, {
          key: "editarHallazgo",
          value: function editarHallazgo() {}
        }, {
          key: "valorHallazagos",
          value: function valorHallazagos(event) {
            this.elahallazgo.hallazgo = event.detail.value;
          }
        }, {
          key: "cancelarHallazo",
          value: function cancelarHallazo() {
            if (this.cancelarHallazgoEmitter) {
              this.cancelarHallazgoEmitter.emit();
            }
          }
        }, {
          key: "guardarHallazgo",
          value: function guardarHallazgo() {
            console.log("Guardar Hallazgo");
            src_app_interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_6__["ConvertFormToObject"].convert(this.ionicFormHallazgo, this.elahallazgo);
            this.elahallazgo.fecha = this.getStringFromDate(new Date());
            this.elahallazgo.usuario = src_app_interfaces_seguridad_usuario__WEBPACK_IMPORTED_MODULE_8__["usuario"].currentUser.nick;

            if (this.guardarHallazgoEmitter) {
              this.guardarHallazgoEmitter.emit(this.elahallazgo);
            }
          }
        }, {
          key: "seleccionarTipo",
          value: function seleccionarTipo(event) {
            console.log("seleccionar Hallazgo", event);
            this.elahallazgo.tipo = event.detail.value.descripcion;
            this.elahallazgo.tipoNemotico = event.detail.value.nemotico;
          }
        }, {
          key: "seleccionarNorma",
          value: function seleccionarNorma(event) {
            console.log("seleccionar Hallazgo", event);
            this.elahallazgo.normas = event.detail.value;
          }
        }, {
          key: "getStringFromDate",
          value: function getStringFromDate(date) {
            return (date.getDate() > 9 ? date.getDate() : "0" + date.getDate()) + "/" + (date.getMonth() > 8 ? date.getMonth() + 1 : "0" + (date.getMonth() + 1)) + "/" + date.getFullYear();
          }
        }]);

        return ElaEditHallazagoComponent;
      }();

      ElaEditHallazagoComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"]
        }, {
          type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
        }];
      };

      ElaEditHallazagoComponent.propDecorators = {
        elahallazgo: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        guardarHallazgoEmitter: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }],
        cancelarHallazgoEmitter: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }],
        lNormas: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }]
      };
      ElaEditHallazagoComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: "app-ela-edit-hallazago",
        template: _raw_loader_ela_edit_hallazago_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_ela_edit_hallazago_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], ElaEditHallazagoComponent);
      /***/
    },

    /***/
    "oNGt":
    /*!*********************************************************************!*\
      !*** ./src/app/components/param-paises/param-paises.component.scss ***!
      \*********************************************************************/

    /*! exports provided: default */

    /***/
    function oNGt(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwYXJhbS1wYWlzZXMuY29tcG9uZW50LnNjc3MifQ== */";
      /***/
    },

    /***/
    "q7BG":
    /*!***************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/pra-cronograma/pra-cronograma.component.html ***!
      \***************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function q7BG(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-card mode=\"ios\" *ngIf=\"currentPraciclocronogramas\">\r\n  <ion-item color=\"medium\" color=\"title-small\">\r\n    <ion-icon name=\"time\" slot=\"start\"></ion-icon>\r\n    <ion-label>CRONOGRAMA</ion-label>\r\n  </ion-item>\r\n  <ion-card-content class=\"ion-content-small-font\">\r\n    <div class=\"item-cronograma\">\r\n      <span class=\"label-cronograma\">DIAS TOTAL: </span>\r\n      <span class=\"data-cronograma\">\r\n        {{ currentPraciclocronogramas.diasPresupuesto }}\r\n      </span>\r\n    </div>\r\n    <div class=\"item-cronograma\">\r\n      <span class=\"label-cronograma\">DIAS INSITU: </span>\r\n      <span class=\"data-cronograma\" class=\"box-click edit-item\" (click)=\"mostrarDiasInsituCronograma($event)\">\r\n        {{ currentPraciclocronogramas.diasInsitu }}\r\n      </span>\r\n    </div>\r\n    <div class=\"item-cronograma\">\r\n      <span class=\"label-cronograma\">DIAS REMOTO: </span>\r\n      <span class=\"data-cronograma\" class=\"box-click edit-item\" (click)=\"mostrarDiasRemotoCronograma($event)\">\r\n        {{ currentPraciclocronogramas.diasRemoto }}\r\n      </span>\r\n    </div>\r\n    <div class=\"item-cronograma\">\r\n      <span class=\"label-cronograma\">HORARIO: </span>\r\n      <span class=\"data-cronograma\" class=\"box-click edit-item\" (click)=\"mostrarHorarioCronograma($event)\">\r\n        {{ currentPraciclocronogramas.horarioTrabajo }}\r\n      </span>\r\n    </div>\r\n    <div class=\"item-cronograma\">\r\n      <span class=\"label-cronograma\">MES PROGRAMADO:</span>\r\n      <span (click)=\"mostrarMesesProgramado($event)\" class=\"box-click edit-item\">\r\n        {{ currentPraciclocronogramas.mesProgramado | date: \"MM/yyyy\" }}\r\n      </span>\r\n    </div>\r\n    <div class=\"item-cronograma\">\r\n      <span class=\"label-cronograma\">MES REPROGRAMADO:</span>\r\n      <ion-label (click)=\"mostrarMesesReprogamado($event)\" class=\"box-click edit-item\">\r\n        {{ currentPraciclocronogramas.mesReprogramado | date: \"MM/yyyy\" }}\r\n      </ion-label>\r\n    </div>\r\n    <div class=\"item-cronograma\">\r\n      <span class=\"label-cronograma\">FECHA DE INICIO DE EJECUCIÓN AUDITORÍA:</span>\r\n      <ion-label (click)=\"mostrarFechaEjecucion($event)\" class=\"box-click edit-item\">\r\n        {{\r\n          currentPraciclocronogramas.fechaInicioDeEjecucionDeAuditoria\r\n            | date: \"dd/MM/yyyy\"\r\n        }}\r\n      </ion-label>\r\n    </div>\r\n    <div class=\"item-cronograma\">\r\n      <span class=\"label-cronograma\">FECHA DE FIN DE EJECUCIÓN AUDITORÍA:</span>\r\n      <ion-label (click)=\"mostrarFechaFin($event)\" class=\"box-click edit-item\">\r\n        {{\r\n          currentPraciclocronogramas.fechaDeFinDeEjecucionAuditoria\r\n            | date: \"dd/MM/yyyy\"\r\n        }}\r\n      </ion-label>\r\n    </div>\r\n    <div class=\"item-cronograma\">\r\n      <span class=\"label-cronograma\">ESTADO:</span>\r\n      <ion-label class=\"box-click\">\r\n        {{ currentPraciclocronogramas.estado }}\r\n      </ion-label>\r\n    </div>\r\n\r\n  </ion-card-content>\r\n</ion-card>\r\n";
      /***/
    },

    /***/
    "qQ6a":
    /*!***********************************************************************!*\
      !*** ./src/app/components/ela-objetivos/ela-objetivos.component.scss ***!
      \***********************************************************************/

    /*! exports provided: default */

    /***/
    function qQ6a(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlbGEtb2JqZXRpdm9zLmNvbXBvbmVudC5zY3NzIn0= */";
      /***/
    },

    /***/
    "qaNy":
    /*!*************************************************************************************!*\
      !*** ./src/app/components/pra-direccion-sistema/pra-direccion-sistema.component.ts ***!
      \*************************************************************************************/

    /*! exports provided: PraDireccionSistemaComponent */

    /***/
    function qaNy(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PraDireccionSistemaComponent", function () {
        return PraDireccionSistemaComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_pra_direccion_sistema_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./pra-direccion-sistema.component.html */
      "iRyo");
      /* harmony import */


      var _pra_direccion_sistema_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./pra-direccion-sistema.component.scss */
      "kEXP");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/angular */
      "sZkV");
      /* harmony import */


      var src_app_interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! src/app/interfaces/cross-ui/ConvertFormToObject */
      "GeA3");

      var PraDireccionSistemaComponent = /*#__PURE__*/function () {
        function PraDireccionSistemaComponent(toastController, formBuilder) {
          _classCallCheck(this, PraDireccionSistemaComponent);

          this.toastController = toastController;
          this.formBuilder = formBuilder;
          this.showBuscadorNormas = false;
          this.guardarDireccionEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
          this.cancelarDireccionEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
          this.mode = "default-pais";
        }

        _createClass(PraDireccionSistemaComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.ionicForm = this.formBuilder.group({});
          }
        }, {
          key: "presentToast",
          value: function presentToast(mensaje) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee10() {
              var toast;
              return regeneratorRuntime.wrap(function _callee10$(_context10) {
                while (1) {
                  switch (_context10.prev = _context10.next) {
                    case 0:
                      _context10.next = 2;
                      return this.toastController.create({
                        message: mensaje,
                        duration: 2000
                      });

                    case 2:
                      toast = _context10.sent;
                      toast.present();

                    case 4:
                    case "end":
                      return _context10.stop();
                  }
                }
              }, _callee10, this);
            }));
          }
        }, {
          key: "guardarDireccion",
          value: function guardarDireccion() {
            var _this48 = this;

            console.log("Guardar Direcc");
            src_app_interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_6__["ConvertFormToObject"].convert(this.ionicForm, this.pradireccionespasistema);
            this.presentToast("Dirección guardada correctamente").then(function (resul) {
              if (_this48.guardarDireccionEmitter) {
                _this48.guardarDireccionEmitter.emit(_this48.pradireccionespasistema);
              }
            });
          }
        }, {
          key: "cancelar",
          value: function cancelar() {
            console.log("Cancelar Direcc");

            if (this.cancelarDireccionEmitter) {
              this.cancelarDireccionEmitter.emit(this.pradireccionespasistema);
            }
          }
        }, {
          key: "cambiarModoPais",
          value: function cambiarModoPais() {
            this.mode = "edit-pais";
          }
        }, {
          key: "localizacionSeleccionda",
          value: function localizacionSeleccionda(localizacion) {
            src_app_interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_6__["ConvertFormToObject"].convert(this.ionicForm, this.pradireccionespasistema);
            this.pradireccionespasistema.pais = localizacion.pais.paisNombre;
            this.pradireccionespasistema.departamento = localizacion.estado.estNombre;
            this.pradireccionespasistema.ciudad = localizacion.ciudad.nomCiudad;
            src_app_interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_6__["ConvertObjectToForm"].convert(this.ionicForm, this.pradireccionespasistema);
            this.mode = "default-pais";
          }
        }]);

        return PraDireccionSistemaComponent;
      }();

      PraDireccionSistemaComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"]
        }, {
          type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
        }];
      };

      PraDireccionSistemaComponent.propDecorators = {
        pradireccionespasistema: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        guardarDireccionEmitter: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }],
        cancelarDireccionEmitter: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }]
      };
      PraDireccionSistemaComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: "app-pra-direccion-sistema",
        template: _raw_loader_pra_direccion_sistema_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_pra_direccion_sistema_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], PraDireccionSistemaComponent);
      /***/
    },

    /***/
    "qvR5":
    /*!*****************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/tm-acta-reunion/tm-acta-reunion.component.html ***!
      \*****************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function qvR5(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-list>\n  <ion-item>\n    <app-custom-input\n      label=\"Nro de Acta\"\n      name=\"nro_acta\"\n      type=\"text\"\n      [formGruop]=\"ionicForm\"\n      [form]=\"form\"\n      [defaultValue]=\"\"\n    ></app-custom-input>\n  </ion-item>\n  <ion-item>\n    <ion-label position=\"stacked\"> Fecha </ion-label>\n    {{ fecha }}\n  </ion-item>\n  <ion-item>\n    <ion-label position=\"stacked\">\n      Consideraciones del acta anterior\n    </ion-label>\n    <ion-select\n      interface=\"popover\"\n      placeholder=\"\"\n      class=\"cargo-select\"\n      okText=\"Ok\"\n      cancelText=\"Cancelar\"\n      (ionChange)=\"seleccionarConsideraciones($event)\"\n      multiple=\"false\"\n    >\n      <ion-select-option\n        *ngFor=\"let organismo of lConsideracione\"\n        [value]=\"organismo\"\n        class=\"cargo-select\"\n        >{{ organismo }}\n      </ion-select-option>\n    </ion-select>\n  </ion-item>\n  <ion-item>\n    <ion-label position=\"stacked\">\n      Revisión y recomendación a la dirección ejecutiva del IBNORCA de los\n      informes presentados al CONCER:\n    </ion-label>\n  </ion-item>\n  <ion-item *ngFor=\"let producto of productos; let i = index\">\n    <ion-icon\n      name=\"pencil-sharp\"\n      slot=\"start\"\n      (click)=\"editar(product, i)\"\n      class=\"big-icon\"\n    ></ion-icon>\n    <div class=\"norma-block\">\n      <h2>\n        Producto: {{ producto.producto }} [Proceso: {{ producto.proceso }}]\n        [Empresa: {{ producto.empresa }}]\n      </h2>\n      <p>\n        Norma {{ producto.norma }}, Confirmacion:\n        {{ producto.confirmacion }}\n      </p>\n      <p class=\"detail-paragraph\">\n        <span class=\"sub-title\">{{ producto.desc_revision }}</span>\n      </p>\n    </div>\n  </ion-item>\n  <ion-item>\n    <ion-label position=\"stacked\">\n      Revisión y decisión sobre Reglamentos Particulares\n    </ion-label>\n    <ion-select\n      interface=\"popover\"\n      placeholder=\"\"\n      class=\"cargo-select\"\n      okText=\"Ok\"\n      cancelText=\"Cancelar\"\n      (ionChange)=\"seleccionarRevision($event)\"\n      [value]=\"currentOrganismo\"\n      multiple=\"false\"\n    >\n      <ion-select-option\n        *ngFor=\"let organismo of lRevision\"\n        [value]=\"organismo\"\n        class=\"cargo-select\"\n        >{{ organismo }}\n      </ion-select-option>\n    </ion-select>\n    <ion-list-header class=\"title-normas\">\n      <ion-item>\n        <ion-icon\n          name=\"add-circle\"\n          slot=\"end\"\n          (click)=\"adicionar()\"\n          class=\"big-icon\"\n        ></ion-icon>\n        Reglamentos\n      </ion-item>\n    </ion-list-header>\n    <ion-item *ngFor=\"let reglamento of reglamentos; let i = index\">\n      <ion-icon\n        name=\"pencil-sharp\"\n        slot=\"start\"\n        (click)=\"editar(product, i)\"\n        class=\"big-icon\"\n      ></ion-icon>\n      <ion-icon\n        name=\"trash\"\n        slot=\"start\"\n        (click)=\"eliminar(i)\"\n        *ngIf=\"allowDelete\"\n        class=\"big-icon\"\n      ></ion-icon>\n      <div class=\"norma-block\">\n        <h2>\n          Nombre: {{ reglamento.nombre }} [Norma Base:\n          {{ reglamento.norma_base }}]\n        </h2>\n        <p>Desicion {{ reglamento.decision }}</p>\n        <p class=\"detail-paragraph\">\n          <span class=\"sub-title\">{{ reglamento.descripcion }}</span>\n        </p>\n      </div>\n    </ion-item>\n  </ion-item>\n  <ion-item>\n    <ion-label position=\"stacked\"> Varios </ion-label>\n    <ion-select\n      interface=\"popover\"\n      placeholder=\"\"\n      class=\"cargo-select\"\n      okText=\"Ok\"\n      cancelText=\"Cancelar\"\n      (ionChange)=\"seleccionarVarios($event)\"\n      [value]=\"currentOrganismo\"\n      multiple=\"false\"\n    >\n      <ion-select-option\n        *ngFor=\"let organismo of lVarios\"\n        [value]=\"organismo\"\n        class=\"cargo-select\"\n        >{{ organismo }}\n      </ion-select-option>\n    </ion-select>\n  </ion-item>\n</ion-list>\n";
      /***/
    },

    /***/
    "sG/3":
    /*!***************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/registro-ciclo/registro-ciclo.component.html ***!
      \***************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function sG3(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<form [formGroup]=\"ionicForm\" (ngSubmit)=\"guardarCiclo()\" #form=\"ngForm\">\n  <ion-grid>\n    <ion-row>\n      <ion-col size=\"4\">\n        <app-custom-input\n          label=\"Años\"\n          name=\"anios\"\n          type=\"text\"\n          [formGruop]=\"ionicForm\"\n          [form]=\"form\"\n          defaultValue=\"La Paz\"\n        ></app-custom-input>\n      </ion-col>\n      <ion-col size=\"4\">\n        <app-custom-input\n          label=\"Etapa\"\n          name=\"etapa\"\n          type=\"text\"\n          [formGruop]=\"ionicForm\"\n          [form]=\"form\"\n          defaultValue=\"La Paz\"\n        ></app-custom-input>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-buttons collapse=\"true\">\n        <ion-button type=\"submit\" color=\"success\"> Aceptar </ion-button>\n        <ion-button type=\"button\" color=\"danger\" (click)=\"cancelar()\"\n          >Cancelar</ion-button\n        >\n      </ion-buttons>\n    </ion-row>\n  </ion-grid>\n</form>\n";
      /***/
    },

    /***/
    "u10Q":
    /*!***************************************************************************!*\
      !*** ./src/app/components/editor-documento/editor-documento.component.ts ***!
      \***************************************************************************/

    /*! exports provided: EditorDocumentoComponent */

    /***/
    function u10Q(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "EditorDocumentoComponent", function () {
        return EditorDocumentoComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_editor_documento_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./editor-documento.component.html */
      "hCss");
      /* harmony import */


      var _editor_documento_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./editor-documento.component.scss */
      "5e0s");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var src_app_interfaces_toma_decisiones_tmddocumentacionauditorium__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! src/app/interfaces/toma_decisiones/tmddocumentacionauditorium */
      "NiF9");

      var EditorDocumentoComponent = /*#__PURE__*/function () {
        function EditorDocumentoComponent() {
          _classCallCheck(this, EditorDocumentoComponent);

          this.guardarContenidoEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
          this.contenido = "";
        }

        _createClass(EditorDocumentoComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            if (!this.tmddocumentacionauditorium) {
              this.tmddocumentacionauditorium = new src_app_interfaces_toma_decisiones_tmddocumentacionauditorium__WEBPACK_IMPORTED_MODULE_4__["Tmddocumentacionauditorium"]();
            }
          }
        }, {
          key: "ngOnDestroy",
          value: function ngOnDestroy() {}
        }, {
          key: "guardarContenido",
          value: function guardarContenido() {
            if (this.guardarContenidoEmitter) {
              this.guardarContenidoEmitter.emit(this.contenido);
            }
          }
        }]);

        return EditorDocumentoComponent;
      }();

      EditorDocumentoComponent.ctorParameters = function () {
        return [];
      };

      EditorDocumentoComponent.propDecorators = {
        titulo: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        tmddocumentacionauditorium: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        guardarContenidoEmitter: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }]
      };
      EditorDocumentoComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: "app-editor-documento",
        template: _raw_loader_editor_documento_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_editor_documento_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], EditorDocumentoComponent);
      /***/
    },

    /***/
    "u2kC":
    /*!***************************************************************************************************************************!*\
      !*** ./src/app/components/tcs-lista-verificacion-reunion-apertura/tcs-lista-verificacion-reunion-apertura.component.scss ***!
      \***************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function u2kC(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0Y3MtbGlzdGEtdmVyaWZpY2FjaW9uLXJldW5pb24tYXBlcnR1cmEuY29tcG9uZW50LnNjc3MifQ== */";
      /***/
    },

    /***/
    "u5Bp":
    /*!*********************************************************************!*\
      !*** ./src/app/components/message-error/message-error.component.ts ***!
      \*********************************************************************/

    /*! exports provided: MessageErrorComponent */

    /***/
    function u5Bp(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "MessageErrorComponent", function () {
        return MessageErrorComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_message_error_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./message-error.component.html */
      "w4ZD");
      /* harmony import */


      var _message_error_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./message-error.component.scss */
      "RA6F");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");

      var MessageErrorComponent = /*#__PURE__*/function () {
        function MessageErrorComponent() {
          _classCallCheck(this, MessageErrorComponent);
        }

        _createClass(MessageErrorComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return MessageErrorComponent;
      }();

      MessageErrorComponent.ctorParameters = function () {
        return [];
      };

      MessageErrorComponent.propDecorators = {
        error: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }]
      };
      MessageErrorComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-message-error',
        template: _raw_loader_message_error_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_message_error_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], MessageErrorComponent);
      /***/
    },

    /***/
    "uBMp":
    /*!****************************************************!*\
      !*** ./src/app/interfaces/General/Localizacion.ts ***!
      \****************************************************/

    /*! exports provided: Localizacion */

    /***/
    function uBMp(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Localizacion", function () {
        return Localizacion;
      });

      var Localizacion = function Localizacion() {
        _classCallCheck(this, Localizacion);
      };
      /***/

    },

    /***/
    "uuHY":
    /*!*********************************************************************!*\
      !*** ./src/app/components/custom-header/custom-header.component.ts ***!
      \*********************************************************************/

    /*! exports provided: CustomHeaderComponent */

    /***/
    function uuHY(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CustomHeaderComponent", function () {
        return CustomHeaderComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_custom_header_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./custom-header.component.html */
      "KzMd");
      /* harmony import */


      var _custom_header_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./custom-header.component.scss */
      "1JxX");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");

      var CustomHeaderComponent = /*#__PURE__*/function () {
        function CustomHeaderComponent() {
          _classCallCheck(this, CustomHeaderComponent);
        }

        _createClass(CustomHeaderComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return CustomHeaderComponent;
      }();

      CustomHeaderComponent.ctorParameters = function () {
        return [];
      };

      CustomHeaderComponent.propDecorators = {
        title: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        icon_name: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }]
      };
      CustomHeaderComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-custom-header',
        template: _raw_loader_custom_header_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_custom_header_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], CustomHeaderComponent);
      /***/
    },

    /***/
    "vRCE":
    /*!*******************************************************************!*\
      !*** ./src/app/components/buscar-norma/buscar-norma.component.ts ***!
      \*******************************************************************/

    /*! exports provided: BuscarNormaComponent */

    /***/
    function vRCE(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "BuscarNormaComponent", function () {
        return BuscarNormaComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_buscar_norma_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./buscar-norma.component.html */
      "0xoF");
      /* harmony import */


      var _buscar_norma_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./buscar-norma.component.scss */
      "J43g");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var src_app_services_apertura_auditoria_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! src/app/services/apertura-auditoria.service */
      "Aoky");

      var BuscarNormaComponent = /*#__PURE__*/function () {
        function BuscarNormaComponent(aperturaAuditoriaService) {
          _classCallCheck(this, BuscarNormaComponent);

          this.aperturaAuditoriaService = aperturaAuditoriaService;
          this.tipoNorma = "nacional";
          this.selectNorma = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        }

        _createClass(BuscarNormaComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "buscar",
          value: function buscar(event) {
            var _this49 = this;

            var codigoNorma = event.detail.value;

            if (codigoNorma.length > 3) {
              if (this.tipoNorma == "nacional") {
                console.log("buscamos la norma nacional");
                this.aperturaAuditoriaService.BuscarNormas(codigoNorma).subscribe(function (x) {
                  console.log(x);
                  _this49.listaNormas = x.listEntities;
                });
              } else {
                console.log("buscamos la norma intenacional");
                this.aperturaAuditoriaService.BuscarNormasInternacionales(codigoNorma).subscribe(function (x) {
                  console.log(x);
                  _this49.listaNormas = x.listEntities;
                });
              }
            }
          }
        }, {
          key: "seleccionarNorma",
          value: function seleccionarNorma(event) {
            console.log("seleccionar norma", event);
            console.log("selectNorma", this.selectNorma);

            if (this.selectNorma) {
              this.selectNorma.emit(event.detail.value);
            }
          }
        }]);

        return BuscarNormaComponent;
      }();

      BuscarNormaComponent.ctorParameters = function () {
        return [{
          type: src_app_services_apertura_auditoria_service__WEBPACK_IMPORTED_MODULE_4__["AperturaAuditoriaService"]
        }];
      };

      BuscarNormaComponent.propDecorators = {
        selectNorma: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }]
      };
      BuscarNormaComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: "app-buscar-norma",
        template: _raw_loader_buscar_norma_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_buscar_norma_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], BuscarNormaComponent);
      /***/
    },

    /***/
    "vY5A":
    /*!***************************************!*\
      !*** ./src/app/app-routing.module.ts ***!
      \***************************************/

    /*! exports provided: AppRoutingModule */

    /***/
    function vY5A(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function () {
        return AppRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "iInd");

      var routes = [{
        path: '',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | pages-login-login-module */
          "pages-login-login-module").then(__webpack_require__.bind(null,
          /*! ./pages/login/login.module */
          "F4UR")).then(function (m) {
            return m.LoginPageModule;
          });
        },
        pathMatch: 'full'
      }, {
        path: 'inbox',
        redirectTo: 'folder/Inbox',
        pathMatch: 'full'
      }, {
        path: 'folder/:id',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | folder-folder-module */
          "folder-folder-module").then(__webpack_require__.bind(null,
          /*! ./folder/folder.module */
          "yIOV")).then(function (m) {
            return m.FolderPageModule;
          });
        }
      }, {
        path: 'programa-auditoria',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | pages-apertura_auditoria-programa-auditoria-programa-auditoria-module */
          "pages-apertura_auditoria-programa-auditoria-programa-auditoria-module").then(__webpack_require__.bind(null,
          /*! ./pages/apertura_auditoria/programa-auditoria/programa-auditoria.module */
          "PTeW")).then(function (m) {
            return m.ProgramaAuditoriaPageModule;
          });
        }
      }, {
        path: 'master-elaboracion-auditoria',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | pages-elaboracion_auditoria-master-elaboracion-auditoria-master-elaboracion-auditoria-module */
          "pages-elaboracion_auditoria-master-elaboracion-auditoria-master-elaboracion-auditoria-module").then(__webpack_require__.bind(null,
          /*! ./pages/elaboracion_auditoria/master-elaboracion-auditoria/master-elaboracion-auditoria.module */
          "mAE4")).then(function (m) {
            return m.MasterElaboracionAuditoriaPageModule;
          });
        }
      }, {
        path: 'ivo',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | pages-test-ivo-ivo-module */
          "pages-test-ivo-ivo-module").then(__webpack_require__.bind(null,
          /*! ./pages/test/ivo/ivo.module */
          "zL5W")).then(function (m) {
            return m.IvoPageModule;
          });
        }
      }, {
        path: 'ruben',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | pages-test-ruben-ruben-module */
          "pages-test-ruben-ruben-module").then(__webpack_require__.bind(null,
          /*! ./pages/test/ruben/ruben.module */
          "qgLO")).then(function (m) {
            return m.RubenPageModule;
          });
        }
      }, {
        path: 'myke',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | pages-test-myke-myke-module */
          "pages-test-myke-myke-module").then(__webpack_require__.bind(null,
          /*! ./pages/test/myke/myke.module */
          "anak")).then(function (m) {
            return m.MykePageModule;
          });
        }
      }, {
        path: 'list-ciclos',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | pages-elaboracion_auditoria-list-ciclos-list-ciclos-module */
          "pages-elaboracion_auditoria-list-ciclos-list-ciclos-module").then(__webpack_require__.bind(null,
          /*! ./pages/elaboracion_auditoria/list-ciclos/list-ciclos.module */
          "286E")).then(function (m) {
            return m.ListCiclosPageModule;
          });
        }
      }, {
        path: 'login',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | pages-login-login-module */
          "pages-login-login-module").then(__webpack_require__.bind(null,
          /*! ./pages/login/login.module */
          "F4UR")).then(function (m) {
            return m.LoginPageModule;
          });
        }
      }, {
        path: 'panel-documentos',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | pages-toma-decision-panel-documentos-panel-documentos-module */
          "pages-toma-decision-panel-documentos-panel-documentos-module").then(__webpack_require__.bind(null,
          /*! ./pages/toma-decision/panel-documentos/panel-documentos.module */
          "KlG+")).then(function (m) {
            return m.PanelDocumentosPageModule;
          });
        }
      }, {
        path: 'registro-solicitud-servicio',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | pages-solicitud-servicio-registro-solicitud-servicio-registro-solicitud-servicio-module */
          "pages-solicitud-servicio-registro-solicitud-servicio-registro-solicitud-servicio-module").then(__webpack_require__.bind(null,
          /*! ./pages/solicitud-servicio/registro-solicitud-servicio/registro-solicitud-servicio.module */
          "RTKG")).then(function (m) {
            return m.RegistroSolicitudServicioPageModule;
          });
        }
      }];

      var AppRoutingModule = function AppRoutingModule() {
        _classCallCheck(this, AppRoutingModule);
      };

      AppRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, {
          preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"],
          useHash: true,
          relativeLinkResolution: 'legacy'
        })],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], AppRoutingModule);
      /***/
    },

    /***/
    "w0e+":
    /*!*********************************************************************************************************!*\
      !*** ./src/app/components/param-organismos-certificadores/param-organismos-certificadores.component.ts ***!
      \*********************************************************************************************************/

    /*! exports provided: ParamOrganismosCertificadoresComponent */

    /***/
    function w0e(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ParamOrganismosCertificadoresComponent", function () {
        return ParamOrganismosCertificadoresComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_param_organismos_certificadores_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./param-organismos-certificadores.component.html */
      "iYeb");
      /* harmony import */


      var _param_organismos_certificadores_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./param-organismos-certificadores.component.scss */
      "QyFm");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "sZkV");
      /* harmony import */


      var _services_apertura_auditoria_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../../services/apertura-auditoria.service */
      "Aoky");

      var ParamOrganismosCertificadoresComponent = /*#__PURE__*/function () {
        function ParamOrganismosCertificadoresComponent(aperturaAuditoriaService, popoverController) {
          _classCallCheck(this, ParamOrganismosCertificadoresComponent);

          this.aperturaAuditoriaService = aperturaAuditoriaService;
          this.popoverController = popoverController;
          this.seleccionarOrganismoEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        }

        _createClass(ParamOrganismosCertificadoresComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this50 = this;

            console.log("iniciamos el control"); ///obtenemos los clasificadores

            this.aperturaAuditoriaService.BuscarOrganismosCertificadores().subscribe(function (x) {
              console.log("resulado de la busqueda oranismos", x);
              _this50.listaOrganismos = x.listEntities;
              /*if (this.defaultValue) {
                this.currentOrganismo = this.listaOrganismos.find(
                  (x) => x.descripcion === this.defaultValue
                );
              }*/
            });
          }
        }, {
          key: "seleccionarOrganismo",
          value: function seleccionarOrganismo(event) {
            var _this51 = this;

            this.descripcion = "";
            event.detail.value.forEach(function (x) {
              if (_this51.descripcion == "") _this51.descripcion = x.abrev;else _this51.descripcion = _this51.descripcion + "," + x.abrev;
            });
            console.log("datos", this.descripcion);

            if (this.seleccionarOrganismoEmitter) {
              this.seleccionarOrganismoEmitter.emit(event);
            }

            if (this.popoverController) {
              this.popoverController.dismiss({
                item: this.descripcion
              });
            }
          }
        }]);

        return ParamOrganismosCertificadoresComponent;
      }();

      ParamOrganismosCertificadoresComponent.ctorParameters = function () {
        return [{
          type: _services_apertura_auditoria_service__WEBPACK_IMPORTED_MODULE_5__["AperturaAuditoriaService"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["PopoverController"]
        }];
      };

      ParamOrganismosCertificadoresComponent.propDecorators = {
        defaultValue: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"]
        }],
        seleccionarOrganismoEmitter: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"]
        }]
      };
      ParamOrganismosCertificadoresComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: "app-param-organismos-certificadores",
        template: _raw_loader_param_organismos_certificadores_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_param_organismos_certificadores_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], ParamOrganismosCertificadoresComponent);
      /***/
    },

    /***/
    "w4ZD":
    /*!*************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/message-error/message-error.component.html ***!
      \*************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function w4ZD(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<div class=\"container-error\">\n  <ion-label class=\"error-message\" >\n    * {{ error }}\n  </ion-label>  \n</div>\n";
      /***/
    },

    /***/
    "w90L":
    /*!*************************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/ela-edit-areapreocupacion/ela-edit-areapreocupacion.component.html ***!
      \*************************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function w90L(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<div class=\"container-product\">\r\n  <form\r\n    [formGroup]=\"ionicFormAdp\"\r\n    (ngSubmit)=\"guardarAreaDePreocupacion()\"\r\n    #form=\"ngForm\"\r\n  >\r\n    <app-custom-input\r\n      label=\"Area\"\r\n      name=\"area\"\r\n      type=\"text\"\r\n      [formGruop]=\"ionicFormAdp\"\r\n      [form]=\"form\"\r\n      [defaultValue]=\"currentAdp.area\"\r\n    ></app-custom-input>\r\n\r\n    <ion-item>\r\n      <ion-label position=\"floating\">Descripción</ion-label>\r\n      <ion-textarea\r\n        clearOnEdit=\"true\"\r\n        rows=\"10\"\r\n        cols=\"20\"\r\n        [value]=\"currentAdp.descripcion\"\r\n        (ionChange)=\"valorDescripcion($event)\"\r\n      ></ion-textarea>\r\n    </ion-item>\r\n\r\n    <section>\r\n      <ion-button size=\"small\" type=\"submit\">Guardar</ion-button>\r\n      <ion-button size=\"small\" color=\"secondary\" (click)=\"cancelarAreaDePreocupacion()\"\r\n        >Cancelar</ion-button\r\n      >\r\n    </section>\r\n  </form>\r\n</div>\r\n";
      /***/
    },

    /***/
    "wELF":
    /*!***************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/product-detail/product-detail.component.html ***!
      \***************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function wELF(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<div class=\"container-product\">\r\n  <form [formGroup]=\"ionicForm\" (ngSubmit)=\"guardarProduct()\" #form=\"ngForm\">\r\n    <app-custom-input\r\n      label=\"Nombre del Producto\"\r\n      name=\"nombre\"\r\n      type=\"text\"\r\n      [formGruop]=\"ionicForm\"\r\n      [form]=\"form\"\r\n      [defaultValue]=\"pradireccionespaproducto.nombre\"\r\n    ></app-custom-input>\r\n    <app-custom-input\r\n      label=\"Direccion\"\r\n      name=\"direccion\"\r\n      type=\"text\"\r\n      [formGruop]=\"ionicForm\"\r\n      [form]=\"form\"\r\n      [defaultValue]=\"pradireccionespaproducto.direccion\"\r\n    ></app-custom-input>\r\n    <app-custom-input\r\n      label=\"Marca\"\r\n      name=\"marca\"\r\n      type=\"text\"\r\n      [formGruop]=\"ionicForm\"\r\n      [form]=\"form\"\r\n      [defaultValue]=\"pradireccionespaproducto.marca\"\r\n    ></app-custom-input>\r\n    <ion-item (click)=\"mostrarBuscadorNorma()\">\r\n      <ion-label> Norma : {{ pradireccionespaproducto.norma }} </ion-label>\r\n    </ion-item>\r\n    <app-buscar-norma\r\n      (selectNorma)=\"cambiarNorma($event)\"\r\n      *ngIf=\"showBuscadorNormas\"\r\n    ></app-buscar-norma>\r\n    <app-custom-input\r\n      label=\"Sello\"\r\n      name=\"sello\"\r\n      type=\"text\"\r\n      [formGruop]=\"ionicForm\"\r\n      [form]=\"form\"\r\n      [defaultValue]=\"pradireccionespaproducto.sello\"\r\n    ></app-custom-input>\r\n    <!-- <div *ngIf=\"mode === 'default-pais'\">\r\n      <app-custom-input\r\n        label=\"PAIS\"\r\n        name=\"pais\"\r\n        type=\"text\"\r\n        [formGruop]=\"ionicForm\"\r\n        readonly=\"true\"\r\n        [form]=\"form\"\r\n        [defaultValue]=\"pradireccionespaproducto.pais\"\r\n        (click)=\"cambiarModoPais()\"\r\n      ></app-custom-input>\r\n      <app-custom-input\r\n        label=\"Departamento\"\r\n        name=\"estado\"\r\n        type=\"text\"\r\n        [formGruop]=\"ionicForm\"\r\n        [form]=\"form\"\r\n        readonly=\"true\"\r\n        [defaultValue]=\"pradireccionespaproducto.estado\"\r\n      ></app-custom-input>\r\n      <app-custom-input\r\n        label=\"Ciudad\"\r\n        name=\"ciudad\"\r\n        type=\"text\"\r\n        [formGruop]=\"ionicForm\"\r\n        [form]=\"form\"\r\n        readonly=\"true\"\r\n        [defaultValue]=\"pradireccionespaproducto.ciudad\"\r\n      ></app-custom-input>\r\n    </div> -->\r\n    <app-param-paises\r\n      *ngIf=\"mode === 'edit-pais'\"\r\n      [defaulValue]=\"pradireccionespaproducto.pais\"\r\n      (selectLocalizacionEmit)=\"localizacionSeleccionda($event)\"\r\n    ></app-param-paises>\r\n    <section>\r\n      <ion-button size=\"small\" type=\"submit\">Guardar</ion-button>\r\n      <ion-button size=\"small\" color=\"secondary\" (click)=\"cancelar()\"\r\n        >Cancelar</ion-button\r\n      >\r\n    </section>\r\n  </form>\r\n</div>\r\n";
      /***/
    },

    /***/
    "xl0N":
    /*!*******************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/pra-edit-norma-sistema/pra-edit-norma-sistema.component.html ***!
      \*******************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function xl0N(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<div class=\"container-product\">\r\n  <form [formGroup]=\"ionicForm\" (ngSubmit)=\"guardarNorma()\" #form=\"ngForm\">\r\n    <ion-item (click)=\"mostrarBuscadorNorma()\">\r\n      <ion-label> Norma : {{ praciclonormassistema.norma }} </ion-label>\r\n    </ion-item>\r\n    <app-buscar-norma\r\n      (selectNorma)=\"cambiarNorma($event)\"\r\n      *ngIf=\"showBuscadorNormas\"\r\n    ></app-buscar-norma>\r\n    <app-custom-input\r\n      label=\"Alcance\"\r\n      name=\"alcance\"\r\n      type=\"text\"\r\n      [formGruop]=\"ionicForm\"\r\n      [form]=\"form\"\r\n      [defaultValue]=\"praciclonormassistema.alcance\"\r\n    ></app-custom-input>\r\n        <section>\r\n      <ion-button size=\"small\" type=\"submit\">Guardar</ion-button>\r\n      <ion-button size=\"small\" (click)=\"cancelarNorma()\" color=\"secondary\">Cancelar</ion-button>\r\n    </section>\r\n  </form>\r\n</div>\r\n";
      /***/
    },

    /***/
    "xy4t":
    /*!*********************************************************************************!*\
      !*** ./src/app/components/ela-edit-hallazago/ela-edit-hallazago.component.scss ***!
      \*********************************************************************************/

    /*! exports provided: default */

    /***/
    function xy4t(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlbGEtZWRpdC1oYWxsYXphZ28uY29tcG9uZW50LnNjc3MifQ== */";
      /***/
    },

    /***/
    "yRs8":
    /*!*******************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/components/param-documentos/param-documentos.component.html ***!
      \*******************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function yRs8(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-list>\n  <ion-item *ngFor=\"let item of listDocumentos; let i = index\">\n    <ion-icon\n      name=\"cloud-download\"\n      slot=\"end\"\n      class=\"icon\"\n      (click)=\"descargarDocumento(item.nombrePlantilla)\"\n    ></ion-icon>\n    <ion-label>\n      {{ i + 1 }} - {{ item.nombrePlantilla }} {{ item.descripcion }}\n    </ion-label>\n  </ion-item>\n</ion-list>\n";
      /***/
    },

    /***/
    "ynWL":
    /*!************************************!*\
      !*** ./src/app/app.component.scss ***!
      \************************************/

    /*! exports provided: default */

    /***/
    function ynWL(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-menu ion-content {\n  --background: var(--ion-item-background, var(--ion-background-color, #fff));\n}\n\nion-menu.md ion-content {\n  --padding-start: 8px;\n  --padding-end: 8px;\n  --padding-top: 20px;\n  --padding-bottom: 20px;\n}\n\nion-menu.md ion-list {\n  padding: 20px 0;\n}\n\nion-menu.md ion-note {\n  margin-bottom: 30px;\n}\n\nion-menu.md ion-list-header,\nion-menu.md ion-note {\n  padding-left: 10px;\n}\n\nion-menu.md ion-list#inbox-list {\n  border-bottom: 1px solid var(--ion-color-step-150, #d7d8da);\n}\n\nion-menu.md ion-list#inbox-list ion-list-header {\n  font-size: 22px;\n  font-weight: 600;\n  min-height: 20px;\n}\n\nion-menu.md ion-list#labels-list ion-list-header {\n  font-size: 16px;\n  margin-bottom: 18px;\n  color: #757575;\n  min-height: 26px;\n}\n\nion-menu.md ion-item {\n  --padding-start: 10px;\n  --padding-end: 10px;\n  border-radius: 4px;\n}\n\nion-menu.md ion-item.selected {\n  --background: rgba(var(--ion-color-primary-rgb), 0.14);\n}\n\nion-menu.md ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n\nion-menu.md ion-item ion-icon {\n  color: #616e7e;\n}\n\nion-menu.md ion-item ion-label {\n  font-weight: 500;\n}\n\nion-menu.ios ion-content {\n  --padding-bottom: 20px;\n}\n\nion-menu.ios ion-list {\n  padding: 20px 0 0 0;\n}\n\nion-menu.ios ion-note {\n  line-height: 24px;\n  margin-bottom: 20px;\n}\n\nion-menu.ios ion-item {\n  --padding-start: 16px;\n  --padding-end: 16px;\n  --min-height: 50px;\n}\n\nion-menu.ios ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n\nion-menu.ios ion-item ion-icon {\n  font-size: 24px;\n  color: #73849a;\n}\n\nion-menu.ios ion-list#labels-list ion-list-header {\n  margin-bottom: 8px;\n}\n\nion-menu.ios ion-list-header,\nion-menu.ios ion-note {\n  padding-left: 16px;\n  padding-right: 16px;\n}\n\nion-menu.ios ion-note {\n  margin-bottom: 8px;\n}\n\nion-note {\n  display: inline-block;\n  font-size: 16px;\n  color: var(--ion-color-medium-shade);\n}\n\nion-item.selected {\n  --color: var(--ion-color-primary);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcYXBwLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsMkVBQUE7QUFDRjs7QUFFQTtFQUNFLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLHNCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxlQUFBO0FBQ0Y7O0FBRUE7RUFDRSxtQkFBQTtBQUNGOztBQUVBOztFQUVFLGtCQUFBO0FBQ0Y7O0FBRUE7RUFDRSwyREFBQTtBQUNGOztBQUVBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBRUEsZ0JBQUE7QUFBRjs7QUFHQTtFQUNFLGVBQUE7RUFFQSxtQkFBQTtFQUVBLGNBQUE7RUFFQSxnQkFBQTtBQUhGOztBQU1BO0VBQ0UscUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FBSEY7O0FBTUE7RUFDRSxzREFBQTtBQUhGOztBQU1BO0VBQ0UsK0JBQUE7QUFIRjs7QUFNQTtFQUNFLGNBQUE7QUFIRjs7QUFNQTtFQUNFLGdCQUFBO0FBSEY7O0FBTUE7RUFDRSxzQkFBQTtBQUhGOztBQU1BO0VBQ0UsbUJBQUE7QUFIRjs7QUFNQTtFQUNFLGlCQUFBO0VBQ0EsbUJBQUE7QUFIRjs7QUFNQTtFQUNFLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQUhGOztBQU1BO0VBQ0UsK0JBQUE7QUFIRjs7QUFNQTtFQUNFLGVBQUE7RUFDQSxjQUFBO0FBSEY7O0FBTUE7RUFDRSxrQkFBQTtBQUhGOztBQU1BOztFQUVFLGtCQUFBO0VBQ0EsbUJBQUE7QUFIRjs7QUFNQTtFQUNFLGtCQUFBO0FBSEY7O0FBTUE7RUFDRSxxQkFBQTtFQUNBLGVBQUE7RUFFQSxvQ0FBQTtBQUpGOztBQU9BO0VBQ0UsaUNBQUE7QUFKRiIsImZpbGUiOiJhcHAuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tbWVudSBpb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWl0ZW0tYmFja2dyb3VuZCwgdmFyKC0taW9uLWJhY2tncm91bmQtY29sb3IsICNmZmYpKTtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWNvbnRlbnQge1xuICAtLXBhZGRpbmctc3RhcnQ6IDhweDtcbiAgLS1wYWRkaW5nLWVuZDogOHB4O1xuICAtLXBhZGRpbmctdG9wOiAyMHB4O1xuICAtLXBhZGRpbmctYm90dG9tOiAyMHB4O1xufVxuXG5pb24tbWVudS5tZCBpb24tbGlzdCB7XG4gIHBhZGRpbmc6IDIwcHggMDtcbn1cblxuaW9uLW1lbnUubWQgaW9uLW5vdGUge1xuICBtYXJnaW4tYm90dG9tOiAzMHB4O1xufVxuXG5pb24tbWVudS5tZCBpb24tbGlzdC1oZWFkZXIsXG5pb24tbWVudS5tZCBpb24tbm90ZSB7XG4gIHBhZGRpbmctbGVmdDogMTBweDtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWxpc3QjaW5ib3gtbGlzdCB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCB2YXIoLS1pb24tY29sb3Itc3RlcC0xNTAsICNkN2Q4ZGEpO1xufVxuXG5pb24tbWVudS5tZCBpb24tbGlzdCNpbmJveC1saXN0IGlvbi1saXN0LWhlYWRlciB7XG4gIGZvbnQtc2l6ZTogMjJweDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcblxuICBtaW4taGVpZ2h0OiAyMHB4O1xufVxuXG5pb24tbWVudS5tZCBpb24tbGlzdCNsYWJlbHMtbGlzdCBpb24tbGlzdC1oZWFkZXIge1xuICBmb250LXNpemU6IDE2cHg7XG5cbiAgbWFyZ2luLWJvdHRvbTogMThweDtcblxuICBjb2xvcjogIzc1NzU3NTtcblxuICBtaW4taGVpZ2h0OiAyNnB4O1xufVxuXG5pb24tbWVudS5tZCBpb24taXRlbSB7XG4gIC0tcGFkZGluZy1zdGFydDogMTBweDtcbiAgLS1wYWRkaW5nLWVuZDogMTBweDtcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xufVxuXG5pb24tbWVudS5tZCBpb24taXRlbS5zZWxlY3RlZCB7XG4gIC0tYmFja2dyb3VuZDogcmdiYSh2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1yZ2IpLCAwLjE0KTtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWl0ZW0uc2VsZWN0ZWQgaW9uLWljb24ge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuXG5pb24tbWVudS5tZCBpb24taXRlbSBpb24taWNvbiB7XG4gIGNvbG9yOiAjNjE2ZTdlO1xufVxuXG5pb24tbWVudS5tZCBpb24taXRlbSBpb24tbGFiZWwge1xuICBmb250LXdlaWdodDogNTAwO1xufVxuXG5pb24tbWVudS5pb3MgaW9uLWNvbnRlbnQge1xuICAtLXBhZGRpbmctYm90dG9tOiAyMHB4O1xufVxuXG5pb24tbWVudS5pb3MgaW9uLWxpc3Qge1xuICBwYWRkaW5nOiAyMHB4IDAgMCAwO1xufVxuXG5pb24tbWVudS5pb3MgaW9uLW5vdGUge1xuICBsaW5lLWhlaWdodDogMjRweDtcbiAgbWFyZ2luLWJvdHRvbTogMjBweDtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1pdGVtIHtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAxNnB4O1xuICAtLXBhZGRpbmctZW5kOiAxNnB4O1xuICAtLW1pbi1oZWlnaHQ6IDUwcHg7XG59XG5cbmlvbi1tZW51LmlvcyBpb24taXRlbS5zZWxlY3RlZCBpb24taWNvbiB7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG59XG5cbmlvbi1tZW51LmlvcyBpb24taXRlbSBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMjRweDtcbiAgY29sb3I6ICM3Mzg0OWE7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbGlzdCNsYWJlbHMtbGlzdCBpb24tbGlzdC1oZWFkZXIge1xuICBtYXJnaW4tYm90dG9tOiA4cHg7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbGlzdC1oZWFkZXIsXG5pb24tbWVudS5pb3MgaW9uLW5vdGUge1xuICBwYWRkaW5nLWxlZnQ6IDE2cHg7XG4gIHBhZGRpbmctcmlnaHQ6IDE2cHg7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbm90ZSB7XG4gIG1hcmdpbi1ib3R0b206IDhweDtcbn1cblxuaW9uLW5vdGUge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIGZvbnQtc2l6ZTogMTZweDtcblxuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bS1zaGFkZSk7XG59XG5cbmlvbi1pdGVtLnNlbGVjdGVkIHtcbiAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufSJdfQ== */";
      /***/
    },

    /***/
    "zDHk":
    /*!***************************************************************************************************!*\
      !*** ./src/app/components/lista-verificacion-apertura/lista-verificacion-apertura.component.scss ***!
      \***************************************************************************************************/

    /*! exports provided: default */

    /***/
    function zDHk(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJsaXN0YS12ZXJpZmljYWNpb24tYXBlcnR1cmEuY29tcG9uZW50LnNjc3MifQ== */";
      /***/
    },

    /***/
    "zMu+":
    /*!*************************************************************************!*\
      !*** ./src/app/components/param-horarios/param-horarios.component.scss ***!
      \*************************************************************************/

    /*! exports provided: default */

    /***/
    function zMu(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwYXJhbS1ob3Jhcmlvcy5jb21wb25lbnQuc2NzcyJ9 */";
      /***/
    },

    /***/
    "zUnb":
    /*!*********************!*\
      !*** ./src/main.ts ***!
      \*********************/

    /*! no exports provided */

    /***/
    function zUnb(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/platform-browser-dynamic */
      "wAiw");
      /* harmony import */


      var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./app/app.module */
      "ZAI4");
      /* harmony import */


      var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./environments/environment */
      "AytR");

      if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
      }

      Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])["catch"](function (err) {
        return console.log(err);
      });
      /***/
    },

    /***/
    "zn8P":
    /*!******************************************************!*\
      !*** ./$$_lazy_route_resource lazy namespace object ***!
      \******************************************************/

    /*! no static exports found */

    /***/
    function zn8P(module, exports) {
      function webpackEmptyAsyncContext(req) {
        // Here Promise.resolve().then() is used instead of new Promise() to prevent
        // uncaught exception popping up in devtools
        return Promise.resolve().then(function () {
          var e = new Error("Cannot find module '" + req + "'");
          e.code = 'MODULE_NOT_FOUND';
          throw e;
        });
      }

      webpackEmptyAsyncContext.keys = function () {
        return [];
      };

      webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
      module.exports = webpackEmptyAsyncContext;
      webpackEmptyAsyncContext.id = "zn8P";
      /***/
    },

    /***/
    "zrJw":
    /*!*****************************************!*\
      !*** ./src/app/services/baseService.ts ***!
      \*****************************************/

    /*! exports provided: BaseService */

    /***/
    function zrJw(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "BaseService", function () {
        return BaseService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");

      var BaseService = /*#__PURE__*/function () {
        function BaseService(databaseService, httpClient, loadingController, toastController) {
          _classCallCheck(this, BaseService);

          this.databaseService = databaseService;
          this.httpClient = httpClient;
          this.loadingController = loadingController;
          this.toastController = toastController;
        }

        _createClass(BaseService, [{
          key: "presentLoader",
          value: function presentLoader() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee11() {
              return regeneratorRuntime.wrap(function _callee11$(_context11) {
                while (1) {
                  switch (_context11.prev = _context11.next) {
                    case 0:
                      BaseService.isLoading = true;
                      _context11.next = 3;
                      return this.loadingController.create({
                        duration: 5000,
                        message: "Procesando..."
                      }).then(function (a) {
                        a.present().then(function () {
                          console.log("presented");

                          if (!BaseService.isLoading) {
                            a.dismiss().then(function () {
                              return console.log("abort presenting");
                            });
                          }
                        });
                      });

                    case 3:
                      return _context11.abrupt("return", _context11.sent);

                    case 4:
                    case "end":
                      return _context11.stop();
                  }
                }
              }, _callee11, this);
            }));
          }
        }, {
          key: "dismissLoader",
          value: function dismissLoader() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee12() {
              return regeneratorRuntime.wrap(function _callee12$(_context12) {
                while (1) {
                  switch (_context12.prev = _context12.next) {
                    case 0:
                      BaseService.isLoading = false;
                      _context12.next = 3;
                      return this.loadingController.dismiss().then(function () {
                        return console.log("dismissed");
                      })["catch"](function (error) {
                        return console.log("error en dismiss loader", error);
                      });

                    case 3:
                      return _context12.abrupt("return", _context12.sent);

                    case 4:
                    case "end":
                      return _context12.stop();
                  }
                }
              }, _callee12, this);
            }));
          }
        }, {
          key: "showMessageResponse",
          value: function showMessageResponse(response) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee13() {
              var color, toast;
              return regeneratorRuntime.wrap(function _callee13$(_context13) {
                while (1) {
                  switch (_context13.prev = _context13.next) {
                    case 0:
                      color = "success";
                      _context13.t0 = response["state"];
                      _context13.next = _context13.t0 === 1 ? 4 : _context13.t0 === 2 ? 6 : _context13.t0 === 3 ? 8 : 10;
                      break;

                    case 4:
                      color = "success";
                      return _context13.abrupt("break", 10);

                    case 6:
                      color = "warning";
                      return _context13.abrupt("break", 10);

                    case 8:
                      color = "danger";
                      return _context13.abrupt("break", 10);

                    case 10:
                      _context13.next = 12;
                      return this.toastController.create({
                        message: response["message"],
                        duration: 3000,
                        position: "top",
                        color: color
                      });

                    case 12:
                      toast = _context13.sent;
                      toast.present();

                    case 14:
                    case "end":
                      return _context13.stop();
                  }
                }
              }, _callee13, this);
            }));
          }
        }, {
          key: "showMessageError",
          value: function showMessageError(message) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee14() {
              var toast;
              return regeneratorRuntime.wrap(function _callee14$(_context14) {
                while (1) {
                  switch (_context14.prev = _context14.next) {
                    case 0:
                      _context14.next = 2;
                      return this.toastController.create({
                        message: message,
                        duration: 3000,
                        position: "top",
                        color: "danger"
                      });

                    case 2:
                      toast = _context14.sent;
                      toast.present();

                    case 4:
                    case "end":
                      return _context14.stop();
                  }
                }
              }, _callee14, this);
            }));
          }
        }, {
          key: "showMessageSucess",
          value: function showMessageSucess(message) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee15() {
              var toast;
              return regeneratorRuntime.wrap(function _callee15$(_context15) {
                while (1) {
                  switch (_context15.prev = _context15.next) {
                    case 0:
                      _context15.next = 2;
                      return this.toastController.create({
                        message: message,
                        duration: 3000,
                        position: "top",
                        color: "success"
                      });

                    case 2:
                      toast = _context15.sent;
                      toast.present();

                    case 4:
                    case "end":
                      return _context15.stop();
                  }
                }
              }, _callee15, this);
            }));
          }
        }]);

        return BaseService;
      }();

      BaseService.isLoading = false;
      /***/
    }
  }, [[0, "runtime", "vendor"]]]);
})();
//# sourceMappingURL=main-es5.js.map