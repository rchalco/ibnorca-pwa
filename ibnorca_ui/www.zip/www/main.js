(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["main"],{

/***/ 158:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 2816);



const routes = [
    {
        path: '',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_login_login_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/login/login.module */ 1053)).then((m) => m.LoginPageModule),
        pathMatch: 'full',
    },
    {
        path: 'inbox',
        redirectTo: 'folder/Inbox',
        pathMatch: 'full',
    },
    {
        path: 'folder/:id',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_folder_folder_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./folder/folder.module */ 3412)).then((m) => m.FolderPageModule),
    },
    {
        path: 'programa-auditoria',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_apertura_auditoria_programa-auditoria_programa-auditoria_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/apertura_auditoria/programa-auditoria/programa-auditoria.module */ 5372)).then((m) => m.ProgramaAuditoriaPageModule),
    },
    {
        path: 'master-elaboracion-auditoria',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_elaboracion_auditoria_master-elaboracion-auditoria_master-elaboracion-auditoria-d7155d").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/elaboracion_auditoria/master-elaboracion-auditoria/master-elaboracion-auditoria.module */ 1040)).then((m) => m.MasterElaboracionAuditoriaPageModule),
    },
    {
        path: 'ivo',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_test_ivo_ivo_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/test/ivo/ivo.module */ 3648)).then((m) => m.IvoPageModule),
    },
    {
        path: 'ruben',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_test_ruben_ruben_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/test/ruben/ruben.module */ 5827)).then((m) => m.RubenPageModule),
    },
    {
        path: 'myke',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_test_myke_myke_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/test/myke/myke.module */ 2201)).then((m) => m.MykePageModule),
    },
    {
        path: 'list-ciclos',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_elaboracion_auditoria_list-ciclos_list-ciclos_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/elaboracion_auditoria/list-ciclos/list-ciclos.module */ 5996)).then((m) => m.ListCiclosPageModule),
    },
    {
        path: 'login',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_login_login_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/login/login.module */ 1053)).then((m) => m.LoginPageModule),
    },
    {
        path: 'panel-documentos',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_toma-decision_panel-documentos_panel-documentos_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/toma-decision/panel-documentos/panel-documentos.module */ 513)).then((m) => m.PanelDocumentosPageModule),
    },
    {
        path: 'registro-solicitud-servicio',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_solicitud-servicio_registro-solicitud-servicio_registro-solicitud-servicio_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./pages/solicitud-servicio/registro-solicitud-servicio/registro-solicitud-servicio.module */ 573)).then((m) => m.RegistroSolicitudServicioPageModule),
    },
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.NgModule)({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule.forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__.PreloadAllModules, useHash: true, relativeLinkResolution: 'legacy' })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule]
    })
    // @NgModule({
    //   imports: [
    //     RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules }),
    //   ],
    //   exports: [RouterModule],
    // })
], AppRoutingModule);



/***/ }),

/***/ 5041:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _app_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.component.html?ngResource */ 3383);
/* harmony import */ var _app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component.scss?ngResource */ 9259);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 3819);





let AppComponent = class AppComponent {
    constructor(platform) {
        this.platform = platform;
        this.selectedIndex = 0;
        this.appPages = [
            {
                title: 'Inbox',
                url: '/folder/Inbox',
                icon: 'mail',
            },
            {
                title: 'Outbox',
                url: '/folder/Outbox',
                icon: 'paper-plane',
            },
            {
                title: 'Favorites',
                url: '/folder/Favorites',
                icon: 'heart',
            },
            {
                title: 'Archived',
                url: '/folder/Archived',
                icon: 'archive',
            },
            {
                title: 'Trash',
                url: '/folder/Trash',
                icon: 'trash',
            },
            {
                title: 'Spam',
                url: '/folder/Spam',
                icon: 'warning',
            },
        ];
        this.labels = ['Family', 'Friends', 'Notes', 'Work', 'Travel', 'Reminders'];
        this.initializeApp();
    }
    initializeApp() {
        this.platform.ready().then(() => { });
    }
    ngOnInit() {
        const path = window.location.pathname.split('folder/')[1];
        if (path !== undefined) {
            this.selectedIndex = this.appPages.findIndex((page) => page.title.toLowerCase() === path.toLowerCase());
        }
    }
};
AppComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.Platform }
];
AppComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-root',
        template: _app_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AppComponent);



/***/ }),

/***/ 6747:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/platform-browser */ 318);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.component */ 5041);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app-routing.module */ 158);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/storage-angular */ 7566);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common/http */ 8784);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _components_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/components.module */ 5642);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common */ 6362);












let AppModule = class AppModule {
};
AppModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent],
        entryComponents: [],
        imports: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__.BrowserModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule.forRoot(),
            _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_7__.IonicStorageModule.forRoot(),
            _app_routing_module__WEBPACK_IMPORTED_MODULE_1__.AppRoutingModule,
            _angular_common_http__WEBPACK_IMPORTED_MODULE_8__.HttpClientModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_9__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_9__.ReactiveFormsModule,
            _components_components_module__WEBPACK_IMPORTED_MODULE_2__.ComponentsModule,
        ],
        providers: [
            _angular_common__WEBPACK_IMPORTED_MODULE_10__.DatePipe,
            { provide: _angular_router__WEBPACK_IMPORTED_MODULE_11__.RouteReuseStrategy, useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicRouteStrategy },
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent],
    })
], AppModule);



/***/ }),

/***/ 9789:
/*!*******************************************************************!*\
  !*** ./src/app/components/buscar-norma/buscar-norma.component.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BuscarNormaComponent": () => (/* binding */ BuscarNormaComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _buscar_norma_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./buscar-norma.component.html?ngResource */ 5762);
/* harmony import */ var _buscar_norma_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./buscar-norma.component.scss?ngResource */ 5292);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_services_apertura_auditoria_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/apertura-auditoria.service */ 7583);



/* eslint-disable @typescript-eslint/consistent-type-assertions */
/* eslint-disable @typescript-eslint/member-ordering */


let BuscarNormaComponent = class BuscarNormaComponent {
    constructor(aperturaAuditoriaService) {
        this.aperturaAuditoriaService = aperturaAuditoriaService;
        this.tipoNorma = 'nacional';
        this.selectNorma = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
    }
    ngOnInit() { }
    buscar(event) {
        const codigoNorma = event.detail.value;
        if (codigoNorma.length > 3) {
            if (this.tipoNorma == 'nacional') {
                console.log('buscamos la norma nacional');
                this.aperturaAuditoriaService
                    .BuscarNormas(codigoNorma)
                    .subscribe((x) => {
                    console.log(x);
                    this.listaNormas = x.listEntities;
                });
            }
            else {
                console.log('buscamos la norma intenacional');
                this.aperturaAuditoriaService
                    .BuscarNormasInternacionales(codigoNorma)
                    .subscribe((x) => {
                    console.log(x);
                    this.listaNormas = x.listEntities;
                });
            }
        }
    }
    seleccionarNorma(event) {
        console.log('seleccionar norma', event);
        console.log('selectNorma', this.selectNorma);
        if (this.selectNorma) {
            this.selectNorma.emit(event.detail.value);
        }
    }
};
BuscarNormaComponent.ctorParameters = () => [
    { type: src_app_services_apertura_auditoria_service__WEBPACK_IMPORTED_MODULE_2__.AperturaAuditoriaService }
];
BuscarNormaComponent.propDecorators = {
    selectNorma: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output }]
};
BuscarNormaComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-buscar-norma',
        template: _buscar_norma_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_buscar_norma_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], BuscarNormaComponent);



/***/ }),

/***/ 5697:
/*!*******************************************************************************!*\
  !*** ./src/app/components/ciclo-participante/ciclo-participante.component.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CicloParticipanteComponent": () => (/* binding */ CicloParticipanteComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ciclo_participante_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ciclo-participante.component.html?ngResource */ 5460);
/* harmony import */ var _ciclo_participante_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ciclo-participante.component.scss?ngResource */ 3183);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_interfaces_apertura_auditoria_Praprogramasdeauditorium__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/interfaces/apertura_auditoria/Praprogramasdeauditorium */ 3996);
/* harmony import */ var src_app_services_apertura_auditoria_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/apertura-auditoria.service */ 7583);






let CicloParticipanteComponent = class CicloParticipanteComponent {
    constructor(aperturaAuditoriaService) {
        this.aperturaAuditoriaService = aperturaAuditoriaService;
        this.allowEdit = true;
        this.visibleAdd = 'NO';
        this.operacion = '';
        this.currentIndex = 0;
    }
    ngOnInit() {
        this.selectParticipante = new src_app_interfaces_apertura_auditoria_Praprogramasdeauditorium__WEBPACK_IMPORTED_MODULE_2__.Pracicloparticipante();
        this.ObtenerCargos();
    }
    adicionarParticipante() {
        this.visibleAdd = 'SI';
        this.operacion = 'ADD';
        this.selectParticipante = new src_app_interfaces_apertura_auditoria_Praprogramasdeauditorium__WEBPACK_IMPORTED_MODULE_2__.Pracicloparticipante();
    }
    editar(item, index) {
        this.currentIndex = index;
        this.selectParticipante = item;
        this.selectParticipante._cargo = this.ListaCargoItem.filter((x) => x.idCargoPuesto === this.selectParticipante._cargo.idCargoPuesto)[0];
        this.ObtenerPersonalXIdCargos(this.selectParticipante._cargo.idCargoPuesto);
        this.visibleAdd = 'SI';
        this.operacion = 'UPD';
    }
    eliminar(index) {
        console.log('item eliminado');
        this.operacion = 'DEL';
        this.currentPracicloparticipantes.splice(index, 1);
    }
    ObtenerCargos() {
        this.aperturaAuditoriaService.ObtenerCargos().subscribe((resul) => {
            this.ListaCargoItem = resul.listEntities;
        });
    }
    ObtenerPersonalXCargos(event) {
        let IdCargo = event.detail.value.idCargoPuesto;
        this.selectParticipante._cargo = event.detail.value;
        this.aperturaAuditoriaService
            .ObtenerParticipanteXCargos(IdCargo)
            .subscribe((resul) => {
            this.ListaPersonal = resul.listEntities;
        });
    }
    ObtenerPersonalXIdCargos(idCargo) {
        this.aperturaAuditoriaService
            .ObtenerParticipanteXCargos(idCargo)
            .subscribe((resul) => {
            this.ListaPersonal = resul.listEntities;
        });
    }
    ObtenerPersonalXIdCargo(IdCargo) {
        this.aperturaAuditoriaService
            .ObtenerParticipanteXCargos(IdCargo)
            .subscribe((resul) => {
            this.ListaPersonal = resul.listEntities;
        });
    }
    seleccionarPersonal(event) {
        this.selectParticipante._personal = event.detail.value;
        this.selectParticipante.cargoDetalleWs = JSON.stringify(this.selectParticipante._cargo);
        this.selectParticipante.idCargoWs = Number(this.selectParticipante._cargo.idCargoPuesto);
        this.selectParticipante.idParticipanteWs = Number(this.selectParticipante._personal.idCliente);
        this.selectParticipante.participanteDetalleWs = JSON.stringify(this.selectParticipante._personal);
        this.visibleAdd = 'NO';
        console.log(this.selectParticipante);
        if (this.operacion == 'UPD') {
            this.currentPracicloparticipantes[this.currentIndex] =
                this.selectParticipante;
        }
        if (this.operacion == 'ADD') {
            this.currentPracicloparticipantes.push(this.selectParticipante);
        }
    }
    cancelar() {
        this.visibleAdd = 'NO';
    }
};
CicloParticipanteComponent.ctorParameters = () => [
    { type: src_app_services_apertura_auditoria_service__WEBPACK_IMPORTED_MODULE_3__.AperturaAuditoriaService }
];
CicloParticipanteComponent.propDecorators = {
    currentPracicloparticipantes: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input }],
    allowEdit: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input }]
};
CicloParticipanteComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-ciclo-participante',
        template: _ciclo_participante_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_ciclo_participante_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], CicloParticipanteComponent);



/***/ }),

/***/ 5642:
/*!*************************************************!*\
  !*** ./src/app/components/components.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ComponentsModule": () => (/* binding */ ComponentsModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _tcs_list_systems_tcs_list_systems_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tcs-list-systems/tcs-list-systems.component */ 3678);
/* harmony import */ var _tcp_list_products_tcp_list_products_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tcp-list-products/tcp-list-products.component */ 9166);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _message_error_message_error_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./message-error/message-error.component */ 2522);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _custom_input_custom_input_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./custom-input/custom-input.component */ 3082);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _custom_header_custom_header_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./custom-header/custom-header.component */ 8814);
/* harmony import */ var _meses_meses_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./meses/meses.component */ 4278);
/* harmony import */ var _product_detail_product_detail_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./product-detail/product-detail.component */ 2612);
/* harmony import */ var _lista_verificacion_apertura_lista_verificacion_apertura_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./lista-verificacion-apertura/lista-verificacion-apertura.component */ 4265);
/* harmony import */ var _registro_ciclo_registro_ciclo_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./registro-ciclo/registro-ciclo.component */ 8112);
/* harmony import */ var _plan_auditoria_plan_auditoria_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./plan-auditoria/plan-auditoria.component */ 7269);
/* harmony import */ var _ciclo_participante_ciclo_participante_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./ciclo-participante/ciclo-participante.component */ 5697);
/* harmony import */ var _tcs_lista_verificacion_reunion_apertura_tcs_lista_verificacion_reunion_apertura_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./tcs-lista-verificacion-reunion-apertura/tcs-lista-verificacion-reunion-apertura.component */ 4211);
/* harmony import */ var _tcs_lista_verificacion_reunion_cierre_tcs_lista_verificacion_reunion_cierre_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./tcs-lista-verificacion-reunion-cierre/tcs-lista-verificacion-reunion-cierre.component */ 2150);
/* harmony import */ var _pra_cronograma_pra_cronograma_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./pra-cronograma/pra-cronograma.component */ 1905);
/* harmony import */ var _buscar_norma_buscar_norma_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./buscar-norma/buscar-norma.component */ 9789);
/* harmony import */ var _pra_direccion_sistema_pra_direccion_sistema_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./pra-direccion-sistema/pra-direccion-sistema.component */ 1876);
/* harmony import */ var _param_paises_param_paises_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./param-paises/param-paises.component */ 5813);
/* harmony import */ var _pra_edit_norma_sistema_pra_edit_norma_sistema_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./pra-edit-norma-sistema/pra-edit-norma-sistema.component */ 1250);
/* harmony import */ var _param_organismos_certificadores_param_organismos_certificadores_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./param-organismos-certificadores/param-organismos-certificadores.component */ 3566);
/* harmony import */ var _ela_cronograma_ela_cronograma_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./ela-cronograma/ela-cronograma.component */ 327);
/* harmony import */ var _ela_edit_hallazago_ela_edit_hallazago_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./ela-edit-hallazago/ela-edit-hallazago.component */ 8546);
/* harmony import */ var _ela_registro_hallazgos_ela_registro_hallazgos_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./ela-registro-hallazgos/ela-registro-hallazgos.component */ 6223);
/* harmony import */ var _ela_objetivos_ela_objetivos_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./ela-objetivos/ela-objetivos.component */ 4649);
/* harmony import */ var _ela_registro_areapreocupacion_ela_registro_areapreocupacion_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./ela-registro-areapreocupacion/ela-registro-areapreocupacion.component */ 8998);
/* harmony import */ var _param_documentos_param_documentos_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./param-documentos/param-documentos.component */ 4072);
/* harmony import */ var _ela_cronograma_list_ela_cronograma_list_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./ela-cronograma-list/ela-cronograma-list.component */ 3181);
/* harmony import */ var _ela_edit_areapreocupacion_ela_edit_areapreocupacion_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./ela-edit-areapreocupacion/ela-edit-areapreocupacion.component */ 7226);
/* harmony import */ var _editor_documento_editor_documento_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./editor-documento/editor-documento.component */ 8543);
/* harmony import */ var _tm_acta_reunion_tm_acta_reunion_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./tm-acta-reunion/tm-acta-reunion.component */ 1850);
/* harmony import */ var _ela_plan_muestreo_ela_plan_muestreo_component__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./ela-plan-muestreo/ela-plan-muestreo.component */ 2094);
/* harmony import */ var _param_horarios_param_horarios_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./param-horarios/param-horarios.component */ 833);




































let ComponentsModule = class ComponentsModule {
};
ComponentsModule = (0,tslib__WEBPACK_IMPORTED_MODULE_31__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_32__.NgModule)({
        declarations: [
            _message_error_message_error_component__WEBPACK_IMPORTED_MODULE_2__.MessageErrorComponent,
            _custom_input_custom_input_component__WEBPACK_IMPORTED_MODULE_3__.CustomInputComponent,
            _custom_header_custom_header_component__WEBPACK_IMPORTED_MODULE_4__.CustomHeaderComponent,
            _tcp_list_products_tcp_list_products_component__WEBPACK_IMPORTED_MODULE_1__.TcpListProductsComponent,
            _tcs_list_systems_tcs_list_systems_component__WEBPACK_IMPORTED_MODULE_0__.TcsListSystemsComponent,
            _meses_meses_component__WEBPACK_IMPORTED_MODULE_5__.MesesComponent,
            _product_detail_product_detail_component__WEBPACK_IMPORTED_MODULE_6__.ProductDetailComponent,
            _lista_verificacion_apertura_lista_verificacion_apertura_component__WEBPACK_IMPORTED_MODULE_7__.ListaVerificacionAperturaComponent,
            _plan_auditoria_plan_auditoria_component__WEBPACK_IMPORTED_MODULE_9__.PlanAuditoriaComponent,
            _registro_ciclo_registro_ciclo_component__WEBPACK_IMPORTED_MODULE_8__.RegistroCicloComponent,
            _ciclo_participante_ciclo_participante_component__WEBPACK_IMPORTED_MODULE_10__.CicloParticipanteComponent,
            _tcs_lista_verificacion_reunion_apertura_tcs_lista_verificacion_reunion_apertura_component__WEBPACK_IMPORTED_MODULE_11__.TcsListaVerificacionReunionAperturaComponent,
            _tcs_lista_verificacion_reunion_cierre_tcs_lista_verificacion_reunion_cierre_component__WEBPACK_IMPORTED_MODULE_12__.TcsListaVerificacionReunionCierreComponent,
            _pra_cronograma_pra_cronograma_component__WEBPACK_IMPORTED_MODULE_13__.PraCronogramaComponent,
            _buscar_norma_buscar_norma_component__WEBPACK_IMPORTED_MODULE_14__.BuscarNormaComponent,
            _pra_direccion_sistema_pra_direccion_sistema_component__WEBPACK_IMPORTED_MODULE_15__.PraDireccionSistemaComponent,
            _param_paises_param_paises_component__WEBPACK_IMPORTED_MODULE_16__.ParamPaisesComponent,
            _pra_edit_norma_sistema_pra_edit_norma_sistema_component__WEBPACK_IMPORTED_MODULE_17__.PraEditNormaSistemaComponent,
            _param_organismos_certificadores_param_organismos_certificadores_component__WEBPACK_IMPORTED_MODULE_18__.ParamOrganismosCertificadoresComponent,
            _ela_cronograma_ela_cronograma_component__WEBPACK_IMPORTED_MODULE_19__.ElaCronogramaComponent,
            _ela_edit_hallazago_ela_edit_hallazago_component__WEBPACK_IMPORTED_MODULE_20__.ElaEditHallazagoComponent,
            _ela_registro_hallazgos_ela_registro_hallazgos_component__WEBPACK_IMPORTED_MODULE_21__.ElaRegistroHallazgosComponent,
            _ela_objetivos_ela_objetivos_component__WEBPACK_IMPORTED_MODULE_22__.ElaObjetivosComponent,
            _ela_registro_areapreocupacion_ela_registro_areapreocupacion_component__WEBPACK_IMPORTED_MODULE_23__.ElaRegistroAreapreocupacionComponent,
            _param_documentos_param_documentos_component__WEBPACK_IMPORTED_MODULE_24__.ParamDocumentosComponent,
            _ela_cronograma_list_ela_cronograma_list_component__WEBPACK_IMPORTED_MODULE_25__.ElaCronogramaListComponent,
            _ela_edit_areapreocupacion_ela_edit_areapreocupacion_component__WEBPACK_IMPORTED_MODULE_26__.ElaEditAreapreocupacionComponent,
            _editor_documento_editor_documento_component__WEBPACK_IMPORTED_MODULE_27__.EditorDocumentoComponent,
            _tm_acta_reunion_tm_acta_reunion_component__WEBPACK_IMPORTED_MODULE_28__.TmActaReunionComponent,
            _ela_plan_muestreo_ela_plan_muestreo_component__WEBPACK_IMPORTED_MODULE_29__.ElaPlanMuestreoComponent,
            _param_horarios_param_horarios_component__WEBPACK_IMPORTED_MODULE_30__.ParamHorariosComponent
        ],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_33__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_34__.IonicModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_35__.ReactiveFormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_35__.FormsModule,
        ],
        exports: [
            _message_error_message_error_component__WEBPACK_IMPORTED_MODULE_2__.MessageErrorComponent,
            _custom_input_custom_input_component__WEBPACK_IMPORTED_MODULE_3__.CustomInputComponent,
            _custom_header_custom_header_component__WEBPACK_IMPORTED_MODULE_4__.CustomHeaderComponent,
            _custom_header_custom_header_component__WEBPACK_IMPORTED_MODULE_4__.CustomHeaderComponent,
            _tcp_list_products_tcp_list_products_component__WEBPACK_IMPORTED_MODULE_1__.TcpListProductsComponent,
            _tcs_list_systems_tcs_list_systems_component__WEBPACK_IMPORTED_MODULE_0__.TcsListSystemsComponent,
            _meses_meses_component__WEBPACK_IMPORTED_MODULE_5__.MesesComponent,
            _product_detail_product_detail_component__WEBPACK_IMPORTED_MODULE_6__.ProductDetailComponent,
            _lista_verificacion_apertura_lista_verificacion_apertura_component__WEBPACK_IMPORTED_MODULE_7__.ListaVerificacionAperturaComponent,
            _plan_auditoria_plan_auditoria_component__WEBPACK_IMPORTED_MODULE_9__.PlanAuditoriaComponent,
            _registro_ciclo_registro_ciclo_component__WEBPACK_IMPORTED_MODULE_8__.RegistroCicloComponent,
            _ciclo_participante_ciclo_participante_component__WEBPACK_IMPORTED_MODULE_10__.CicloParticipanteComponent,
            _tcs_lista_verificacion_reunion_apertura_tcs_lista_verificacion_reunion_apertura_component__WEBPACK_IMPORTED_MODULE_11__.TcsListaVerificacionReunionAperturaComponent,
            _tcs_lista_verificacion_reunion_cierre_tcs_lista_verificacion_reunion_cierre_component__WEBPACK_IMPORTED_MODULE_12__.TcsListaVerificacionReunionCierreComponent,
            _pra_cronograma_pra_cronograma_component__WEBPACK_IMPORTED_MODULE_13__.PraCronogramaComponent,
            _buscar_norma_buscar_norma_component__WEBPACK_IMPORTED_MODULE_14__.BuscarNormaComponent,
            _pra_direccion_sistema_pra_direccion_sistema_component__WEBPACK_IMPORTED_MODULE_15__.PraDireccionSistemaComponent,
            _param_paises_param_paises_component__WEBPACK_IMPORTED_MODULE_16__.ParamPaisesComponent,
            _pra_edit_norma_sistema_pra_edit_norma_sistema_component__WEBPACK_IMPORTED_MODULE_17__.PraEditNormaSistemaComponent,
            _param_organismos_certificadores_param_organismos_certificadores_component__WEBPACK_IMPORTED_MODULE_18__.ParamOrganismosCertificadoresComponent,
            _ela_cronograma_ela_cronograma_component__WEBPACK_IMPORTED_MODULE_19__.ElaCronogramaComponent,
            _ela_edit_hallazago_ela_edit_hallazago_component__WEBPACK_IMPORTED_MODULE_20__.ElaEditHallazagoComponent,
            _ela_registro_hallazgos_ela_registro_hallazgos_component__WEBPACK_IMPORTED_MODULE_21__.ElaRegistroHallazgosComponent,
            _ela_objetivos_ela_objetivos_component__WEBPACK_IMPORTED_MODULE_22__.ElaObjetivosComponent,
            _ela_registro_areapreocupacion_ela_registro_areapreocupacion_component__WEBPACK_IMPORTED_MODULE_23__.ElaRegistroAreapreocupacionComponent,
            _param_documentos_param_documentos_component__WEBPACK_IMPORTED_MODULE_24__.ParamDocumentosComponent,
            _ela_cronograma_list_ela_cronograma_list_component__WEBPACK_IMPORTED_MODULE_25__.ElaCronogramaListComponent,
            _ela_edit_areapreocupacion_ela_edit_areapreocupacion_component__WEBPACK_IMPORTED_MODULE_26__.ElaEditAreapreocupacionComponent,
            _editor_documento_editor_documento_component__WEBPACK_IMPORTED_MODULE_27__.EditorDocumentoComponent,
            _tm_acta_reunion_tm_acta_reunion_component__WEBPACK_IMPORTED_MODULE_28__.TmActaReunionComponent,
            _ela_plan_muestreo_ela_plan_muestreo_component__WEBPACK_IMPORTED_MODULE_29__.ElaPlanMuestreoComponent,
            _param_horarios_param_horarios_component__WEBPACK_IMPORTED_MODULE_30__.ParamHorariosComponent
        ],
    })
], ComponentsModule);



/***/ }),

/***/ 8814:
/*!*********************************************************************!*\
  !*** ./src/app/components/custom-header/custom-header.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CustomHeaderComponent": () => (/* binding */ CustomHeaderComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _custom_header_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./custom-header.component.html?ngResource */ 4175);
/* harmony import */ var _custom_header_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./custom-header.component.scss?ngResource */ 1747);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);




let CustomHeaderComponent = class CustomHeaderComponent {
    constructor() { }
    ngOnInit() { }
};
CustomHeaderComponent.ctorParameters = () => [];
CustomHeaderComponent.propDecorators = {
    title: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    icon_name: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }]
};
CustomHeaderComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-custom-header',
        template: _custom_header_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_custom_header_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], CustomHeaderComponent);



/***/ }),

/***/ 3082:
/*!*******************************************************************!*\
  !*** ./src/app/components/custom-input/custom-input.component.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CustomInputComponent": () => (/* binding */ CustomInputComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _custom_input_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./custom-input.component.html?ngResource */ 393);
/* harmony import */ var _custom_input_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./custom-input.component.scss?ngResource */ 1088);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);






let CustomInputComponent = class CustomInputComponent {
    constructor(popoverController) {
        this.popoverController = popoverController;
        this.readonly = false;
        this._ionChange = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
        this.customDate = new Date();
        this.currentDate = new Date();
        this.formatDate = 'date';
        this.maxDate = this.currentDate.getUTCFullYear() + 10;
        this.eventKeyEnterEmiiter = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
        console.log('maxDate', this.maxDate);
    }
    ngOnInit() {
        if (this.formGruop && !this.formGruop.get(this.name)) {
            this.formGruop.addControl(this.name, new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(this.defaultValue));
            const validators = [];
            if (this.Validations) {
                for (const val of this.Validations) {
                    validators.push(val.validator);
                }
                this.formGruop.controls[this.name].setValidators(validators);
            }
        }
        if (this.type === 'datetime' && this.defaultValue) {
            const date = new Date(this.defaultValue);
            date.setDate(date.getDate() + 1);
            this.formGruop.controls[this.name]['valueDate'] = date;
        }
        else if (this.type === 'datetime' && !this.defaultValue) {
            const date = (this.defaultValue = new Date());
            date.setDate(date.getDate() + 1);
            this.formGruop.controls[this.name]['valueDate'] = date;
        }
    }
    get Control() {
        console.log('solicitando el control');
        console.log(this.formGruop.controls[this.name].errors);
        return this.formGruop.controls[this.name];
    }
    ExistsError(validator) {
        return validator(this.formGruop.controls[this.name]);
    }
    eventKeyEnter(event) {
        if (this.popoverController) {
            this.popoverController.dismiss({
                item: this.formGruop.controls[this.name]['value'],
            });
        }
        if (this.eventKeyEnterEmiiter) {
            this.eventKeyEnterEmiiter.emit(event);
        }
    }
    selectionarFecha(event) {
        const dateSelect = new Date(event.detail.value);
        if (this.popoverController) {
            this.popoverController.dismiss({
                item: dateSelect,
            });
        }
        if (this.eventKeyEnterEmiiter) {
            this.eventKeyEnterEmiiter.emit(dateSelect);
        }
    }
};
CustomInputComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.PopoverController }
];
CustomInputComponent.propDecorators = {
    readonly: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    label: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    name: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    type: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    formGruop: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    Validations: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    form: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    defaultValue: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    _ionChange: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Output }],
    formatDate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    maxDate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    eventKeyEnterEmiiter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Output }]
};
CustomInputComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-custom-input',
        template: _custom_input_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_custom_input_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], CustomInputComponent);



/***/ }),

/***/ 8543:
/*!***************************************************************************!*\
  !*** ./src/app/components/editor-documento/editor-documento.component.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EditorDocumentoComponent": () => (/* binding */ EditorDocumentoComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _editor_documento_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./editor-documento.component.html?ngResource */ 6545);
/* harmony import */ var _editor_documento_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./editor-documento.component.scss?ngResource */ 5902);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_interfaces_toma_decisiones_tmddocumentacionauditorium__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/interfaces/toma_decisiones/tmddocumentacionauditorium */ 2281);





let EditorDocumentoComponent = class EditorDocumentoComponent {
    constructor() {
        this.guardarContenidoEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
        this.contenido = "";
    }
    ngOnInit() {
        if (!this.tmddocumentacionauditorium) {
            this.tmddocumentacionauditorium = new src_app_interfaces_toma_decisiones_tmddocumentacionauditorium__WEBPACK_IMPORTED_MODULE_2__.Tmddocumentacionauditorium();
        }
    }
    ngOnDestroy() { }
    guardarContenido() {
        if (this.guardarContenidoEmitter) {
            this.guardarContenidoEmitter.emit(this.contenido);
        }
    }
};
EditorDocumentoComponent.ctorParameters = () => [];
EditorDocumentoComponent.propDecorators = {
    titulo: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    tmddocumentacionauditorium: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    guardarContenidoEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output }]
};
EditorDocumentoComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: "app-editor-documento",
        template: _editor_documento_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_editor_documento_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], EditorDocumentoComponent);



/***/ }),

/***/ 3181:
/*!*********************************************************************************!*\
  !*** ./src/app/components/ela-cronograma-list/ela-cronograma-list.component.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ElaCronogramaListComponent": () => (/* binding */ ElaCronogramaListComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ela_cronograma_list_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ela-cronograma-list.component.html?ngResource */ 6228);
/* harmony import */ var _ela_cronograma_list_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ela-cronograma-list.component.scss?ngResource */ 7613);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_interfaces_elaboracion_auditoria_PlanAuditoriaDTO__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/interfaces/elaboracion_auditoria/PlanAuditoriaDTO */ 7522);





let ElaCronogramaListComponent = class ElaCronogramaListComponent {
    constructor() {
        this.guardarCronogramaEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
        this.eliminarCronogramaEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
        this.currentCrongramaIndex = -1;
        this.mode = "LIST";
        this.operation = "UPDATE";
    }
    ngOnInit() {
        if (!this.listCronograma) {
            this.listCronograma = new Array();
        }
    }
    addCronograma() {
        this.currentCrongrama = new src_app_interfaces_elaboracion_auditoria_PlanAuditoriaDTO__WEBPACK_IMPORTED_MODULE_2__.Elacronogama();
        this.mode = "EDIT";
        this.operation = "ADD";
    }
    editarCronograma(index) {
        this.currentCrongrama = this.listCronograma[index];
        this.currentCrongramaIndex = index;
        this.mode = "EDIT";
        this.operation = "UPDATE";
    }
    eliminarCronograma(index) {
        let idElacronograma = this.listCronograma[index].idElAcronograma;
        this.listCronograma.splice(index, 1);
        if (this.eliminarCronogramaEmitter) {
            this.eliminarCronogramaEmitter.emit(idElacronograma);
        }
    }
    guardarCronograma(event) {
        console.log("*** se guarda en lista", event);
        /*event.idDireccionPaproducto = this.llaves.idDireccionPaproducto;
        event.idDireccionPasistema = this.llaves.idDireccionPasistema;*/
        if (this.operation === "UPDATE") {
            this.listCronograma[this.currentCrongramaIndex] = event;
        }
        else {
            this.listCronograma.push(event);
        }
        if (this.guardarCronogramaEmitter) {
            this.guardarCronogramaEmitter.emit(this.listCronograma);
        }
        console.log("*** listCronograma", this.listCronograma);
        this.mode = "LIST";
    }
    cancelarCronograma() {
        this.mode = "LIST";
    }
};
ElaCronogramaListComponent.ctorParameters = () => [];
ElaCronogramaListComponent.propDecorators = {
    listCronograma: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    listaParticipantes: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    guardarCronogramaEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output }],
    eliminarCronogramaEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output }],
    listaDirecciones: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    llaves: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }]
};
ElaCronogramaListComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: "app-ela-cronograma-list",
        template: _ela_cronograma_list_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_ela_cronograma_list_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ElaCronogramaListComponent);



/***/ }),

/***/ 327:
/*!***********************************************************************!*\
  !*** ./src/app/components/ela-cronograma/ela-cronograma.component.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ElaCronogramaComponent": () => (/* binding */ ElaCronogramaComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ela_cronograma_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ela-cronograma.component.html?ngResource */ 1155);
/* harmony import */ var _ela_cronograma_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ela-cronograma.component.scss?ngResource */ 2291);
/* harmony import */ var _interfaces_elaboracion_auditoria_PlanAuditoriaDTO__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../interfaces/elaboracion_auditoria/PlanAuditoriaDTO */ 7522);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var src_app_interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/interfaces/cross-ui/ConvertFormToObject */ 9788);








let ElaCronogramaComponent = class ElaCronogramaComponent {
    constructor(toastController, formBuilder) {
        this.toastController = toastController;
        this.formBuilder = formBuilder;
        this.guardarCronogramaEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter();
        this.cancelarCronogramaEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter();
        this.participantes = "";
    }
    ngOnInit() {
        var _a;
        if (!this.currentElacronogama)
            this.currentElacronogama = new _interfaces_elaboracion_auditoria_PlanAuditoriaDTO__WEBPACK_IMPORTED_MODULE_2__.Elacronogama();
        this.ionicFormHorario = this.formBuilder.group({});
        this.selectedParticipantes = new Array();
        (_a = this.currentElacronogama.auditor) === null || _a === void 0 ? void 0 : _a.split(";").forEach((x) => {
            this.selectedParticipantes.push(x);
        });
    }
    seleccionarParticipante(event) {
        console.log("se selecciono particiapante", event);
        console.log("valor actual de la lista", this.selectedParticipantes);
        if (event.detail) {
            event.detail.value.forEach((element) => {
                this.participantes = this.participantes + element.nombreCompleto + ";";
            });
        }
    }
    seleccionarDireccion(event) {
        console.log("se selecciono direccion", event);
        this.currentElacronogama.direccion = event.detail.value;
    }
    cancelar() {
        if (this.cancelarCronogramaEmitter) {
            this.cancelarCronogramaEmitter.emit(this.currentElacronogama);
        }
    }
    guardarCronograma() {
        src_app_interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_3__.ConvertFormToObject.convert(this.ionicFormHorario, this.currentElacronogama);
        this.currentElacronogama.auditor = this.participantes;
        console.log("seleccionarParticipante", this.currentElacronogama);
        if (this.guardarCronogramaEmitter) {
            this.guardarCronogramaEmitter.emit(this.currentElacronogama);
        }
    }
};
ElaCronogramaComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ToastController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder }
];
ElaCronogramaComponent.propDecorators = {
    currentElacronogama: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input }],
    guardarCronogramaEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output }],
    cancelarCronogramaEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output }],
    listaParticipantes: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input }],
    listaDirecciones: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input }]
};
ElaCronogramaComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: "app-ela-cronograma",
        template: _ela_cronograma_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_ela_cronograma_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ElaCronogramaComponent);



/***/ }),

/***/ 7226:
/*!*********************************************************************************************!*\
  !*** ./src/app/components/ela-edit-areapreocupacion/ela-edit-areapreocupacion.component.ts ***!
  \*********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ElaEditAreapreocupacionComponent": () => (/* binding */ ElaEditAreapreocupacionComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ela_edit_areapreocupacion_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ela-edit-areapreocupacion.component.html?ngResource */ 8685);
/* harmony import */ var _ela_edit_areapreocupacion_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ela-edit-areapreocupacion.component.scss?ngResource */ 612);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var src_app_interfaces_elaboracion_auditoria_PlanAuditoriaDTO__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/interfaces/elaboracion_auditoria/PlanAuditoriaDTO */ 7522);
/* harmony import */ var src_app_interfaces_seguridad_usuario__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/interfaces/seguridad/usuario */ 6598);
/* harmony import */ var _interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../interfaces/cross-ui/ConvertFormToObject */ 9788);









let ElaEditAreapreocupacionComponent = class ElaEditAreapreocupacionComponent {
    constructor(toastController, formBuilder) {
        this.toastController = toastController;
        this.formBuilder = formBuilder;
        this.guardarAdpEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter();
        this.cancelarAdpEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter();
        this.currentAdp = new src_app_interfaces_elaboracion_auditoria_PlanAuditoriaDTO__WEBPACK_IMPORTED_MODULE_2__.Elaadp();
    }
    ngOnInit() {
        this.ionicFormAdp = this.formBuilder.group({});
    }
    cancelarAreaDePreocupacion() {
        if (this.cancelarAdpEmitter) {
            this.cancelarAdpEmitter.emit();
        }
    }
    guardarAreaDePreocupacion() {
        _interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_4__.ConvertFormToObject.convert(this.ionicFormAdp, this.currentAdp);
        this.currentAdp.fecha = this.getStringFromDate(new Date());
        this.currentAdp.usuario = src_app_interfaces_seguridad_usuario__WEBPACK_IMPORTED_MODULE_3__.usuario.currentUser.nick;
        if (this.guardarAdpEmitter) {
            this.guardarAdpEmitter.emit(this.currentAdp);
        }
    }
    valorDescripcion(event) {
        this.currentAdp.descripcion = event.detail.value;
    }
    getStringFromDate(date) {
        return ((date.getDate() > 9 ? date.getDate() : "0" + date.getDate()) +
            "/" +
            (date.getMonth() > 8
                ? date.getMonth() + 1
                : "0" + (date.getMonth() + 1)) +
            "/" +
            date.getFullYear());
    }
};
ElaEditAreapreocupacionComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder }
];
ElaEditAreapreocupacionComponent.propDecorators = {
    guardarAdpEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output }],
    cancelarAdpEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output }],
    currentAdp: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input }]
};
ElaEditAreapreocupacionComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: "app-ela-edit-areapreocupacion",
        template: _ela_edit_areapreocupacion_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_ela_edit_areapreocupacion_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ElaEditAreapreocupacionComponent);



/***/ }),

/***/ 8546:
/*!*******************************************************************************!*\
  !*** ./src/app/components/ela-edit-hallazago/ela-edit-hallazago.component.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ElaEditHallazagoComponent": () => (/* binding */ ElaEditHallazagoComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ela_edit_hallazago_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ela-edit-hallazago.component.html?ngResource */ 4408);
/* harmony import */ var _ela_edit_hallazago_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ela-edit-hallazago.component.scss?ngResource */ 9967);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var src_app_interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/interfaces/cross-ui/ConvertFormToObject */ 9788);
/* harmony import */ var src_app_interfaces_elaboracion_auditoria_PlanAuditoriaDTO__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/interfaces/elaboracion_auditoria/PlanAuditoriaDTO */ 7522);
/* harmony import */ var src_app_interfaces_seguridad_usuario__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/interfaces/seguridad/usuario */ 6598);









let ElaEditHallazagoComponent = class ElaEditHallazagoComponent {
    constructor(toastController, formBuilder) {
        this.toastController = toastController;
        this.formBuilder = formBuilder;
        //@Input() lNormas: string[];
        //@Input() ltiposObervacion: string[];
        this.tipoObservacion = null;
        this.guardarHallazgoEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter();
        this.cancelarHallazgoEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter();
        this.ltiposObervacion = [
            { nemotico: "NCM", descripcion: "No-Conformidad Mayor" },
            { nemotico: "OM", descripcion: "Oportunidad de mejora" },
            { nemotico: "NCm", descripcion: "No Conformidad Menor" },
            { nemotico: "F", descripcion: "Fortaleza" },
            //{ nemotico: "C", descripcion: "Conformidades" },
        ];
        this.lNormas = ["ISO:2007", "ISO:9001", "ISO:4427", "ISO:1334"];
    }
    ngOnInit() {
        this.ionicFormHallazgo = this.formBuilder.group({});
        if (this.elahallazgo) {
            this.tipoObservacion = this.ltiposObervacion.filter((x) => x.nemotico === this.elahallazgo.tipoNemotico)[0];
        }
        if (!this.elahallazgo)
            this.elahallazgo = new src_app_interfaces_elaboracion_auditoria_PlanAuditoriaDTO__WEBPACK_IMPORTED_MODULE_3__.Elahallazgo();
    }
    editarHallazgo() { }
    valorHallazagos(event) {
        this.elahallazgo.hallazgo = event.detail.value;
    }
    cancelarHallazo() {
        if (this.cancelarHallazgoEmitter) {
            this.cancelarHallazgoEmitter.emit();
        }
    }
    guardarHallazgo() {
        console.log("Guardar Hallazgo");
        src_app_interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_2__.ConvertFormToObject.convert(this.ionicFormHallazgo, this.elahallazgo);
        this.elahallazgo.fecha = this.getStringFromDate(new Date());
        this.elahallazgo.usuario = src_app_interfaces_seguridad_usuario__WEBPACK_IMPORTED_MODULE_4__.usuario.currentUser.nick;
        if (this.guardarHallazgoEmitter) {
            this.guardarHallazgoEmitter.emit(this.elahallazgo);
        }
    }
    seleccionarTipo(event) {
        console.log("seleccionar Hallazgo", event);
        this.elahallazgo.tipo = event.detail.value.descripcion;
        this.elahallazgo.tipoNemotico = event.detail.value.nemotico;
    }
    seleccionarNorma(event) {
        console.log("seleccionar Hallazgo", event);
        this.elahallazgo.normas = event.detail.value;
    }
    getStringFromDate(date) {
        return ((date.getDate() > 9 ? date.getDate() : "0" + date.getDate()) +
            "/" +
            (date.getMonth() > 8
                ? date.getMonth() + 1
                : "0" + (date.getMonth() + 1)) +
            "/" +
            date.getFullYear());
    }
};
ElaEditHallazagoComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder }
];
ElaEditHallazagoComponent.propDecorators = {
    elahallazgo: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input }],
    guardarHallazgoEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output }],
    cancelarHallazgoEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Output }],
    lNormas: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input }]
};
ElaEditHallazagoComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: "app-ela-edit-hallazago",
        template: _ela_edit_hallazago_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_ela_edit_hallazago_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ElaEditHallazagoComponent);



/***/ }),

/***/ 4649:
/*!*********************************************************************!*\
  !*** ./src/app/components/ela-objetivos/ela-objetivos.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ElaObjetivosComponent": () => (/* binding */ ElaObjetivosComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ela_objetivos_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ela-objetivos.component.html?ngResource */ 5835);
/* harmony import */ var _ela_objetivos_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ela-objetivos.component.scss?ngResource */ 5881);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_services_elaboracion_auditoria_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/elaboracion-auditoria.service */ 1264);





let ElaObjetivosComponent = class ElaObjetivosComponent {
    constructor(elaboracionAuditoriaService) {
        this.elaboracionAuditoriaService = elaboracionAuditoriaService;
        this.area = "";
        this.guardarContenidoEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
        this.listSubtitulos = new Array();
    }
    ngOnInit() {
        if (this.listContenido) {
            this.listContenido.forEach((contenido) => {
                if (this.listSubtitulos.filter((hh) => hh.nemotico === contenido.nemotico)
                    .length === 0) {
                    this.listSubtitulos.push(contenido);
                }
            });
        }
    }
    ListByCategoria(nemotico) {
        if (this.listContenido) {
            return this.listContenido.filter((x) => x.nemotico == nemotico);
        }
        else
            return null;
    }
    guardarContenido() {
        this.listContenido.forEach((x) => {
            x.seleccionado = x["select"] ? 1 : 0;
        });
        if (this.guardarContenidoEmitter) {
            this.guardarContenidoEmitter.emit(this.listContenido);
        }
    }
};
ElaObjetivosComponent.ctorParameters = () => [
    { type: src_app_services_elaboracion_auditoria_service__WEBPACK_IMPORTED_MODULE_2__.ElaboracionAuditoriaService }
];
ElaObjetivosComponent.propDecorators = {
    listContenido: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    area: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    guardarContenidoEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output }]
};
ElaObjetivosComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: "app-ela-objetivos",
        template: _ela_objetivos_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_ela_objetivos_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ElaObjetivosComponent);



/***/ }),

/***/ 2094:
/*!*****************************************************************************!*\
  !*** ./src/app/components/ela-plan-muestreo/ela-plan-muestreo.component.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ElaPlanMuestreoComponent": () => (/* binding */ ElaPlanMuestreoComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ela_plan_muestreo_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ela-plan-muestreo.component.html?ngResource */ 5465);
/* harmony import */ var _ela_plan_muestreo_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ela-plan-muestreo.component.scss?ngResource */ 1516);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_interfaces_elaboracion_auditoria_PlanAuditoriaDTO__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/interfaces/elaboracion_auditoria/PlanAuditoriaDTO */ 7522);





let ElaPlanMuestreoComponent = class ElaPlanMuestreoComponent {
    constructor() {
        this.listaContenido = [];
        this.nemotico = "";
        this.titulo = "";
        this.currentContenido = new src_app_interfaces_elaboracion_auditoria_PlanAuditoriaDTO__WEBPACK_IMPORTED_MODULE_2__.Elacontenidoauditorium();
        this.guardarPlanMuestreo = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
    }
    ngOnInit() {
        this.currentContenido = this.listaContenido.find(x => x.nemotico === this.nemotico);
        console.log(this.listaContenido);
    }
    guardarMuestreo() {
        this.listaContenido.map(obj => this.listaContenido.find(o => o.nemotico === this.currentContenido.nemotico) || obj);
        console.log("ingresa a guardar muestreo");
        if (this.guardarPlanMuestreo) {
            this.guardarPlanMuestreo.emit(this.listaContenido);
        }
    }
};
ElaPlanMuestreoComponent.ctorParameters = () => [];
ElaPlanMuestreoComponent.propDecorators = {
    listaContenido: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    nemotico: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    titulo: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    guardarPlanMuestreo: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output }]
};
ElaPlanMuestreoComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-ela-plan-muestreo',
        template: _ela_plan_muestreo_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_ela_plan_muestreo_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ElaPlanMuestreoComponent);



/***/ }),

/***/ 8998:
/*!*****************************************************************************************************!*\
  !*** ./src/app/components/ela-registro-areapreocupacion/ela-registro-areapreocupacion.component.ts ***!
  \*****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ElaRegistroAreapreocupacionComponent": () => (/* binding */ ElaRegistroAreapreocupacionComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ela_registro_areapreocupacion_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ela-registro-areapreocupacion.component.html?ngResource */ 724);
/* harmony import */ var _ela_registro_areapreocupacion_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ela-registro-areapreocupacion.component.scss?ngResource */ 7979);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_interfaces_elaboracion_auditoria_PlanAuditoriaDTO__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/interfaces/elaboracion_auditoria/PlanAuditoriaDTO */ 7522);





let ElaRegistroAreapreocupacionComponent = class ElaRegistroAreapreocupacionComponent {
    constructor() {
        this.guardarAdpEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
        this.mode = "LIST";
        this.operacion = "";
        this.currentIndex = -1;
    }
    ngOnInit() {
        if (!this.listaAdp) {
            this.listaAdp = new Array();
        }
    }
    eliminarAdp(i) {
        this.listaAdp.splice(i, 1);
        if (this.guardarAdpEmitter) {
            this.guardarAdpEmitter.emit(this.listaAdp);
        }
    }
    editarAdp(i) {
        this.mode = "EDIT";
        this.operacion = "UPD";
        console.log("Guardar Adp", this.listaAdp[i]);
        this.currentAdp = this.listaAdp[i];
        this.currentIndex = i;
    }
    adicionarAdp() {
        this.mode = "EDIT";
        this.operacion = "ADD";
        this.currentAdp = new src_app_interfaces_elaboracion_auditoria_PlanAuditoriaDTO__WEBPACK_IMPORTED_MODULE_2__.Elaadp();
    }
    guardarAreaDePreocupacion(event) {
        this.mode = "LIST";
        if (this.operacion === "UPD")
            this.listaAdp[this.currentIndex] = event;
        else
            this.listaAdp.push(event);
        if (this.guardarAdpEmitter) {
            this.guardarAdpEmitter.emit(this.listaAdp);
        }
    }
    cancelarAreaDePreocupacion() {
        this.mode = "LIST";
    }
};
ElaRegistroAreapreocupacionComponent.ctorParameters = () => [];
ElaRegistroAreapreocupacionComponent.propDecorators = {
    listaAdp: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    guardarAdpEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output }]
};
ElaRegistroAreapreocupacionComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: "app-ela-registro-areapreocupacion",
        template: _ela_registro_areapreocupacion_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_ela_registro_areapreocupacion_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ElaRegistroAreapreocupacionComponent);



/***/ }),

/***/ 6223:
/*!***************************************************************************************!*\
  !*** ./src/app/components/ela-registro-hallazgos/ela-registro-hallazgos.component.ts ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ElaRegistroHallazgosComponent": () => (/* binding */ ElaRegistroHallazgosComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ela_registro_hallazgos_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ela-registro-hallazgos.component.html?ngResource */ 9376);
/* harmony import */ var _ela_registro_hallazgos_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ela-registro-hallazgos.component.scss?ngResource */ 6169);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_interfaces_elaboracion_auditoria_PlanAuditoriaDTO__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/interfaces/elaboracion_auditoria/PlanAuditoriaDTO */ 7522);





let ElaRegistroHallazgosComponent = class ElaRegistroHallazgosComponent {
    constructor() {
        this.lNormas = ["ISO:2007", "ISO:9001", "ISO:4427", "ISO:1334"];
        this.guardarHallazgoEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
        this.mode = "LIST";
        this.operacion = "";
        this.currentIndex = -1;
    }
    ngOnInit() {
        if (!this.listaHallazgos) {
            this.listaHallazgos = new Array();
        }
    }
    eliminarHallazgo(i) {
        this.listaHallazgos.splice(i, 1);
        if (this.guardarHallazgoEmitter) {
            this.guardarHallazgoEmitter.emit(this.listaHallazgos);
        }
    }
    editarHallazgo(i) {
        this.mode = "EDIT";
        this.operacion = "UPD";
        console.log("Guardar Hallazgo", this.listaHallazgos[i]);
        this.currentHallazgo = this.listaHallazgos[i];
        this.currentIndex = i;
    }
    guardarHallazgo(event) {
        this.mode = "LIST";
        if (this.operacion === "UPD")
            this.listaHallazgos[this.currentIndex] = event;
        else
            this.listaHallazgos.push(event);
        if (this.guardarHallazgoEmitter) {
            this.guardarHallazgoEmitter.emit(this.listaHallazgos);
        }
    }
    cancelarHallazo() {
        this.mode = "LIST";
    }
    adicionarHallazgo() {
        this.mode = "EDIT";
        this.operacion = "ADD";
        this.currentHallazgo = new src_app_interfaces_elaboracion_auditoria_PlanAuditoriaDTO__WEBPACK_IMPORTED_MODULE_2__.Elahallazgo();
    }
};
ElaRegistroHallazgosComponent.ctorParameters = () => [];
ElaRegistroHallazgosComponent.propDecorators = {
    listaHallazgos: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    lNormas: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    guardarHallazgoEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output }]
};
ElaRegistroHallazgosComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: "app-ela-registro-hallazgos",
        template: _ela_registro_hallazgos_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_ela_registro_hallazgos_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ElaRegistroHallazgosComponent);



/***/ }),

/***/ 4265:
/*!*************************************************************************************************!*\
  !*** ./src/app/components/lista-verificacion-apertura/lista-verificacion-apertura.component.ts ***!
  \*************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ListaVerificacionAperturaComponent": () => (/* binding */ ListaVerificacionAperturaComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _lista_verificacion_apertura_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./lista-verificacion-apertura.component.html?ngResource */ 7417);
/* harmony import */ var _lista_verificacion_apertura_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./lista-verificacion-apertura.component.scss?ngResource */ 6923);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let ListaVerificacionAperturaComponent = class ListaVerificacionAperturaComponent {
    constructor() {
        this.data = [
            {
                name: 'Presentación del Equipo Auditor y de los representantes del auditado',
                selected: true
            },
            {
                name: 'Confirmar propósito y alcance de la auditoría',
                selected: false
            },
            {
                name: 'Mencionar la(s) norma(s) de referencia de la auditoría para establecer la conformidad del producto',
                selected: true
            },
            {
                name: 'Hacer énfasis en el compromiso de confidencialidad',
                selected: false
            },
            {
                name: 'Definir canales de comunicación',
                selected: false
            },
            {
                name: 'Confirmar la disponibilidad de recursos y medios necesarios',
                selected: false
            },
            {
                name: 'Revisar el plan de auditoría y confirmar los horarios del cronograma, reunión de cierre y reuniones intermedias',
                selected: false
            },
            {
                name: 'Arreglos',
                selected: false
            },
            {
                name: 'Preguntas y respuestas',
                selected: false
            },
            {
                name: 'Agradecer a los participantes por asistir',
                selected: false
            },
        ];
    }
    clickCheck(check) {
        console.log(check);
    }
    ngOnInit() { }
};
ListaVerificacionAperturaComponent.ctorParameters = () => [];
ListaVerificacionAperturaComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-lista-verificacion-apertura',
        template: _lista_verificacion_apertura_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_lista_verificacion_apertura_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ListaVerificacionAperturaComponent);



/***/ }),

/***/ 4278:
/*!*****************************************************!*\
  !*** ./src/app/components/meses/meses.component.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MesesComponent": () => (/* binding */ MesesComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _meses_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./meses.component.html?ngResource */ 377);
/* harmony import */ var _meses_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./meses.component.scss?ngResource */ 3420);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 3819);





let MesesComponent = class MesesComponent {
    constructor(popoverController) {
        this.popoverController = popoverController;
        this.items = [
            { value: 1, label: "Enero" },
            { value: 2, label: "Febrero" },
            { value: 3, label: "Marzo" },
            { value: 4, label: "Abril" },
            { value: 5, label: "Mayo" },
            { value: 6, label: "Junio" },
            { value: 7, label: "Julio" },
            { value: 8, label: "Agosto" },
            { value: 9, label: "Septiembre" },
            { value: 10, label: "Octubre" },
            { value: 11, label: "Noviembre" },
            { value: 12, label: "Diciembre" },
        ];
    }
    ngOnInit() { }
    selectMes(value) {
        console.log(this.items.find((x) => x.value == value));
        return this.popoverController.dismiss({
            item: this.items.find((x) => x.value == value),
        });
    }
};
MesesComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.PopoverController }
];
MesesComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: "app-meses",
        template: _meses_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_meses_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], MesesComponent);



/***/ }),

/***/ 2522:
/*!*********************************************************************!*\
  !*** ./src/app/components/message-error/message-error.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MessageErrorComponent": () => (/* binding */ MessageErrorComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _message_error_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./message-error.component.html?ngResource */ 5859);
/* harmony import */ var _message_error_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./message-error.component.scss?ngResource */ 421);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);




let MessageErrorComponent = class MessageErrorComponent {
    constructor() { }
    ngOnInit() { }
};
MessageErrorComponent.ctorParameters = () => [];
MessageErrorComponent.propDecorators = {
    error: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }]
};
MessageErrorComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-message-error',
        template: _message_error_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_message_error_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], MessageErrorComponent);



/***/ }),

/***/ 4072:
/*!***************************************************************************!*\
  !*** ./src/app/components/param-documentos/param-documentos.component.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ParamDocumentosComponent": () => (/* binding */ ParamDocumentosComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _param_documentos_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./param-documentos.component.html?ngResource */ 3618);
/* harmony import */ var _param_documentos_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./param-documentos.component.scss?ngResource */ 282);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_services_docmentos_services_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/docmentos-services.service */ 5749);
/* harmony import */ var src_app_services_elaboracion_auditoria_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/elaboracion-auditoria.service */ 1264);






let ParamDocumentosComponent = class ParamDocumentosComponent {
    constructor(elaboracionAuditoriaService, docmentosServicesService) {
        this.elaboracionAuditoriaService = elaboracionAuditoriaService;
        this.docmentosServicesService = docmentosServicesService;
        this.area = "TCS";
        this.IdCiclo = 0;
        this.proceso = "ELABORACION";
    }
    ngOnInit() {
        this.elaboracionAuditoriaService
            .GetListasDocumetos(this.area, this.proceso)
            .subscribe((x) => {
            this.listDocumentos = x.listEntities;
        });
    }
    descargarDocumento(nombrePlantilla) {
        this.docmentosServicesService.GenerarDocumento(this.IdCiclo, nombrePlantilla);
    }
};
ParamDocumentosComponent.ctorParameters = () => [
    { type: src_app_services_elaboracion_auditoria_service__WEBPACK_IMPORTED_MODULE_3__.ElaboracionAuditoriaService },
    { type: src_app_services_docmentos_services_service__WEBPACK_IMPORTED_MODULE_2__.DocmentosServicesService }
];
ParamDocumentosComponent.propDecorators = {
    area: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input }],
    IdCiclo: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input }],
    proceso: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input }]
};
ParamDocumentosComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: "app-param-documentos",
        template: _param_documentos_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_param_documentos_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ParamDocumentosComponent);



/***/ }),

/***/ 833:
/*!***********************************************************************!*\
  !*** ./src/app/components/param-horarios/param-horarios.component.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ParamHorariosComponent": () => (/* binding */ ParamHorariosComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _param_horarios_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./param-horarios.component.html?ngResource */ 4299);
/* harmony import */ var _param_horarios_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./param-horarios.component.scss?ngResource */ 4977);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 3819);





let ParamHorariosComponent = class ParamHorariosComponent {
    constructor(popoverController) {
        this.popoverController = popoverController;
        this.seleccionarHorarioEmit = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
        this.horarioIni = new Date();
        this.horarioFin = new Date();
        this.horarioFinFormat = '';
    }
    ngOnInit() {
        if (this.horario) {
            const horaIniAux = this.horario.substring(0, 5);
            const horaFinAux = this.horario.substring(5, 5);
            let time = horaIniAux.split(':');
            this.horarioIni.setHours(parseInt(time[0], 10));
            this.horarioIni.setMinutes(parseInt(time[1], 10));
            time = horaFinAux.split(':');
            this.horarioFin.setHours(parseInt(time[0], 10));
            this.horarioFin.setMinutes(parseInt(time[1], 10));
        }
    }
    selectionarHorarioIni(event) {
        //console.log('hora ini', event);
        this.horarioIni = new Date(event.detail.value);
    }
    selectionarHorarioFin(event) {
        this.horarioFin = new Date(event.detail.value);
        // console.log('horarioIni', this.horarioIni);
        // console.log('horarioFin', this.horarioFin);
        this.horarioFinFormat =
            this.pad(this.horarioIni.getHours(), 2) +
                ':' +
                this.pad(this.horarioIni.getMinutes(), 2) +
                '-' +
                this.pad(this.horarioFin.getHours(), 2) +
                ':' +
                this.pad(this.horarioFin.getMinutes(), 2);
    }
    confirmarSeleccion() {
        if (this.seleccionarHorarioEmit) {
            this.seleccionarHorarioEmit.emit(this.horarioFinFormat);
        }
        if (this.popoverController) {
            this.popoverController.dismiss({
                item: this.horarioFinFormat,
            });
        }
    }
    pad(num, size) {
        num = num.toString();
        while (num.length < size) {
            num = '0' + num;
        }
        return num;
    }
};
ParamHorariosComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.PopoverController }
];
ParamHorariosComponent.propDecorators = {
    horario: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Input }],
    seleccionarHorarioEmit: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__.Output }]
};
ParamHorariosComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Component)({
        selector: 'app-param-horarios',
        template: _param_horarios_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_param_horarios_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ParamHorariosComponent);



/***/ }),

/***/ 3566:
/*!*********************************************************************************************************!*\
  !*** ./src/app/components/param-organismos-certificadores/param-organismos-certificadores.component.ts ***!
  \*********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ParamOrganismosCertificadoresComponent": () => (/* binding */ ParamOrganismosCertificadoresComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _param_organismos_certificadores_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./param-organismos-certificadores.component.html?ngResource */ 6639);
/* harmony import */ var _param_organismos_certificadores_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./param-organismos-certificadores.component.scss?ngResource */ 4242);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_apertura_auditoria_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/apertura-auditoria.service */ 7583);






let ParamOrganismosCertificadoresComponent = class ParamOrganismosCertificadoresComponent {
    constructor(aperturaAuditoriaService, popoverController) {
        this.aperturaAuditoriaService = aperturaAuditoriaService;
        this.popoverController = popoverController;
        this.seleccionarOrganismoEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
    }
    ngOnInit() {
        console.log('iniciamos el control');
        ///obtenemos los clasificadores
        this.aperturaAuditoriaService
            .BuscarOrganismosCertificadores()
            .subscribe((x) => {
            console.log('resulado de la busqueda oranismos', x);
            this.listaOrganismos = x.listEntities;
            /*if (this.defaultValue) {
              this.currentOrganismo = this.listaOrganismos.find(
                (x) => x.descripcion === this.defaultValue
              );
            }*/
        });
    }
    seleccionarOrganismo(event) {
        this.descripcion = '';
        event.detail.value.forEach((x) => {
            if (this.descripcion === '') {
                this.descripcion = x.abrev;
            }
            else {
                this.descripcion = this.descripcion + ',' + x.abrev;
            }
        });
        console.log('datos', this.descripcion);
        if (this.seleccionarOrganismoEmitter) {
            this.seleccionarOrganismoEmitter.emit(event);
        }
        if (this.popoverController) {
            this.popoverController.dismiss({
                item: this.descripcion,
            });
        }
    }
};
ParamOrganismosCertificadoresComponent.ctorParameters = () => [
    { type: _services_apertura_auditoria_service__WEBPACK_IMPORTED_MODULE_2__.AperturaAuditoriaService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.PopoverController }
];
ParamOrganismosCertificadoresComponent.propDecorators = {
    defaultValue: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    seleccionarOrganismoEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output }]
};
ParamOrganismosCertificadoresComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-param-organismos-certificadores',
        template: _param_organismos_certificadores_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_param_organismos_certificadores_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ParamOrganismosCertificadoresComponent);



/***/ }),

/***/ 5813:
/*!*******************************************************************!*\
  !*** ./src/app/components/param-paises/param-paises.component.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ParamPaisesComponent": () => (/* binding */ ParamPaisesComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _param_paises_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./param-paises.component.html?ngResource */ 3041);
/* harmony import */ var _param_paises_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./param-paises.component.scss?ngResource */ 9909);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_interfaces_General_Localizacion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/interfaces/General/Localizacion */ 402);
/* harmony import */ var src_app_services_apertura_auditoria_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/apertura-auditoria.service */ 7583);






let ParamPaisesComponent = class ParamPaisesComponent {
    constructor(aperturaAuditoriaService) {
        this.aperturaAuditoriaService = aperturaAuditoriaService;
        this.currentLocalizacion = new src_app_interfaces_General_Localizacion__WEBPACK_IMPORTED_MODULE_2__.Localizacion();
        this.selectLocalizacionEmit = new _angular_core__WEBPACK_IMPORTED_MODULE_4__.EventEmitter();
    }
    ngOnInit() {
        this.buscarPaisInit(this.defaulValue);
    }
    buscarPais(event) {
        let codigoPais = event.detail.value;
        if (codigoPais.length > 3) {
            console.log("buscamos el pais");
            this.aperturaAuditoriaService.BuscarPais(codigoPais).subscribe((x) => {
                console.log(x);
                this.listaPaises = x.listEntities;
            });
        }
    }
    buscarPaisInit(_pais) {
        this.aperturaAuditoriaService.BuscarPais(_pais).subscribe((x) => {
            this.listaPaises = x.listEntities;
            if (this.listaPaises && this.listaPaises.length > 0)
                this.currentPais = this.listaPaises[0];
        });
    }
    seleccionarPais(event) {
        console.log("seleccionar pais", event);
        this.currentPais = event.detail.value;
        this.buscarEstados(event.detail.value.idPais);
    }
    buscarEstados(IdPais) {
        console.log("buscamos el estado");
        this.aperturaAuditoriaService.BuscarEstado(IdPais).subscribe((x) => {
            console.log(x);
            this.listaEstados = x.listEntities;
        });
    }
    seleccionarEstado(event) {
        console.log("Estado Seleccionado", event);
        this.currentEstado = event.detail.value;
        this.buscarCiudad(event.detail.value.idEstado);
    }
    buscarCiudad(iDEstado) {
        this.aperturaAuditoriaService.BuscarCiudad(iDEstado).subscribe((x) => {
            console.log(x);
            this.listaCiudades = x.listEntities;
        });
    }
    seleccionarCiudad(event) {
        this.currentCiudad = event.detail.value;
        this.currentLocalizacion.ciudad = this.currentCiudad;
        this.currentLocalizacion.estado = this.currentEstado;
        this.currentLocalizacion.pais = this.currentPais;
        if (this.selectLocalizacionEmit) {
            this.selectLocalizacionEmit.emit(this.currentLocalizacion);
        }
    }
};
ParamPaisesComponent.ctorParameters = () => [
    { type: src_app_services_apertura_auditoria_service__WEBPACK_IMPORTED_MODULE_3__.AperturaAuditoriaService }
];
ParamPaisesComponent.propDecorators = {
    defaulValue: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Input }],
    selectLocalizacionEmit: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.Output }]
};
ParamPaisesComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: "app-param-paises",
        template: _param_paises_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_param_paises_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ParamPaisesComponent);



/***/ }),

/***/ 7269:
/*!***********************************************************************!*\
  !*** ./src/app/components/plan-auditoria/plan-auditoria.component.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PlanAuditoriaComponent": () => (/* binding */ PlanAuditoriaComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _plan_auditoria_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./plan-auditoria.component.html?ngResource */ 8457);
/* harmony import */ var _plan_auditoria_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./plan-auditoria.component.scss?ngResource */ 2586);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var src_app_services_elaboracion_auditoria_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/elaboracion-auditoria.service */ 1264);








let PlanAuditoriaComponent = class PlanAuditoriaComponent {
    constructor(formBuilder, popoverController, datepipe, elaboracionAuditoriaService) {
        this.formBuilder = formBuilder;
        this.popoverController = popoverController;
        this.datepipe = datepipe;
        this.elaboracionAuditoriaService = elaboracionAuditoriaService;
        this.mode = "TCP";
        this.guardarCronogramaEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
        this.eliminarCronogramaEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
        this.listaDirecciones = [];
        this.DocumentacionReferencia = "Norma NAG E 210 (2005) Sistema de tubería compuesta de acero-Polietileno unidos por termo fusión para conducción de gas natural y gases licuados de petróleo en instalaciones internas.  \n" +
            "Sistema de Gestión conforme a los requisitos del Anexo 1 de la Especificación Esquema 5 para la certificación de productos con Sello IBNORCA. \n" +
            "Reglamento Particular de Producto RP-TCP - 65 \n" +
            "Procedimientos y otra documentación de la organización. \n";
    }
    ngOnInit() {
        this.listaParticipantes = this.currentPlanAuditoriaDTO["listaParticipantes"];
        this.mode = this.currentPlanAuditoriaDTO.area;
        this.currentPlanAuditoriaDTO.pradireccionespaproducto.forEach(x => {
            if (this.listaDirecciones.indexOf(x.direccion) === -1) {
                this.listaDirecciones.push(x.direccion);
            }
        });
        this.currentPlanAuditoriaDTO.pradireccionespasistema.forEach(x => {
            if (x.dias > 0 && this.listaDirecciones.indexOf(x.direccion) === -1) {
                this.listaDirecciones.push(x.direccion);
            }
        });
    }
    guardarCronograma(event) {
        if (this.guardarCronogramaEmitter) {
            this.guardarCronogramaEmitter.emit(event);
        }
    }
    eliminarCronograma(event) {
        if (this.eliminarCronogramaEmitter) {
            this.eliminarCronogramaEmitter.emit(event);
        }
    }
};
PlanAuditoriaComponent.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.PopoverController },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_6__.DatePipe },
    { type: src_app_services_elaboracion_auditoria_service__WEBPACK_IMPORTED_MODULE_2__.ElaboracionAuditoriaService }
];
PlanAuditoriaComponent.propDecorators = {
    currentPlanAuditoriaDTO: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    guardarCronogramaEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output }],
    eliminarCronogramaEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output }],
    listaDirecciones: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }]
};
PlanAuditoriaComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: "app-plan-auditoria",
        template: _plan_auditoria_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_plan_auditoria_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], PlanAuditoriaComponent);



/***/ }),

/***/ 1905:
/*!***********************************************************************!*\
  !*** ./src/app/components/pra-cronograma/pra-cronograma.component.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PraCronogramaComponent": () => (/* binding */ PraCronogramaComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _pra_cronograma_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pra-cronograma.component.html?ngResource */ 174);
/* harmony import */ var _pra_cronograma_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pra-cronograma.component.scss?ngResource */ 2627);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _custom_input_custom_input_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../custom-input/custom-input.component */ 3082);
/* harmony import */ var _param_horarios_param_horarios_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../param-horarios/param-horarios.component */ 833);









let PraCronogramaComponent = class PraCronogramaComponent {
    constructor(popoverController, datepipe, formBuilder) {
        this.popoverController = popoverController;
        this.datepipe = datepipe;
        this.formBuilder = formBuilder;
    }
    ngOnInit() {
        this.cronogramaForm = this.formBuilder.group({});
        console.log('currentPraciclocronogramas', this.currentPraciclocronogramas);
    }
    mostrarMesesProgramado(_event) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const popover = yield this.popoverController.create({
                component: _custom_input_custom_input_component__WEBPACK_IMPORTED_MODULE_2__.CustomInputComponent,
                componentProps: {
                    formGruop: this.cronogramaForm,
                    label: 'Mes Programado',
                    name: 'FechaEjecucion',
                    type: 'datetime',
                    form: 'form',
                    formatDate: 'month',
                    defaultValue: Date(),
                },
                event: _event,
                mode: 'md',
                backdropDismiss: false,
            });
            yield popover.present();
            const info = yield popover.onDidDismiss();
            console.log('Padre', info);
            this.currentPraciclocronogramas.mesProgramado = info.data.item;
        });
    }
    mostrarMesesReprogamado(_event) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const popover = yield this.popoverController.create({
                component: _custom_input_custom_input_component__WEBPACK_IMPORTED_MODULE_2__.CustomInputComponent,
                componentProps: {
                    formGruop: this.cronogramaForm,
                    label: 'Mes Reprogramado',
                    name: 'FechaEjecucion',
                    type: 'datetime',
                    form: 'form',
                    formatDate: 'month',
                    defaultValue: Date(),
                },
                event: _event,
                mode: 'md',
                backdropDismiss: false,
            });
            yield popover.present();
            const info = yield popover.onDidDismiss();
            console.log('Padre', info);
            this.currentPraciclocronogramas.mesReprogramado = info.data.item;
        });
    }
    mostrarFechaEjecucion(_event) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const popover = yield this.popoverController.create({
                component: _custom_input_custom_input_component__WEBPACK_IMPORTED_MODULE_2__.CustomInputComponent,
                componentProps: {
                    formGruop: this.cronogramaForm,
                    label: 'Fecha Eejcucion',
                    name: 'FechaEjecucion',
                    type: 'datetime',
                    form: 'form',
                    defaultValue: Date(),
                },
                event: _event,
                mode: 'md',
                backdropDismiss: false,
            });
            yield popover.present();
            const info = yield popover.onDidDismiss();
            console.log('Padre', info);
            this.currentPraciclocronogramas.fechaInicioDeEjecucionDeAuditoria =
                info.data.item;
        });
    }
    mostrarFechaFin(_event) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const popover = yield this.popoverController.create({
                component: _custom_input_custom_input_component__WEBPACK_IMPORTED_MODULE_2__.CustomInputComponent,
                componentProps: {
                    formGruop: this.cronogramaForm,
                    label: 'Fecha Fin Eejcucion',
                    name: 'FechaEjecucion',
                    type: 'datetime',
                    form: 'form',
                    defaultValue: Date(),
                },
                event: _event,
                mode: 'md',
                backdropDismiss: false,
                size: 'auto',
            });
            yield popover.present();
            const info = yield popover.onDidDismiss();
            console.log('Padre', info);
            this.currentPraciclocronogramas.fechaDeFinDeEjecucionAuditoria =
                info.data.item;
        });
    }
    mostrarDiasInsituCronograma(_event) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const popover = yield this.popoverController.create({
                component: _custom_input_custom_input_component__WEBPACK_IMPORTED_MODULE_2__.CustomInputComponent,
                componentProps: {
                    formGruop: this.cronogramaForm,
                    label: 'CANTIDAD DE DIAS',
                    name: 'cantidad_dias',
                    type: 'number',
                    form: 'form',
                    defaultValue: Date(),
                },
                event: _event,
                mode: 'md',
                backdropDismiss: false,
            });
            yield popover.present();
            const info = yield popover.onDidDismiss();
            console.log('Padre', info);
            this.currentPraciclocronogramas.diasInsitu = info.data.item;
        });
    }
    mostrarDiasRemotoCronograma(_event) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const popover = yield this.popoverController.create({
                component: _custom_input_custom_input_component__WEBPACK_IMPORTED_MODULE_2__.CustomInputComponent,
                componentProps: {
                    formGruop: this.cronogramaForm,
                    label: 'CANTIDAD DE DIAS',
                    name: 'cantidad_dias',
                    type: 'number',
                    form: 'form',
                    defaultValue: Date(),
                },
                event: _event,
                mode: 'md',
                backdropDismiss: false,
            });
            yield popover.present();
            const info = yield popover.onDidDismiss();
            console.log('Padre', info);
            this.currentPraciclocronogramas.diasRemoto = info.data.item;
        });
    }
    mostrarHorarioCronograma(_event) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const popover = yield this.popoverController.create({
                component: _param_horarios_param_horarios_component__WEBPACK_IMPORTED_MODULE_3__.ParamHorariosComponent,
                componentProps: {
                    horario: this.currentPraciclocronogramas.horarioTrabajo,
                },
                event: _event,
                mode: 'md',
                backdropDismiss: false,
            });
            yield popover.present();
            const info = yield popover.onDidDismiss();
            console.log('Padre', info);
            this.currentPraciclocronogramas.horarioTrabajo = info.data.item;
        });
    }
};
PraCronogramaComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.PopoverController },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_6__.DatePipe },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormBuilder }
];
PraCronogramaComponent.propDecorators = {
    currentPraciclocronogramas: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.Input }]
};
PraCronogramaComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-pra-cronograma',
        template: _pra_cronograma_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_pra_cronograma_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], PraCronogramaComponent);



/***/ }),

/***/ 1876:
/*!*************************************************************************************!*\
  !*** ./src/app/components/pra-direccion-sistema/pra-direccion-sistema.component.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PraDireccionSistemaComponent": () => (/* binding */ PraDireccionSistemaComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _pra_direccion_sistema_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pra-direccion-sistema.component.html?ngResource */ 1183);
/* harmony import */ var _pra_direccion_sistema_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pra-direccion-sistema.component.scss?ngResource */ 4346);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var src_app_interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/interfaces/cross-ui/ConvertFormToObject */ 9788);







let PraDireccionSistemaComponent = class PraDireccionSistemaComponent {
    constructor(toastController, formBuilder) {
        this.toastController = toastController;
        this.formBuilder = formBuilder;
        this.showBuscadorNormas = false;
        this.guardarDireccionEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
        this.cancelarDireccionEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
        this.mode = "default-pais";
    }
    ngOnInit() {
        this.ionicForm = this.formBuilder.group({});
    }
    presentToast(mensaje) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: mensaje,
                duration: 2000,
            });
            toast.present();
        });
    }
    guardarDireccion() {
        console.log("Guardar Direcc");
        src_app_interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_2__.ConvertFormToObject.convert(this.ionicForm, this.pradireccionespasistema);
        this.presentToast("Dirección guardada correctamente").then((resul) => {
            if (this.guardarDireccionEmitter) {
                this.guardarDireccionEmitter.emit(this.pradireccionespasistema);
            }
        });
    }
    cancelar() {
        console.log("Cancelar Direcc");
        if (this.cancelarDireccionEmitter) {
            this.cancelarDireccionEmitter.emit(this.pradireccionespasistema);
        }
    }
    cambiarModoPais() {
        this.mode = "edit-pais";
    }
    localizacionSeleccionda(localizacion) {
        src_app_interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_2__.ConvertFormToObject.convert(this.ionicForm, this.pradireccionespasistema);
        this.pradireccionespasistema.pais = localizacion.pais.paisNombre;
        this.pradireccionespasistema.departamento = localizacion.estado.estNombre;
        this.pradireccionespasistema.ciudad = localizacion.ciudad.nomCiudad;
        src_app_interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_2__.ConvertObjectToForm.convert(this.ionicForm, this.pradireccionespasistema);
        this.mode = "default-pais";
    }
};
PraDireccionSistemaComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ToastController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder }
];
PraDireccionSistemaComponent.propDecorators = {
    pradireccionespasistema: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    guardarDireccionEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output }],
    cancelarDireccionEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output }]
};
PraDireccionSistemaComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: "app-pra-direccion-sistema",
        template: _pra_direccion_sistema_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_pra_direccion_sistema_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], PraDireccionSistemaComponent);



/***/ }),

/***/ 1250:
/*!***************************************************************************************!*\
  !*** ./src/app/components/pra-edit-norma-sistema/pra-edit-norma-sistema.component.ts ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PraEditNormaSistemaComponent": () => (/* binding */ PraEditNormaSistemaComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _pra_edit_norma_sistema_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pra-edit-norma-sistema.component.html?ngResource */ 536);
/* harmony import */ var _pra_edit_norma_sistema_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pra-edit-norma-sistema.component.scss?ngResource */ 9937);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var src_app_interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/interfaces/cross-ui/ConvertFormToObject */ 9788);







let PraEditNormaSistemaComponent = class PraEditNormaSistemaComponent {
    constructor(toastController, formBuilder) {
        this.toastController = toastController;
        this.formBuilder = formBuilder;
        this.showBuscadorNormas = false;
        this.guardarNormaEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
        this.cancelarNormaEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
    }
    ngOnInit() {
        this.ionicForm = this.formBuilder.group({});
    }
    guardarNorma() {
        src_app_interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_2__.ConvertFormToObject.convert(this.ionicForm, this.praciclonormassistema);
        this.presentToast("Norma guardada correctamente").then((resul) => {
            if (this.guardarNormaEmitter) {
                this.guardarNormaEmitter.emit(this.praciclonormassistema);
            }
        });
    }
    cancelarNorma() {
        if (this.cancelarNormaEmitter) {
            this.cancelarNormaEmitter.emit(this.praciclonormassistema);
        }
    }
    mostrarBuscadorNorma() {
        console.log("ingreso al evento");
        this.showBuscadorNormas = true;
    }
    cambiarNorma(norma) {
        console.log("cambiarNorma", norma);
        this.praciclonormassistema.norma = norma.codigoNorma;
        this.showBuscadorNormas = false;
    }
    presentToast(mensaje) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: mensaje,
                duration: 2000,
            });
            toast.present();
        });
    }
};
PraEditNormaSistemaComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ToastController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder }
];
PraEditNormaSistemaComponent.propDecorators = {
    praciclonormassistema: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    guardarNormaEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output }],
    cancelarNormaEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output }]
};
PraEditNormaSistemaComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: "app-pra-edit-norma-sistema",
        template: _pra_edit_norma_sistema_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_pra_edit_norma_sistema_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], PraEditNormaSistemaComponent);



/***/ }),

/***/ 2612:
/*!***********************************************************************!*\
  !*** ./src/app/components/product-detail/product-detail.component.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductDetailComponent": () => (/* binding */ ProductDetailComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _product_detail_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./product-detail.component.html?ngResource */ 3824);
/* harmony import */ var _product_detail_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./product-detail.component.scss?ngResource */ 3997);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var src_app_interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/interfaces/cross-ui/ConvertFormToObject */ 9788);







let ProductDetailComponent = class ProductDetailComponent {
    constructor(toastController, formBuilder) {
        this.toastController = toastController;
        this.formBuilder = formBuilder;
        this.showBuscadorNormas = false;
        this.guardarProductEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
        this.cancelarProductEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
        this.mode = "default-pais";
    }
    ngOnInit() {
        this.ionicForm = this.formBuilder.group({});
    }
    guardarProduct() {
        src_app_interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_2__.ConvertFormToObject.convert(this.ionicForm, this.pradireccionespaproducto);
        this.presentToast("Producto guardado correctamente").then((resul) => {
            if (this.guardarProductEmitter) {
                this.guardarProductEmitter.emit(this.pradireccionespaproducto);
            }
        });
    }
    presentToast(mensaje) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: mensaje,
                duration: 2000,
            });
            toast.present();
        });
    }
    cambiarNorma(norma) {
        console.log("cambiarNorma", norma);
        this.pradireccionespaproducto.norma = norma.codigoNorma;
        this.showBuscadorNormas = false;
    }
    mostrarBuscadorNorma() {
        console.log("ingreso al evento");
        this.showBuscadorNormas = true;
    }
    cancelar() {
        this.showBuscadorNormas = false;
        if (this.cancelarProductEmitter) {
            this.cancelarProductEmitter.emit(this.pradireccionespaproducto);
        }
    }
    cambiarModoPais() {
        this.mode = "edit-pais";
    }
    localizacionSeleccionda(localizacion) {
        src_app_interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_2__.ConvertFormToObject.convert(this.ionicForm, this.pradireccionespaproducto);
        this.pradireccionespaproducto.pais = localizacion.pais.paisNombre;
        this.pradireccionespaproducto.estado = localizacion.estado.estNombre;
        this.pradireccionespaproducto.ciudad = localizacion.ciudad.nomCiudad;
        src_app_interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_2__.ConvertObjectToForm.convert(this.ionicForm, this.pradireccionespaproducto);
        this.mode = "default-pais";
    }
};
ProductDetailComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ToastController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder }
];
ProductDetailComponent.propDecorators = {
    pradireccionespaproducto: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    guardarProductEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output }],
    cancelarProductEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output }]
};
ProductDetailComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: "app-product-detail",
        template: _product_detail_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_product_detail_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ProductDetailComponent);



/***/ }),

/***/ 8112:
/*!***********************************************************************!*\
  !*** ./src/app/components/registro-ciclo/registro-ciclo.component.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegistroCicloComponent": () => (/* binding */ RegistroCicloComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _registro_ciclo_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./registro-ciclo.component.html?ngResource */ 8391);
/* harmony import */ var _registro_ciclo_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./registro-ciclo.component.scss?ngResource */ 3050);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 587);





let RegistroCicloComponent = class RegistroCicloComponent {
    constructor(formBuilder) {
        this.formBuilder = formBuilder;
    }
    ngOnInit() {
        this.ionicForm = this.formBuilder.group({});
    }
    guardarCiclo() {
        console.log("ciclo guardado correctamente");
    }
    cancelar() {
        console.log("cancelamdo");
    }
};
RegistroCicloComponent.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormBuilder }
];
RegistroCicloComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-registro-ciclo',
        template: _registro_ciclo_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_registro_ciclo_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], RegistroCicloComponent);



/***/ }),

/***/ 9166:
/*!*****************************************************************************!*\
  !*** ./src/app/components/tcp-list-products/tcp-list-products.component.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TcpListProductsComponent": () => (/* binding */ TcpListProductsComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _tcp_list_products_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tcp-list-products.component.html?ngResource */ 7976);
/* harmony import */ var _tcp_list_products_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tcp-list-products.component.scss?ngResource */ 7719);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var src_app_interfaces_apertura_auditoria_Praprogramasdeauditorium__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/interfaces/apertura_auditoria/Praprogramasdeauditorium */ 3996);







let TcpListProductsComponent = class TcpListProductsComponent {
    constructor(popoverController, formBuilder, modalController) {
        this.popoverController = popoverController;
        this.formBuilder = formBuilder;
        this.modalController = modalController;
        this.productList = [];
        this.addCronograma = false;
        this.allowDelete = true;
        this.guardarCronogramaEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
        this.eliminarCronogramaEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
        this.mode = "LIST";
        this.operacion = "";
        this.currentIndex = -1;
        this.display = false;
    }
    ngOnInit() { }
    toggle() {
        this.display = !this.display;
    }
    editar(product, i) {
        this.mode = "EDIT";
        this.operacion = "UPD";
        this.currentProduct = product;
        this.currentIndex = i;
    }
    eliminar(index) {
        console.log("evento eliminar", index);
        this.productList.splice(index, 1);
    }
    adicionar() {
        this.mode = "EDIT";
        this.operacion = "ADD";
        this.currentProduct = new src_app_interfaces_apertura_auditoria_Praprogramasdeauditorium__WEBPACK_IMPORTED_MODULE_2__.Pradireccionespaproducto();
    }
    guardarProducto(event) {
        this.mode = "LIST";
        if (this.operacion === "UPD")
            this.productList[this.currentIndex] = event;
        else
            this.productList.push(event);
    }
    guardarCronograma(event) {
        if (this.guardarCronogramaEmitter) {
            this.guardarCronogramaEmitter.emit(event);
        }
    }
    cancelarProducto(event) {
        this.mode = "LIST";
    }
    getLlaves(producto) {
        let llave = {
            idDireccionPaproducto: producto.idDireccionPaproducto,
            idDireccionPasistema: null,
        };
        return llave;
    }
    eliminarCronograma(event) {
        if (this.eliminarCronogramaEmitter) {
            this.eliminarCronogramaEmitter.emit(event);
        }
    }
};
TcpListProductsComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.PopoverController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormBuilder },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController }
];
TcpListProductsComponent.propDecorators = {
    productList: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    nombreOrganizacion: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    addCronograma: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    listaParticipantes: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    allowDelete: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    guardarCronogramaEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output }],
    eliminarCronogramaEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output }]
};
TcpListProductsComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: "app-tcp-list-products",
        template: _tcp_list_products_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_tcp_list_products_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], TcpListProductsComponent);



/***/ }),

/***/ 3678:
/*!***************************************************************************!*\
  !*** ./src/app/components/tcs-list-systems/tcs-list-systems.component.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TcsListSystemsComponent": () => (/* binding */ TcsListSystemsComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _tcs_list_systems_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tcs-list-systems.component.html?ngResource */ 8131);
/* harmony import */ var _tcs_list_systems_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tcs-list-systems.component.scss?ngResource */ 5656);
/* harmony import */ var _interfaces_apertura_auditoria_Praprogramasdeauditorium__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../interfaces/apertura_auditoria/Praprogramasdeauditorium */ 3996);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);







let TcsListSystemsComponent = class TcsListSystemsComponent {
    constructor(popoverController, formBuilder) {
        this.popoverController = popoverController;
        this.formBuilder = formBuilder;
        this.mode = "list";
        this.currentIndex = -1;
        this.currentIndexNorma = -1;
        //currentDireccion: Pradireccionespasistema;
        this.operacion = "";
        this.direccionesSistema = [];
        this.normasSistema = [];
        this.allowHorario = false;
        this.allowDelete = true;
        this.isAuditor = false;
        this.guardarCronogramaEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
        this.eliminarCronogramaEmitter = new _angular_core__WEBPACK_IMPORTED_MODULE_3__.EventEmitter();
        this.addCronograma = false;
        this.display = false;
    }
    ngOnInit() {
        this.ionicForm = this.formBuilder.group({});
    }
    toggle() {
        console.log("se expande");
        this.display = !this.display;
    }
    guardarDireccion(event) {
        this.mode = "list";
        console.log("guardar direccion");
        if (this.operacion === "UPD")
            this.direccionesSistema[this.currentIndex] = event;
        else
            this.direccionesSistema.push(event);
    }
    cancelarDireccion(event) {
        this.mode = "list";
    }
    editarDireccion(item, i) {
        console.log("item", item);
        this.mode = "EDIT";
        this.operacion = "UPD";
        this.currentdireccionesSistema = item;
        this.currentIndex = i;
    }
    editarHorario(item, i) {
        this.mode = "EDIT_HORARIO";
        this.operacion = "UPD";
    }
    eliminarDireccion(index) {
        console.log("evento eliminar", index);
        this.direccionesSistema.splice(index, 1);
    }
    adicionarDireccion() {
        this.mode = "EDIT";
        this.operacion = "ADD";
        this.currentdireccionesSistema = new _interfaces_apertura_auditoria_Praprogramasdeauditorium__WEBPACK_IMPORTED_MODULE_2__.Pradireccionespasistema();
        this.currentdireccionesSistema.pais = "Bolivia";
    }
    adicionarNorma() {
        this.mode = "EDIT1";
        this.operacion = "ADD";
        this.currentnormaSistema = new _interfaces_apertura_auditoria_Praprogramasdeauditorium__WEBPACK_IMPORTED_MODULE_2__.Praciclonormassistema();
        //this.currentnormaSistema.pais = "Bolivia";
    }
    editarNorma(item, i) {
        console.log("editar norma", item);
        this.mode = "EDIT1";
        this.operacion = "UPD";
        this.currentnormaSistema = item;
        this.currentIndexNorma = i;
    }
    cancelarNorma(event) {
        this.mode = "list";
    }
    guardarNorma(event) {
        this.mode = "list";
        console.log("guardar norma");
        if (this.operacion === "UPD")
            this.normasSistema[this.currentIndex] = event;
        else
            this.normasSistema.push(event);
    }
    eliminarNorma(index) {
        console.log("evento eliminar norma", index);
        this.normasSistema.splice(index, 1);
    }
    cancelarCronograma(event) {
        this.mode = "list";
    }
    guardarCronograma(event) {
        this.mode = "list";
        if (this.guardarCronogramaEmitter) {
            this.guardarCronogramaEmitter.emit(event);
        }
    }
    eliminarCronograma(event) {
        if (this.eliminarCronogramaEmitter) {
            this.eliminarCronogramaEmitter.emit(event);
        }
    }
    getLlaves(sistema) {
        let llave = {
            idDireccionPaproducto: null,
            idDireccionPasistema: sistema.idDireccionPasistema,
        };
        return llave;
    }
};
TcsListSystemsComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.PopoverController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormBuilder }
];
TcsListSystemsComponent.propDecorators = {
    nombreOrganizacion: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    direccionesSistema: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    normasSistema: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    allowHorario: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    allowDelete: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    isAuditor: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    listaParticipantes: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    guardarCronogramaEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output }],
    eliminarCronogramaEmitter: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Output }],
    addCronograma: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }]
};
TcsListSystemsComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: "app-tcs-list-systems",
        template: _tcs_list_systems_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_tcs_list_systems_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], TcsListSystemsComponent);



/***/ }),

/***/ 4211:
/*!*************************************************************************************************************************!*\
  !*** ./src/app/components/tcs-lista-verificacion-reunion-apertura/tcs-lista-verificacion-reunion-apertura.component.ts ***!
  \*************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TcsListaVerificacionReunionAperturaComponent": () => (/* binding */ TcsListaVerificacionReunionAperturaComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _tcs_lista_verificacion_reunion_apertura_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tcs-lista-verificacion-reunion-apertura.component.html?ngResource */ 6269);
/* harmony import */ var _tcs_lista_verificacion_reunion_apertura_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tcs-lista-verificacion-reunion-apertura.component.scss?ngResource */ 9431);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_services_elaboracion_auditoria_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/elaboracion-auditoria.service */ 1264);



/* eslint-disable max-len */


let TcsListaVerificacionReunionAperturaComponent = class TcsListaVerificacionReunionAperturaComponent {
    constructor(elaboracionAuditoriaService) {
        this.elaboracionAuditoriaService = elaboracionAuditoriaService;
        this.checkBoxList = [
            {
                item: '1.',
                value: 'Presentación del equipo auditor, incluyendo una breve descripción de funciones.',
                isChecked: false,
            },
            {
                item: '2.',
                value: 'Confirmación del idioma que se utilizará durante la auditoría.',
                isChecked: false,
            },
            {
                item: '3.',
                value: 'Confirmación de los temas relativos a la confidencialidad.',
                isChecked: false,
            },
            {
                item: '4.',
                value: 'Confirmación del alcance y objetivos de la auditoría, norma auditada.',
                isChecked: false,
            },
            {
                item: '5.',
                value: 'Confirmación del plan de auditoría (incluye tipo y alcance de auditoría los objetivos y los criterios), cualquier cambio, y otros acuerdos pertinentes con el cliente.',
                isChecked: false,
            },
            {
                item: '6.',
                value: 'Confirmación de los canales comunicación formal.',
                isChecked: false,
            },
            {
                item: '7.',
                value: 'Confirmación del estado de los hallazgos de la revisión o auditoría anterior cuando corresponda.',
                isChecked: false,
            },
            {
                item: '8.',
                value: 'Confirmación de la disponibilidad, de las funciones y de la identidad de los guías y observadores.',
                isChecked: false,
            },
            {
                item: '9.',
                value: 'El método para presentar la información, incluyendo cualquier categorización de los hallazgos de la auditoría.',
                isChecked: false,
            },
            {
                item: '10 .',
                value: 'Información sobre las condiciones bajo las cuales la auditoría puede darse por terminada prematuramente.',
                isChecked: false,
            },
            {
                item: '11.',
                value: 'Confirmación que durante la auditoría se mantendrá informada a la organización sobre el proceso de la auditoría y cualquier problema.',
                isChecked: false,
            },
            {
                item: '12.',
                value: 'Confirmación de que el líder y los miembros del equipo auditor, que representan a IBNORCA, son responsables de la auditoría y que deben controlar la ejecución del plan de auditoría, incluyendo las actividades y las líneas de investigación de la auditoría.',
                isChecked: false,
            },
            {
                item: '13.',
                value: 'Los métodos y procedimientos a utilizar para llevar a cabo la auditoría sobre la base de un muestreo.',
                isChecked: false,
            },
            {
                item: '14.',
                value: 'Confirmación de que están disponibles los recursos y la logística necesaria para el equipo auditor.',
                isChecked: false,
            },
            {
                item: '15.',
                value: 'Confirmación de los procedimientos de protección, emergencia y seguridad en el trabajo pertinentes para el equipo auditor.',
                isChecked: false,
            },
            {
                item: '16.',
                value: 'Confirmación de las TICs a aplicar y su disponibilidad.',
                isChecked: false,
            },
            { item: '17.', value: 'Aclaraciones.', isChecked: false },
        ];
    }
    ngOnInit() {
        this.elaboracionAuditoriaService
            .GetListasVerificacion(1)
            .subscribe((resul) => {
            this.pParamitemselect = resul.listEntities;
        });
    }
    checkMaster() {
        setTimeout(() => {
            this.checkBoxList.forEach((obj) => {
                obj.isChecked = this.masterCheck;
            });
        });
    }
    checkEvent() {
        const totalItems = this.checkBoxList.length;
        let checked = 0;
        this.checkBoxList.map((obj) => {
            if (obj.isChecked) {
                checked++;
            }
        });
        if (checked > 0 && checked < totalItems) {
            //If even one item is checked but not all
            this.isIndeterminate = true;
            this.masterCheck = false;
        }
        else if (checked === totalItems) {
            //If all are checked
            this.masterCheck = true;
            this.isIndeterminate = false;
        }
        else {
            //If none is checked
            this.isIndeterminate = false;
            this.masterCheck = false;
        }
    }
};
TcsListaVerificacionReunionAperturaComponent.ctorParameters = () => [
    { type: src_app_services_elaboracion_auditoria_service__WEBPACK_IMPORTED_MODULE_2__.ElaboracionAuditoriaService }
];
TcsListaVerificacionReunionAperturaComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-tcs-lista-verificacion-reunion-apertura',
        template: _tcs_lista_verificacion_reunion_apertura_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_tcs_lista_verificacion_reunion_apertura_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], TcsListaVerificacionReunionAperturaComponent);



/***/ }),

/***/ 2150:
/*!*********************************************************************************************************************!*\
  !*** ./src/app/components/tcs-lista-verificacion-reunion-cierre/tcs-lista-verificacion-reunion-cierre.component.ts ***!
  \*********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TcsListaVerificacionReunionCierreComponent": () => (/* binding */ TcsListaVerificacionReunionCierreComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _tcs_lista_verificacion_reunion_cierre_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tcs-lista-verificacion-reunion-cierre.component.html?ngResource */ 1945);
/* harmony import */ var _tcs_lista_verificacion_reunion_cierre_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tcs-lista-verificacion-reunion-cierre.component.scss?ngResource */ 1295);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_services_elaboracion_auditoria_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/elaboracion-auditoria.service */ 1264);





let TcsListaVerificacionReunionCierreComponent = class TcsListaVerificacionReunionCierreComponent {
    constructor(elaboracionAuditoriaService) {
        this.elaboracionAuditoriaService = elaboracionAuditoriaService;
        this.checkBoxList = [
            { item: '1.', value: 'Agradecimiento.', isChecked: false },
            {
                item: '2.',
                value: 'Confirmación del alcance y objetivos de la auditoría, alcance de la certificación y norma auditada.',
                isChecked: false,
            },
            {
                item: '3.',
                value: 'Informar que las evidencias de auditoría reunidas se basan en un muestreo por lo tanto se introduce un elemento de incertidumbre.',
                isChecked: false,
            },
            {
                item: '4.',
                value: 'Lectura y hallazgos de auditoría indicando su categorización .',
                isChecked: false,
            },
            {
                item: '5.',
                value: 'Lectura de conclusión de auditoría.',
                isChecked: false,
            },
            {
                item: '6.',
                value: 
                // eslint-disable-next-line max-len
                'Informar sobre el plazo máximo de 15 días calendario a partir de la culminación de la auditoría para él envió de las correcciones y acciones correctivas al auditor líder de las No conformidades menores y/o mayores identificadas para posterior aprobación por el auditor líder. En el caso de no conformidades mayores la organización debe de enviar las evidencias en un plazo de 90 días calendario a partir de la auditoría, para posterior aprobación por el auditor líder.',
                isChecked: false,
            },
            {
                item: '7.',
                value: 'Fecha estimada de la próxima auditoría.',
                isChecked: false,
            },
            {
                item: '8.',
                value: 'Informar acerca de los procesos que tienen IBNORCA, para el tratamiento de quejas y de apelaciones.',
                isChecked: false,
            },
            { item: '9.', value: 'Aclaraciones.', isChecked: false },
            {
                item: '10 .',
                value: 'Firma del informe de auditoría.',
                isChecked: false,
            },
            {
                item: '11.',
                value: 'Revisión del alcance en el informe y el formulario de Datos de la organización.',
                isChecked: false,
            },
        ];
    }
    ngOnInit() {
        this.elaboracionAuditoriaService
            .GetListasVerificacion(2)
            .subscribe((resul) => {
            this.pParamitemselect = resul.listEntities;
        });
    }
    checkMaster() {
        setTimeout(() => {
            this.checkBoxList.forEach((obj) => {
                obj.isChecked = this.masterCheck;
            });
        });
    }
    checkEvent() {
        const totalItems = this.checkBoxList.length;
        let checked = 0;
        this.checkBoxList.map((obj) => {
            if (obj.isChecked) {
                checked++;
            }
        });
        if (checked > 0 && checked < totalItems) {
            //If even one item is checked but not all
            this.isIndeterminate = true;
            this.masterCheck = false;
        }
        else if (checked === totalItems) {
            //If all are checked
            this.masterCheck = true;
            this.isIndeterminate = false;
        }
        else {
            //If none is checked
            this.isIndeterminate = false;
            this.masterCheck = false;
        }
    }
};
TcsListaVerificacionReunionCierreComponent.ctorParameters = () => [
    { type: src_app_services_elaboracion_auditoria_service__WEBPACK_IMPORTED_MODULE_2__.ElaboracionAuditoriaService }
];
TcsListaVerificacionReunionCierreComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-tcs-lista-verificacion-reunion-cierre',
        template: _tcs_lista_verificacion_reunion_cierre_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_tcs_lista_verificacion_reunion_cierre_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], TcsListaVerificacionReunionCierreComponent);



/***/ }),

/***/ 1850:
/*!*************************************************************************!*\
  !*** ./src/app/components/tm-acta-reunion/tm-acta-reunion.component.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TmActaReunionComponent": () => (/* binding */ TmActaReunionComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _tm_acta_reunion_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tm-acta-reunion.component.html?ngResource */ 3767);
/* harmony import */ var _tm_acta_reunion_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tm-acta-reunion.component.scss?ngResource */ 5030);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 587);






let TmActaReunionComponent = class TmActaReunionComponent {
    constructor(datepipe, formBuilder) {
        this.datepipe = datepipe;
        this.formBuilder = formBuilder;
        this.consideracion = "";
        this.revison = "";
        this.varios = "";
        this.fecha = this.datepipe.transform(new Date(), "dd/MM/yyyy");
        this.reglamentos = [
            {
                nombre: "Reglamento particular de Cemento",
                norma_base: "ASTM C 150",
                descripcion: "xxxxxxxxxxxxxxxxxxxxxxxx xxxxxxxxxxxxx xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
                decision: "Aprobado",
            },
            {
                nombre: "Reglamento particular de Cemento",
                norma_base: "ASTM C 150",
                descripcion: "xxxxxxxxxxxxxxxxxxxxxxxx xxxxxxxxxxxxx xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
                decision: "Aprobado",
            },
            {
                nombre: "Reglamento particular de Cemento",
                norma_base: "ASTM C 150",
                descripcion: "xxxxxxxxxxxxxxxxxxxxxxxx xxxxxxxxxxxxx xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
                decision: "Aprobado",
            },
        ];
        this.productos = [
            {
                proceso: "RENOVACIÓN ",
                empresa: "113 A",
                producto: "Agua de mesa no carbonatada (sin gas) marca 1  ",
                norma: "NB 325002:2004",
                desc_revision: "ZZZZZZZZZZZZZZZZZZZZZZZZ ZZZZZZZZZZZ",
                confirmacion: "SI",
                recomendacion: "Positiva/Negativa/Pendiente",
            },
            {
                proceso: "RENOVACIÓN ",
                empresa: "113 A",
                producto: "Agua de mesa no carbonatada (sin gas) marca 1  ",
                norma: "NB 325002:2004",
                desc_revision: "ZZZZZZZZZZZZZZZZZZZZZZZZ ZZZZZZZZZZZ",
                confirmacion: "SI",
                recomendacion: "Positiva/Negativa/Pendiente",
            },
            {
                proceso: "RENOVACIÓN ",
                empresa: "113 A",
                producto: "Agua de mesa no carbonatada (sin gas) marca 1  ",
                norma: "NB 325002:2004",
                desc_revision: "ZZZZZZZZZZZZZZZZZZZZZZZZ ZZZZZZZZZZZ",
                confirmacion: "SI",
                recomendacion: "Positiva/Negativa/Pendiente",
            },
        ];
        this.lConsideracione = [
            "Se realizó la lectura del acta anterior para considerar los temas pendientes en la reunión del día de hoy",
            "No se tienen pendientes de la reunión anterior.",
        ];
        this.lRevision = [
            "N/A",
            "Se realizó la revisión y la toma de decisión respecto a los siguientes reglamentos particulares:",
        ];
        this.lVarios = [
            "N/A",
            "Describir los criterios y comentarios más importantes, vertidos a cerca de otros temas de interés del Área de Certificación de Producto, por los miembros del CONCER y/o auditores",
        ];
    }
    seleccionarConsideraciones(event) {
        this.consideracion = event.detail.value;
    }
    seleccionarRevision(event) {
        this.revison = event.detail.value;
    }
    seleccionarVarios(event) {
        this.varios = event.detail.value;
    }
    ngOnInit() {
        this.ionicForm = this.formBuilder.group({});
    }
};
TmActaReunionComponent.ctorParameters = () => [
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_2__.DatePipe },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormBuilder }
];
TmActaReunionComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: "app-tm-acta-reunion",
        template: _tm_acta_reunion_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_tm_acta_reunion_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], TmActaReunionComponent);



/***/ }),

/***/ 402:
/*!****************************************************!*\
  !*** ./src/app/interfaces/General/Localizacion.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Localizacion": () => (/* binding */ Localizacion)
/* harmony export */ });
class Localizacion {
}


/***/ }),

/***/ 3996:
/*!***************************************************************************!*\
  !*** ./src/app/interfaces/apertura_auditoria/Praprogramasdeauditorium.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Praprogramasdeauditorium": () => (/* binding */ Praprogramasdeauditorium),
/* harmony export */   "Praciclosprogauditorium": () => (/* binding */ Praciclosprogauditorium),
/* harmony export */   "Praciclocronograma": () => (/* binding */ Praciclocronograma),
/* harmony export */   "Praciclonormassistema": () => (/* binding */ Praciclonormassistema),
/* harmony export */   "Pracicloparticipante": () => (/* binding */ Pracicloparticipante),
/* harmony export */   "Pradireccionespaproducto": () => (/* binding */ Pradireccionespaproducto),
/* harmony export */   "Pradireccionespasistema": () => (/* binding */ Pradireccionespasistema)
/* harmony export */ });
class Praprogramasdeauditorium {
}
class Praciclosprogauditorium {
}
class Praciclocronograma {
}
class Praciclonormassistema {
}
class Pracicloparticipante {
}
class Pradireccionespaproducto {
}
class Pradireccionespasistema {
}


/***/ }),

/***/ 9788:
/*!************************************************************!*\
  !*** ./src/app/interfaces/cross-ui/ConvertFormToObject.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConvertFormToObject": () => (/* binding */ ConvertFormToObject),
/* harmony export */   "ConvertObjectToForm": () => (/* binding */ ConvertObjectToForm)
/* harmony export */ });
class ConvertFormToObject {
    static convert(formGroup, customObject) {
        for (const prop in formGroup.controls) {
            customObject[prop] = formGroup.controls[prop]["valueDate"]
                ? formGroup.controls[prop]["valueDate"]
                : formGroup.controls[prop].value;
        }
    }
}
class ConvertObjectToForm {
    static convert(formGroup, customObject) {
        for (const prop in formGroup.controls) {
            if (customObject[prop] instanceof Date) {
                formGroup.controls[prop]["valueDate"] = customObject[prop];
            }
            else {
                formGroup.controls[prop].setValue(customObject[prop]);
            }
        }
    }
}


/***/ }),

/***/ 7522:
/*!**********************************************************************!*\
  !*** ./src/app/interfaces/elaboracion_auditoria/PlanAuditoriaDTO.ts ***!
  \**********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PlanAuditoriaDTO": () => (/* binding */ PlanAuditoriaDTO),
/* harmony export */   "Designacion": () => (/* binding */ Designacion),
/* harmony export */   "Elaauditorium": () => (/* binding */ Elaauditorium),
/* harmony export */   "Elaadp": () => (/* binding */ Elaadp),
/* harmony export */   "Elacontenidoauditorium": () => (/* binding */ Elacontenidoauditorium),
/* harmony export */   "Elahallazgo": () => (/* binding */ Elahallazgo),
/* harmony export */   "Elacronogama": () => (/* binding */ Elacronogama)
/* harmony export */ });
class PlanAuditoriaDTO {
}
class Designacion {
}
class Elaauditorium {
}
class Elaadp {
}
class Elacontenidoauditorium {
}
class Elahallazgo {
}
class Elacronogama {
}


/***/ }),

/***/ 6598:
/*!*************************************************!*\
  !*** ./src/app/interfaces/seguridad/usuario.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "usuario": () => (/* binding */ usuario)
/* harmony export */ });
class usuario {
}
usuario.currentUser = {
    nombre: "RUBEN",
    apellidos: "CHALCO",
    oficina: "LA PAZ",
    nick: "ruben.chalco",
};


/***/ }),

/***/ 2281:
/*!**************************************************************************!*\
  !*** ./src/app/interfaces/toma_decisiones/tmddocumentacionauditorium.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tmddocumentacionauditorium": () => (/* binding */ Tmddocumentacionauditorium)
/* harmony export */ });
class Tmddocumentacionauditorium {
}


/***/ }),

/***/ 7583:
/*!********************************************************!*\
  !*** ./src/app/services/apertura-auditoria.service.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AperturaAuditoriaService": () => (/* binding */ AperturaAuditoriaService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ 8784);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 2340);
/* harmony import */ var _baseService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./baseService */ 6306);
/* harmony import */ var _database_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./database.service */ 4382);
/* harmony import */ var _interfaces_seguridad_usuario__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../interfaces/seguridad/usuario */ 6598);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 2378);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 4661);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 7418);










const headers = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.HEADERS_SERVICE;
let AperturaAuditoriaService = class AperturaAuditoriaService extends _baseService__WEBPACK_IMPORTED_MODULE_1__.BaseService {
    constructor(databaseService, httpClient, loadingController, toastController) {
        super(databaseService, httpClient, loadingController, toastController);
        this.databaseService = databaseService;
        this.httpClient = httpClient;
        this.loadingController = loadingController;
        this.toastController = toastController;
    }
    ObtenerProgramaAuditoria(pidServicio) {
        const urlQuery = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.URL_APERTURA + 'ObtenerProgramaAuditoria';
        const dataRequest = {
            idServicio: pidServicio,
            usuario: _interfaces_seguridad_usuario__WEBPACK_IMPORTED_MODULE_3__.usuario.currentUser.nick,
        };
        this.presentLoader();
        return this.httpClient
            .post(urlQuery, JSON.stringify(dataRequest), { headers })
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.finalize)(() => {
            console.log('**se termino la llamada ObtenerProgramaAuditoria');
            this.dismissLoader();
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)((error) => {
            this.showMessageError('No se tiene comunicacion con el servidor');
            return rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable["throw"](new Error(error.status));
        }));
    }
    ObtenerCargos() {
        const url_query = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.URL_APERTURA + 'ObtenerCargos';
        const dataRequest = {};
        this.presentLoader();
        return this.httpClient
            .post(url_query, JSON.stringify(dataRequest), {
            headers,
        })
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.finalize)(() => {
            console.log('se termino la llamada ObtenerCargos');
            this.dismissLoader();
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)((error) => {
            this.showMessageError('No se tiene comunicacion con el servidor');
            return rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable["throw"](new Error(error.status));
        }));
    }
    ObtenerParticipanteXCargos(IdCargoCalificado) {
        const url_query = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.URL_APERTURA + 'BuscarPersonalCargos';
        const dataRequest = {
            IdCargoCalificado,
        };
        this.presentLoader();
        return this.httpClient
            .post(url_query, JSON.stringify(dataRequest), {
            headers,
        })
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.finalize)(() => {
            console.log('se termino la llamada');
            this.dismissLoader();
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)((error) => {
            this.showMessageError('No se tiene comunicacion con el servidor');
            return rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable["throw"](new Error(error.status));
        }));
    }
    BuscarNormas(Codigo) {
        const url_query = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.URL_APERTURA + 'BuscarNormas';
        const dataRequest = {
            Codigo,
        };
        this.presentLoader();
        return this.httpClient
            .post(url_query, JSON.stringify(dataRequest), {
            headers,
        })
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.finalize)(() => {
            console.log('se termino la llamada BuscarNormas');
            this.dismissLoader();
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)((error) => {
            this.showMessageError('No se tiene comunicacion con el servidor');
            return rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable["throw"](new Error(error.status));
        }));
    }
    BuscarNormasInternacionales(Codigo) {
        const url_query = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.URL_APERTURA + 'BuscarNormasInternacionales';
        const dataRequest = {
            Codigo,
        };
        this.presentLoader();
        return this.httpClient
            .post(url_query, JSON.stringify(dataRequest), {
            headers,
        })
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.finalize)(() => {
            console.log('se termino la llamada BuscarNormasInternacionales');
            this.dismissLoader();
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)((error) => {
            this.showMessageError('No se tiene comunicacion con el servidor');
            return rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable["throw"](new Error(error.status));
        }));
    }
    BuscarPais(pais) {
        const url_query = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.URL_APERTURA + 'BuscarPais';
        const dataRequest = {
            pais,
        };
        this.presentLoader();
        return this.httpClient
            .post(url_query, JSON.stringify(dataRequest), {
            headers,
        })
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.finalize)(() => {
            console.log('se termino la llamada BuscarPais');
            this.dismissLoader();
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)((error) => {
            this.showMessageError('No se tiene comunicacion con el servidor');
            return rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable["throw"](new Error(error.status));
        }));
    }
    BuscarEstado(IdPais) {
        const url_query = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.URL_APERTURA + 'BuscarEstado';
        const dataRequest = {
            IdPais,
        };
        this.presentLoader();
        return this.httpClient
            .post(url_query, JSON.stringify(dataRequest), {
            headers,
        })
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.finalize)(() => {
            console.log('se termino la llamada BuscarEstado');
            this.dismissLoader();
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)((error) => {
            this.showMessageError('No se tiene comunicacion con el servidor');
            return rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable["throw"](new Error(error.status));
        }));
    }
    BuscarCiudad(IdEstado) {
        const url_query = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.URL_APERTURA + 'BuscarCiudad';
        const dataRequest = {
            IdEstado,
        };
        this.presentLoader();
        return this.httpClient
            .post(url_query, JSON.stringify(dataRequest), {
            headers,
        })
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.finalize)(() => {
            console.log('se termino la llamada BuscarCiudad');
            this.dismissLoader();
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)((error) => {
            this.showMessageError('No se tiene comunicacion con el servidor');
            return rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable["throw"](new Error(error.status));
        }));
    }
    RegisterProgramaAuditoria(programa) {
        const url_query = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.URL_APERTURA + 'RegisterProgramaAuditoria';
        this.presentLoader();
        return this.httpClient
            .post(url_query, JSON.stringify(programa), { headers })
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.finalize)(() => {
            console.log('se termino la llamada RegisterProgramaAuditoria');
            this.dismissLoader();
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)((error) => {
            this.showMessageError('No se tiene comunicacion con el servidor');
            return rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable["throw"](new Error(error.status));
        }));
    }
    GenerarDesignacion(IdCiclo, Plantilla) {
        const url_query = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.URL_APERTURA + 'GenerarDesignacion';
        const dataRequest = {
            IdCiclo,
            pathPlantilla: Plantilla,
        };
        this.presentLoader();
        return this.httpClient
            .post(url_query, JSON.stringify(dataRequest), {
            headers,
        })
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.finalize)(() => {
            console.log('se termino la llamada GenerarDesignacion');
            this.dismissLoader();
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)((error) => {
            this.showMessageError('No se tiene comunicacion con el servidor');
            return rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable["throw"](new Error(error.status));
        }));
    }
    ObtenerArchivoDesignacion(fileName) {
        const url_query = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.URL_APERTURA + 'ObtenerArchivoDesignacion?fileName=' + fileName;
        this.httpClient
            .get(url_query, {
            responseType: 'arraybuffer',
            headers,
        })
            //.subscribe((response) => this.downLoadFile(response, "application/pdf"));
            .subscribe((response) => this.downLoadFileWord(response, 'Desginacion.doc'));
    }
    downLoadFile(data, type) {
        const blob = new Blob([data], { type });
        const url = window.URL.createObjectURL(blob);
        const pwa = window.open(url);
        if (!pwa || pwa.closed || typeof pwa.closed == 'undefined') {
            alert('Por favor deshabilite los bloqueadores de descarga para continuar.');
        }
    }
    downLoadFileWord(data, fileName) {
        const blob = new Blob([data], { type: 'application/octet-stream' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        // set the name of the file
        link.download = fileName;
        // clicking the anchor element will download the file
        link.click();
    }
    BuscarOrganismosCertificadores() {
        const url_query = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.URL_APERTURA + 'BuscarOrganismosCertificadores';
        const dataRequest = {};
        this.presentLoader();
        return this.httpClient
            .post(url_query, JSON.stringify(dataRequest), {
            headers,
        })
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.finalize)(() => {
            console.log('se termino la llamada GenerarDesignacion');
            this.dismissLoader();
        }));
    }
    CargarSolicitud(fileToUpload) {
        const urlQuery = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.URL_APERTURA + 'CargarSolcitud';
        this.presentLoader();
        const formData = new FormData();
        formData.append('fileKey', fileToUpload, fileToUpload.name);
        return this.httpClient.post(urlQuery, formData).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.finalize)(() => {
            console.log('se termino la llamada CargarSolicitud');
            this.dismissLoader();
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)((error) => {
            console.error(error);
            this.showMessageError('Error al cargar el archivo ' + error.error);
            return rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable["throw"](new Error(error.status));
        }));
    }
};
AperturaAuditoriaService.ctorParameters = () => [
    { type: _database_service__WEBPACK_IMPORTED_MODULE_2__.DatabaseService },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ToastController }
];
AperturaAuditoriaService = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Injectable)({
        providedIn: 'root',
    })
], AperturaAuditoriaService);



/***/ }),

/***/ 6306:
/*!*****************************************!*\
  !*** ./src/app/services/baseService.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BaseService": () => (/* binding */ BaseService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 4929);

class BaseService {
    constructor(databaseService, httpClient, loadingController, toastController) {
        this.databaseService = databaseService;
        this.httpClient = httpClient;
        this.loadingController = loadingController;
        this.toastController = toastController;
    }
    presentLoader() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            BaseService.isLoading = true;
            return yield this.loadingController
                .create({
                duration: 5000,
                message: "Procesando...",
            })
                .then((a) => {
                a.present().then(() => {
                    console.log("presented");
                    if (!BaseService.isLoading) {
                        a.dismiss().then(() => console.log("abort presenting"));
                    }
                });
            });
        });
    }
    dismissLoader() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            BaseService.isLoading = false;
            return yield this.loadingController
                .dismiss()
                .then(() => console.log("dismissed"))
                .catch((error) => console.log("error en dismiss loader", error));
        });
    }
    showMessageResponse(response) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            let color = "success";
            switch (response["state"]) {
                case 1:
                    color = "success";
                    break;
                case 2:
                    color = "warning";
                    break;
                case 3:
                    color = "danger";
                    break;
            }
            const toast = yield this.toastController.create({
                message: response["message"],
                duration: 3000,
                position: "top",
                color: color,
            });
            toast.present();
        });
    }
    showMessageError(message) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: message,
                duration: 3000,
                position: "top",
                color: "danger",
            });
            toast.present();
        });
    }
    showMessageSucess(message) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: message,
                duration: 3000,
                position: "top",
                color: "success",
            });
            toast.present();
        });
    }
}
BaseService.isLoading = false;


/***/ }),

/***/ 4382:
/*!**********************************************!*\
  !*** ./src/app/services/database.service.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DatabaseService": () => (/* binding */ DatabaseService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ionic/storage */ 190);



let DatabaseService = class DatabaseService {
    constructor(storage) {
        this.storage = storage;
    }
    testDB() {
        this.storage.set("persona", { nombre: "ruben", apellido: "chalco" });
        console.log("dato rescatado", this.storage.get("persona"));
    }
    setItem(key, _object) {
        this.storage.set(key, _object);
    }
    getItem(key) {
        return this.storage.get(key);
    }
    removeItem(key) {
        return this.storage.remove(key);
    }
};
DatabaseService.ctorParameters = () => [
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_0__.Storage }
];
DatabaseService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: "root",
    })
], DatabaseService);



/***/ }),

/***/ 5749:
/*!********************************************************!*\
  !*** ./src/app/services/docmentos-services.service.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DocmentosServicesService": () => (/* binding */ DocmentosServicesService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common/http */ 8784);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 2378);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 4661);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 7418);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 2340);
/* harmony import */ var _baseService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./baseService */ 6306);
/* harmony import */ var _database_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./database.service */ 4382);

/* eslint-disable @typescript-eslint/naming-convention */








const headers = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.HEADERS_SERVICE;
let DocmentosServicesService = class DocmentosServicesService extends _baseService__WEBPACK_IMPORTED_MODULE_1__.BaseService {
    constructor(databaseService, httpClient, loadingController, toastController) {
        super(databaseService, httpClient, loadingController, toastController);
        this.databaseService = databaseService;
        this.httpClient = httpClient;
        this.loadingController = loadingController;
        this.toastController = toastController;
    }
    GenerarDocumento(IdCiclo, Plantilla) {
        const url_query = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.URL_ELABORACION + 'GenerarDocumento';
        const dataRequest = {
            idCicloAuditoria: IdCiclo,
            nombrePlantilla: Plantilla,
        };
        this.presentLoader();
        this.httpClient
            .post(url_query, JSON.stringify(dataRequest), {
            headers,
        })
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.finalize)(() => {
            console.log('se termino la llamada GenerarDocumento');
            this.dismissLoader();
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.catchError)((error) => {
            this.showMessageError('No se tiene comunicacion con el servidor');
            return rxjs__WEBPACK_IMPORTED_MODULE_5__.Observable["throw"](new Error(error.status));
        }))
            .subscribe((x) => {
            if (x.state !== 1) {
                this.showMessageError('Error en la plantilla: ' + x.message);
                return;
            }
            this.ObtenerArchivo(x.message, Plantilla);
        });
    }
    ObtenerArchivo(fileName, nombrePlantilla) {
        const url_query = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.URL_ELABORACION + 'ObtenerArchivo?fileName=' + fileName;
        this.httpClient
            .get(url_query, {
            responseType: 'arraybuffer',
            headers: src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.HEADERS_SERVICE,
        })
            //.subscribe((response) => this.downLoadFile(response, "application/pdf"));
            .subscribe((response) => this.downLoadFileWord(response, nombrePlantilla + '.doc'));
    }
    downLoadFile(data, _type) {
        const blob = new Blob([data], { type: _type });
        const url = window.URL.createObjectURL(blob);
        const pwa = window.open(url);
        if (!pwa || pwa.closed || typeof pwa.closed == 'undefined') {
            alert('Por favor deshabilite los bloqueadores de descarga para continuar.');
        }
    }
    downLoadFileWord(data, fileName) {
        const blob = new Blob([data], { type: 'application/octet-stream' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = fileName;
        link.click();
    }
};
DocmentosServicesService.ctorParameters = () => [
    { type: _database_service__WEBPACK_IMPORTED_MODULE_2__.DatabaseService },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ToastController }
];
DocmentosServicesService = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Injectable)({
        providedIn: 'root',
    })
], DocmentosServicesService);



/***/ }),

/***/ 1264:
/*!***********************************************************!*\
  !*** ./src/app/services/elaboracion-auditoria.service.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ElaboracionAuditoriaService": () => (/* binding */ ElaboracionAuditoriaService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ 8784);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 2378);
/* harmony import */ var rxjs_internal_operators_finalize__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/internal/operators/finalize */ 8039);
/* harmony import */ var rxjs_internal_operators_finalize__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(rxjs_internal_operators_finalize__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 7418);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 2340);
/* harmony import */ var _interfaces_seguridad_usuario__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../interfaces/seguridad/usuario */ 6598);
/* harmony import */ var _baseService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./baseService */ 6306);
/* harmony import */ var _database_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./database.service */ 4382);

/* eslint-disable @typescript-eslint/naming-convention */










const headers = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.HEADERS_SERVICE;
const url_elaboracion = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.URL_ELABORACION;
let ElaboracionAuditoriaService = class ElaboracionAuditoriaService extends _baseService__WEBPACK_IMPORTED_MODULE_2__.BaseService {
    constructor(databaseService, httpClient, loadingController, toastController) {
        super(databaseService, httpClient, loadingController, toastController);
        this.databaseService = databaseService;
        this.httpClient = httpClient;
        this.loadingController = loadingController;
        this.toastController = toastController;
    }
    ObtenerCiclosPorIdAuditor(_IdAuditor) {
        const url_query = url_elaboracion + 'ObtenerCiclosPorIdAuditor';
        const dataRequest = {
            IdAuditor: _IdAuditor,
        };
        this.presentLoader();
        return this.httpClient
            .post(url_query, JSON.stringify(dataRequest), { headers })
            .pipe((0,rxjs_internal_operators_finalize__WEBPACK_IMPORTED_MODULE_4__.finalize)(() => {
            console.log('**se termino la llamada ObtenerCiclosPorIdAuditor');
            this.dismissLoader();
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)((error) => {
            this.showMessageError('No se tiene comunicacion con el servidor');
            return rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable["throw"](new Error(error.status));
        }));
    }
    ObtenerPlanAuditoria(_IdCicloPrograma) {
        const url_query = url_elaboracion + 'ObtenerPlanAuditoria';
        const dataRequest = {
            IdCicloPrograma: _IdCicloPrograma,
            usuario: _interfaces_seguridad_usuario__WEBPACK_IMPORTED_MODULE_1__.usuario.currentUser.nick,
        };
        this.presentLoader();
        return this.httpClient
            .post(url_query, JSON.stringify(dataRequest), { headers })
            .pipe((0,rxjs_internal_operators_finalize__WEBPACK_IMPORTED_MODULE_4__.finalize)(() => {
            console.log('**se termino la llamada ObtenerCiclosPorIdAuditor');
            this.dismissLoader();
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)((error) => {
            this.showMessageError('No se tiene comunicacion con el servidor');
            return rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable["throw"](new Error(error.status));
        }));
    }
    RegistrarPlanAuditoria(planAuditoriaDTO) {
        const url_query = url_elaboracion + 'RegistrarPlanAuditoria';
        const dataRequest = planAuditoriaDTO;
        this.presentLoader();
        return this.httpClient
            .post(url_query, JSON.stringify(dataRequest), { headers })
            .pipe((0,rxjs_internal_operators_finalize__WEBPACK_IMPORTED_MODULE_4__.finalize)(() => {
            console.log('**se termino la llamada RegistrarPlanAuditoria');
            this.dismissLoader();
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)((error) => {
            this.showMessageError('No se tiene comunicacion con el servidor');
            return rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable["throw"](new Error(error.status));
        }));
    }
    GetListasPredefinidas(_area) {
        const url_query = url_elaboracion + 'GetListasPredefinidas';
        const dataRequest = {
            area: _area,
        };
        this.presentLoader();
        return this.httpClient
            .post(url_query, JSON.stringify(dataRequest), { headers })
            .pipe((0,rxjs_internal_operators_finalize__WEBPACK_IMPORTED_MODULE_4__.finalize)(() => {
            console.log('**se termino la llamada GetListasPredefinidas');
            this.dismissLoader();
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)((error) => {
            this.showMessageError('No se tiene comunicacion con el servidor');
            return rxjs__WEBPACK_IMPORTED_MODULE_6__.Observable["throw"](new Error(error.status));
        }));
    }
    GetListasVerificacion(_IdLista) {
        const url_query = url_elaboracion + 'GetListasVerificacion';
        const dataRequest = {
            IdLista: _IdLista,
        };
        return this.httpClient.post(url_query, JSON.stringify(dataRequest), { headers });
    }
    GetListasDocumetos(_area, _proceso) {
        const url_query = url_elaboracion + 'GetListasDocumetos';
        const dataRequest = {
            area: _area,
            proceso: _proceso,
        };
        return this.httpClient.post(url_query, JSON.stringify(dataRequest), { headers });
    }
};
ElaboracionAuditoriaService.ctorParameters = () => [
    { type: _database_service__WEBPACK_IMPORTED_MODULE_3__.DatabaseService },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpClient },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ToastController }
];
ElaboracionAuditoriaService = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Injectable)({
        providedIn: 'root',
    })
], ElaboracionAuditoriaService);



/***/ }),

/***/ 2340:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": () => (/* binding */ environment),
/* harmony export */   "HEADERS_SERVICE": () => (/* binding */ HEADERS_SERVICE),
/* harmony export */   "HEADERS_FILE": () => (/* binding */ HEADERS_FILE),
/* harmony export */   "URL_GLOBAL": () => (/* binding */ URL_GLOBAL),
/* harmony export */   "URL_APERTURA": () => (/* binding */ URL_APERTURA),
/* harmony export */   "URL_ELABORACION": () => (/* binding */ URL_ELABORACION)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common/http */ 8784);
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

const environment = {
    production: false
};
const HEADERS_SERVICE = new _angular_common_http__WEBPACK_IMPORTED_MODULE_0__.HttpHeaders({
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT',
    Accept: '*/*',
    'content-type': 'application/json',
});
const HEADERS_FILE = new _angular_common_http__WEBPACK_IMPORTED_MODULE_0__.HttpHeaders({
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT',
    Accept: '*/*',
});
//export const URL_GLOBAL = 'http://localhost:8001/api/';
//export const URL_GLOBAL = 'http://formacion.ibnorca.org:8880/api/';
const URL_GLOBAL = 'http://localhost/api/';
const URL_APERTURA = URL_GLOBAL + 'AperturaAuditoria/';
const URL_ELABORACION = URL_GLOBAL + 'ElaboracionAuditoria/';
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ 4431:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ 8150);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 6747);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 2340);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
(0,_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__.platformBrowserDynamic)().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule)
    .catch(err => console.log(err));


/***/ }),

/***/ 863:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./ion-accordion_2.entry.js": [
		79,
		"common",
		"node_modules_ionic_core_dist_esm_ion-accordion_2_entry_js"
	],
	"./ion-action-sheet.entry.js": [
		5593,
		"common",
		"node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"
	],
	"./ion-alert.entry.js": [
		3225,
		"common",
		"node_modules_ionic_core_dist_esm_ion-alert_entry_js"
	],
	"./ion-app_8.entry.js": [
		4812,
		"common",
		"node_modules_ionic_core_dist_esm_ion-app_8_entry_js"
	],
	"./ion-avatar_3.entry.js": [
		6655,
		"common",
		"node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"
	],
	"./ion-back-button.entry.js": [
		4856,
		"common",
		"node_modules_ionic_core_dist_esm_ion-back-button_entry_js"
	],
	"./ion-backdrop.entry.js": [
		3059,
		"node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"
	],
	"./ion-breadcrumb_2.entry.js": [
		8648,
		"common",
		"node_modules_ionic_core_dist_esm_ion-breadcrumb_2_entry_js"
	],
	"./ion-button_2.entry.js": [
		8308,
		"common",
		"node_modules_ionic_core_dist_esm_ion-button_2_entry_js"
	],
	"./ion-card_5.entry.js": [
		4690,
		"common",
		"node_modules_ionic_core_dist_esm_ion-card_5_entry_js"
	],
	"./ion-checkbox.entry.js": [
		4090,
		"common",
		"node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"
	],
	"./ion-chip.entry.js": [
		6214,
		"common",
		"node_modules_ionic_core_dist_esm_ion-chip_entry_js"
	],
	"./ion-col_3.entry.js": [
		9447,
		"node_modules_ionic_core_dist_esm_ion-col_3_entry_js"
	],
	"./ion-datetime_3.entry.js": [
		9689,
		"common",
		"node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"
	],
	"./ion-fab_3.entry.js": [
		8840,
		"common",
		"node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"
	],
	"./ion-img.entry.js": [
		749,
		"node_modules_ionic_core_dist_esm_ion-img_entry_js"
	],
	"./ion-infinite-scroll_2.entry.js": [
		9667,
		"common",
		"node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"
	],
	"./ion-input.entry.js": [
		3288,
		"common",
		"node_modules_ionic_core_dist_esm_ion-input_entry_js"
	],
	"./ion-item-option_3.entry.js": [
		5473,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"
	],
	"./ion-item_8.entry.js": [
		3634,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item_8_entry_js"
	],
	"./ion-loading.entry.js": [
		2855,
		"common",
		"node_modules_ionic_core_dist_esm_ion-loading_entry_js"
	],
	"./ion-menu_3.entry.js": [
		495,
		"common",
		"node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"
	],
	"./ion-modal.entry.js": [
		8737,
		"common",
		"node_modules_ionic_core_dist_esm_ion-modal_entry_js"
	],
	"./ion-nav_2.entry.js": [
		9632,
		"common",
		"node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"
	],
	"./ion-picker-column-internal.entry.js": [
		4446,
		"common",
		"node_modules_ionic_core_dist_esm_ion-picker-column-internal_entry_js"
	],
	"./ion-picker-internal.entry.js": [
		2275,
		"node_modules_ionic_core_dist_esm_ion-picker-internal_entry_js"
	],
	"./ion-popover.entry.js": [
		8050,
		"common",
		"node_modules_ionic_core_dist_esm_ion-popover_entry_js"
	],
	"./ion-progress-bar.entry.js": [
		8994,
		"common",
		"node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"
	],
	"./ion-radio_2.entry.js": [
		3592,
		"common",
		"node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"
	],
	"./ion-range.entry.js": [
		5454,
		"common",
		"node_modules_ionic_core_dist_esm_ion-range_entry_js"
	],
	"./ion-refresher_2.entry.js": [
		290,
		"common",
		"node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"
	],
	"./ion-reorder_2.entry.js": [
		2666,
		"common",
		"node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"
	],
	"./ion-ripple-effect.entry.js": [
		4816,
		"node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"
	],
	"./ion-route_4.entry.js": [
		5534,
		"common",
		"node_modules_ionic_core_dist_esm_ion-route_4_entry_js"
	],
	"./ion-searchbar.entry.js": [
		4902,
		"common",
		"node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"
	],
	"./ion-segment_2.entry.js": [
		1938,
		"common",
		"node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"
	],
	"./ion-select_3.entry.js": [
		8179,
		"common",
		"node_modules_ionic_core_dist_esm_ion-select_3_entry_js"
	],
	"./ion-slide_2.entry.js": [
		668,
		"node_modules_ionic_core_dist_esm_ion-slide_2_entry_js"
	],
	"./ion-spinner.entry.js": [
		1624,
		"common",
		"node_modules_ionic_core_dist_esm_ion-spinner_entry_js"
	],
	"./ion-split-pane.entry.js": [
		9989,
		"node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"
	],
	"./ion-tab-bar_2.entry.js": [
		8902,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"
	],
	"./ion-tab_2.entry.js": [
		199,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"
	],
	"./ion-text.entry.js": [
		8395,
		"common",
		"node_modules_ionic_core_dist_esm_ion-text_entry_js"
	],
	"./ion-textarea.entry.js": [
		6357,
		"common",
		"node_modules_ionic_core_dist_esm_ion-textarea_entry_js"
	],
	"./ion-toast.entry.js": [
		8268,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toast_entry_js"
	],
	"./ion-toggle.entry.js": [
		5269,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toggle_entry_js"
	],
	"./ion-virtual-scroll.entry.js": [
		2875,
		"node_modules_ionic_core_dist_esm_ion-virtual-scroll_entry_js"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(() => {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 863;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 9259:
/*!***********************************************!*\
  !*** ./src/app/app.component.scss?ngResource ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = "ion-menu ion-content {\n  --background: var(--ion-item-background, var(--ion-background-color, #fff));\n}\n\nion-menu.md ion-content {\n  --padding-start: 8px;\n  --padding-end: 8px;\n  --padding-top: 20px;\n  --padding-bottom: 20px;\n}\n\nion-menu.md ion-list {\n  padding: 20px 0;\n}\n\nion-menu.md ion-note {\n  margin-bottom: 30px;\n}\n\nion-menu.md ion-list-header,\nion-menu.md ion-note {\n  padding-left: 10px;\n}\n\nion-menu.md ion-list#inbox-list {\n  border-bottom: 1px solid var(--ion-color-step-150, #d7d8da);\n}\n\nion-menu.md ion-list#inbox-list ion-list-header {\n  font-size: 22px;\n  font-weight: 600;\n  min-height: 20px;\n}\n\nion-menu.md ion-list#labels-list ion-list-header {\n  font-size: 16px;\n  margin-bottom: 18px;\n  color: #757575;\n  min-height: 26px;\n}\n\nion-menu.md ion-item {\n  --padding-start: 10px;\n  --padding-end: 10px;\n  border-radius: 4px;\n}\n\nion-menu.md ion-item.selected {\n  --background: rgba(var(--ion-color-primary-rgb), 0.14);\n}\n\nion-menu.md ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n\nion-menu.md ion-item ion-icon {\n  color: #616e7e;\n}\n\nion-menu.md ion-item ion-label {\n  font-weight: 500;\n}\n\nion-menu.ios ion-content {\n  --padding-bottom: 20px;\n}\n\nion-menu.ios ion-list {\n  padding: 20px 0 0 0;\n}\n\nion-menu.ios ion-note {\n  line-height: 24px;\n  margin-bottom: 20px;\n}\n\nion-menu.ios ion-item {\n  --padding-start: 16px;\n  --padding-end: 16px;\n  --min-height: 50px;\n}\n\nion-menu.ios ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n\nion-menu.ios ion-item ion-icon {\n  font-size: 24px;\n  color: #73849a;\n}\n\nion-menu.ios ion-list#labels-list ion-list-header {\n  margin-bottom: 8px;\n}\n\nion-menu.ios ion-list-header,\nion-menu.ios ion-note {\n  padding-left: 16px;\n  padding-right: 16px;\n}\n\nion-menu.ios ion-note {\n  margin-bottom: 8px;\n}\n\nion-note {\n  display: inline-block;\n  font-size: 16px;\n  color: var(--ion-color-medium-shade);\n}\n\nion-item.selected {\n  --color: var(--ion-color-primary);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXEJja0RlbGwlMjAlMjAxNSUyMDU1MDBcXGVcXFBST1lFQ1RPU1xcaWJub3JjYVxcaWJub3JjYS1wd2FcXGlibm9yY2EtcHdhXFxpYm5vcmNhX3VpXFxzcmNcXGFwcFxcYXBwLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsMkVBQUE7QUNDRjs7QURFQTtFQUNFLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLHNCQUFBO0FDQ0Y7O0FERUE7RUFDRSxlQUFBO0FDQ0Y7O0FERUE7RUFDRSxtQkFBQTtBQ0NGOztBREVBOztFQUVFLGtCQUFBO0FDQ0Y7O0FERUE7RUFDRSwyREFBQTtBQ0NGOztBREVBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBRUEsZ0JBQUE7QUNBRjs7QURHQTtFQUNFLGVBQUE7RUFFQSxtQkFBQTtFQUVBLGNBQUE7RUFFQSxnQkFBQTtBQ0hGOztBRE1BO0VBQ0UscUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FDSEY7O0FETUE7RUFDRSxzREFBQTtBQ0hGOztBRE1BO0VBQ0UsK0JBQUE7QUNIRjs7QURNQTtFQUNFLGNBQUE7QUNIRjs7QURNQTtFQUNFLGdCQUFBO0FDSEY7O0FETUE7RUFDRSxzQkFBQTtBQ0hGOztBRE1BO0VBQ0UsbUJBQUE7QUNIRjs7QURNQTtFQUNFLGlCQUFBO0VBQ0EsbUJBQUE7QUNIRjs7QURNQTtFQUNFLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQ0hGOztBRE1BO0VBQ0UsK0JBQUE7QUNIRjs7QURNQTtFQUNFLGVBQUE7RUFDQSxjQUFBO0FDSEY7O0FETUE7RUFDRSxrQkFBQTtBQ0hGOztBRE1BOztFQUVFLGtCQUFBO0VBQ0EsbUJBQUE7QUNIRjs7QURNQTtFQUNFLGtCQUFBO0FDSEY7O0FETUE7RUFDRSxxQkFBQTtFQUNBLGVBQUE7RUFFQSxvQ0FBQTtBQ0pGOztBRE9BO0VBQ0UsaUNBQUE7QUNKRiIsImZpbGUiOiJhcHAuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tbWVudSBpb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWl0ZW0tYmFja2dyb3VuZCwgdmFyKC0taW9uLWJhY2tncm91bmQtY29sb3IsICNmZmYpKTtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWNvbnRlbnQge1xuICAtLXBhZGRpbmctc3RhcnQ6IDhweDtcbiAgLS1wYWRkaW5nLWVuZDogOHB4O1xuICAtLXBhZGRpbmctdG9wOiAyMHB4O1xuICAtLXBhZGRpbmctYm90dG9tOiAyMHB4O1xufVxuXG5pb24tbWVudS5tZCBpb24tbGlzdCB7XG4gIHBhZGRpbmc6IDIwcHggMDtcbn1cblxuaW9uLW1lbnUubWQgaW9uLW5vdGUge1xuICBtYXJnaW4tYm90dG9tOiAzMHB4O1xufVxuXG5pb24tbWVudS5tZCBpb24tbGlzdC1oZWFkZXIsXG5pb24tbWVudS5tZCBpb24tbm90ZSB7XG4gIHBhZGRpbmctbGVmdDogMTBweDtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWxpc3QjaW5ib3gtbGlzdCB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCB2YXIoLS1pb24tY29sb3Itc3RlcC0xNTAsICNkN2Q4ZGEpO1xufVxuXG5pb24tbWVudS5tZCBpb24tbGlzdCNpbmJveC1saXN0IGlvbi1saXN0LWhlYWRlciB7XG4gIGZvbnQtc2l6ZTogMjJweDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcblxuICBtaW4taGVpZ2h0OiAyMHB4O1xufVxuXG5pb24tbWVudS5tZCBpb24tbGlzdCNsYWJlbHMtbGlzdCBpb24tbGlzdC1oZWFkZXIge1xuICBmb250LXNpemU6IDE2cHg7XG5cbiAgbWFyZ2luLWJvdHRvbTogMThweDtcblxuICBjb2xvcjogIzc1NzU3NTtcblxuICBtaW4taGVpZ2h0OiAyNnB4O1xufVxuXG5pb24tbWVudS5tZCBpb24taXRlbSB7XG4gIC0tcGFkZGluZy1zdGFydDogMTBweDtcbiAgLS1wYWRkaW5nLWVuZDogMTBweDtcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xufVxuXG5pb24tbWVudS5tZCBpb24taXRlbS5zZWxlY3RlZCB7XG4gIC0tYmFja2dyb3VuZDogcmdiYSh2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1yZ2IpLCAwLjE0KTtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWl0ZW0uc2VsZWN0ZWQgaW9uLWljb24ge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuXG5pb24tbWVudS5tZCBpb24taXRlbSBpb24taWNvbiB7XG4gIGNvbG9yOiAjNjE2ZTdlO1xufVxuXG5pb24tbWVudS5tZCBpb24taXRlbSBpb24tbGFiZWwge1xuICBmb250LXdlaWdodDogNTAwO1xufVxuXG5pb24tbWVudS5pb3MgaW9uLWNvbnRlbnQge1xuICAtLXBhZGRpbmctYm90dG9tOiAyMHB4O1xufVxuXG5pb24tbWVudS5pb3MgaW9uLWxpc3Qge1xuICBwYWRkaW5nOiAyMHB4IDAgMCAwO1xufVxuXG5pb24tbWVudS5pb3MgaW9uLW5vdGUge1xuICBsaW5lLWhlaWdodDogMjRweDtcbiAgbWFyZ2luLWJvdHRvbTogMjBweDtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1pdGVtIHtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAxNnB4O1xuICAtLXBhZGRpbmctZW5kOiAxNnB4O1xuICAtLW1pbi1oZWlnaHQ6IDUwcHg7XG59XG5cbmlvbi1tZW51LmlvcyBpb24taXRlbS5zZWxlY3RlZCBpb24taWNvbiB7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG59XG5cbmlvbi1tZW51LmlvcyBpb24taXRlbSBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMjRweDtcbiAgY29sb3I6ICM3Mzg0OWE7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbGlzdCNsYWJlbHMtbGlzdCBpb24tbGlzdC1oZWFkZXIge1xuICBtYXJnaW4tYm90dG9tOiA4cHg7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbGlzdC1oZWFkZXIsXG5pb24tbWVudS5pb3MgaW9uLW5vdGUge1xuICBwYWRkaW5nLWxlZnQ6IDE2cHg7XG4gIHBhZGRpbmctcmlnaHQ6IDE2cHg7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbm90ZSB7XG4gIG1hcmdpbi1ib3R0b206IDhweDtcbn1cblxuaW9uLW5vdGUge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIGZvbnQtc2l6ZTogMTZweDtcblxuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bS1zaGFkZSk7XG59XG5cbmlvbi1pdGVtLnNlbGVjdGVkIHtcbiAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufSIsImlvbi1tZW51IGlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24taXRlbS1iYWNrZ3JvdW5kLCB2YXIoLS1pb24tYmFja2dyb3VuZC1jb2xvciwgI2ZmZikpO1xufVxuXG5pb24tbWVudS5tZCBpb24tY29udGVudCB7XG4gIC0tcGFkZGluZy1zdGFydDogOHB4O1xuICAtLXBhZGRpbmctZW5kOiA4cHg7XG4gIC0tcGFkZGluZy10b3A6IDIwcHg7XG4gIC0tcGFkZGluZy1ib3R0b206IDIwcHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0IHtcbiAgcGFkZGluZzogMjBweCAwO1xufVxuXG5pb24tbWVudS5tZCBpb24tbm90ZSB7XG4gIG1hcmdpbi1ib3R0b206IDMwcHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0LWhlYWRlcixcbmlvbi1tZW51Lm1kIGlvbi1ub3RlIHtcbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xufVxuXG5pb24tbWVudS5tZCBpb24tbGlzdCNpbmJveC1saXN0IHtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1zdGVwLTE1MCwgI2Q3ZDhkYSk7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0I2luYm94LWxpc3QgaW9uLWxpc3QtaGVhZGVyIHtcbiAgZm9udC1zaXplOiAyMnB4O1xuICBmb250LXdlaWdodDogNjAwO1xuICBtaW4taGVpZ2h0OiAyMHB4O1xufVxuXG5pb24tbWVudS5tZCBpb24tbGlzdCNsYWJlbHMtbGlzdCBpb24tbGlzdC1oZWFkZXIge1xuICBmb250LXNpemU6IDE2cHg7XG4gIG1hcmdpbi1ib3R0b206IDE4cHg7XG4gIGNvbG9yOiAjNzU3NTc1O1xuICBtaW4taGVpZ2h0OiAyNnB4O1xufVxuXG5pb24tbWVudS5tZCBpb24taXRlbSB7XG4gIC0tcGFkZGluZy1zdGFydDogMTBweDtcbiAgLS1wYWRkaW5nLWVuZDogMTBweDtcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xufVxuXG5pb24tbWVudS5tZCBpb24taXRlbS5zZWxlY3RlZCB7XG4gIC0tYmFja2dyb3VuZDogcmdiYSh2YXIoLS1pb24tY29sb3ItcHJpbWFyeS1yZ2IpLCAwLjE0KTtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWl0ZW0uc2VsZWN0ZWQgaW9uLWljb24ge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuXG5pb24tbWVudS5tZCBpb24taXRlbSBpb24taWNvbiB7XG4gIGNvbG9yOiAjNjE2ZTdlO1xufVxuXG5pb24tbWVudS5tZCBpb24taXRlbSBpb24tbGFiZWwge1xuICBmb250LXdlaWdodDogNTAwO1xufVxuXG5pb24tbWVudS5pb3MgaW9uLWNvbnRlbnQge1xuICAtLXBhZGRpbmctYm90dG9tOiAyMHB4O1xufVxuXG5pb24tbWVudS5pb3MgaW9uLWxpc3Qge1xuICBwYWRkaW5nOiAyMHB4IDAgMCAwO1xufVxuXG5pb24tbWVudS5pb3MgaW9uLW5vdGUge1xuICBsaW5lLWhlaWdodDogMjRweDtcbiAgbWFyZ2luLWJvdHRvbTogMjBweDtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1pdGVtIHtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAxNnB4O1xuICAtLXBhZGRpbmctZW5kOiAxNnB4O1xuICAtLW1pbi1oZWlnaHQ6IDUwcHg7XG59XG5cbmlvbi1tZW51LmlvcyBpb24taXRlbS5zZWxlY3RlZCBpb24taWNvbiB7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG59XG5cbmlvbi1tZW51LmlvcyBpb24taXRlbSBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMjRweDtcbiAgY29sb3I6ICM3Mzg0OWE7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbGlzdCNsYWJlbHMtbGlzdCBpb24tbGlzdC1oZWFkZXIge1xuICBtYXJnaW4tYm90dG9tOiA4cHg7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbGlzdC1oZWFkZXIsXG5pb24tbWVudS5pb3MgaW9uLW5vdGUge1xuICBwYWRkaW5nLWxlZnQ6IDE2cHg7XG4gIHBhZGRpbmctcmlnaHQ6IDE2cHg7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbm90ZSB7XG4gIG1hcmdpbi1ib3R0b206IDhweDtcbn1cblxuaW9uLW5vdGUge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0tc2hhZGUpO1xufVxuXG5pb24taXRlbS5zZWxlY3RlZCB7XG4gIC0tY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbn0iXX0= */";

/***/ }),

/***/ 5292:
/*!********************************************************************************!*\
  !*** ./src/app/components/buscar-norma/buscar-norma.component.scss?ngResource ***!
  \********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".cargo-select {\n  width: 100%;\n  font-size: 13px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJ1c2Nhci1ub3JtYS5jb21wb25lbnQuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcQmNrRGVsbCUyMCUyMDE1JTIwNTUwMFxcZVxcUFJPWUVDVE9TXFxpYm5vcmNhXFxpYm5vcmNhLXB3YVxcaWJub3JjYS1wd2FcXGlibm9yY2FfdWlcXHNyY1xcYXBwXFxjb21wb25lbnRzXFxidXNjYXItbm9ybWFcXGJ1c2Nhci1ub3JtYS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7RUFDQSxlQUFBO0FDQ0oiLCJmaWxlIjoiYnVzY2FyLW5vcm1hLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNhcmdvLXNlbGVjdHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgZm9udC1zaXplOiAxM3B4O1xyXG59IiwiLmNhcmdvLXNlbGVjdCB7XG4gIHdpZHRoOiAxMDAlO1xuICBmb250LXNpemU6IDEzcHg7XG59Il19 */";

/***/ }),

/***/ 3183:
/*!********************************************************************************************!*\
  !*** ./src/app/components/ciclo-participante/ciclo-participante.component.scss?ngResource ***!
  \********************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".label-cronograma {\n  font-weight: bold;\n  font-size: 12px;\n}\n\n.data-cronograma {\n  font-style: italic;\n  font-size: 13px;\n}\n\n.ion-content-small-font {\n  font-family: \"Calibri Light\";\n  font-size: 12px;\n  color: #093537;\n}\n\n.title-medium-font {\n  font-family: \"Courier New\";\n  font-weight: bold;\n}\n\nion-card-content {\n  text-align: left;\n}\n\n.box-click {\n  min-width: 100px;\n  min-height: 20px;\n  border-bottom: solid;\n  border-color: #778e8f;\n  border-width: 1px;\n  padding: 2px;\n  margin-left: 3px;\n  display: inline-block;\n}\n\n.edit-item {\n  cursor: grab;\n}\n\n.edit-item:hover {\n  background-color: #9dd8dc;\n}\n\n.item-cronograma {\n  display: block;\n  margin-bottom: 4px;\n}\n\n.big-icon {\n  font-size: 1.2em;\n  margin-left: 3px;\n  cursor: grab;\n}\n\n.bigger-icon {\n  font-size: 2em;\n  margin-left: 3px;\n  cursor: grab;\n}\n\n.cargo-select {\n  width: 100%;\n  font-size: 13px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNpY2xvLXBhcnRpY2lwYW50ZS5jb21wb25lbnQuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcQmNrRGVsbCUyMCUyMDE1JTIwNTUwMFxcZVxcUFJPWUVDVE9TXFxpYm5vcmNhXFxpYm5vcmNhLXB3YVxcaWJub3JjYS1wd2FcXGlibm9yY2FfdWlcXHNyY1xcYXBwXFxjb21wb25lbnRzXFxjaWNsby1wYXJ0aWNpcGFudGVcXGNpY2xvLXBhcnRpY2lwYW50ZS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGlCQUFBO0VBQ0EsZUFBQTtBQ0NGOztBRENBO0VBQ0Usa0JBQUE7RUFDQSxlQUFBO0FDRUY7O0FEQUE7RUFDRSw0QkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0FDR0Y7O0FEREE7RUFDRSwwQkFBQTtFQUNBLGlCQUFBO0FDSUY7O0FERkE7RUFDRSxnQkFBQTtBQ0tGOztBREhBO0VBQ0UsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLG9CQUFBO0VBQ0EscUJBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLHFCQUFBO0FDTUY7O0FESkE7RUFDRSxZQUFBO0FDT0Y7O0FETEE7RUFDRSx5QkFBQTtBQ1FGOztBRE5BO0VBQ0UsY0FBQTtFQUNBLGtCQUFBO0FDU0Y7O0FEUEE7RUFDRSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtBQ1VGOztBRFJBO0VBQ0UsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtBQ1dGOztBRFRBO0VBQ0ksV0FBQTtFQUNBLGVBQUE7QUNZSiIsImZpbGUiOiJjaWNsby1wYXJ0aWNpcGFudGUuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubGFiZWwtY3Jvbm9ncmFtYSB7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgZm9udC1zaXplOiAxMnB4O1xyXG59XHJcbi5kYXRhLWNyb25vZ3JhbWEge1xyXG4gIGZvbnQtc3R5bGU6IGl0YWxpYztcclxuICBmb250LXNpemU6IDEzcHg7XHJcbn1cclxuLmlvbi1jb250ZW50LXNtYWxsLWZvbnQge1xyXG4gIGZvbnQtZmFtaWx5OiBcIkNhbGlicmkgTGlnaHRcIjtcclxuICBmb250LXNpemU6IDEycHg7XHJcbiAgY29sb3I6ICMwOTM1Mzc7XHJcbn1cclxuLnRpdGxlLW1lZGl1bS1mb250IHtcclxuICBmb250LWZhbWlseTogXCJDb3VyaWVyIE5ld1wiO1xyXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG59XHJcbmlvbi1jYXJkLWNvbnRlbnQge1xyXG4gIHRleHQtYWxpZ246IGxlZnQ7XHJcbn1cclxuLmJveC1jbGljayB7XHJcbiAgbWluLXdpZHRoOiAxMDBweDtcclxuICBtaW4taGVpZ2h0OiAyMHB4O1xyXG4gIGJvcmRlci1ib3R0b206IHNvbGlkO1xyXG4gIGJvcmRlci1jb2xvcjogIzc3OGU4ZjtcclxuICBib3JkZXItd2lkdGg6IDFweDtcclxuICBwYWRkaW5nOiAycHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDNweDtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbn1cclxuLmVkaXQtaXRlbSB7XHJcbiAgY3Vyc29yOiBncmFiO1xyXG59XHJcbi5lZGl0LWl0ZW06aG92ZXIge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICM5ZGQ4ZGM7XHJcbn1cclxuLml0ZW0tY3Jvbm9ncmFtYSB7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgbWFyZ2luLWJvdHRvbTogNHB4O1xyXG59XHJcbi5iaWctaWNvbiB7XHJcbiAgZm9udC1zaXplOiAxLjJlbTtcclxuICBtYXJnaW4tbGVmdDogM3B4O1xyXG4gIGN1cnNvcjogZ3JhYjtcclxufVxyXG4uYmlnZ2VyLWljb24ge1xyXG4gIGZvbnQtc2l6ZTogMmVtO1xyXG4gIG1hcmdpbi1sZWZ0OiAzcHg7XHJcbiAgY3Vyc29yOiBncmFiO1xyXG59XHJcbi5jYXJnby1zZWxlY3R7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGZvbnQtc2l6ZTogMTNweDtcclxufSIsIi5sYWJlbC1jcm9ub2dyYW1hIHtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGZvbnQtc2l6ZTogMTJweDtcbn1cblxuLmRhdGEtY3Jvbm9ncmFtYSB7XG4gIGZvbnQtc3R5bGU6IGl0YWxpYztcbiAgZm9udC1zaXplOiAxM3B4O1xufVxuXG4uaW9uLWNvbnRlbnQtc21hbGwtZm9udCB7XG4gIGZvbnQtZmFtaWx5OiBcIkNhbGlicmkgTGlnaHRcIjtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBjb2xvcjogIzA5MzUzNztcbn1cblxuLnRpdGxlLW1lZGl1bS1mb250IHtcbiAgZm9udC1mYW1pbHk6IFwiQ291cmllciBOZXdcIjtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59XG5cbmlvbi1jYXJkLWNvbnRlbnQge1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xufVxuXG4uYm94LWNsaWNrIHtcbiAgbWluLXdpZHRoOiAxMDBweDtcbiAgbWluLWhlaWdodDogMjBweDtcbiAgYm9yZGVyLWJvdHRvbTogc29saWQ7XG4gIGJvcmRlci1jb2xvcjogIzc3OGU4ZjtcbiAgYm9yZGVyLXdpZHRoOiAxcHg7XG4gIHBhZGRpbmc6IDJweDtcbiAgbWFyZ2luLWxlZnQ6IDNweDtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xufVxuXG4uZWRpdC1pdGVtIHtcbiAgY3Vyc29yOiBncmFiO1xufVxuXG4uZWRpdC1pdGVtOmhvdmVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzlkZDhkYztcbn1cblxuLml0ZW0tY3Jvbm9ncmFtYSB7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBtYXJnaW4tYm90dG9tOiA0cHg7XG59XG5cbi5iaWctaWNvbiB7XG4gIGZvbnQtc2l6ZTogMS4yZW07XG4gIG1hcmdpbi1sZWZ0OiAzcHg7XG4gIGN1cnNvcjogZ3JhYjtcbn1cblxuLmJpZ2dlci1pY29uIHtcbiAgZm9udC1zaXplOiAyZW07XG4gIG1hcmdpbi1sZWZ0OiAzcHg7XG4gIGN1cnNvcjogZ3JhYjtcbn1cblxuLmNhcmdvLXNlbGVjdCB7XG4gIHdpZHRoOiAxMDAlO1xuICBmb250LXNpemU6IDEzcHg7XG59Il19 */";

/***/ }),

/***/ 1747:
/*!**********************************************************************************!*\
  !*** ./src/app/components/custom-header/custom-header.component.scss?ngResource ***!
  \**********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjdXN0b20taGVhZGVyLmNvbXBvbmVudC5zY3NzIn0= */";

/***/ }),

/***/ 1088:
/*!********************************************************************************!*\
  !*** ./src/app/components/custom-input/custom-input.component.scss?ngResource ***!
  \********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".margin-top {\n  margin-top: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImN1c3RvbS1pbnB1dC5jb21wb25lbnQuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcQmNrRGVsbCUyMCUyMDE1JTIwNTUwMFxcZVxcUFJPWUVDVE9TXFxpYm5vcmNhXFxpYm5vcmNhLXB3YVxcaWJub3JjYS1wd2FcXGlibm9yY2FfdWlcXHNyY1xcYXBwXFxjb21wb25lbnRzXFxjdXN0b20taW5wdXRcXGN1c3RvbS1pbnB1dC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGdCQUFBO0FDQ0oiLCJmaWxlIjoiY3VzdG9tLWlucHV0LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1hcmdpbi10b3B7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG59IiwiLm1hcmdpbi10b3Age1xuICBtYXJnaW4tdG9wOiAxMHB4O1xufSJdfQ== */";

/***/ }),

/***/ 5902:
/*!****************************************************************************************!*\
  !*** ./src/app/components/editor-documento/editor-documento.component.scss?ngResource ***!
  \****************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlZGl0b3ItZG9jdW1lbnRvLmNvbXBvbmVudC5zY3NzIn0= */";

/***/ }),

/***/ 7613:
/*!**********************************************************************************************!*\
  !*** ./src/app/components/ela-cronograma-list/ela-cronograma-list.component.scss?ngResource ***!
  \**********************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".sub-title-horario {\n  font-size: 14px;\n  font-family: sans-serif;\n}\n\n.paragraph-horario {\n  font-style: italic;\n  font-size: 13px;\n  color: #05022e;\n  display: block;\n  padding: 1px;\n}\n\n.row-cronogama {\n  width: 100%;\n  background-color: #f5d6d6;\n  padding: 3px;\n  margin: 2px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImVsYS1jcm9ub2dyYW1hLWxpc3QuY29tcG9uZW50LnNjc3MiLCIuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXEJja0RlbGwlMjAlMjAxNSUyMDU1MDBcXGVcXFBST1lFQ1RPU1xcaWJub3JjYVxcaWJub3JjYS1wd2FcXGlibm9yY2EtcHdhXFxpYm5vcmNhX3VpXFxzcmNcXGFwcFxcY29tcG9uZW50c1xcZWxhLWNyb25vZ3JhbWEtbGlzdFxcZWxhLWNyb25vZ3JhbWEtbGlzdC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGVBQUE7RUFDQSx1QkFBQTtBQ0NGOztBRENBO0VBQ0Usa0JBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0FDRUY7O0FEQUE7RUFDRSxXQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtBQ0dGIiwiZmlsZSI6ImVsYS1jcm9ub2dyYW1hLWxpc3QuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc3ViLXRpdGxlLWhvcmFyaW8ge1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxuICBmb250LWZhbWlseTogc2Fucy1zZXJpZjtcclxufVxyXG4ucGFyYWdyYXBoLWhvcmFyaW8ge1xyXG4gIGZvbnQtc3R5bGU6IGl0YWxpYztcclxuICBmb250LXNpemU6IDEzcHg7XHJcbiAgY29sb3I6IHJnYig1LCAyLCA0Nik7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgcGFkZGluZzogMXB4O1xyXG59XHJcbi5yb3ctY3Jvbm9nYW1hIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMjQ1LCAyMTQsIDIxNCk7XHJcbiAgcGFkZGluZzogM3B4O1xyXG4gIG1hcmdpbjogMnB4O1xyXG59XHJcbiIsIi5zdWItdGl0bGUtaG9yYXJpbyB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XG59XG5cbi5wYXJhZ3JhcGgtaG9yYXJpbyB7XG4gIGZvbnQtc3R5bGU6IGl0YWxpYztcbiAgZm9udC1zaXplOiAxM3B4O1xuICBjb2xvcjogIzA1MDIyZTtcbiAgZGlzcGxheTogYmxvY2s7XG4gIHBhZGRpbmc6IDFweDtcbn1cblxuLnJvdy1jcm9ub2dhbWEge1xuICB3aWR0aDogMTAwJTtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y1ZDZkNjtcbiAgcGFkZGluZzogM3B4O1xuICBtYXJnaW46IDJweDtcbn0iXX0= */";

/***/ }),

/***/ 2291:
/*!************************************************************************************!*\
  !*** ./src/app/components/ela-cronograma/ela-cronograma.component.scss?ngResource ***!
  \************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".container-product {\n  width: 80%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImVsYS1jcm9ub2dyYW1hLmNvbXBvbmVudC5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFxCY2tEZWxsJTIwJTIwMTUlMjA1NTAwXFxlXFxQUk9ZRUNUT1NcXGlibm9yY2FcXGlibm9yY2EtcHdhXFxpYm5vcmNhLXB3YVxcaWJub3JjYV91aVxcc3JjXFxhcHBcXGNvbXBvbmVudHNcXGVsYS1jcm9ub2dyYW1hXFxlbGEtY3Jvbm9ncmFtYS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFVBQUE7QUNDSiIsImZpbGUiOiJlbGEtY3Jvbm9ncmFtYS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXItcHJvZHVjdHtcclxuICAgIHdpZHRoOiA4MCU7XHJcbn1cclxuIiwiLmNvbnRhaW5lci1wcm9kdWN0IHtcbiAgd2lkdGg6IDgwJTtcbn0iXX0= */";

/***/ }),

/***/ 612:
/*!**********************************************************************************************************!*\
  !*** ./src/app/components/ela-edit-areapreocupacion/ela-edit-areapreocupacion.component.scss?ngResource ***!
  \**********************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlbGEtZWRpdC1hcmVhcHJlb2N1cGFjaW9uLmNvbXBvbmVudC5zY3NzIn0= */";

/***/ }),

/***/ 9967:
/*!********************************************************************************************!*\
  !*** ./src/app/components/ela-edit-hallazago/ela-edit-hallazago.component.scss?ngResource ***!
  \********************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlbGEtZWRpdC1oYWxsYXphZ28uY29tcG9uZW50LnNjc3MifQ== */";

/***/ }),

/***/ 5881:
/*!**********************************************************************************!*\
  !*** ./src/app/components/ela-objetivos/ela-objetivos.component.scss?ngResource ***!
  \**********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlbGEtb2JqZXRpdm9zLmNvbXBvbmVudC5zY3NzIn0= */";

/***/ }),

/***/ 1516:
/*!******************************************************************************************!*\
  !*** ./src/app/components/ela-plan-muestreo/ela-plan-muestreo.component.scss?ngResource ***!
  \******************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJlbGEtcGxhbi1tdWVzdHJlby5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 7979:
/*!******************************************************************************************************************!*\
  !*** ./src/app/components/ela-registro-areapreocupacion/ela-registro-areapreocupacion.component.scss?ngResource ***!
  \******************************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".normas {\n  font-size: 12px;\n  color: #1b192c;\n}\n\n.title-normas {\n  color: #0b480f;\n  font-size: 1em;\n  text-align: left;\n}\n\n.norma-block {\n  background-color: #c6e8e6;\n  padding: 10px;\n  margin: 1.5px;\n  min-width: 100%;\n}\n\n.big-icon {\n  font-size: 2em;\n  margin-left: 3px;\n  cursor: grab;\n}\n\n.detail-paragraph {\n  font-size: 11px;\n  color: #3d3c44;\n}\n\n.sub-title {\n  /*font-style: italic;*/\n  font-size: 13px;\n  color: #055a0f;\n  font-family: sans-serif;\n}\n\n.sub-title-horario {\n  /*font-style: italic;*/\n  font-size: 13px;\n  color: #dfd0f2;\n  font-family: sans-serif;\n}\n\n.direccion-block {\n  background-color: #c1ebd6;\n  padding: 10px;\n  margin: 1.5px;\n  min-width: 100%;\n}\n\n.horario-block {\n  background-color: #1c1118;\n  padding: 20px;\n  margin: 0.5px;\n  min-width: 100%;\n}\n\n.horario-block p {\n  color: #c6e8e6;\n}\n\n.titles {\n  font-style: italic;\n  font-weight: 300;\n  font-size: 18px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImVsYS1yZWdpc3Ryby1hcmVhcHJlb2N1cGFjaW9uLmNvbXBvbmVudC5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFxCY2tEZWxsJTIwJTIwMTUlMjA1NTAwXFxlXFxQUk9ZRUNUT1NcXGlibm9yY2FcXGlibm9yY2EtcHdhXFxpYm5vcmNhLXB3YVxcaWJub3JjYV91aVxcc3JjXFxhcHBcXGNvbXBvbmVudHNcXGVsYS1yZWdpc3Ryby1hcmVhcHJlb2N1cGFjaW9uXFxlbGEtcmVnaXN0cm8tYXJlYXByZW9jdXBhY2lvbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGVBQUE7RUFDQSxjQUFBO0FDQ0o7O0FEQ0U7RUFDRSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0FDRUo7O0FEQUU7RUFDRSx5QkFBQTtFQUNBLGFBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtBQ0dKOztBRERFO0VBQ0UsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtBQ0lKOztBREZFO0VBQ0UsZUFBQTtFQUNBLGNBQUE7QUNLSjs7QURIRTtFQUNFLHNCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSx1QkFBQTtBQ01KOztBREhFO0VBQ0Usc0JBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLHVCQUFBO0FDTUo7O0FESkU7RUFDRSx5QkFBQTtFQUNBLGFBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtBQ09KOztBRExFO0VBQ0UseUJBQUE7RUFDQSxhQUFBO0VBQ0EsYUFBQTtFQUNBLGVBQUE7QUNRSjs7QURORTtFQUNFLGNBQUE7QUNTSjs7QURQRTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FDVUoiLCJmaWxlIjoiZWxhLXJlZ2lzdHJvLWFyZWFwcmVvY3VwYWNpb24uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubm9ybWFzIHtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIGNvbG9yOiAjMWIxOTJjO1xyXG4gIH1cclxuICAudGl0bGUtbm9ybWFzIHtcclxuICAgIGNvbG9yOiAjMGI0ODBmO1xyXG4gICAgZm9udC1zaXplOiAxZW07XHJcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gIH1cclxuICAubm9ybWEtYmxvY2sge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2M2ZThlNjtcclxuICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICBtYXJnaW46IDEuNXB4O1xyXG4gICAgbWluLXdpZHRoOiAxMDAlO1xyXG4gIH1cclxuICAuYmlnLWljb24ge1xyXG4gICAgZm9udC1zaXplOiAyZW07XHJcbiAgICBtYXJnaW4tbGVmdDogM3B4O1xyXG4gICAgY3Vyc29yOiBncmFiO1xyXG4gIH1cclxuICAuZGV0YWlsLXBhcmFncmFwaCB7XHJcbiAgICBmb250LXNpemU6IDExcHg7XHJcbiAgICBjb2xvcjogIzNkM2M0NDtcclxuICB9XHJcbiAgLnN1Yi10aXRsZSB7XHJcbiAgICAvKmZvbnQtc3R5bGU6IGl0YWxpYzsqL1xyXG4gICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgY29sb3I6ICMwNTVhMGY7XHJcbiAgICBmb250LWZhbWlseTogc2Fucy1zZXJpZjtcclxuICB9XHJcbiAgXHJcbiAgLnN1Yi10aXRsZS1ob3JhcmlvIHtcclxuICAgIC8qZm9udC1zdHlsZTogaXRhbGljOyovXHJcbiAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICBjb2xvcjogI2RmZDBmMjtcclxuICAgIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xyXG4gIH1cclxuICAuZGlyZWNjaW9uLWJsb2NrIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNjMWViZDY7XHJcbiAgICBwYWRkaW5nOiAxMHB4O1xyXG4gICAgbWFyZ2luOiAxLjVweDtcclxuICAgIG1pbi13aWR0aDogMTAwJTtcclxuICB9XHJcbiAgLmhvcmFyaW8tYmxvY2sge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzFjMTExODtcclxuICAgIHBhZGRpbmc6IDIwcHg7XHJcbiAgICBtYXJnaW46IDAuNXB4O1xyXG4gICAgbWluLXdpZHRoOiAxMDAlO1xyXG4gIH1cclxuICAuaG9yYXJpby1ibG9jayBwe1xyXG4gICAgY29sb3I6ICNjNmU4ZTY7XHJcbiAgfVxyXG4gIC50aXRsZXMge1xyXG4gICAgZm9udC1zdHlsZTogaXRhbGljO1xyXG4gICAgZm9udC13ZWlnaHQ6IDMwMDtcclxuICAgIGZvbnQtc2l6ZTogMThweDtcclxuICB9XHJcbiAgIiwiLm5vcm1hcyB7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgY29sb3I6ICMxYjE5MmM7XG59XG5cbi50aXRsZS1ub3JtYXMge1xuICBjb2xvcjogIzBiNDgwZjtcbiAgZm9udC1zaXplOiAxZW07XG4gIHRleHQtYWxpZ246IGxlZnQ7XG59XG5cbi5ub3JtYS1ibG9jayB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNjNmU4ZTY7XG4gIHBhZGRpbmc6IDEwcHg7XG4gIG1hcmdpbjogMS41cHg7XG4gIG1pbi13aWR0aDogMTAwJTtcbn1cblxuLmJpZy1pY29uIHtcbiAgZm9udC1zaXplOiAyZW07XG4gIG1hcmdpbi1sZWZ0OiAzcHg7XG4gIGN1cnNvcjogZ3JhYjtcbn1cblxuLmRldGFpbC1wYXJhZ3JhcGgge1xuICBmb250LXNpemU6IDExcHg7XG4gIGNvbG9yOiAjM2QzYzQ0O1xufVxuXG4uc3ViLXRpdGxlIHtcbiAgLypmb250LXN0eWxlOiBpdGFsaWM7Ki9cbiAgZm9udC1zaXplOiAxM3B4O1xuICBjb2xvcjogIzA1NWEwZjtcbiAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XG59XG5cbi5zdWItdGl0bGUtaG9yYXJpbyB7XG4gIC8qZm9udC1zdHlsZTogaXRhbGljOyovXG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgY29sb3I6ICNkZmQwZjI7XG4gIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xufVxuXG4uZGlyZWNjaW9uLWJsb2NrIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2MxZWJkNjtcbiAgcGFkZGluZzogMTBweDtcbiAgbWFyZ2luOiAxLjVweDtcbiAgbWluLXdpZHRoOiAxMDAlO1xufVxuXG4uaG9yYXJpby1ibG9jayB7XG4gIGJhY2tncm91bmQtY29sb3I6ICMxYzExMTg7XG4gIHBhZGRpbmc6IDIwcHg7XG4gIG1hcmdpbjogMC41cHg7XG4gIG1pbi13aWR0aDogMTAwJTtcbn1cblxuLmhvcmFyaW8tYmxvY2sgcCB7XG4gIGNvbG9yOiAjYzZlOGU2O1xufVxuXG4udGl0bGVzIHtcbiAgZm9udC1zdHlsZTogaXRhbGljO1xuICBmb250LXdlaWdodDogMzAwO1xuICBmb250LXNpemU6IDE4cHg7XG59Il19 */";

/***/ }),

/***/ 6169:
/*!****************************************************************************************************!*\
  !*** ./src/app/components/ela-registro-hallazgos/ela-registro-hallazgos.component.scss?ngResource ***!
  \****************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".normas {\n  font-size: 12px;\n  color: #1b192c;\n}\n\n.title-normas {\n  color: #0b480f;\n  font-size: 1em;\n  text-align: left;\n}\n\n.norma-block {\n  background-color: #c6e8e6;\n  padding: 10px;\n  margin: 1.5px;\n  min-width: 100%;\n}\n\n.big-icon {\n  font-size: 2em;\n  margin-left: 3px;\n  cursor: grab;\n}\n\n.detail-paragraph {\n  font-size: 11px;\n  color: #3d3c44;\n}\n\n.sub-title {\n  /*font-style: italic;*/\n  font-size: 13px;\n  color: #055a0f;\n  font-family: sans-serif;\n}\n\n.sub-title-horario {\n  /*font-style: italic;*/\n  font-size: 13px;\n  color: #dfd0f2;\n  font-family: sans-serif;\n}\n\n.direccion-block {\n  background-color: #c1ebd6;\n  padding: 10px;\n  margin: 1.5px;\n  min-width: 100%;\n}\n\n.horario-block {\n  background-color: #1c1118;\n  padding: 20px;\n  margin: 0.5px;\n  min-width: 100%;\n}\n\n.horario-block p {\n  color: #c6e8e6;\n}\n\n.titles {\n  font-style: italic;\n  font-weight: 300;\n  font-size: 18px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImVsYS1yZWdpc3Ryby1oYWxsYXpnb3MuY29tcG9uZW50LnNjc3MiLCIuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXEJja0RlbGwlMjAlMjAxNSUyMDU1MDBcXGVcXFBST1lFQ1RPU1xcaWJub3JjYVxcaWJub3JjYS1wd2FcXGlibm9yY2EtcHdhXFxpYm5vcmNhX3VpXFxzcmNcXGFwcFxcY29tcG9uZW50c1xcZWxhLXJlZ2lzdHJvLWhhbGxhemdvc1xcZWxhLXJlZ2lzdHJvLWhhbGxhemdvcy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGVBQUE7RUFDQSxjQUFBO0FDQ0o7O0FEQ0U7RUFDRSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0FDRUo7O0FEQUU7RUFDRSx5QkFBQTtFQUNBLGFBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtBQ0dKOztBRERFO0VBQ0UsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtBQ0lKOztBREZFO0VBQ0UsZUFBQTtFQUNBLGNBQUE7QUNLSjs7QURIRTtFQUNFLHNCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSx1QkFBQTtBQ01KOztBREhFO0VBQ0Usc0JBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLHVCQUFBO0FDTUo7O0FESkU7RUFDRSx5QkFBQTtFQUNBLGFBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtBQ09KOztBRExFO0VBQ0UseUJBQUE7RUFDQSxhQUFBO0VBQ0EsYUFBQTtFQUNBLGVBQUE7QUNRSjs7QURORTtFQUNFLGNBQUE7QUNTSjs7QURQRTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FDVUoiLCJmaWxlIjoiZWxhLXJlZ2lzdHJvLWhhbGxhemdvcy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5ub3JtYXMge1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgY29sb3I6ICMxYjE5MmM7XHJcbiAgfVxyXG4gIC50aXRsZS1ub3JtYXMge1xyXG4gICAgY29sb3I6ICMwYjQ4MGY7XHJcbiAgICBmb250LXNpemU6IDFlbTtcclxuICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgfVxyXG4gIC5ub3JtYS1ibG9jayB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjYzZlOGU2O1xyXG4gICAgcGFkZGluZzogMTBweDtcclxuICAgIG1hcmdpbjogMS41cHg7XHJcbiAgICBtaW4td2lkdGg6IDEwMCU7XHJcbiAgfVxyXG4gIC5iaWctaWNvbiB7XHJcbiAgICBmb250LXNpemU6IDJlbTtcclxuICAgIG1hcmdpbi1sZWZ0OiAzcHg7XHJcbiAgICBjdXJzb3I6IGdyYWI7XHJcbiAgfVxyXG4gIC5kZXRhaWwtcGFyYWdyYXBoIHtcclxuICAgIGZvbnQtc2l6ZTogMTFweDtcclxuICAgIGNvbG9yOiAjM2QzYzQ0O1xyXG4gIH1cclxuICAuc3ViLXRpdGxlIHtcclxuICAgIC8qZm9udC1zdHlsZTogaXRhbGljOyovXHJcbiAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICBjb2xvcjogIzA1NWEwZjtcclxuICAgIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xyXG4gIH1cclxuICBcclxuICAuc3ViLXRpdGxlLWhvcmFyaW8ge1xyXG4gICAgLypmb250LXN0eWxlOiBpdGFsaWM7Ki9cclxuICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgIGNvbG9yOiAjZGZkMGYyO1xyXG4gICAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XHJcbiAgfVxyXG4gIC5kaXJlY2Npb24tYmxvY2sge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2MxZWJkNjtcclxuICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICBtYXJnaW46IDEuNXB4O1xyXG4gICAgbWluLXdpZHRoOiAxMDAlO1xyXG4gIH1cclxuICAuaG9yYXJpby1ibG9jayB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMWMxMTE4O1xyXG4gICAgcGFkZGluZzogMjBweDtcclxuICAgIG1hcmdpbjogMC41cHg7XHJcbiAgICBtaW4td2lkdGg6IDEwMCU7XHJcbiAgfVxyXG4gIC5ob3JhcmlvLWJsb2NrIHB7XHJcbiAgICBjb2xvcjogI2M2ZThlNjtcclxuICB9XHJcbiAgLnRpdGxlcyB7XHJcbiAgICBmb250LXN0eWxlOiBpdGFsaWM7XHJcbiAgICBmb250LXdlaWdodDogMzAwO1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG4gIH1cclxuICAiLCIubm9ybWFzIHtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBjb2xvcjogIzFiMTkyYztcbn1cblxuLnRpdGxlLW5vcm1hcyB7XG4gIGNvbG9yOiAjMGI0ODBmO1xuICBmb250LXNpemU6IDFlbTtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbn1cblxuLm5vcm1hLWJsb2NrIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2M2ZThlNjtcbiAgcGFkZGluZzogMTBweDtcbiAgbWFyZ2luOiAxLjVweDtcbiAgbWluLXdpZHRoOiAxMDAlO1xufVxuXG4uYmlnLWljb24ge1xuICBmb250LXNpemU6IDJlbTtcbiAgbWFyZ2luLWxlZnQ6IDNweDtcbiAgY3Vyc29yOiBncmFiO1xufVxuXG4uZGV0YWlsLXBhcmFncmFwaCB7XG4gIGZvbnQtc2l6ZTogMTFweDtcbiAgY29sb3I6ICMzZDNjNDQ7XG59XG5cbi5zdWItdGl0bGUge1xuICAvKmZvbnQtc3R5bGU6IGl0YWxpYzsqL1xuICBmb250LXNpemU6IDEzcHg7XG4gIGNvbG9yOiAjMDU1YTBmO1xuICBmb250LWZhbWlseTogc2Fucy1zZXJpZjtcbn1cblxuLnN1Yi10aXRsZS1ob3JhcmlvIHtcbiAgLypmb250LXN0eWxlOiBpdGFsaWM7Ki9cbiAgZm9udC1zaXplOiAxM3B4O1xuICBjb2xvcjogI2RmZDBmMjtcbiAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XG59XG5cbi5kaXJlY2Npb24tYmxvY2sge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjYzFlYmQ2O1xuICBwYWRkaW5nOiAxMHB4O1xuICBtYXJnaW46IDEuNXB4O1xuICBtaW4td2lkdGg6IDEwMCU7XG59XG5cbi5ob3JhcmlvLWJsb2NrIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzFjMTExODtcbiAgcGFkZGluZzogMjBweDtcbiAgbWFyZ2luOiAwLjVweDtcbiAgbWluLXdpZHRoOiAxMDAlO1xufVxuXG4uaG9yYXJpby1ibG9jayBwIHtcbiAgY29sb3I6ICNjNmU4ZTY7XG59XG5cbi50aXRsZXMge1xuICBmb250LXN0eWxlOiBpdGFsaWM7XG4gIGZvbnQtd2VpZ2h0OiAzMDA7XG4gIGZvbnQtc2l6ZTogMThweDtcbn0iXX0= */";

/***/ }),

/***/ 6923:
/*!**************************************************************************************************************!*\
  !*** ./src/app/components/lista-verificacion-apertura/lista-verificacion-apertura.component.scss?ngResource ***!
  \**************************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJsaXN0YS12ZXJpZmljYWNpb24tYXBlcnR1cmEuY29tcG9uZW50LnNjc3MifQ== */";

/***/ }),

/***/ 3420:
/*!******************************************************************!*\
  !*** ./src/app/components/meses/meses.component.scss?ngResource ***!
  \******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtZXNlcy5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 421:
/*!**********************************************************************************!*\
  !*** ./src/app/components/message-error/message-error.component.scss?ngResource ***!
  \**********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".error-message {\n  color: #fcfcfc;\n}\n\n.container-error {\n  background-color: rgba(221, 19, 19, 0.953) !important;\n  display: block;\n  padding-left: 2em;\n  padding-top: 2px;\n  padding-bottom: 2px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1lc3NhZ2UtZXJyb3IuY29tcG9uZW50LnNjc3MiLCIuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXEJja0RlbGwlMjAlMjAxNSUyMDU1MDBcXGVcXFBST1lFQ1RPU1xcaWJub3JjYVxcaWJub3JjYS1wd2FcXGlibm9yY2EtcHdhXFxpYm5vcmNhX3VpXFxzcmNcXGFwcFxcY29tcG9uZW50c1xcbWVzc2FnZS1lcnJvclxcbWVzc2FnZS1lcnJvci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGNBQUE7QUNDSjs7QURDQTtFQUNJLHFEQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtBQ0VKIiwiZmlsZSI6Im1lc3NhZ2UtZXJyb3IuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZXJyb3ItbWVzc2FnZXtcclxuICAgIGNvbG9yOiByZ2IoMjUyLCAyNTIsIDI1Mik7XHJcbn1cclxuLmNvbnRhaW5lci1lcnJvcntcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHJnYmEoMjIxLCAxOSwgMTksIDAuOTUzKSAhaW1wb3J0YW50O1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDJlbTsgICAgXHJcbiAgICBwYWRkaW5nLXRvcDogMnB4O1xyXG4gICAgcGFkZGluZy1ib3R0b206IDJweDtcclxufVxyXG4iLCIuZXJyb3ItbWVzc2FnZSB7XG4gIGNvbG9yOiAjZmNmY2ZjO1xufVxuXG4uY29udGFpbmVyLWVycm9yIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiYSgyMjEsIDE5LCAxOSwgMC45NTMpICFpbXBvcnRhbnQ7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBwYWRkaW5nLWxlZnQ6IDJlbTtcbiAgcGFkZGluZy10b3A6IDJweDtcbiAgcGFkZGluZy1ib3R0b206IDJweDtcbn0iXX0= */";

/***/ }),

/***/ 282:
/*!****************************************************************************************!*\
  !*** ./src/app/components/param-documentos/param-documentos.component.scss?ngResource ***!
  \****************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".icon {\n  margin: 1px;\n  cursor: grab;\n  color: #0e12d1;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBhcmFtLWRvY3VtZW50b3MuY29tcG9uZW50LnNjc3MiLCIuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXEJja0RlbGwlMjAlMjAxNSUyMDU1MDBcXGVcXFBST1lFQ1RPU1xcaWJub3JjYVxcaWJub3JjYS1wd2FcXGlibm9yY2EtcHdhXFxpYm5vcmNhX3VpXFxzcmNcXGFwcFxcY29tcG9uZW50c1xccGFyYW0tZG9jdW1lbnRvc1xccGFyYW0tZG9jdW1lbnRvcy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsY0FBQTtBQ0NKIiwiZmlsZSI6InBhcmFtLWRvY3VtZW50b3MuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaWNvbiB7ICAgIFxyXG4gICAgbWFyZ2luOiAxcHg7XHJcbiAgICBjdXJzb3I6IGdyYWI7XHJcbiAgICBjb2xvcjogcmdiKDE0LCAxOCwgMjA5KTtcclxuICB9IiwiLmljb24ge1xuICBtYXJnaW46IDFweDtcbiAgY3Vyc29yOiBncmFiO1xuICBjb2xvcjogIzBlMTJkMTtcbn0iXX0= */";

/***/ }),

/***/ 4977:
/*!************************************************************************************!*\
  !*** ./src/app/components/param-horarios/param-horarios.component.scss?ngResource ***!
  \************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwYXJhbS1ob3Jhcmlvcy5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 4242:
/*!**********************************************************************************************************************!*\
  !*** ./src/app/components/param-organismos-certificadores/param-organismos-certificadores.component.scss?ngResource ***!
  \**********************************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".cargo-select {\n  width: 100%;\n  font-size: 13px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBhcmFtLW9yZ2FuaXNtb3MtY2VydGlmaWNhZG9yZXMuY29tcG9uZW50LnNjc3MiLCIuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXEJja0RlbGwlMjAlMjAxNSUyMDU1MDBcXGVcXFBST1lFQ1RPU1xcaWJub3JjYVxcaWJub3JjYS1wd2FcXGlibm9yY2EtcHdhXFxpYm5vcmNhX3VpXFxzcmNcXGFwcFxcY29tcG9uZW50c1xccGFyYW0tb3JnYW5pc21vcy1jZXJ0aWZpY2Fkb3Jlc1xccGFyYW0tb3JnYW5pc21vcy1jZXJ0aWZpY2Fkb3Jlcy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7RUFDQSxlQUFBO0FDQ0oiLCJmaWxlIjoicGFyYW0tb3JnYW5pc21vcy1jZXJ0aWZpY2Fkb3Jlcy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jYXJnby1zZWxlY3R7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGZvbnQtc2l6ZTogMTNweDtcclxufSIsIi5jYXJnby1zZWxlY3Qge1xuICB3aWR0aDogMTAwJTtcbiAgZm9udC1zaXplOiAxM3B4O1xufSJdfQ== */";

/***/ }),

/***/ 9909:
/*!********************************************************************************!*\
  !*** ./src/app/components/param-paises/param-paises.component.scss?ngResource ***!
  \********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwYXJhbS1wYWlzZXMuY29tcG9uZW50LnNjc3MifQ== */";

/***/ }),

/***/ 2586:
/*!************************************************************************************!*\
  !*** ./src/app/components/plan-auditoria/plan-auditoria.component.scss?ngResource ***!
  \************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".ciclo-header {\n  background-color: #3bb8bd;\n  color: #e626d6;\n  font-weight: 300;\n  font-size: 16px;\n}\n\n.slider .slider-pager {\n  color: blue;\n}\n\n.slide-full {\n  width: 100% !important;\n}\n\n.avatar {\n  width: 50px;\n  display: block;\n  margin-left: auto;\n  margin-right: auto;\n}\n\nion-card-content {\n  text-align: left;\n}\n\n.ion-content-small-font {\n  font-family: \"Calibri Light\";\n  font-size: 12px;\n  color: #093537;\n}\n\n.container-detail-auditoria {\n  width: 100%;\n}\n\n.container-detail-certificacion {\n  margin-bottom: 15px;\n}\n\n.buttons-group {\n  margin-top: 5px;\n}\n\n.title-medium-font {\n  font-family: \"Courier New\";\n  font-weight: bold;\n}\n\n.big-icon {\n  font-size: 1.2em;\n  margin-left: 3px;\n  cursor: grab;\n}\n\n.box-click {\n  min-width: 100px;\n  min-height: 20px;\n  border-bottom: solid;\n  border-color: #778e8f;\n  border-width: 1px;\n  padding: 2px;\n  margin-left: 3px;\n  display: inline-block;\n}\n\n.edit-item {\n  cursor: grab;\n}\n\n.edit-item:hover {\n  background-color: #9dd8dc;\n}\n\n.small-item {\n  font-size: 13px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBsYW4tYXVkaXRvcmlhLmNvbXBvbmVudC5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFxCY2tEZWxsJTIwJTIwMTUlMjA1NTAwXFxlXFxQUk9ZRUNUT1NcXGlibm9yY2FcXGlibm9yY2EtcHdhXFxpYm5vcmNhLXB3YVxcaWJub3JjYV91aVxcc3JjXFxhcHBcXGNvbXBvbmVudHNcXHBsYW4tYXVkaXRvcmlhXFxwbGFuLWF1ZGl0b3JpYS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHlCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQ0NGOztBRENBO0VBQ0UsV0FBQTtBQ0VGOztBREFBO0VBQ0Usc0JBQUE7QUNHRjs7QURBQTtFQUNFLFdBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtBQ0dGOztBRERBO0VBQ0UsZ0JBQUE7QUNJRjs7QUREQTtFQUNFLDRCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUNJRjs7QURGQTtFQUNFLFdBQUE7QUNLRjs7QURIQTtFQUNFLG1CQUFBO0FDTUY7O0FESkE7RUFDRSxlQUFBO0FDT0Y7O0FETEE7RUFDRSwwQkFBQTtFQUNBLGlCQUFBO0FDUUY7O0FETkE7RUFDRSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtBQ1NGOztBRFBBO0VBQ0UsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLG9CQUFBO0VBQ0EscUJBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLHFCQUFBO0FDVUY7O0FEUkE7RUFDRSxZQUFBO0FDV0Y7O0FEVEE7RUFDRSx5QkFBQTtBQ1lGOztBRFRBO0VBQ0UsZUFBQTtBQ1lGIiwiZmlsZSI6InBsYW4tYXVkaXRvcmlhLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNpY2xvLWhlYWRlciB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzNiYjhiZDtcclxuICBjb2xvcjogI2U2MjZkNjtcclxuICBmb250LXdlaWdodDogMzAwO1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxufVxyXG4uc2xpZGVyIC5zbGlkZXItcGFnZXIge1xyXG4gIGNvbG9yOiBibHVlO1xyXG59XHJcbi5zbGlkZS1mdWxsIHtcclxuICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uYXZhdGFyIHtcclxuICB3aWR0aDogNTBweDtcclxuICBkaXNwbGF5OiBibG9jaztcclxuICBtYXJnaW4tbGVmdDogYXV0bztcclxuICBtYXJnaW4tcmlnaHQ6IGF1dG87XHJcbn1cclxuaW9uLWNhcmQtY29udGVudCB7XHJcbiAgdGV4dC1hbGlnbjogbGVmdDtcclxufVxyXG5cclxuLmlvbi1jb250ZW50LXNtYWxsLWZvbnQge1xyXG4gIGZvbnQtZmFtaWx5OiBcIkNhbGlicmkgTGlnaHRcIjtcclxuICBmb250LXNpemU6IDEycHg7XHJcbiAgY29sb3I6ICMwOTM1Mzc7XHJcbn1cclxuLmNvbnRhaW5lci1kZXRhaWwtYXVkaXRvcmlhIHtcclxuICB3aWR0aDogMTAwJTtcclxufVxyXG4uY29udGFpbmVyLWRldGFpbC1jZXJ0aWZpY2FjaW9uIHtcclxuICBtYXJnaW4tYm90dG9tOiAxNXB4O1xyXG59XHJcbi5idXR0b25zLWdyb3VwIHtcclxuICBtYXJnaW4tdG9wOiA1cHg7XHJcbn1cclxuLnRpdGxlLW1lZGl1bS1mb250IHtcclxuICBmb250LWZhbWlseTogXCJDb3VyaWVyIE5ld1wiO1xyXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG59XHJcbi5iaWctaWNvbiB7XHJcbiAgZm9udC1zaXplOiAxLjJlbTtcclxuICBtYXJnaW4tbGVmdDogM3B4O1xyXG4gIGN1cnNvcjogZ3JhYjtcclxufVxyXG4uYm94LWNsaWNrIHtcclxuICBtaW4td2lkdGg6IDEwMHB4O1xyXG4gIG1pbi1oZWlnaHQ6IDIwcHg7XHJcbiAgYm9yZGVyLWJvdHRvbTogc29saWQ7XHJcbiAgYm9yZGVyLWNvbG9yOiAjNzc4ZThmO1xyXG4gIGJvcmRlci13aWR0aDogMXB4O1xyXG4gIHBhZGRpbmc6IDJweDtcclxuICBtYXJnaW4tbGVmdDogM3B4O1xyXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxufVxyXG4uZWRpdC1pdGVtIHtcclxuICBjdXJzb3I6IGdyYWI7XHJcbn1cclxuLmVkaXQtaXRlbTpob3ZlciB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzlkZDhkYztcclxufVxyXG5cclxuLnNtYWxsLWl0ZW0ge1xyXG4gIGZvbnQtc2l6ZTogMTNweDtcclxufVxyXG4iLCIuY2ljbG8taGVhZGVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzNiYjhiZDtcbiAgY29sb3I6ICNlNjI2ZDY7XG4gIGZvbnQtd2VpZ2h0OiAzMDA7XG4gIGZvbnQtc2l6ZTogMTZweDtcbn1cblxuLnNsaWRlciAuc2xpZGVyLXBhZ2VyIHtcbiAgY29sb3I6IGJsdWU7XG59XG5cbi5zbGlkZS1mdWxsIHtcbiAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcbn1cblxuLmF2YXRhciB7XG4gIHdpZHRoOiA1MHB4O1xuICBkaXNwbGF5OiBibG9jaztcbiAgbWFyZ2luLWxlZnQ6IGF1dG87XG4gIG1hcmdpbi1yaWdodDogYXV0bztcbn1cblxuaW9uLWNhcmQtY29udGVudCB7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG59XG5cbi5pb24tY29udGVudC1zbWFsbC1mb250IHtcbiAgZm9udC1mYW1pbHk6IFwiQ2FsaWJyaSBMaWdodFwiO1xuICBmb250LXNpemU6IDEycHg7XG4gIGNvbG9yOiAjMDkzNTM3O1xufVxuXG4uY29udGFpbmVyLWRldGFpbC1hdWRpdG9yaWEge1xuICB3aWR0aDogMTAwJTtcbn1cblxuLmNvbnRhaW5lci1kZXRhaWwtY2VydGlmaWNhY2lvbiB7XG4gIG1hcmdpbi1ib3R0b206IDE1cHg7XG59XG5cbi5idXR0b25zLWdyb3VwIHtcbiAgbWFyZ2luLXRvcDogNXB4O1xufVxuXG4udGl0bGUtbWVkaXVtLWZvbnQge1xuICBmb250LWZhbWlseTogXCJDb3VyaWVyIE5ld1wiO1xuICBmb250LXdlaWdodDogYm9sZDtcbn1cblxuLmJpZy1pY29uIHtcbiAgZm9udC1zaXplOiAxLjJlbTtcbiAgbWFyZ2luLWxlZnQ6IDNweDtcbiAgY3Vyc29yOiBncmFiO1xufVxuXG4uYm94LWNsaWNrIHtcbiAgbWluLXdpZHRoOiAxMDBweDtcbiAgbWluLWhlaWdodDogMjBweDtcbiAgYm9yZGVyLWJvdHRvbTogc29saWQ7XG4gIGJvcmRlci1jb2xvcjogIzc3OGU4ZjtcbiAgYm9yZGVyLXdpZHRoOiAxcHg7XG4gIHBhZGRpbmc6IDJweDtcbiAgbWFyZ2luLWxlZnQ6IDNweDtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xufVxuXG4uZWRpdC1pdGVtIHtcbiAgY3Vyc29yOiBncmFiO1xufVxuXG4uZWRpdC1pdGVtOmhvdmVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzlkZDhkYztcbn1cblxuLnNtYWxsLWl0ZW0ge1xuICBmb250LXNpemU6IDEzcHg7XG59Il19 */";

/***/ }),

/***/ 2627:
/*!************************************************************************************!*\
  !*** ./src/app/components/pra-cronograma/pra-cronograma.component.scss?ngResource ***!
  \************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".label-cronograma {\n  font-weight: bold;\n  font-size: 12px;\n}\n\n.data-cronograma {\n  font-style: italic;\n  font-size: 13px;\n}\n\n.ion-content-small-font {\n  font-family: \"Calibri Light\";\n  font-size: 12px;\n  color: #093537;\n}\n\n.title-medium-font {\n  font-family: \"Courier New\";\n  font-weight: bold;\n}\n\nion-card-content {\n  text-align: left;\n}\n\n.box-click {\n  min-width: 100px;\n  min-height: 20px;\n  border-bottom: solid;\n  border-color: #778e8f;\n  border-width: 1px;\n  padding: 2px;\n  margin-left: 3px;\n  display: inline-block;\n}\n\n.edit-item {\n  cursor: grab;\n}\n\n.edit-item:hover {\n  background-color: #9dd8dc;\n}\n\n.item-cronograma {\n  display: block;\n  margin-bottom: 4px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByYS1jcm9ub2dyYW1hLmNvbXBvbmVudC5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFxCY2tEZWxsJTIwJTIwMTUlMjA1NTAwXFxlXFxQUk9ZRUNUT1NcXGlibm9yY2FcXGlibm9yY2EtcHdhXFxpYm5vcmNhLXB3YVxcaWJub3JjYV91aVxcc3JjXFxhcHBcXGNvbXBvbmVudHNcXHByYS1jcm9ub2dyYW1hXFxwcmEtY3Jvbm9ncmFtYS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGlCQUFBO0VBQ0EsZUFBQTtBQ0NGOztBRENBO0VBQ0Usa0JBQUE7RUFDQSxlQUFBO0FDRUY7O0FEQUE7RUFDRSw0QkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0FDR0Y7O0FEREE7RUFDRSwwQkFBQTtFQUNBLGlCQUFBO0FDSUY7O0FERkE7RUFDRSxnQkFBQTtBQ0tGOztBREhBO0VBQ0UsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLG9CQUFBO0VBQ0EscUJBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLHFCQUFBO0FDTUY7O0FESkE7RUFDRSxZQUFBO0FDT0Y7O0FETEE7RUFDRSx5QkFBQTtBQ1FGOztBRE5BO0VBQ0UsY0FBQTtFQUNBLGtCQUFBO0FDU0YiLCJmaWxlIjoicHJhLWNyb25vZ3JhbWEuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubGFiZWwtY3Jvbm9ncmFtYSB7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgZm9udC1zaXplOiAxMnB4O1xyXG59XHJcbi5kYXRhLWNyb25vZ3JhbWEge1xyXG4gIGZvbnQtc3R5bGU6IGl0YWxpYztcclxuICBmb250LXNpemU6IDEzcHg7XHJcbn1cclxuLmlvbi1jb250ZW50LXNtYWxsLWZvbnQge1xyXG4gIGZvbnQtZmFtaWx5OiBcIkNhbGlicmkgTGlnaHRcIjtcclxuICBmb250LXNpemU6IDEycHg7XHJcbiAgY29sb3I6ICMwOTM1Mzc7XHJcbn1cclxuLnRpdGxlLW1lZGl1bS1mb250IHtcclxuICBmb250LWZhbWlseTogXCJDb3VyaWVyIE5ld1wiO1xyXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG59XHJcbmlvbi1jYXJkLWNvbnRlbnQge1xyXG4gIHRleHQtYWxpZ246IGxlZnQ7XHJcbn1cclxuLmJveC1jbGljayB7XHJcbiAgbWluLXdpZHRoOiAxMDBweDtcclxuICBtaW4taGVpZ2h0OiAyMHB4O1xyXG4gIGJvcmRlci1ib3R0b206IHNvbGlkO1xyXG4gIGJvcmRlci1jb2xvcjogIzc3OGU4ZjtcclxuICBib3JkZXItd2lkdGg6IDFweDtcclxuICBwYWRkaW5nOiAycHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDNweDtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbn1cclxuLmVkaXQtaXRlbSB7XHJcbiAgY3Vyc29yOiBncmFiO1xyXG59XHJcbi5lZGl0LWl0ZW06aG92ZXIge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICM5ZGQ4ZGM7XHJcbn1cclxuLml0ZW0tY3Jvbm9ncmFtYSB7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgbWFyZ2luLWJvdHRvbTogNHB4O1xyXG59XHJcbiIsIi5sYWJlbC1jcm9ub2dyYW1hIHtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGZvbnQtc2l6ZTogMTJweDtcbn1cblxuLmRhdGEtY3Jvbm9ncmFtYSB7XG4gIGZvbnQtc3R5bGU6IGl0YWxpYztcbiAgZm9udC1zaXplOiAxM3B4O1xufVxuXG4uaW9uLWNvbnRlbnQtc21hbGwtZm9udCB7XG4gIGZvbnQtZmFtaWx5OiBcIkNhbGlicmkgTGlnaHRcIjtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBjb2xvcjogIzA5MzUzNztcbn1cblxuLnRpdGxlLW1lZGl1bS1mb250IHtcbiAgZm9udC1mYW1pbHk6IFwiQ291cmllciBOZXdcIjtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59XG5cbmlvbi1jYXJkLWNvbnRlbnQge1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xufVxuXG4uYm94LWNsaWNrIHtcbiAgbWluLXdpZHRoOiAxMDBweDtcbiAgbWluLWhlaWdodDogMjBweDtcbiAgYm9yZGVyLWJvdHRvbTogc29saWQ7XG4gIGJvcmRlci1jb2xvcjogIzc3OGU4ZjtcbiAgYm9yZGVyLXdpZHRoOiAxcHg7XG4gIHBhZGRpbmc6IDJweDtcbiAgbWFyZ2luLWxlZnQ6IDNweDtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xufVxuXG4uZWRpdC1pdGVtIHtcbiAgY3Vyc29yOiBncmFiO1xufVxuXG4uZWRpdC1pdGVtOmhvdmVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzlkZDhkYztcbn1cblxuLml0ZW0tY3Jvbm9ncmFtYSB7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBtYXJnaW4tYm90dG9tOiA0cHg7XG59Il19 */";

/***/ }),

/***/ 4346:
/*!**************************************************************************************************!*\
  !*** ./src/app/components/pra-direccion-sistema/pra-direccion-sistema.component.scss?ngResource ***!
  \**************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwcmEtZGlyZWNjaW9uLXNpc3RlbWEuY29tcG9uZW50LnNjc3MifQ== */";

/***/ }),

/***/ 9937:
/*!****************************************************************************************************!*\
  !*** ./src/app/components/pra-edit-norma-sistema/pra-edit-norma-sistema.component.scss?ngResource ***!
  \****************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwcmEtZWRpdC1ub3JtYS1zaXN0ZW1hLmNvbXBvbmVudC5zY3NzIn0= */";

/***/ }),

/***/ 3997:
/*!************************************************************************************!*\
  !*** ./src/app/components/product-detail/product-detail.component.scss?ngResource ***!
  \************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".container-product {\n  width: 80%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2R1Y3QtZGV0YWlsLmNvbXBvbmVudC5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFxCY2tEZWxsJTIwJTIwMTUlMjA1NTAwXFxlXFxQUk9ZRUNUT1NcXGlibm9yY2FcXGlibm9yY2EtcHdhXFxpYm5vcmNhLXB3YVxcaWJub3JjYV91aVxcc3JjXFxhcHBcXGNvbXBvbmVudHNcXHByb2R1Y3QtZGV0YWlsXFxwcm9kdWN0LWRldGFpbC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFVBQUE7QUNDSiIsImZpbGUiOiJwcm9kdWN0LWRldGFpbC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXItcHJvZHVjdHtcclxuICAgIHdpZHRoOiA4MCU7XHJcbn1cclxuIiwiLmNvbnRhaW5lci1wcm9kdWN0IHtcbiAgd2lkdGg6IDgwJTtcbn0iXX0= */";

/***/ }),

/***/ 3050:
/*!************************************************************************************!*\
  !*** ./src/app/components/registro-ciclo/registro-ciclo.component.scss?ngResource ***!
  \************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyZWdpc3Ryby1jaWNsby5jb21wb25lbnQuc2NzcyJ9 */";

/***/ }),

/***/ 7719:
/*!******************************************************************************************!*\
  !*** ./src/app/components/tcp-list-products/tcp-list-products.component.scss?ngResource ***!
  \******************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".container-product-list {\n  margin-top: 0em;\n}\n\n.popover-content.sc-ion-popover-md {\n  width: 500px !important;\n}\n\n.my-custom-modal-css .modal-wrapper {\n  width: 600px;\n  height: 650px !important;\n}\n\n.normas {\n  font-size: 12px;\n  color: #1b192c;\n}\n\n.title-normas {\n  color: #0b480f;\n  font-size: 1em;\n  text-align: left;\n}\n\n.norma-block {\n  background-color: #c6e8e6;\n  padding: 10px;\n  margin: 1.5px;\n  min-width: 100%;\n}\n\n.big-icon {\n  font-size: 1.2em;\n  margin-left: 3px;\n  cursor: grab;\n}\n\n.detail-paragraph {\n  font-size: 11px;\n  color: #3d3c44;\n}\n\n.sub-title {\n  /*font-style: italic;*/\n  font-size: 13px;\n  color: #055a0f;\n  font-family: sans-serif;\n}\n\n.direccion-block {\n  background-color: #c1ebd6;\n  padding: 10px;\n  margin: 1.5px;\n  min-width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRjcC1saXN0LXByb2R1Y3RzLmNvbXBvbmVudC5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFxCY2tEZWxsJTIwJTIwMTUlMjA1NTAwXFxlXFxQUk9ZRUNUT1NcXGlibm9yY2FcXGlibm9yY2EtcHdhXFxpYm5vcmNhLXB3YVxcaWJub3JjYV91aVxcc3JjXFxhcHBcXGNvbXBvbmVudHNcXHRjcC1saXN0LXByb2R1Y3RzXFx0Y3AtbGlzdC1wcm9kdWN0cy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGVBQUE7QUNDRjs7QURDQTtFQUNJLHVCQUFBO0FDRUo7O0FEQ0E7RUFDRSxZQUFBO0VBQ0Esd0JBQUE7QUNFRjs7QURBQTtFQUNFLGVBQUE7RUFDQSxjQUFBO0FDR0Y7O0FEREE7RUFDRSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0FDSUY7O0FERkE7RUFDRSx5QkFBQTtFQUNBLGFBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtBQ0tGOztBREhBO0VBQ0UsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7QUNNRjs7QURKQTtFQUNFLGVBQUE7RUFDQSxjQUFBO0FDT0Y7O0FETEE7RUFDRSxzQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsdUJBQUE7QUNRRjs7QUROQTtFQUNFLHlCQUFBO0VBQ0EsYUFBQTtFQUNBLGFBQUE7RUFDQSxlQUFBO0FDU0YiLCJmaWxlIjoidGNwLWxpc3QtcHJvZHVjdHMuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY29udGFpbmVyLXByb2R1Y3QtbGlzdCB7XHJcbiAgbWFyZ2luLXRvcDogMGVtO1xyXG59XHJcbi5wb3BvdmVyLWNvbnRlbnQuc2MtaW9uLXBvcG92ZXItbWQge1xyXG4gICAgd2lkdGg6IDUwMHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5teS1jdXN0b20tbW9kYWwtY3NzIC5tb2RhbC13cmFwcGVyIHtcclxuICB3aWR0aDogNjAwcHg7XHJcbiAgaGVpZ2h0OiA2NTBweCAhaW1wb3J0YW50O1xyXG59IFxyXG4ubm9ybWFzIHtcclxuICBmb250LXNpemU6IDEycHg7XHJcbiAgY29sb3I6ICMxYjE5MmM7XHJcbn1cclxuLnRpdGxlLW5vcm1hcyB7XHJcbiAgY29sb3I6ICMwYjQ4MGY7XHJcbiAgZm9udC1zaXplOiAxZW07XHJcbiAgdGV4dC1hbGlnbjogbGVmdDtcclxufVxyXG4ubm9ybWEtYmxvY2sge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNjNmU4ZTY7XHJcbiAgcGFkZGluZzogMTBweDtcclxuICBtYXJnaW46IDEuNXB4O1xyXG4gIG1pbi13aWR0aDogMTAwJTtcclxufVxyXG4uYmlnLWljb24ge1xyXG4gIGZvbnQtc2l6ZTogMS4yZW07XHJcbiAgbWFyZ2luLWxlZnQ6IDNweDtcclxuICBjdXJzb3I6IGdyYWI7XHJcbn1cclxuLmRldGFpbC1wYXJhZ3JhcGgge1xyXG4gIGZvbnQtc2l6ZTogMTFweDtcclxuICBjb2xvcjogIzNkM2M0NDtcclxufVxyXG4uc3ViLXRpdGxlIHtcclxuICAvKmZvbnQtc3R5bGU6IGl0YWxpYzsqL1xyXG4gIGZvbnQtc2l6ZTogMTNweDtcclxuICBjb2xvcjogIzA1NWEwZjtcclxuICBmb250LWZhbWlseTogc2Fucy1zZXJpZjtcclxufVxyXG4uZGlyZWNjaW9uLWJsb2NrIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjYzFlYmQ2O1xyXG4gIHBhZGRpbmc6IDEwcHg7XHJcbiAgbWFyZ2luOiAxLjVweDtcclxuICBtaW4td2lkdGg6IDEwMCU7XHJcbn0iLCIuY29udGFpbmVyLXByb2R1Y3QtbGlzdCB7XG4gIG1hcmdpbi10b3A6IDBlbTtcbn1cblxuLnBvcG92ZXItY29udGVudC5zYy1pb24tcG9wb3Zlci1tZCB7XG4gIHdpZHRoOiA1MDBweCAhaW1wb3J0YW50O1xufVxuXG4ubXktY3VzdG9tLW1vZGFsLWNzcyAubW9kYWwtd3JhcHBlciB7XG4gIHdpZHRoOiA2MDBweDtcbiAgaGVpZ2h0OiA2NTBweCAhaW1wb3J0YW50O1xufVxuXG4ubm9ybWFzIHtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBjb2xvcjogIzFiMTkyYztcbn1cblxuLnRpdGxlLW5vcm1hcyB7XG4gIGNvbG9yOiAjMGI0ODBmO1xuICBmb250LXNpemU6IDFlbTtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbn1cblxuLm5vcm1hLWJsb2NrIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2M2ZThlNjtcbiAgcGFkZGluZzogMTBweDtcbiAgbWFyZ2luOiAxLjVweDtcbiAgbWluLXdpZHRoOiAxMDAlO1xufVxuXG4uYmlnLWljb24ge1xuICBmb250LXNpemU6IDEuMmVtO1xuICBtYXJnaW4tbGVmdDogM3B4O1xuICBjdXJzb3I6IGdyYWI7XG59XG5cbi5kZXRhaWwtcGFyYWdyYXBoIHtcbiAgZm9udC1zaXplOiAxMXB4O1xuICBjb2xvcjogIzNkM2M0NDtcbn1cblxuLnN1Yi10aXRsZSB7XG4gIC8qZm9udC1zdHlsZTogaXRhbGljOyovXG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgY29sb3I6ICMwNTVhMGY7XG4gIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xufVxuXG4uZGlyZWNjaW9uLWJsb2NrIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2MxZWJkNjtcbiAgcGFkZGluZzogMTBweDtcbiAgbWFyZ2luOiAxLjVweDtcbiAgbWluLXdpZHRoOiAxMDAlO1xufSJdfQ== */";

/***/ }),

/***/ 5656:
/*!****************************************************************************************!*\
  !*** ./src/app/components/tcs-list-systems/tcs-list-systems.component.scss?ngResource ***!
  \****************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".normas {\n  font-size: 12px;\n  color: #1b192c;\n}\n\n.title-normas {\n  color: #0b480f;\n  font-size: 1em;\n  text-align: left;\n}\n\n.norma-block {\n  background-color: #c6e8e6;\n  padding: 10px;\n  margin: 1.5px;\n  min-width: 100%;\n}\n\n.big-icon {\n  font-size: 1.2em;\n  margin-left: 3px;\n  cursor: grab;\n}\n\n.detail-paragraph {\n  font-size: 11px;\n  color: #3d3c44;\n}\n\n.sub-title {\n  /*font-style: italic;*/\n  font-size: 13px;\n  color: #055a0f;\n  font-family: sans-serif;\n}\n\n.direccion-block {\n  background-color: #c1ebd6;\n  padding: 10px;\n  margin: 1.5px;\n  min-width: 100%;\n}\n\n.horario-block {\n  background-color: #1c1118;\n  padding: 20px;\n  margin: 0.5px;\n  min-width: 100%;\n}\n\n.horario-block p {\n  color: #c6e8e6;\n}\n\n.titles {\n  font-style: italic;\n  font-weight: 300;\n  font-size: 18px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRjcy1saXN0LXN5c3RlbXMuY29tcG9uZW50LnNjc3MiLCIuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXEJja0RlbGwlMjAlMjAxNSUyMDU1MDBcXGVcXFBST1lFQ1RPU1xcaWJub3JjYVxcaWJub3JjYS1wd2FcXGlibm9yY2EtcHdhXFxpYm5vcmNhX3VpXFxzcmNcXGFwcFxcY29tcG9uZW50c1xcdGNzLWxpc3Qtc3lzdGVtc1xcdGNzLWxpc3Qtc3lzdGVtcy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGVBQUE7RUFDQSxjQUFBO0FDQ0Y7O0FEQ0E7RUFDRSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0FDRUY7O0FEQUE7RUFDRSx5QkFBQTtFQUNBLGFBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtBQ0dGOztBRERBO0VBQ0UsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7QUNJRjs7QURGQTtFQUNFLGVBQUE7RUFDQSxjQUFBO0FDS0Y7O0FESEE7RUFDRSxzQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsdUJBQUE7QUNNRjs7QURKQTtFQUNFLHlCQUFBO0VBQ0EsYUFBQTtFQUNBLGFBQUE7RUFDQSxlQUFBO0FDT0Y7O0FETEE7RUFDRSx5QkFBQTtFQUNBLGFBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtBQ1FGOztBRE5BO0VBQ0UsY0FBQTtBQ1NGOztBRFBBO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUNVRiIsImZpbGUiOiJ0Y3MtbGlzdC1zeXN0ZW1zLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm5vcm1hcyB7XHJcbiAgZm9udC1zaXplOiAxMnB4O1xyXG4gIGNvbG9yOiAjMWIxOTJjO1xyXG59XHJcbi50aXRsZS1ub3JtYXMge1xyXG4gIGNvbG9yOiAjMGI0ODBmO1xyXG4gIGZvbnQtc2l6ZTogMWVtO1xyXG4gIHRleHQtYWxpZ246IGxlZnQ7XHJcbn1cclxuLm5vcm1hLWJsb2NrIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjYzZlOGU2O1xyXG4gIHBhZGRpbmc6IDEwcHg7XHJcbiAgbWFyZ2luOiAxLjVweDtcclxuICBtaW4td2lkdGg6IDEwMCU7XHJcbn1cclxuLmJpZy1pY29uIHtcclxuICBmb250LXNpemU6IDEuMmVtO1xyXG4gIG1hcmdpbi1sZWZ0OiAzcHg7XHJcbiAgY3Vyc29yOiBncmFiO1xyXG59XHJcbi5kZXRhaWwtcGFyYWdyYXBoIHtcclxuICBmb250LXNpemU6IDExcHg7XHJcbiAgY29sb3I6ICMzZDNjNDQ7XHJcbn1cclxuLnN1Yi10aXRsZSB7XHJcbiAgLypmb250LXN0eWxlOiBpdGFsaWM7Ki9cclxuICBmb250LXNpemU6IDEzcHg7XHJcbiAgY29sb3I6ICMwNTVhMGY7XHJcbiAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XHJcbn1cclxuLmRpcmVjY2lvbi1ibG9jayB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2MxZWJkNjtcclxuICBwYWRkaW5nOiAxMHB4O1xyXG4gIG1hcmdpbjogMS41cHg7XHJcbiAgbWluLXdpZHRoOiAxMDAlO1xyXG59XHJcbi5ob3JhcmlvLWJsb2NrIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMWMxMTE4O1xyXG4gIHBhZGRpbmc6IDIwcHg7XHJcbiAgbWFyZ2luOiAwLjVweDtcclxuICBtaW4td2lkdGg6IDEwMCU7XHJcbn1cclxuLmhvcmFyaW8tYmxvY2sgcHtcclxuICBjb2xvcjogI2M2ZThlNjtcclxufVxyXG4udGl0bGVzIHtcclxuICBmb250LXN0eWxlOiBpdGFsaWM7XHJcbiAgZm9udC13ZWlnaHQ6IDMwMDtcclxuICBmb250LXNpemU6IDE4cHg7XHJcbn1cclxuIiwiLm5vcm1hcyB7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgY29sb3I6ICMxYjE5MmM7XG59XG5cbi50aXRsZS1ub3JtYXMge1xuICBjb2xvcjogIzBiNDgwZjtcbiAgZm9udC1zaXplOiAxZW07XG4gIHRleHQtYWxpZ246IGxlZnQ7XG59XG5cbi5ub3JtYS1ibG9jayB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNjNmU4ZTY7XG4gIHBhZGRpbmc6IDEwcHg7XG4gIG1hcmdpbjogMS41cHg7XG4gIG1pbi13aWR0aDogMTAwJTtcbn1cblxuLmJpZy1pY29uIHtcbiAgZm9udC1zaXplOiAxLjJlbTtcbiAgbWFyZ2luLWxlZnQ6IDNweDtcbiAgY3Vyc29yOiBncmFiO1xufVxuXG4uZGV0YWlsLXBhcmFncmFwaCB7XG4gIGZvbnQtc2l6ZTogMTFweDtcbiAgY29sb3I6ICMzZDNjNDQ7XG59XG5cbi5zdWItdGl0bGUge1xuICAvKmZvbnQtc3R5bGU6IGl0YWxpYzsqL1xuICBmb250LXNpemU6IDEzcHg7XG4gIGNvbG9yOiAjMDU1YTBmO1xuICBmb250LWZhbWlseTogc2Fucy1zZXJpZjtcbn1cblxuLmRpcmVjY2lvbi1ibG9jayB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNjMWViZDY7XG4gIHBhZGRpbmc6IDEwcHg7XG4gIG1hcmdpbjogMS41cHg7XG4gIG1pbi13aWR0aDogMTAwJTtcbn1cblxuLmhvcmFyaW8tYmxvY2sge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMWMxMTE4O1xuICBwYWRkaW5nOiAyMHB4O1xuICBtYXJnaW46IDAuNXB4O1xuICBtaW4td2lkdGg6IDEwMCU7XG59XG5cbi5ob3JhcmlvLWJsb2NrIHAge1xuICBjb2xvcjogI2M2ZThlNjtcbn1cblxuLnRpdGxlcyB7XG4gIGZvbnQtc3R5bGU6IGl0YWxpYztcbiAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgZm9udC1zaXplOiAxOHB4O1xufSJdfQ== */";

/***/ }),

/***/ 9431:
/*!**************************************************************************************************************************************!*\
  !*** ./src/app/components/tcs-lista-verificacion-reunion-apertura/tcs-lista-verificacion-reunion-apertura.component.scss?ngResource ***!
  \**************************************************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0Y3MtbGlzdGEtdmVyaWZpY2FjaW9uLXJldW5pb24tYXBlcnR1cmEuY29tcG9uZW50LnNjc3MifQ== */";

/***/ }),

/***/ 1295:
/*!**********************************************************************************************************************************!*\
  !*** ./src/app/components/tcs-lista-verificacion-reunion-cierre/tcs-lista-verificacion-reunion-cierre.component.scss?ngResource ***!
  \**********************************************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0Y3MtbGlzdGEtdmVyaWZpY2FjaW9uLXJldW5pb24tY2llcnJlLmNvbXBvbmVudC5zY3NzIn0= */";

/***/ }),

/***/ 5030:
/*!**************************************************************************************!*\
  !*** ./src/app/components/tm-acta-reunion/tm-acta-reunion.component.scss?ngResource ***!
  \**************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = ".container-product-list {\n  margin-top: 0em;\n}\n\n.popover-content.sc-ion-popover-md {\n  width: 500px !important;\n}\n\n.my-custom-modal-css .modal-wrapper {\n  width: 600px;\n  height: 650px !important;\n}\n\n.normas {\n  font-size: 12px;\n  color: #1b192c;\n}\n\n.title-normas {\n  color: #0b480f;\n  font-size: 1em;\n  text-align: left;\n}\n\n.norma-block {\n  background-color: #c6e8e6;\n  padding: 10px;\n  margin: 1.5px;\n  min-width: 100%;\n}\n\n.big-icon {\n  font-size: 1.2em;\n  margin-left: 3px;\n  cursor: grab;\n}\n\n.detail-paragraph {\n  font-size: 11px;\n  color: #3d3c44;\n}\n\n.sub-title {\n  /*font-style: italic;*/\n  font-size: 13px;\n  color: #055a0f;\n  font-family: sans-serif;\n}\n\n.direccion-block {\n  background-color: #c1ebd6;\n  padding: 10px;\n  margin: 1.5px;\n  min-width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRtLWFjdGEtcmV1bmlvbi5jb21wb25lbnQuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcQmNrRGVsbCUyMCUyMDE1JTIwNTUwMFxcZVxcUFJPWUVDVE9TXFxpYm5vcmNhXFxpYm5vcmNhLXB3YVxcaWJub3JjYS1wd2FcXGlibm9yY2FfdWlcXHNyY1xcYXBwXFxjb21wb25lbnRzXFx0bS1hY3RhLXJldW5pb25cXHRtLWFjdGEtcmV1bmlvbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGVBQUE7QUNDSjs7QURDRTtFQUNJLHVCQUFBO0FDRU47O0FEQ0U7RUFDRSxZQUFBO0VBQ0Esd0JBQUE7QUNFSjs7QURBRTtFQUNFLGVBQUE7RUFDQSxjQUFBO0FDR0o7O0FEREU7RUFDRSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0FDSUo7O0FERkU7RUFDRSx5QkFBQTtFQUNBLGFBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtBQ0tKOztBREhFO0VBQ0UsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7QUNNSjs7QURKRTtFQUNFLGVBQUE7RUFDQSxjQUFBO0FDT0o7O0FETEU7RUFDRSxzQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsdUJBQUE7QUNRSjs7QURORTtFQUNFLHlCQUFBO0VBQ0EsYUFBQTtFQUNBLGFBQUE7RUFDQSxlQUFBO0FDU0oiLCJmaWxlIjoidG0tYWN0YS1yZXVuaW9uLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRhaW5lci1wcm9kdWN0LWxpc3Qge1xyXG4gICAgbWFyZ2luLXRvcDogMGVtO1xyXG4gIH1cclxuICAucG9wb3Zlci1jb250ZW50LnNjLWlvbi1wb3BvdmVyLW1kIHtcclxuICAgICAgd2lkdGg6IDUwMHB4ICFpbXBvcnRhbnQ7XHJcbiAgfVxyXG4gIFxyXG4gIC5teS1jdXN0b20tbW9kYWwtY3NzIC5tb2RhbC13cmFwcGVyIHtcclxuICAgIHdpZHRoOiA2MDBweDtcclxuICAgIGhlaWdodDogNjUwcHggIWltcG9ydGFudDtcclxuICB9IFxyXG4gIC5ub3JtYXMge1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgY29sb3I6ICMxYjE5MmM7XHJcbiAgfVxyXG4gIC50aXRsZS1ub3JtYXMge1xyXG4gICAgY29sb3I6ICMwYjQ4MGY7XHJcbiAgICBmb250LXNpemU6IDFlbTtcclxuICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgfVxyXG4gIC5ub3JtYS1ibG9jayB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjYzZlOGU2O1xyXG4gICAgcGFkZGluZzogMTBweDtcclxuICAgIG1hcmdpbjogMS41cHg7XHJcbiAgICBtaW4td2lkdGg6IDEwMCU7XHJcbiAgfVxyXG4gIC5iaWctaWNvbiB7XHJcbiAgICBmb250LXNpemU6IDEuMmVtO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDNweDtcclxuICAgIGN1cnNvcjogZ3JhYjtcclxuICB9XHJcbiAgLmRldGFpbC1wYXJhZ3JhcGgge1xyXG4gICAgZm9udC1zaXplOiAxMXB4O1xyXG4gICAgY29sb3I6ICMzZDNjNDQ7XHJcbiAgfVxyXG4gIC5zdWItdGl0bGUge1xyXG4gICAgLypmb250LXN0eWxlOiBpdGFsaWM7Ki9cclxuICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgIGNvbG9yOiAjMDU1YTBmO1xyXG4gICAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XHJcbiAgfVxyXG4gIC5kaXJlY2Npb24tYmxvY2sge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2MxZWJkNjtcclxuICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICBtYXJnaW46IDEuNXB4O1xyXG4gICAgbWluLXdpZHRoOiAxMDAlO1xyXG4gIH0iLCIuY29udGFpbmVyLXByb2R1Y3QtbGlzdCB7XG4gIG1hcmdpbi10b3A6IDBlbTtcbn1cblxuLnBvcG92ZXItY29udGVudC5zYy1pb24tcG9wb3Zlci1tZCB7XG4gIHdpZHRoOiA1MDBweCAhaW1wb3J0YW50O1xufVxuXG4ubXktY3VzdG9tLW1vZGFsLWNzcyAubW9kYWwtd3JhcHBlciB7XG4gIHdpZHRoOiA2MDBweDtcbiAgaGVpZ2h0OiA2NTBweCAhaW1wb3J0YW50O1xufVxuXG4ubm9ybWFzIHtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBjb2xvcjogIzFiMTkyYztcbn1cblxuLnRpdGxlLW5vcm1hcyB7XG4gIGNvbG9yOiAjMGI0ODBmO1xuICBmb250LXNpemU6IDFlbTtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbn1cblxuLm5vcm1hLWJsb2NrIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2M2ZThlNjtcbiAgcGFkZGluZzogMTBweDtcbiAgbWFyZ2luOiAxLjVweDtcbiAgbWluLXdpZHRoOiAxMDAlO1xufVxuXG4uYmlnLWljb24ge1xuICBmb250LXNpemU6IDEuMmVtO1xuICBtYXJnaW4tbGVmdDogM3B4O1xuICBjdXJzb3I6IGdyYWI7XG59XG5cbi5kZXRhaWwtcGFyYWdyYXBoIHtcbiAgZm9udC1zaXplOiAxMXB4O1xuICBjb2xvcjogIzNkM2M0NDtcbn1cblxuLnN1Yi10aXRsZSB7XG4gIC8qZm9udC1zdHlsZTogaXRhbGljOyovXG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgY29sb3I6ICMwNTVhMGY7XG4gIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xufVxuXG4uZGlyZWNjaW9uLWJsb2NrIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2MxZWJkNjtcbiAgcGFkZGluZzogMTBweDtcbiAgbWFyZ2luOiAxLjVweDtcbiAgbWluLXdpZHRoOiAxMDAlO1xufSJdfQ== */";

/***/ }),

/***/ 3383:
/*!***********************************************!*\
  !*** ./src/app/app.component.html?ngResource ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-app>\n  <ion-split-pane contentId=\"main-content\">\n    <!--<ion-menu contentId=\"main-content\" type=\"overlay\">\n      <ion-content>\n        <ion-list id=\"inbox-list\">\n          <ion-list-header>Inbox</ion-list-header>\n          <ion-note>hi@ionicframework.com</ion-note>\n\n            <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages; let i = index\">\n            <ion-item (click)=\"selectedIndex = i\" routerDirection=\"root\" [routerLink]=\"[p.url]\" lines=\"none\" detail=\"false\" [class.selected]=\"selectedIndex == i\">\n              <ion-icon slot=\"start\" [ios]=\"p.icon + '-outline'\" [md]=\"p.icon + '-sharp'\"></ion-icon>\n              <ion-label>{{ p.title }}</ion-label>\n            </ion-item>\n          </ion-menu-toggle>\n        </ion-list>\n\n        <ion-list id=\"labels-list\">\n          <ion-list-header>Labels</ion-list-header>\n\n          <ion-item *ngFor=\"let label of labels\" lines=\"none\">\n            <ion-icon\n              slot=\"start\"\n              ios=\"bookmark-outline\"\n              md=\"bookmark-sharp\"\n            ></ion-icon>\n            <ion-label>{{ label }}</ion-label>\n          </ion-item>\n        </ion-list>\n      </ion-content>\n    </ion-menu>-->\n    <ion-router-outlet id=\"main-content\"></ion-router-outlet>\n  </ion-split-pane>\n</ion-app>\n";

/***/ }),

/***/ 5762:
/*!********************************************************************************!*\
  !*** ./src/app/components/buscar-norma/buscar-norma.component.html?ngResource ***!
  \********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-header translucent>\n  <ion-toolbar>\n    <ion-radio-group [(ngModel)]=\"tipoNorma\">\n      <ion-item>\n        <ion-label>Nacional</ion-label>\n        <ion-radio slot=\"start\" color=\"success\" value=\"nacional\"></ion-radio>\n      </ion-item>\n      <ion-item>\n        <ion-label>Internacional</ion-label>\n        <ion-radio slot=\"start\" color=\"success\" value=\"internacional\"></ion-radio>\n      </ion-item>\n    </ion-radio-group>\n    <ion-searchbar\n      placeholder=\"Código de Norma\"\n      animated=\"true\"\n      (ionChange)=\"buscar($event)\"\n    ></ion-searchbar>\n  </ion-toolbar>  \n</ion-header>\n<ion-list>\n  <ion-item>\n    <ion-select\n      interface=\"alert\"\n      placeholder=\"Norma\"\n      class=\"cargo-select\"\n      okText=\"Ok\"\n      cancelText=\"Cancelar\"\n      (ionChange)=\"seleccionarNorma($event)\"\n      [value]=\"currentNorma\"\n    >\n      <ion-select-option\n        *ngFor=\"let norma of listaNormas\"\n        [value]=\"norma\"\n        class=\"cargo-select\"\n        >{{ norma.codigoNorma }} - {{ norma.nombreNorma }}\n      </ion-select-option>\n    </ion-select>\n  </ion-item>\n</ion-list>\n";

/***/ }),

/***/ 5460:
/*!********************************************************************************************!*\
  !*** ./src/app/components/ciclo-participante/ciclo-participante.component.html?ngResource ***!
  \********************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-content>\r\n  <ion-card mode=\"ios\">\r\n    <ion-item color=\"medium\" color=\"title-small\">\r\n      <ion-icon name=\"people\" slot=\"start\"></ion-icon>\r\n      <ion-label>PARTICIPANTES</ion-label>\r\n      <ion-icon\r\n        name=\"add-circle\"\r\n        slot=\"start\"\r\n        (click)=\"adicionarParticipante()\"\r\n        *ngIf=\"allowEdit === true\"\r\n        class=\"bigger-icon\"\r\n      ></ion-icon>\r\n    </ion-item>\r\n    <ion-card-content\r\n      class=\"ion-content-small-font\"\r\n      *ngIf=\"visibleAdd === 'NO'\"\r\n    >\r\n      <ion-row>\r\n        <ion-col size=\"4\">Cargo</ion-col>\r\n        <ion-col size=\"6\">Personal</ion-col>\r\n        <ion-col size=\"1\">Situ</ion-col>\r\n        <ion-col size=\"1\">Rem</ion-col>\r\n      </ion-row>\r\n      <ion-row *ngFor=\"let item of currentPracicloparticipantes; let i = index\">\r\n        <ion-col size=\"4\">\r\n          <ion-label>\r\n            <ion-icon\r\n              name=\"pencil-sharp\"\r\n              slot=\"start\"\r\n              (click)=\"editar(item, i)\"\r\n              class=\"big-icon\"\r\n              *ngIf=\"allowEdit === true\"\r\n            ></ion-icon>\r\n            <ion-icon\r\n              name=\"trash\"\r\n              slot=\"start\"\r\n              (click)=\"eliminar(i)\"\r\n              class=\"big-icon\"\r\n              *ngIf=\"allowEdit === true\"\r\n            ></ion-icon>\r\n            {{ item._cargo.cargoPuesto }}\r\n          </ion-label>\r\n        </ion-col>\r\n        <ion-col size=\"6\">\r\n          <ion-label *ngIf=\"item._personal\">\r\n            {{ item._personal.nombreCompleto }}\r\n          </ion-label>\r\n        </ion-col>\r\n        <ion-col size=\"1\">\r\n          <ion-label *ngIf=\"item._personal\">\r\n            {{ item.diasInsistu }}\r\n          </ion-label>\r\n        </ion-col>\r\n        <ion-col size=\"1\">\r\n          <ion-label *ngIf=\"item._personal\">\r\n            {{ item.diasRemoto }}\r\n          </ion-label>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-card-content>\r\n\r\n    <ion-card-content\r\n      class=\"ion-content-small-font\"\r\n      *ngIf=\"visibleAdd === 'SI' && allowEdit === true\"\r\n    >\r\n      <ion-list>\r\n        <ion-item>\r\n          <ion-icon\r\n            name=\"arrow-undo\"\r\n            class=\"big-icon\"\r\n            (click)=\"cancelar()\"\r\n          ></ion-icon>\r\n        </ion-item>\r\n        <ion-item>\r\n          <ion-select\r\n            interface=\"alert\"\r\n            placeholder=\"Cargo\"\r\n            class=\"cargo-select\"\r\n            okText=\"Ok\"\r\n            cancelText=\"Cancelar\"\r\n            (ionChange)=\"ObtenerPersonalXCargos($event)\"\r\n            [value]=\"selectParticipante._cargo\"\r\n          >\r\n            <ion-select-option\r\n              *ngFor=\"let cargo of ListaCargoItem\"\r\n              [value]=\"cargo\"\r\n              class=\"cargo-select\"\r\n              >{{ cargo.cargoPuesto }}</ion-select-option\r\n            >\r\n          </ion-select>\r\n        </ion-item>\r\n        <ion-item>\r\n          <ion-label position=\"fixed\">Dias Insitu</ion-label>\r\n          <ion-input\r\n            type=\"number\"\r\n            placeholder=\"0\"\r\n            [(ngModel)]=\"selectParticipante.diasInsistu\"\r\n            name=\"cantidadDias\"\r\n          ></ion-input>\r\n        </ion-item>\r\n        <ion-item>\r\n          <ion-label position=\"fixed\">Dias Remoto</ion-label>\r\n          <ion-input\r\n            type=\"number\"\r\n            placeholder=\"0\"\r\n            [(ngModel)]=\"selectParticipante.diasRemoto\"\r\n            name=\"cantidadDias\"\r\n          ></ion-input>\r\n        </ion-item>\r\n        <ion-item>\r\n          <ion-select\r\n            interface=\"alert\"\r\n            placeholder=\"Personal\"\r\n            class=\"cargo-select\"\r\n            okText=\"Ok\"\r\n            cancelText=\"Cancelar\"\r\n            (ionChange)=\"seleccionarPersonal($event)\"\r\n            [value]=\"selectParticipante._personal\"\r\n          >\r\n            <ion-select-option\r\n              *ngFor=\"let personal of ListaPersonal\"\r\n              [value]=\"personal\"\r\n              class=\"cargo-select\"\r\n              >{{ personal.nombreCompleto }}</ion-select-option\r\n            >\r\n          </ion-select>\r\n        </ion-item>\r\n      </ion-list>\r\n    </ion-card-content>\r\n  </ion-card>\r\n</ion-content>\r\n";

/***/ }),

/***/ 4175:
/*!**********************************************************************************!*\
  !*** ./src/app/components/custom-header/custom-header.component.html?ngResource ***!
  \**********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-header translucent=\"true\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button>\n        <ion-icon [name]=\"icon_name\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title class=\"ion-text-capitalize\">\n      {{ title }}\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n";

/***/ }),

/***/ 393:
/*!********************************************************************************!*\
  !*** ./src/app/components/custom-input/custom-input.component.html?ngResource ***!
  \********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div [formGroup]=\"formGruop\">\n  <ion-item lines=\"full\">\n    <ion-label position=\"floating\">{{ label }}</ion-label>\n    <ion-input\n      class=\"margin-top\"\n      *ngIf=\"type !== 'datetime'\"\n      [formControlName]=\"name\"\n      [type]=\"type\"\n      [readonly]=\"readonly\"\n      (keyup.enter)=\"eventKeyEnter($event)\"\n    ></ion-input>\n    <ion-datetime\n      class=\"margin-top\"\n      *ngIf=\"type === 'datetime'\"\n      [presentation]=\"formatDate\"\n      locale=\"es-BO\"\n      (ionChange)=\"selectionarFecha($event)\"\n    ></ion-datetime>\n  </ion-item>\n  <div *ngIf=\"Validations\">\n    <div *ngFor=\"let validation of Validations\">\n      <app-message-error\n        [error]=\"validation.message\"\n        *ngIf=\"form.submitted && ExistsError(validation.validator)\"\n      >\n      </app-message-error>\n    </div>\n  </div>\n</div>\n";

/***/ }),

/***/ 6545:
/*!****************************************************************************************!*\
  !*** ./src/app/components/editor-documento/editor-documento.component.html?ngResource ***!
  \****************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-list>\n  <ion-item>\n    <ion-label position=\"stacked\">{{ titulo }}</ion-label>\n    <ion-textarea\n      [(ngModel)]=\"tmddocumentacionauditorium.tmdDocumentoAuditoria\"\n      placeholder=\"contenido\"\n      rows=\"20\"\n    ></ion-textarea>\n  </ion-item>\n  <ion-item>\n    <ion-button\n      size=\"small\"\n      fill=\"outline\"\n      color=\"success\"\n      (click)=\"guardarContenido()\"\n    >\n      <ion-icon slot=\"start\" name=\"caret-up-outline\"></ion-icon>\n      Guardar\n    </ion-button>\n  </ion-item>\n</ion-list>\n";

/***/ }),

/***/ 6228:
/*!**********************************************************************************************!*\
  !*** ./src/app/components/ela-cronograma-list/ela-cronograma-list.component.html?ngResource ***!
  \**********************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-list *ngIf=\"mode === 'LIST'\">\n  <ion-list-header lines=\"full\">\n    <ion-item>\n      <ion-icon\n        name=\"add-circle\"\n        slot=\"start\"\n        (click)=\"addCronograma()\"\n        class=\"big-icon\"></ion-icon>\n      <ion-text color=\"secondary\"> Cronograma </ion-text>\n    </ion-item>\n  </ion-list-header>\n  <ion-item *ngFor=\"let cronograma of listCronograma; let i= index\">\n    <ion-icon\n      name=\"pencil-sharp\"\n      slot=\"start\"\n      (click)=\"editarCronograma(i)\"\n      class=\"big-icon\"></ion-icon>\n    <ion-icon\n      name=\"trash\"\n      slot=\"start\"\n      (click)=\"eliminarCronograma(i)\"\n      class=\"big-icon\"></ion-icon>\n    <div class=\"row-cronogama\">\n      Fecha:\n      <span class=\"sub-title-horario\">{{ cronograma.fechaInicio }}</span> |\n      Hora: <span class=\"sub-title-horario\">{{ cronograma.horario }}</span>\n      <br />\n      Requisito:\n      <span class=\"paragraph-horario\">{{ cronograma.requisitosEsquema }}</span>\n      Responsable:\n      <span class=\"paragraph-horario\">{{\n        cronograma.personaEntrevistadaCargo\n        }}</span>\n      Proceso:\n      <span class=\"paragraph-horario\">{{ cronograma.procesoArea }}</span>\n      Equipo:\n      <span class=\"paragraph-horario\">{{ cronograma.auditor }}</span>\n      Direccion:\n      <span class=\"paragraph-horario\">{{ cronograma.direccion }}</span>\n    </div>\n  </ion-item>\n</ion-list>\n<app-ela-cronograma\n  *ngIf=\"mode === 'EDIT'\"\n  [currentElacronogama]=\"currentCrongrama\"\n  [listaParticipantes]=\"listaParticipantes\"\n  [listaDirecciones]=\"listaDirecciones\"\n  (guardarCronogramaEmitter)=\"guardarCronograma($event)\"\n  (cancelarCronogramaEmitter)=\"cancelarCronograma()\"></app-ela-cronograma>\n";

/***/ }),

/***/ 1155:
/*!************************************************************************************!*\
  !*** ./src/app/components/ela-cronograma/ela-cronograma.component.html?ngResource ***!
  \************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div class=\"container-product\">\r\n    <form [formGroup]=\"ionicFormHorario\" (ngSubmit)=\"guardarCronograma()\"\r\n        #form=\"ngForm\">\r\n        <app-custom-input label=\"Fecha\" name=\"fechaInicio\" type=\"date\"\r\n            [formGruop]=\"ionicFormHorario\" [form]=\"form\"\r\n            [defaultValue]=\"currentElacronogama.fechaInicio\"></app-custom-input>\r\n        <app-custom-input label=\"Horario\" name=\"horario\" type=\"text\"\r\n            [formGruop]=\"ionicFormHorario\" [form]=\"form\"\r\n            [defaultValue]=\"currentElacronogama.horario\"></app-custom-input>\r\n        <app-custom-input label=\"Requisitos\" name=\"requisitosEsquema\"\r\n            type=\"text\" [formGruop]=\"ionicFormHorario\"\r\n            [form]=\"form\"\r\n            [defaultValue]=\"currentElacronogama.requisitosEsquema\"></app-custom-input>\r\n        <app-custom-input label=\"Persona Entrevistada\"\r\n            name=\"personaEntrevistadaCargo\" type=\"text\"\r\n            [formGruop]=\"ionicFormHorario\" [form]=\"form\"\r\n            [defaultValue]=\"currentElacronogama.personaEntrevistadaCargo\">\r\n        </app-custom-input>\r\n        <app-custom-input label=\"Proceso/Area\" name=\"procesoArea\" type=\"text\"\r\n            [formGruop]=\"ionicFormHorario\"\r\n            [form]=\"form\" [defaultValue]=\"currentElacronogama.procesoArea\"></app-custom-input>\r\n        <ion-item>\r\n            <ion-label position=\"floating\">Participante</ion-label>\r\n            <ion-select interface=\"alert\" placeholder=\"Participante\"\r\n                class=\"cargo-select\" okText=\"Ok\"\r\n                cancelText=\"Cancelar\"\r\n                (ionChange)=\"seleccionarParticipante($event)\" multiple=\"true\"\r\n                [value]=\"selectedParticipantes\">\r\n                <ion-select-option *ngFor=\"let participante of\r\n                    listaParticipantes\" [value]=\"participante\"\r\n                    class=\"cargo-select\">\r\n                    {{ participante.nombreCompleto }}\r\n                </ion-select-option>\r\n            </ion-select>\r\n        </ion-item>\r\n        <ion-item>\r\n            <ion-label position=\"floating\">Direccion</ion-label>\r\n            <ion-select interface=\"popover\" placeholder=\"direccion\"\r\n                class=\"cargo-select\" okText=\"Ok\"\r\n                cancelText=\"Cancelar\" (ionChange)=\"seleccionarDireccion($event)\"\r\n                [value]=\"selectedParticipantes\">\r\n                <ion-select-option *ngFor=\"let direccion of listaDirecciones\"\r\n                    [value]=\"direccion\"\r\n                    class=\"cargo-select\">{{ direccion }}\r\n                </ion-select-option>\r\n            </ion-select>\r\n        </ion-item>\r\n\r\n        <p class=\"detail-paragraph\">\r\n            Fecha 21/03/2021 | Usuario: Rubén | Auditor: Jorge | Cargo: Jefe de\r\n            Producción\r\n        </p>\r\n        <section>\r\n            <ion-button size=\"small\" type=\"submit\">Guardar</ion-button>\r\n            <ion-button size=\"small\" color=\"secondary\" (click)=\"cancelar()\">Cancelar</ion-button>\r\n        </section>\r\n    </form>\r\n</div>";

/***/ }),

/***/ 8685:
/*!**********************************************************************************************************!*\
  !*** ./src/app/components/ela-edit-areapreocupacion/ela-edit-areapreocupacion.component.html?ngResource ***!
  \**********************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div class=\"container-product\">\r\n  <form\r\n    [formGroup]=\"ionicFormAdp\"\r\n    (ngSubmit)=\"guardarAreaDePreocupacion()\"\r\n    #form=\"ngForm\"\r\n  >\r\n    <app-custom-input\r\n      label=\"Area\"\r\n      name=\"area\"\r\n      type=\"text\"\r\n      [formGruop]=\"ionicFormAdp\"\r\n      [form]=\"form\"\r\n      [defaultValue]=\"currentAdp.area\"\r\n    ></app-custom-input>\r\n\r\n    <ion-item>\r\n      <ion-label position=\"floating\">Descripción</ion-label>\r\n      <ion-textarea\r\n        clearOnEdit=\"true\"\r\n        rows=\"10\"\r\n        cols=\"20\"\r\n        [value]=\"currentAdp.descripcion\"\r\n        (ionChange)=\"valorDescripcion($event)\"\r\n      ></ion-textarea>\r\n    </ion-item>\r\n\r\n    <section>\r\n      <ion-button size=\"small\" type=\"submit\">Guardar</ion-button>\r\n      <ion-button size=\"small\" color=\"secondary\" (click)=\"cancelarAreaDePreocupacion()\"\r\n        >Cancelar</ion-button\r\n      >\r\n    </section>\r\n  </form>\r\n</div>\r\n";

/***/ }),

/***/ 4408:
/*!********************************************************************************************!*\
  !*** ./src/app/components/ela-edit-hallazago/ela-edit-hallazago.component.html?ngResource ***!
  \********************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div class=\"container-product\">\r\n  <form\r\n    [formGroup]=\"ionicFormHallazgo\"\r\n    (ngSubmit)=\"guardarHallazgo()\"\r\n    #form=\"ngForm\">\r\n    <ion-select\r\n      interface=\"alert\"\r\n      placeholder=\"Tipo de hallazgo\"\r\n      class=\"cargo-select\"\r\n      okText=\"Ok\"\r\n      cancelText=\"Cancelar\"\r\n      (ionChange)=\"seleccionarTipo($event)\"\r\n      [value]=\"tipoObservacion\">\r\n      <ion-select-option\r\n        *ngFor=\"let tipo of ltiposObervacion\"\r\n        [value]=\"tipo\"\r\n        class=\"cargo-select\">\r\n        {{ tipo.descripcion }}\r\n      </ion-select-option>\r\n    </ion-select>\r\n    <app-custom-input\r\n      label=\"Requisito\"\r\n      name=\"proceso\"\r\n      type=\"text\"\r\n      [formGruop]=\"ionicFormHallazgo\"\r\n      [form]=\"form\"\r\n      [defaultValue]=\"elahallazgo.proceso\"></app-custom-input>\r\n\r\n    <!-- <app-custom-input\r\n      label=\"Hallazgo\"\r\n      name=\"sitio\"\r\n      type=\"text\"\r\n      [formGruop]=\"ionicFormHallazgo\"\r\n      [form]=\"form\"\r\n      [defaultValue]=\"elahallazgo.sitio\"\r\n    ></app-custom-input> -->\r\n    <!-- <ion-select\r\n      interface=\"alert\"\r\n      placeholder=\"Normas\"\r\n      class=\"cargo-select\"\r\n      okText=\"Ok\"\r\n      cancelText=\"Cancelar\"\r\n      (ionChange)=\"seleccionarNorma($event)\"\r\n      [value]=\"elahallazgo.normas\"\r\n    >\r\n      <ion-select-option\r\n        *ngFor=\"let norma of lNormas\"\r\n        [value]=\"norma\"\r\n        class=\"cargo-select\"\r\n      >\r\n        {{ norma }}\r\n      </ion-select-option>\r\n    </ion-select> -->\r\n    <ion-item>\r\n      <ion-label position=\"floating\">Hallazgo</ion-label>\r\n      <ion-textarea\r\n        clearOnEdit=\"true\"\r\n        rows=\"10\"\r\n        (ionChange)=\"valorHallazagos($event)\"\r\n        cols=\"20\"\r\n        [value]=\"elahallazgo.hallazgo\"></ion-textarea>\r\n    </ion-item>\r\n\r\n    <section>\r\n      <ion-button size=\"small\" type=\"submit\">Guardar</ion-button>\r\n      <ion-button size=\"small\" color=\"secondary\" (click)=\"cancelarHallazo()\">Cancelar</ion-button>\r\n    </section>\r\n  </form>\r\n</div>\r\n";

/***/ }),

/***/ 5835:
/*!**********************************************************************************!*\
  !*** ./src/app/components/ela-objetivos/ela-objetivos.component.html?ngResource ***!
  \**********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-list>\r\n  <ion-item>\r\n    <ion-button\r\n      size=\"small\"\r\n      fill=\"outline\"\r\n      color=\"success\"\r\n      (click)=\"guardarContenido()\"    >\r\n      <ion-icon slot=\"start\" name=\"caret-up-outline\"></ion-icon>\r\n      Guardar\r\n    </ion-button>\r\n  </ion-item>\r\n  <div *ngFor=\"let subtitulo of listSubtitulos; let i = index\">\r\n    <ion-list-header lines=\"full\">\r\n      <ion-text color=\"primary\">\r\n        <h3>{{ i + 1 }}. {{ subtitulo.titulo }}</h3>\r\n      </ion-text>\r\n    </ion-list-header>\r\n    <ion-item *ngFor=\"let contenido of ListByCategoria(subtitulo.nemotico)\">\r\n      <ion-label position=\"floating\" color=\"secondary\">{{\r\n        contenido.label\r\n      }}</ion-label>\r\n      <ion-textarea [(ngModel)]=\"contenido.contenido\" rows=\"4\"></ion-textarea>\r\n      <ion-checkbox slot=\"end\" [(ngModel)]=\"contenido['select']\"></ion-checkbox>\r\n    </ion-item>\r\n  </div>\r\n</ion-list>\r\n";

/***/ }),

/***/ 5465:
/*!******************************************************************************************!*\
  !*** ./src/app/components/ela-plan-muestreo/ela-plan-muestreo.component.html?ngResource ***!
  \******************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-list>\n  <ion-item>\n    <ion-button\n      size=\"small\"\n      fill=\"outline\"\n      color=\"success\"\n      (click)=\"guardarMuestreo()\">\n      <ion-icon slot=\"start\" name=\"caret-up-outline\"></ion-icon>\n      Guardar\n    </ion-button>\n  </ion-item>\n  <ion-list-header lines=\"full\">\n    <ion-text color=\"primary\">\n      <h3>{{titulo}}</h3>\n    </ion-text>\n  </ion-list-header>\n  <ion-item>\n    <ion-textarea [(ngModel)]=\"currentContenido.contenido\" rows=\"15\"></ion-textarea>\n  </ion-item>\n</ion-list>";

/***/ }),

/***/ 724:
/*!******************************************************************************************************************!*\
  !*** ./src/app/components/ela-registro-areapreocupacion/ela-registro-areapreocupacion.component.html?ngResource ***!
  \******************************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-list *ngIf=\"mode === 'LIST'\">\r\n  <ion-list-header class=\"title-normas\">\r\n    <ion-item>\r\n      <ion-icon\r\n        name=\"add-circle\"\r\n        slot=\"end\"\r\n        (click)=\"adicionarAdp()\"\r\n        class=\"big-icon\"\r\n      ></ion-icon>\r\n      Registro Areas de Preocupación\r\n    </ion-item>\r\n  </ion-list-header>\r\n  <ion-item *ngFor=\"let adp of listaAdp; let i = index\">\r\n    <ion-icon\r\n      name=\"pencil-sharp\"\r\n      slot=\"start\"\r\n      (click)=\"editarAdp(i)\"\r\n      class=\"big-icon\"\r\n    ></ion-icon>\r\n    <ion-icon\r\n      name=\"trash\"\r\n      slot=\"start\"\r\n      (click)=\"eliminarAdp(i)\"\r\n      class=\"big-icon\"\r\n    ></ion-icon>\r\n    <div class=\"norma-block\">\r\n      <h2>Area: {{ adp.area }}</h2>\r\n      <p>\r\n        Descripción:\r\n        <span class=\"sub-title\">{{ adp.descripcion }}</span>\r\n      </p>\r\n      <p class=\"detail-paragraph\">\r\n        Fecha {{adp.fecha}} | Auditor: {{adp.usuario}}\r\n      </p>\r\n    </div>\r\n  </ion-item>\r\n</ion-list>\r\n<app-ela-edit-areapreocupacion\r\n  *ngIf=\"mode === 'EDIT'\"\r\n  (guardarAdpEmitter)=\"guardarAreaDePreocupacion($event)\"\r\n  (cancelarAdpEmitter)=\"cancelarAreaDePreocupacion($event)\"\r\n  [currentAdp]=\"currentAdp\"\r\n></app-ela-edit-areapreocupacion>\r\n";

/***/ }),

/***/ 9376:
/*!****************************************************************************************************!*\
  !*** ./src/app/components/ela-registro-hallazgos/ela-registro-hallazgos.component.html?ngResource ***!
  \****************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-list *ngIf=\"mode === 'LIST'\">\r\n  <ion-list-header class=\"title-normas\">\r\n    <ion-item>\r\n      <ion-icon\r\n        name=\"add-circle\"\r\n        slot=\"end\"\r\n        (click)=\"adicionarHallazgo()\"\r\n        class=\"big-icon\"></ion-icon>\r\n      Registro de Hallazgos\r\n    </ion-item>\r\n  </ion-list-header>\r\n  <ion-item *ngFor=\"let hallazgos of listaHallazgos; let i= index\">\r\n    <ion-icon\r\n      name=\"pencil-sharp\"\r\n      slot=\"start\"\r\n      (click)=\"editarHallazgo(i)\"\r\n      class=\"big-icon\"></ion-icon>\r\n    <ion-icon\r\n      name=\"trash\"\r\n      slot=\"start\"\r\n      (click)=\"eliminarHallazgo(i)\"\r\n      class=\"big-icon\"></ion-icon>\r\n    <div class=\"norma-block\">\r\n      <h2>\r\n        Tipo: {{ hallazgos.tipo }} [Normas: {{ hallazgos.normas }}]\r\n      </h2>\r\n      <h3>Requisito: {{ hallazgos.proceso }}</h3>\r\n      <!-- <h3>Hallazgo: {{ hallazgos.proceso }}</h3> -->\r\n      <p>\r\n        Hallazgo:\r\n        <span class=\"sub-title\">\r\n          {{ hallazgos.hallazgo }}\r\n          <!-- A tomar en consideración: - en el caso de las auditorías\r\n          multisitio, la columna F permite vincular los resultados con el\r\n          \"sitio\". llene la hoja de Excel \"sitios\" para que sólo tenga que\r\n          introducir los nombres de los sitios una vez y pueda encontrarlos en\r\n          forma de menú desplegable en la columna \"sitio en cuestión\" para\r\n          cada auditoría. Para auditorías de un solo sitio, oculte esta\r\n          columna. Ocultar las columnas de las normas que no necesita y así\r\n          hacer el informe más legible para el cliente. -->\r\n        </span>\r\n      </p>\r\n      <p class=\"detail-paragraph\">\r\n        Sitio.{{ hallazgos.sitio }} | Fecha {{ hallazgos.fecha }} | Auditor: {{\r\n        hallazgos.usuario }}\r\n      </p>\r\n    </div>\r\n  </ion-item>\r\n</ion-list>\r\n<app-ela-edit-hallazago\r\n  *ngIf=\"mode === 'EDIT'\"\r\n  [elahallazgo]=\"currentHallazgo\"\r\n  (guardarHallazgoEmitter)=\"guardarHallazgo($event)\"\r\n  (cancelarHallazgoEmitter)=\"cancelarHallazo($event)\"\r\n  [lNormas]=\"lNormas\"></app-ela-edit-hallazago>";

/***/ }),

/***/ 7417:
/*!**************************************************************************************************************!*\
  !*** ./src/app/components/lista-verificacion-apertura/lista-verificacion-apertura.component.html?ngResource ***!
  \**************************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-custom-header\r\n  title=\"LISTA DE VERIFICACION DE APERTURA\"\r\n  icon_name=\"list\"\r\n></app-custom-header>\r\n<ion-content>\r\n  <ion-list>\r\n    <ion-item *ngFor=\"let entry of data\" (click)=\"clickCheck(entry)\">\r\n      <ion-checkbox\r\n        slot=\"start\"\r\n        [(ngModel)]=\"entry.selected\"\r\n      ></ion-checkbox>\r\n      <ion-label>{{ entry.name }}</ion-label>\r\n    </ion-item>\r\n  </ion-list>\r\n</ion-content>\r\n";

/***/ }),

/***/ 377:
/*!******************************************************************!*\
  !*** ./src/app/components/meses/meses.component.html?ngResource ***!
  \******************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-list>\n  <ion-item\n    *ngFor=\"let item of items; let i = index;\"\n    (click)=\"selectMes(item.value)\"\n    detail=\"true\"\n  >\n    <ion-label>{{item.label}}</ion-label>\n  </ion-item>\n</ion-list>";

/***/ }),

/***/ 5859:
/*!**********************************************************************************!*\
  !*** ./src/app/components/message-error/message-error.component.html?ngResource ***!
  \**********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div class=\"container-error\">\n  <ion-label class=\"error-message\" >\n    * {{ error }}\n  </ion-label>  \n</div>\n";

/***/ }),

/***/ 3618:
/*!****************************************************************************************!*\
  !*** ./src/app/components/param-documentos/param-documentos.component.html?ngResource ***!
  \****************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-list>\n  <ion-item *ngFor=\"let item of listDocumentos; let i = index\">\n    <ion-icon\n      name=\"cloud-download\"\n      slot=\"end\"\n      class=\"icon\"\n      (click)=\"descargarDocumento(item.nombrePlantilla)\"\n    ></ion-icon>\n    <ion-label>\n      {{ i + 1 }} - {{ item.nombrePlantilla }} {{ item.descripcion }}\n    </ion-label>\n  </ion-item>\n</ion-list>\n";

/***/ }),

/***/ 4299:
/*!************************************************************************************!*\
  !*** ./src/app/components/param-horarios/param-horarios.component.html?ngResource ***!
  \************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-list>\n  <ion-item>\n    <ion-label>Inicio</ion-label>\n    <ion-datetime\n      presentation=\"time\"\n      display-format=\"H:mm\"\n      picker-format=\"H:mm\"\n      cancelText=\"Cancelar\"\n      doneText=\"Confirmar\"\n      (ionChange)=\"selectionarHorarioIni($event)\"\n    ></ion-datetime>\n  </ion-item>\n  <ion-item>\n    <ion-label>Fin</ion-label>\n    <ion-datetime\n      presentation=\"time\"\n      display-format=\"H:mm\"\n      picker-format=\"H:mm\"\n      cancelText=\"Cancelar\"\n      doneText=\"Confirmar\"\n      (ionChange)=\"selectionarHorarioFin($event)\"\n    >\n    </ion-datetime>\n  </ion-item>\n  <ion-item>\n    <ion-button (click)=\"confirmarSeleccion()\"> Confirmar </ion-button>\n  </ion-item>\n</ion-list>\n";

/***/ }),

/***/ 6639:
/*!**********************************************************************************************************************!*\
  !*** ./src/app/components/param-organismos-certificadores/param-organismos-certificadores.component.html?ngResource ***!
  \**********************************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-list>\r\n  <ion-item>\r\n    <ion-select\r\n      interface=\"alert\"\r\n      placeholder=\"Organismo\"\r\n      class=\"cargo-select\"\r\n      okText=\"Ok\"\r\n      cancelText=\"Cancelar\"\r\n      (ionChange)=\"seleccionarOrganismo($event)\"\r\n      [value]=\"currentOrganismo\"\r\n      multiple=\"true\"\r\n    >\r\n      <ion-select-option\r\n        *ngFor=\"let organismo of listaOrganismos\"\r\n        [value]=\"organismo\"\r\n        class=\"cargo-select\"        \r\n        >{{ organismo.descripcion }}\r\n      </ion-select-option>\r\n    </ion-select>\r\n  </ion-item>\r\n</ion-list>";

/***/ }),

/***/ 3041:
/*!********************************************************************************!*\
  !*** ./src/app/components/param-paises/param-paises.component.html?ngResource ***!
  \********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-header translucent>\r\n  <ion-toolbar>\r\n    <ion-searchbar\r\n      placeholder=\"Código de País\"\r\n      animated=\"true\"\r\n      (ionChange)=\"buscarPais($event)\"\r\n      [value] = \"defaulValue\"\r\n    ></ion-searchbar>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-list>\r\n  <ion-item>\r\n    <ion-select\r\n      interface=\"alert\"\r\n      placeholder=\"Pais\"\r\n      class=\"cargo-select\"\r\n      okText=\"Ok\"\r\n      cancelText=\"Cancelar\"\r\n      (ionChange)=\"seleccionarPais($event)\"\r\n      [value]=\"currentPais\"\r\n    >\r\n      <ion-select-option\r\n        *ngFor=\"let norma of listaPaises\"\r\n        [value]=\"norma\"\r\n        class=\"cargo-select\"\r\n        >{{ norma.idPais }} - {{ norma.paisNombre }}\r\n      </ion-select-option>\r\n    </ion-select>\r\n  </ion-item>\r\n\r\n  <ion-item>\r\n    <ion-select\r\n      interface=\"alert\"\r\n      placeholder=\"Estados - Departamentos\"\r\n      class=\"cargo-select\"\r\n      okText=\"Ok\"\r\n      cancelText=\"Cancelar\"\r\n      (ionChange)=\"seleccionarEstado($event)\"\r\n      [value]=\"currentEstado\"\r\n    >\r\n      <ion-select-option\r\n        *ngFor=\"let norma of listaEstados\"\r\n        [value]=\"norma\"\r\n        class=\"cargo-select\"\r\n        >{{ norma.idEstado }} - {{ norma.estNombre }}\r\n      </ion-select-option>\r\n    </ion-select>\r\n  </ion-item>\r\n  <ion-item>\r\n    <ion-select\r\n      interface=\"alert\"\r\n      placeholder=\"Ciudad\"\r\n      class=\"cargo-select\"\r\n      okText=\"Ok\"\r\n      cancelText=\"Cancelar\"\r\n      (ionChange)=\"seleccionarCiudad($event)\"\r\n      [value]=\"currentCiudad\"\r\n    >\r\n      <ion-select-option\r\n        *ngFor=\"let norma of listaCiudades\"\r\n        [value]=\"norma\"\r\n        class=\"cargo-select\"\r\n        >{{ norma.idCiudad }} - {{ norma.nomCiudad }}\r\n      </ion-select-option>\r\n    </ion-select>\r\n  </ion-item>\r\n\r\n</ion-list>\r\n";

/***/ }),

/***/ 8457:
/*!************************************************************************************!*\
  !*** ./src/app/components/plan-auditoria/plan-auditoria.component.html?ngResource ***!
  \************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = " <ion-card *ngIf=\"currentPlanAuditoriaDTO &&\r\n    currentPlanAuditoriaDTO.cliente\">\r\n    <ion-card-header color=\"primary\">\r\n        <ion-card-subtitle>ID CLIENTE:\r\n            {{ currentPlanAuditoriaDTO.cliente[\"idCliente\"] }}</ion-card-subtitle>\r\n        <ion-item color=\"primary\">\r\n            <ion-icon color=\"light\" name=\"server-outline\" slot=\"start\"></ion-icon>\r\n            <ion-label>CLIENTE:\r\n                {{ currentPlanAuditoriaDTO.cliente[\"nombreRazon\"] }}</ion-label>\r\n        </ion-item>\r\n    </ion-card-header>\r\n    <ion-card-content class=\"ion-content-small-font\">\r\n        <ion-row>\r\n            <ion-col size=\"6\" size-lg=\"6\" size-md=\"6\" size-sm=\"12\"\r\n                size-xs=\"12\">\r\n                <ion-card mode=\"ios\">\r\n                    <ion-item color=\"medium\" color=\"title-small\">\r\n                        <ion-icon name=\"person\" slot=\"start\"></ion-icon>\r\n                        <ion-label>DATOS DE DESIGNACION</ion-label>\r\n                    </ion-item>\r\n                    <ion-card-content class=\"ion-content-small-font\">\r\n                        <ion-list>\r\n                            <ion-item class=\"ion-no-padding small-item\">\r\n                                Código del servicio:\r\n                                <ion-label>\r\n                                    {{currentPlanAuditoriaDTO.designacion.codigoServicio}}\r\n                                </ion-label>\r\n                            </ion-item>\r\n                            <ion-item class=\"ion-no-padding small-item\">\r\n                                Tipo de Auditoría:\r\n                                <ion-label>\r\n                                    {{currentPlanAuditoriaDTO.designacion.tipoAuditroria}}\r\n                                </ion-label>\r\n                            </ion-item>\r\n                            <ion-item class=\"ion-no-padding small-item\">\r\n                                Fecha de Auditoría:\r\n                                <ion-label>\r\n                                    {{currentPlanAuditoriaDTO.designacion.fechaAuditoria}}\r\n                                </ion-label>\r\n                            </ion-item>\r\n                        </ion-list>\r\n                    </ion-card-content>\r\n                </ion-card>\r\n            </ion-col>\r\n            <ion-col size=\"6\" size-lg=\"6\" size-md=\"6\"\r\n                size-sm=\"12\" size-xs=\"12\">\r\n                <app-ciclo-participante allowEdit=\"false\"\r\n                    *ngIf=\"currentPlanAuditoriaDTO\"\r\n                    [currentPracicloparticipantes]=\"currentPlanAuditoriaDTO.pracicloparticipante\"></app-ciclo-participante>\r\n            </ion-col>\r\n        </ion-row>\r\n\r\n        <app-tcp-list-products\r\n            [productList]=\"currentPlanAuditoriaDTO.pradireccionespaproducto\"\r\n            [addCronograma]=\"true\" [allowDelete]=\"false\"\r\n            *ngIf=\"mode === 'TCP'\"\r\n            [listaParticipantes]=\"listaParticipantes\"\r\n            (guardarCronogramaEmitter)=\"guardarCronograma($event)\"\r\n            (eliminarCronogramaEmitter)=\"eliminarCronograma($event)\"></app-tcp-list-products>\r\n        <app-tcs-list-systems\r\n            [direccionesSistema]=\"currentPlanAuditoriaDTO.pradireccionespasistema\"\r\n            [normasSistema]=\"currentPlanAuditoriaDTO.praciclonormassistema\"\r\n            [nombreOrganizacion]=\"currentPlanAuditoriaDTO.nombreClienteCertificado\"\r\n            *ngIf=\"mode === 'TCS'\" [allowHorario]=\"true\"\r\n            [addCronograma]=\"true\" [allowDelete]=\"false\"\r\n            [isAuditor]=\"true\"\r\n            [listaParticipantes]=\"listaParticipantes\"\r\n            (guardarCronogramaEmitter)=\"guardarCronograma($event)\"\r\n            (eliminarCronogramaEmitter)=\"eliminarCronograma($event)\"></app-tcs-list-systems>\r\n    </ion-card-content>\r\n</ion-card>\r\n";

/***/ }),

/***/ 174:
/*!************************************************************************************!*\
  !*** ./src/app/components/pra-cronograma/pra-cronograma.component.html?ngResource ***!
  \************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-card mode=\"ios\" *ngIf=\"currentPraciclocronogramas\">\r\n  <ion-item color=\"medium\" color=\"title-small\">\r\n    <ion-icon name=\"time\" slot=\"start\"></ion-icon>\r\n    <ion-label>CRONOGRAMA</ion-label>\r\n  </ion-item>\r\n  <ion-card-content class=\"ion-content-small-font\">\r\n    <div class=\"item-cronograma\">\r\n      <span class=\"label-cronograma\">DIAS TOTAL: </span>\r\n      <span class=\"data-cronograma\">\r\n        {{ currentPraciclocronogramas.diasPresupuesto | number: '1.2-2' }}\r\n      </span>\r\n    </div>\r\n    <div class=\"item-cronograma\">\r\n      <span class=\"label-cronograma\">DIAS INSITU: </span>\r\n      <span class=\"data-cronograma\" class=\"box-click edit-item\" (click)=\"mostrarDiasInsituCronograma($event)\">\r\n        {{ currentPraciclocronogramas.diasInsitu }}\r\n      </span>\r\n    </div>\r\n    <div class=\"item-cronograma\">\r\n      <span class=\"label-cronograma\">DIAS REMOTO: </span>\r\n      <span class=\"data-cronograma\" class=\"box-click edit-item\" (click)=\"mostrarDiasRemotoCronograma($event)\">\r\n        {{ currentPraciclocronogramas.diasRemoto }}\r\n      </span>\r\n    </div>\r\n    <div class=\"item-cronograma\">\r\n      <span class=\"label-cronograma\">HORARIO: </span>\r\n      <span class=\"data-cronograma\" class=\"box-click edit-item\" (click)=\"mostrarHorarioCronograma($event)\">\r\n        {{ currentPraciclocronogramas.horarioTrabajo }}\r\n      </span>\r\n    </div>\r\n    <div class=\"item-cronograma\">\r\n      <span class=\"label-cronograma\">MES PROGRAMADO:</span>\r\n      <span (click)=\"mostrarMesesProgramado($event)\" class=\"box-click edit-item\">\r\n        {{ currentPraciclocronogramas.mesProgramado | date: \"MM/yyyy\" }}\r\n      </span>\r\n    </div>\r\n    <div class=\"item-cronograma\">\r\n      <span class=\"label-cronograma\">MES REPROGRAMADO:</span>\r\n      <ion-label (click)=\"mostrarMesesReprogamado($event)\" class=\"box-click edit-item\">\r\n        {{ currentPraciclocronogramas.mesReprogramado | date: \"MM/yyyy\" }}\r\n      </ion-label>\r\n    </div>\r\n    <div class=\"item-cronograma\">\r\n      <span class=\"label-cronograma\">FECHA DE INICIO DE EJECUCIÓN AUDITORÍA:</span>\r\n      <ion-label (click)=\"mostrarFechaEjecucion($event)\" class=\"box-click edit-item\">\r\n        {{\r\n          currentPraciclocronogramas.fechaInicioDeEjecucionDeAuditoria\r\n            | date: \"dd/MM/yyyy\"\r\n        }}\r\n      </ion-label>\r\n    </div>\r\n    <div class=\"item-cronograma\">\r\n      <span class=\"label-cronograma\">FECHA DE FIN DE EJECUCIÓN AUDITORÍA:</span>\r\n      <ion-label (click)=\"mostrarFechaFin($event)\" class=\"box-click edit-item\">\r\n        {{\r\n          currentPraciclocronogramas.fechaDeFinDeEjecucionAuditoria\r\n            | date: \"dd/MM/yyyy\"\r\n        }}\r\n      </ion-label>\r\n    </div>\r\n    <div class=\"item-cronograma\">\r\n      <span class=\"label-cronograma\">ESTADO:</span>\r\n      <ion-label class=\"box-click\">\r\n        {{ currentPraciclocronogramas.estado }}\r\n      </ion-label>\r\n    </div>\r\n\r\n  </ion-card-content>\r\n</ion-card>\r\n";

/***/ }),

/***/ 1183:
/*!**************************************************************************************************!*\
  !*** ./src/app/components/pra-direccion-sistema/pra-direccion-sistema.component.html?ngResource ***!
  \**************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div class=\"container-product\">\r\n  <form [formGroup]=\"ionicForm\" (ngSubmit)=\"guardarDireccion()\" #form=\"ngForm\">\r\n    <!-- <app-custom-input\r\n      label=\"Oficina\"\r\n      name=\"nombre\"\r\n      type=\"text\"\r\n      [formGruop]=\"ionicForm\"\r\n      [form]=\"form\"\r\n      [defaultValue]=\"pradireccionespasistema.nombre\"\r\n    ></app-custom-input> -->\r\n    <app-custom-input\r\n      label=\"Direccion\"\r\n      name=\"direccion\"\r\n      type=\"text\"\r\n      [formGruop]=\"ionicForm\"\r\n      [form]=\"form\"\r\n      [defaultValue]=\"pradireccionespasistema.direccion\"\r\n    ></app-custom-input>\r\n    <!-- <div *ngIf=\"mode === 'default-pais'\">\r\n      <app-custom-input\r\n        label=\"PAIS\"\r\n        name=\"pais\"\r\n        type=\"text\"\r\n        [formGruop]=\"ionicForm\"\r\n        readonly=\"true\"\r\n        [form]=\"form\"\r\n        [defaultValue]=\"pradireccionespasistema.pais\"\r\n        (click)=\"cambiarModoPais()\"\r\n      ></app-custom-input>\r\n      <app-custom-input\r\n        label=\"Departamento\"\r\n        name=\"departamento\"\r\n        type=\"text\"\r\n        [formGruop]=\"ionicForm\"\r\n        [form]=\"form\"\r\n        readonly=\"true\"\r\n        [defaultValue]=\"pradireccionespasistema.departamento\"\r\n      ></app-custom-input>\r\n      <app-custom-input\r\n        label=\"Ciudad\"\r\n        name=\"ciudad\"\r\n        type=\"text\"\r\n        [formGruop]=\"ionicForm\"\r\n        [form]=\"form\"\r\n        readonly=\"true\"\r\n        [defaultValue]=\"pradireccionespasistema.ciudad\"\r\n      ></app-custom-input>\r\n    </div>\r\n    <app-param-paises\r\n      *ngIf=\"mode === 'edit-pais'\"\r\n      [defaulValue]=\"pradireccionespasistema.pais\"\r\n      (selectLocalizacionEmit) = \"localizacionSeleccionda($event)\"\r\n    ></app-param-paises> -->\r\n    <app-custom-input\r\n      label=\"Dias\"\r\n      name=\"dias\"\r\n      type=\"number\"\r\n      [formGruop]=\"ionicForm\"\r\n      [form]=\"form\"\r\n      readonly=\"false\"\r\n      [defaultValue]=\"pradireccionespasistema.dias\"\r\n    ></app-custom-input>    \r\n    <section>\r\n      <ion-button size=\"small\" type=\"submit\">Guardar</ion-button>\r\n      <ion-button size=\"small\" (click)=\"cancelar()\" color=\"secondary\"\r\n        >Cancelar</ion-button\r\n      >\r\n     \r\n    </section>\r\n  </form>\r\n</div>\r\n";

/***/ }),

/***/ 536:
/*!****************************************************************************************************!*\
  !*** ./src/app/components/pra-edit-norma-sistema/pra-edit-norma-sistema.component.html?ngResource ***!
  \****************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div class=\"container-product\">\r\n  <form [formGroup]=\"ionicForm\" (ngSubmit)=\"guardarNorma()\" #form=\"ngForm\">\r\n    <ion-item (click)=\"mostrarBuscadorNorma()\">\r\n      <ion-label> Norma : {{ praciclonormassistema.norma }} </ion-label>\r\n    </ion-item>\r\n    <app-buscar-norma\r\n      (selectNorma)=\"cambiarNorma($event)\"\r\n      *ngIf=\"showBuscadorNormas\"\r\n    ></app-buscar-norma>\r\n    <app-custom-input\r\n      label=\"Alcance\"\r\n      name=\"alcance\"\r\n      type=\"text\"\r\n      [formGruop]=\"ionicForm\"\r\n      [form]=\"form\"\r\n      [defaultValue]=\"praciclonormassistema.alcance\"\r\n    ></app-custom-input>\r\n        <section>\r\n      <ion-button size=\"small\" type=\"submit\">Guardar</ion-button>\r\n      <ion-button size=\"small\" (click)=\"cancelarNorma()\" color=\"secondary\">Cancelar</ion-button>\r\n    </section>\r\n  </form>\r\n</div>\r\n";

/***/ }),

/***/ 3824:
/*!************************************************************************************!*\
  !*** ./src/app/components/product-detail/product-detail.component.html?ngResource ***!
  \************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div class=\"container-product\">\r\n  <form [formGroup]=\"ionicForm\" (ngSubmit)=\"guardarProduct()\" #form=\"ngForm\">\r\n    <app-custom-input\r\n      label=\"Nombre del Producto\"\r\n      name=\"nombre\"\r\n      type=\"text\"\r\n      [formGruop]=\"ionicForm\"\r\n      [form]=\"form\"\r\n      [defaultValue]=\"pradireccionespaproducto.nombre\"\r\n    ></app-custom-input>\r\n    <app-custom-input\r\n      label=\"Direccion\"\r\n      name=\"direccion\"\r\n      type=\"text\"\r\n      [formGruop]=\"ionicForm\"\r\n      [form]=\"form\"\r\n      [defaultValue]=\"pradireccionespaproducto.direccion\"\r\n    ></app-custom-input>\r\n    <app-custom-input\r\n      label=\"Marca\"\r\n      name=\"marca\"\r\n      type=\"text\"\r\n      [formGruop]=\"ionicForm\"\r\n      [form]=\"form\"\r\n      [defaultValue]=\"pradireccionespaproducto.marca\"\r\n    ></app-custom-input>\r\n    <ion-item (click)=\"mostrarBuscadorNorma()\">\r\n      <ion-label> Norma : {{ pradireccionespaproducto.norma }} </ion-label>\r\n    </ion-item>\r\n    <app-buscar-norma\r\n      (selectNorma)=\"cambiarNorma($event)\"\r\n      *ngIf=\"showBuscadorNormas\"\r\n    ></app-buscar-norma>\r\n    <app-custom-input\r\n      label=\"Sello\"\r\n      name=\"sello\"\r\n      type=\"text\"\r\n      [formGruop]=\"ionicForm\"\r\n      [form]=\"form\"\r\n      [defaultValue]=\"pradireccionespaproducto.sello\"\r\n    ></app-custom-input>\r\n    <!-- <div *ngIf=\"mode === 'default-pais'\">\r\n      <app-custom-input\r\n        label=\"PAIS\"\r\n        name=\"pais\"\r\n        type=\"text\"\r\n        [formGruop]=\"ionicForm\"\r\n        readonly=\"true\"\r\n        [form]=\"form\"\r\n        [defaultValue]=\"pradireccionespaproducto.pais\"\r\n        (click)=\"cambiarModoPais()\"\r\n      ></app-custom-input>\r\n      <app-custom-input\r\n        label=\"Departamento\"\r\n        name=\"estado\"\r\n        type=\"text\"\r\n        [formGruop]=\"ionicForm\"\r\n        [form]=\"form\"\r\n        readonly=\"true\"\r\n        [defaultValue]=\"pradireccionespaproducto.estado\"\r\n      ></app-custom-input>\r\n      <app-custom-input\r\n        label=\"Ciudad\"\r\n        name=\"ciudad\"\r\n        type=\"text\"\r\n        [formGruop]=\"ionicForm\"\r\n        [form]=\"form\"\r\n        readonly=\"true\"\r\n        [defaultValue]=\"pradireccionespaproducto.ciudad\"\r\n      ></app-custom-input>\r\n    </div> -->\r\n    <app-param-paises\r\n      *ngIf=\"mode === 'edit-pais'\"\r\n      [defaulValue]=\"pradireccionespaproducto.pais\"\r\n      (selectLocalizacionEmit)=\"localizacionSeleccionda($event)\"\r\n    ></app-param-paises>\r\n    <section>\r\n      <ion-button size=\"small\" type=\"submit\">Guardar</ion-button>\r\n      <ion-button size=\"small\" color=\"secondary\" (click)=\"cancelar()\"\r\n        >Cancelar</ion-button\r\n      >\r\n    </section>\r\n  </form>\r\n</div>\r\n";

/***/ }),

/***/ 8391:
/*!************************************************************************************!*\
  !*** ./src/app/components/registro-ciclo/registro-ciclo.component.html?ngResource ***!
  \************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<form [formGroup]=\"ionicForm\" (ngSubmit)=\"guardarCiclo()\" #form=\"ngForm\">\n  <ion-grid>\n    <ion-row>\n      <ion-col size=\"4\">\n        <app-custom-input\n          label=\"Años\"\n          name=\"anios\"\n          type=\"text\"\n          [formGruop]=\"ionicForm\"\n          [form]=\"form\"\n          defaultValue=\"La Paz\"\n        ></app-custom-input>\n      </ion-col>\n      <ion-col size=\"4\">\n        <app-custom-input\n          label=\"Etapa\"\n          name=\"etapa\"\n          type=\"text\"\n          [formGruop]=\"ionicForm\"\n          [form]=\"form\"\n          defaultValue=\"La Paz\"\n        ></app-custom-input>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-buttons collapse=\"true\">\n        <ion-button type=\"submit\" color=\"success\"> Aceptar </ion-button>\n        <ion-button type=\"button\" color=\"danger\" (click)=\"cancelar()\"\n          >Cancelar</ion-button\n        >\n      </ion-buttons>\n    </ion-row>\n  </ion-grid>\n</form>\n";

/***/ }),

/***/ 7976:
/*!******************************************************************************************!*\
  !*** ./src/app/components/tcp-list-products/tcp-list-products.component.html?ngResource ***!
  \******************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div class=\"container-product-list\">\r\n  <ion-item color=\"medium\" color=\"title-small\" (click)=\"toggle()\">\r\n    <ion-icon name=\"menu\" slot=\"start\"></ion-icon>\r\n    <ion-label> PRODUCTOS / NORMAS / DIRECCIONES</ion-label>\r\n  </ion-item>\r\n  <div *ngIf=\"display\">\r\n    <ion-list *ngIf=\"mode == 'LIST'\">\r\n      <ion-item>\r\n        <ion-label position=\"stacked\">\r\n          Nombre del cliente para el Certificado\r\n        </ion-label>\r\n        <ion-textarea [(ngModel)]=\"nombreOrganizacion\"></ion-textarea>\r\n      </ion-item>\r\n      <ion-list-header class=\"title-normas\">\r\n        <ion-item>\r\n          <ion-icon name=\"add-circle\" slot=\"end\" (click)=\"adicionar()\" class=\"big-icon\"></ion-icon>\r\n          Productos\r\n        </ion-item>\r\n      </ion-list-header>\r\n      <ion-item *ngFor=\"let product of productList; let i = index\">\r\n        <ion-icon name=\"pencil-sharp\" slot=\"start\" (click)=\"editar(product, i)\" class=\"big-icon\"></ion-icon>\r\n        <ion-icon name=\"trash\" slot=\"start\" (click)=\"eliminar(i)\" *ngIf=\"allowDelete\" class=\"big-icon\"></ion-icon>\r\n        <div class=\"norma-block\">\r\n          <h2>\r\n            Nombre: {{ product.nombre }} [Marca: {{ product.marca }}] [Norma:\r\n            {{ product.norma }}]\r\n          </h2>\r\n          <p>\r\n            Dirección <span class=\"sub-title\">{{ product.direccion }}</span> |\r\n            Sello {{ product.sello }}\r\n          </p>\r\n          <!-- <p>\r\n            Sello {{ product.sello }} | Pais: {{ product.pais }} | Departamento:\r\n            {{ product.estado }} | Ciudad: {{ product.ciudad }}\r\n          </p> -->\r\n          <p class=\"detail-paragraph\">\r\n            Fecha Emision Cert. {{ product.fechaEmisionPrimerCertificado }} |\r\n            Fecha Vencimiento Cert. {{ product.fechaVencimientoCertificado }} |\r\n            Nro. Cert.\r\n            {{ product.numeroDeCertificacion }}\r\n          </p>\r\n        </div>\r\n      </ion-item>\r\n    </ion-list>\r\n    <app-product-detail *ngIf=\"mode == 'EDIT'\" [pradireccionespaproducto]=\"currentProduct\"\r\n      (guardarProductEmitter)=\"guardarProducto($event)\" (cancelarProductEmitter)=\"cancelarProducto($event)\">\r\n    </app-product-detail>\r\n  </div>\r\n</div>";

/***/ }),

/***/ 8131:
/*!****************************************************************************************!*\
  !*** ./src/app/components/tcs-list-systems/tcs-list-systems.component.html?ngResource ***!
  \****************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<div class=\"container-product-list\">\r\n  <ion-item color=\"medium\" color=\"title-small\" (click)=\"toggle()\">\r\n    <ion-icon name=\"menu\" slot=\"start\"></ion-icon>\r\n    <ion-label>ALCANCE / NORMAS / DIRECCIONES</ion-label>\r\n  </ion-item>\r\n  <div *ngIf=\"display\">\r\n    <ion-list *ngIf=\"mode === 'list'\">\r\n      <ion-item>\r\n        <ion-label position=\"stacked\">\r\n          Nombre del cliente para el Certificado\r\n        </ion-label>\r\n        <ion-textarea [(ngModel)]=\"nombreOrganizacion\"></ion-textarea>\r\n      </ion-item>\r\n      <ion-list-header class=\"title-normas\">\r\n        <ion-item>\r\n          <ion-icon name=\"add-circle\" slot=\"end\" (click)=\"adicionarNorma(item,\r\n            i)\" class=\"big-icon\"></ion-icon>\r\n          Normas y Alcances\r\n        </ion-item>\r\n      </ion-list-header>\r\n      <ion-item *ngFor=\"let norma of normasSistema; let i= index\">\r\n        <ion-icon name=\"pencil-sharp\" slot=\"start\" (click)=\"editarNorma(norma,\r\n          i)\" class=\"big-icon\"></ion-icon>\r\n        <ion-icon name=\"trash\" slot=\"start\" (click)=\"eliminarNorma(i)\"\r\n          class=\"big-icon\"></ion-icon>\r\n        <div class=\"norma-block\">\r\n          <h2>Norma: {{ norma.norma }}</h2>\r\n          <p>\r\n            Alcance: <span class=\"sub-title\">{{ norma.alcance }}</span>\r\n          </p>\r\n          <p class=\"detail-paragraph\">\r\n            Fecha Emision Cert. {{ norma.fechaEmisionPrimerCertificado }} |\r\n            Fecha Vencimiento Cert.\r\n            {{ norma.fechaVencimientoUltimoCertificado }} | Nro. Cert.\r\n            {{ norma.numeroDeCertificacion }}\r\n          </p>\r\n        </div>\r\n      </ion-item>\r\n      <ion-list-header class=\"title-normas\">\r\n        <ion-item>\r\n          <ion-icon name=\"add-circle\" slot=\"end\"\r\n            (click)=\"adicionarDireccion(item, i)\" class=\"big-icon\"></ion-icon>\r\n          Programación de direcciones\r\n        </ion-item>\r\n      </ion-list-header>\r\n      <ion-item *ngFor=\"let direccion of direccionesSistema; let i= index\">\r\n        <ion-icon name=\"pencil-sharp\" slot=\"start\"\r\n          (click)=\"editarDireccion(direccion, i)\" class=\"big-icon\"></ion-icon>\r\n        <ion-icon name=\"trash\" slot=\"start\" (click)=\"eliminarDireccion(i)\"\r\n          class=\"big-icon\" *ngIf=\"allowDelete\">\r\n        </ion-icon>\r\n        <div class=\"direccion-block\">\r\n          <!-- <h2>{{ direccion.nombre }} - Diás Insitu: {{ direccion.dias }}</h2> -->\r\n          <h2>Diás Insitu: {{ direccion.dias }}</h2>\r\n          <p>\r\n            Dirección:\r\n            <span class=\"sub-title\">{{ direccion.direccion }}</span>\r\n          </p>\r\n          <!-- <p class=\"detail-paragraph\">\r\n            Pais: {{ direccion.pais }} | Departamento:\r\n            {{ direccion.departamento }} | Ciudad: {{ direccion.ciudad }}\r\n          </p> -->\r\n        </div>\r\n      </ion-item>\r\n    </ion-list>\r\n    <app-pra-direccion-sistema *ngIf=\"mode === 'EDIT'\"\r\n      [pradireccionespasistema]=\"currentdireccionesSistema\"\r\n      (guardarDireccionEmitter)=\"guardarDireccion($event)\"\r\n      (cancelarDireccionEmitter)=\"cancelarDireccion($event)\">\r\n    </app-pra-direccion-sistema>\r\n    <app-pra-edit-norma-sistema *ngIf=\"mode === 'EDIT1'\"\r\n      [praciclonormassistema]=\"currentnormaSistema\"\r\n      (guardarNormaEmitter)=\"guardarNorma($event)\"\r\n      (cancelarNormaEmitter)=\"cancelarNorma($event)\">\r\n    </app-pra-edit-norma-sistema>\r\n  </div>\r\n</div>";

/***/ }),

/***/ 6269:
/*!**************************************************************************************************************************************!*\
  !*** ./src/app/components/tcs-lista-verificacion-reunion-apertura/tcs-lista-verificacion-reunion-apertura.component.html?ngResource ***!
  \**************************************************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<p>\r\n  tcs-lista-verificacion-reunion-apertura works!\r\n</p>\r\n\r\n<app-custom-header\r\n  title=\"TCS - LISTA DE VERIFICACION DE APERTURA\"\r\n  icon_name=\"list\"\r\n></app-custom-header>\r\n<ion-content>\r\n \r\n  <ion-list>\r\n    <ion-item>\r\n      <ion-label><strong>Todo</strong></ion-label>\r\n      <ion-checkbox slot=\"end\" \r\n      [(ngModel)]=\"masterCheck\"\r\n      [indeterminate]=\"isIndeterminate\"\r\n        (click)=\"checkMaster($event)\"></ion-checkbox>\r\n    </ion-item>\r\n  </ion-list>\r\n  <ion-list>\r\n    <ion-item *ngFor=\"let item of pParamitemselect\">\r\n      <ion-label class=\"ion-text-wrap\">{{item.itemSelect}}</ion-label>\r\n      <ion-checkbox slot=\"end\" \r\n      [(ngModel)]=\"item.isChecked\" \r\n      (ionChange)=\"checkEvent()\"></ion-checkbox>\r\n    </ion-item>\r\n  </ion-list>\r\n\r\n</ion-content>\r\n\r\n";

/***/ }),

/***/ 1945:
/*!**********************************************************************************************************************************!*\
  !*** ./src/app/components/tcs-lista-verificacion-reunion-cierre/tcs-lista-verificacion-reunion-cierre.component.html?ngResource ***!
  \**********************************************************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<app-custom-header\r\n  title=\"TCS-LISTA DE VERIFICACION DE CIERRE\"\r\n  icon_name=\"list\"\r\n></app-custom-header>\r\n<ion-content>\r\n \r\n  <ion-list>\r\n    <ion-item>\r\n      <ion-label><strong>Todo</strong></ion-label>\r\n      <ion-checkbox slot=\"end\" \r\n      [(ngModel)]=\"masterCheck\"\r\n      [indeterminate]=\"isIndeterminate\"\r\n        (click)=\"checkMaster($event)\"></ion-checkbox>\r\n    </ion-item>\r\n  </ion-list>\r\n  <ion-list>\r\n    <ion-item *ngFor=\"let item of pParamitemselect\">\r\n      <ion-label class=\"ion-text-wrap\"> {{item.itemSelect}}</ion-label>\r\n      <ion-checkbox slot=\"end\" \r\n      [(ngModel)]=\"item.isChecked\" \r\n      (ionChange)=\"checkEvent()\"></ion-checkbox>\r\n    </ion-item>\r\n  </ion-list>\r\n\r\n</ion-content>";

/***/ }),

/***/ 3767:
/*!**************************************************************************************!*\
  !*** ./src/app/components/tm-acta-reunion/tm-acta-reunion.component.html?ngResource ***!
  \**************************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-list>\n  <ion-item>\n    <app-custom-input\n      label=\"Nro de Acta\"\n      name=\"nro_acta\"\n      type=\"text\"\n      [formGruop]=\"ionicForm\"\n      [form]=\"form\"\n      [defaultValue]=\"\"\n    ></app-custom-input>\n  </ion-item>\n  <ion-item>\n    <ion-label position=\"stacked\"> Fecha </ion-label>\n    {{ fecha }}\n  </ion-item>\n  <ion-item>\n    <ion-label position=\"stacked\">\n      Consideraciones del acta anterior\n    </ion-label>\n    <ion-select\n      interface=\"popover\"\n      placeholder=\"\"\n      class=\"cargo-select\"\n      okText=\"Ok\"\n      cancelText=\"Cancelar\"\n      (ionChange)=\"seleccionarConsideraciones($event)\"\n      multiple=\"false\"\n    >\n      <ion-select-option\n        *ngFor=\"let organismo of lConsideracione\"\n        [value]=\"organismo\"\n        class=\"cargo-select\"\n        >{{ organismo }}\n      </ion-select-option>\n    </ion-select>\n  </ion-item>\n  <ion-item>\n    <ion-label position=\"stacked\">\n      Revisión y recomendación a la dirección ejecutiva del IBNORCA de los\n      informes presentados al CONCER:\n    </ion-label>\n  </ion-item>\n  <ion-item *ngFor=\"let producto of productos; let i = index\">\n    <ion-icon\n      name=\"pencil-sharp\"\n      slot=\"start\"\n      (click)=\"editar(product, i)\"\n      class=\"big-icon\"\n    ></ion-icon>\n    <div class=\"norma-block\">\n      <h2>\n        Producto: {{ producto.producto }} [Proceso: {{ producto.proceso }}]\n        [Empresa: {{ producto.empresa }}]\n      </h2>\n      <p>\n        Norma {{ producto.norma }}, Confirmacion:\n        {{ producto.confirmacion }}\n      </p>\n      <p class=\"detail-paragraph\">\n        <span class=\"sub-title\">{{ producto.desc_revision }}</span>\n      </p>\n    </div>\n  </ion-item>\n  <ion-item>\n    <ion-label position=\"stacked\">\n      Revisión y decisión sobre Reglamentos Particulares\n    </ion-label>\n    <ion-select\n      interface=\"popover\"\n      placeholder=\"\"\n      class=\"cargo-select\"\n      okText=\"Ok\"\n      cancelText=\"Cancelar\"\n      (ionChange)=\"seleccionarRevision($event)\"\n      [value]=\"currentOrganismo\"\n      multiple=\"false\"\n    >\n      <ion-select-option\n        *ngFor=\"let organismo of lRevision\"\n        [value]=\"organismo\"\n        class=\"cargo-select\"\n        >{{ organismo }}\n      </ion-select-option>\n    </ion-select>\n    <ion-list-header class=\"title-normas\">\n      <ion-item>\n        <ion-icon\n          name=\"add-circle\"\n          slot=\"end\"\n          (click)=\"adicionar()\"\n          class=\"big-icon\"\n        ></ion-icon>\n        Reglamentos\n      </ion-item>\n    </ion-list-header>\n    <ion-item *ngFor=\"let reglamento of reglamentos; let i = index\">\n      <ion-icon\n        name=\"pencil-sharp\"\n        slot=\"start\"\n        (click)=\"editar(product, i)\"\n        class=\"big-icon\"\n      ></ion-icon>\n      <ion-icon\n        name=\"trash\"\n        slot=\"start\"\n        (click)=\"eliminar(i)\"\n        *ngIf=\"allowDelete\"\n        class=\"big-icon\"\n      ></ion-icon>\n      <div class=\"norma-block\">\n        <h2>\n          Nombre: {{ reglamento.nombre }} [Norma Base:\n          {{ reglamento.norma_base }}]\n        </h2>\n        <p>Desicion {{ reglamento.decision }}</p>\n        <p class=\"detail-paragraph\">\n          <span class=\"sub-title\">{{ reglamento.descripcion }}</span>\n        </p>\n      </div>\n    </ion-item>\n  </ion-item>\n  <ion-item>\n    <ion-label position=\"stacked\"> Varios </ion-label>\n    <ion-select\n      interface=\"popover\"\n      placeholder=\"\"\n      class=\"cargo-select\"\n      okText=\"Ok\"\n      cancelText=\"Cancelar\"\n      (ionChange)=\"seleccionarVarios($event)\"\n      [value]=\"currentOrganismo\"\n      multiple=\"false\"\n    >\n      <ion-select-option\n        *ngFor=\"let organismo of lVarios\"\n        [value]=\"organismo\"\n        class=\"cargo-select\"\n        >{{ organismo }}\n      </ion-select-option>\n    </ion-select>\n  </ion-item>\n</ion-list>\n";

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(4431)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map