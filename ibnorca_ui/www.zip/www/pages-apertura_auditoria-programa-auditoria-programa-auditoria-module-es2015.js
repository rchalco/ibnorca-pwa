(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-apertura_auditoria-programa-auditoria-programa-auditoria-module"],{

/***/ "4Rew":
/*!******************************************************************************************!*\
  !*** ./src/app/pages/apertura_auditoria/programa-auditoria/programa-auditoria.page.scss ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".ciclo-header {\n  background-color: #3bb8bd;\n  color: #e626d6;\n  font-weight: 300;\n  font-size: 16px;\n}\n\n.slider .slider-pager {\n  color: blue;\n}\n\n.slide-full {\n  width: 100% !important;\n}\n\n.avatar {\n  width: 50px;\n  display: block;\n  margin-left: auto;\n  margin-right: auto;\n}\n\nion-card-content {\n  text-align: left;\n}\n\n.ion-content-small-font {\n  font-family: \"Calibri Light\";\n  font-size: 12px;\n  color: #093537;\n}\n\n.container-detail-auditoria {\n  width: 100%;\n}\n\n.container-detail-certificacion {\n  margin-bottom: 15px;\n}\n\n.buttons-group {\n  margin-top: 5px;\n}\n\n.title-medium-font {\n  font-family: \"Courier New\";\n  font-weight: bold;\n}\n\n.big-icon {\n  font-size: 1.2em;\n  margin-left: 3px;\n  cursor: -webkit-grab;\n  cursor: grab;\n}\n\n.box-click {\n  min-width: 100px;\n  min-height: 20px;\n  border-bottom: solid;\n  border-color: #778e8f;\n  border-width: 1px;\n  padding: 2px;\n  margin-left: 3px;\n  display: inline-block;\n}\n\n.edit-item {\n  cursor: -webkit-grab;\n  cursor: grab;\n}\n\n.edit-item:hover {\n  background-color: #9dd8dc;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxccHJvZ3JhbWEtYXVkaXRvcmlhLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHlCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQUNGOztBQUNBO0VBQ0UsV0FBQTtBQUVGOztBQUFBO0VBQ0Usc0JBQUE7QUFHRjs7QUFBQTtFQUNFLFdBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtBQUdGOztBQURBO0VBQ0UsZ0JBQUE7QUFJRjs7QUFEQTtFQUNFLDRCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUFJRjs7QUFGQTtFQUNJLFdBQUE7QUFLSjs7QUFIQTtFQUNJLG1CQUFBO0FBTUo7O0FBSkE7RUFDSSxlQUFBO0FBT0o7O0FBTEE7RUFDSSwwQkFBQTtFQUNBLGlCQUFBO0FBUUo7O0FBTkE7RUFDRSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0Esb0JBQUE7RUFBQSxZQUFBO0FBU0Y7O0FBUEE7RUFDRSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0Esb0JBQUE7RUFDQSxxQkFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EscUJBQUE7QUFVRjs7QUFSQTtFQUNFLG9CQUFBO0VBQUEsWUFBQTtBQVdGOztBQVRBO0VBQ0UseUJBQUE7QUFZRiIsImZpbGUiOiJwcm9ncmFtYS1hdWRpdG9yaWEucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNpY2xvLWhlYWRlciB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzNiYjhiZDtcclxuICBjb2xvcjogI2U2MjZkNjtcclxuICBmb250LXdlaWdodDogMzAwO1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxufVxyXG4uc2xpZGVyIC5zbGlkZXItcGFnZXIge1xyXG4gIGNvbG9yOiBibHVlO1xyXG59XHJcbi5zbGlkZS1mdWxsIHtcclxuICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uYXZhdGFyIHtcclxuICB3aWR0aDogNTBweDtcclxuICBkaXNwbGF5OiBibG9jaztcclxuICBtYXJnaW4tbGVmdDogYXV0bztcclxuICBtYXJnaW4tcmlnaHQ6IGF1dG87XHJcbn1cclxuaW9uLWNhcmQtY29udGVudCB7XHJcbiAgdGV4dC1hbGlnbjogbGVmdDtcclxufVxyXG5cclxuLmlvbi1jb250ZW50LXNtYWxsLWZvbnQge1xyXG4gIGZvbnQtZmFtaWx5OiBcIkNhbGlicmkgTGlnaHRcIjtcclxuICBmb250LXNpemU6IDEycHg7XHJcbiAgY29sb3I6ICMwOTM1Mzc7XHJcbn1cclxuLmNvbnRhaW5lci1kZXRhaWwtYXVkaXRvcmlhe1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbn1cclxuLmNvbnRhaW5lci1kZXRhaWwtY2VydGlmaWNhY2lvbntcclxuICAgIG1hcmdpbi1ib3R0b206IDE1cHg7XHJcbn1cclxuLmJ1dHRvbnMtZ3JvdXB7XHJcbiAgICBtYXJnaW4tdG9wOjVweDtcclxufVxyXG4udGl0bGUtbWVkaXVtLWZvbnR7XHJcbiAgICBmb250LWZhbWlseTogXCJDb3VyaWVyIE5ld1wiO1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxuLmJpZy1pY29uIHtcclxuICBmb250LXNpemU6IDEuMmVtO1xyXG4gIG1hcmdpbi1sZWZ0OiAzcHg7XHJcbiAgY3Vyc29yOiBncmFiO1xyXG59XHJcbi5ib3gtY2xpY2sge1xyXG4gIG1pbi13aWR0aDogMTAwcHg7XHJcbiAgbWluLWhlaWdodDogMjBweDtcclxuICBib3JkZXItYm90dG9tOiBzb2xpZDtcclxuICBib3JkZXItY29sb3I6ICM3NzhlOGY7XHJcbiAgYm9yZGVyLXdpZHRoOiAxcHg7XHJcbiAgcGFkZGluZzogMnB4O1xyXG4gIG1hcmdpbi1sZWZ0OiAzcHg7XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG59XHJcbi5lZGl0LWl0ZW0ge1xyXG4gIGN1cnNvcjogZ3JhYjtcclxufVxyXG4uZWRpdC1pdGVtOmhvdmVyIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjOWRkOGRjO1xyXG59Il19 */");

/***/ }),

/***/ "KzaY":
/*!********************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/apertura_auditoria/programa-auditoria/programa-auditoria.page.html ***!
  \********************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-custom-header\n  title=\"Programa de Auditoria\"\n  icon_name=\"calendar-number-outline\"\n></app-custom-header>\n\n<ion-content>\n  <ion-card *ngIf=\"currentCliente\">\n    <ion-card-header color=\"primary\">\n      <ion-card-subtitle\n        >ID CLIENTE: {{currentCliente.IdCliente}}\n      </ion-card-subtitle>\n      <ion-item color=\"primary\">\n        <ion-icon color=\"light\" name=\"server-outline\" slot=\"start\"></ion-icon>\n        <ion-label>CLIENTE: {{currentCliente.NombreRazon}}</ion-label>\n      </ion-item>\n      <ion-item color=\"certificacion\">\n        <ion-label\n          >CÓDIGO DE SERVICIO:\n          {{currentPraprogramasdeauditorium.codigoServicioWs}}</ion-label\n        >\n      </ion-item>\n    </ion-card-header>\n    <ion-card-content>\n      <ion-row>\n        <ion-col size=\"12\">\n          <div class=\"container-detail-certificacion ion-content-small-font\">\n            CODIGO IAF: {{currentPraprogramasdeauditorium.codigoIafws}}<br />\n            Organismo Certificador:\n            <span class=\"box-click edit-item\" (click)=\"mostrarOrganismo()\"\n              >{{currentPraprogramasdeauditorium.organismoCertificador}}</span\n            >\n          </div>\n          <ion-slides pager=\"false\" class=\"slide-full\">\n            <ion-slide\n              *ngFor=\"let ciclo of currentPraprogramasdeauditorium.praciclosprogauditoria; let i=index\"\n            >\n              <div class=\"container-detail-auditoria\">\n                <ion-item color=\"title-medium\">\n                  <ion-label class=\"title-medium-font\">\n                    <ion-icon\n                      name=\"pencil-sharp\"\n                      slot=\"end\"\n                      (click)=\"editarCiclo(ciclo, i)\"\n                      class=\"big-icon\"\n                    ></ion-icon>\n                    AÑO {{ciclo.anio}} {{ciclo.referencia}}\n                  </ion-label>\n                </ion-item>\n                <ion-row>\n                  <ion-col\n                    size=\"6\"\n                    size-lg=\"6\"\n                    size-md=\"6\"\n                    size-sm=\"6\"\n                    size-xs=\"12\"\n                  >\n                    <app-pra-cronograma\n                      [currentPraciclocronogramas]=\"ciclo.praciclocronogramas[0]\"\n                    ></app-pra-cronograma>\n                  </ion-col>\n                  <ion-col\n                    size=\"6\"\n                    size-lg=\"6\"\n                    size-md=\"6\"\n                    size-sm=\"6\"\n                    size-xs=\"12\"\n                  >\n                    <app-ciclo-participante\n                      [currentPracicloparticipantes]=\"ciclo.pracicloparticipantes\"\n                    ></app-ciclo-participante>\n                  </ion-col>\n                </ion-row>\n                <app-tcp-list-products\n                  [productList]=\"ciclo.pradireccionespaproductos\"\n                  [nombreOrganizacion]=\"ciclo.nombreOrganizacionCertificado\"\n                  *ngIf=\"mode === 'TCP'\"\n                ></app-tcp-list-products>\n                <app-tcs-list-systems\n                  [nombreOrganizacion]=\"ciclo.nombreOrganizacionCertificado\"\n                  [direccionesSistema]=\"ciclo.pradireccionespasistemas\"\n                  [normasSistema]=\"ciclo.praciclonormassistemas\"\n                  *ngIf=\"mode === 'TCS'\"\n                ></app-tcs-list-systems>\n                <ion-buttons slot=\"start\" class=\"buttons-group\">\n                  <ion-button\n                    size=\"small\"\n                    fill=\"outline\"\n                    color=\"success\"\n                    (click)=\"guardarPrograma()\"\n                  >\n                    <ion-icon slot=\"start\" name=\"save\"></ion-icon>\n                    Guardar\n                  </ion-button>\n                  <ion-button\n                    size=\"small\"\n                    fill=\"outline\"\n                    color=\"tertiary\"\n                    (click)=\"VerDesignacion(ciclo)\"\n                  >\n                    <ion-icon slot=\"start\" name=\"document\"></ion-icon>\n                    Ver Designacion\n                  </ion-button>\n                </ion-buttons>\n              </div>\n            </ion-slide>\n          </ion-slides>\n        </ion-col>\n      </ion-row>\n    </ion-card-content>\n  </ion-card>\n</ion-content>\n");

/***/ }),

/***/ "PTeW":
/*!******************************************************************************************!*\
  !*** ./src/app/pages/apertura_auditoria/programa-auditoria/programa-auditoria.module.ts ***!
  \******************************************************************************************/
/*! exports provided: ProgramaAuditoriaPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProgramaAuditoriaPageModule", function() { return ProgramaAuditoriaPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _programa_auditoria_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./programa-auditoria-routing.module */ "ayrI");
/* harmony import */ var br_mask__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! br-mask */ "mzEM");
/* harmony import */ var _programa_auditoria_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./programa-auditoria.page */ "o3gy");
/* harmony import */ var _components_components_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./../../../components/components.module */ "j1ZV");









let ProgramaAuditoriaPageModule = class ProgramaAuditoriaPageModule {
};
ProgramaAuditoriaPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _programa_auditoria_routing_module__WEBPACK_IMPORTED_MODULE_5__["ProgramaAuditoriaPageRoutingModule"],
            br_mask__WEBPACK_IMPORTED_MODULE_6__["BrMaskerModule"],
            _components_components_module__WEBPACK_IMPORTED_MODULE_8__["ComponentsModule"]
        ],
        declarations: [_programa_auditoria_page__WEBPACK_IMPORTED_MODULE_7__["ProgramaAuditoriaPage"]]
    })
], ProgramaAuditoriaPageModule);



/***/ }),

/***/ "ayrI":
/*!**************************************************************************************************!*\
  !*** ./src/app/pages/apertura_auditoria/programa-auditoria/programa-auditoria-routing.module.ts ***!
  \**************************************************************************************************/
/*! exports provided: ProgramaAuditoriaPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProgramaAuditoriaPageRoutingModule", function() { return ProgramaAuditoriaPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _programa_auditoria_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./programa-auditoria.page */ "o3gy");




const routes = [
    {
        path: '',
        component: _programa_auditoria_page__WEBPACK_IMPORTED_MODULE_3__["ProgramaAuditoriaPage"]
    }
];
let ProgramaAuditoriaPageRoutingModule = class ProgramaAuditoriaPageRoutingModule {
};
ProgramaAuditoriaPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ProgramaAuditoriaPageRoutingModule);



/***/ }),

/***/ "o3gy":
/*!****************************************************************************************!*\
  !*** ./src/app/pages/apertura_auditoria/programa-auditoria/programa-auditoria.page.ts ***!
  \****************************************************************************************/
/*! exports provided: ProgramaAuditoriaPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProgramaAuditoriaPage", function() { return ProgramaAuditoriaPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_programa_auditoria_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./programa-auditoria.page.html */ "KzaY");
/* harmony import */ var _programa_auditoria_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./programa-auditoria.page.scss */ "4Rew");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var src_app_components_custom_input_custom_input_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/components/custom-input/custom-input.component */ "P85u");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var src_app_services_apertura_auditoria_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/services/apertura-auditoria.service */ "Aoky");
/* harmony import */ var src_app_components_param_organismos_certificadores_param_organismos_certificadores_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/components/param-organismos-certificadores/param-organismos-certificadores.component */ "w0e+");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var src_app_services_docmentos_services_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/services/docmentos-services.service */ "RWpN");












let ProgramaAuditoriaPage = class ProgramaAuditoriaPage {
    constructor(modalController, formBuilder, popoverController, datepipe, aperturaAuditoriaService, route, docmentosServicesService) {
        this.modalController = modalController;
        this.formBuilder = formBuilder;
        this.popoverController = popoverController;
        this.datepipe = datepipe;
        this.aperturaAuditoriaService = aperturaAuditoriaService;
        this.route = route;
        this.docmentosServicesService = docmentosServicesService;
        this.mode = "TCS";
    }
    ngOnInit() {
        this.route.queryParams.subscribe((params) => {
            console.log(params);
            if (params.currentIdService) {
                this.currentIdService = params.currentIdService;
                console.log("Id servicio", this.currentIdService);
                ///TDO : convocacmos al servicio para obtner la informacion globla de los servicios TCS TCP
                this.aperturaAuditoriaService
                    .ObtenerProgramaAuditoria(this.currentIdService)
                    .subscribe((resul) => {
                    console.log(resul);
                    if (resul.state === 1) {
                        this.currentPraprogramasdeauditorium = resul.object;
                        this.currentCliente = JSON.parse(resul.object.organizacionContentWs);
                        this.currentDatosServicio = JSON.parse(resul.object.detalleServicioWs);
                        this.currentPraprogramasdeauditorium.praciclosprogauditoria.forEach((x) => {
                            //copiamos los estaodos del ciclo al cronoramoa
                            x.praciclocronogramas[0].estado = x.estadoDescripcion;
                            //deseralizamos los cargos
                            if (x.pracicloparticipantes) {
                                x.pracicloparticipantes.forEach((yy) => {
                                    yy._cargo = JSON.parse(yy.cargoDetalleWs);
                                    if (yy._cargo["cod_tipoauditor"]) {
                                        yy._cargo.idCargoPuesto = yy._cargo["cod_tipoauditor"];
                                        yy._cargo.cargoPuesto = yy._cargo["descripcion"];
                                    }
                                    if (yy.participanteDetalleWs) {
                                        yy._personal = JSON.parse(yy.participanteDetalleWs);
                                    }
                                });
                            }
                        });
                        this.mode = this.currentDatosServicio.area;
                    }
                    else {
                        this.aperturaAuditoriaService.showMessageResponse(resul);
                    }
                });
            }
            else {
                this.aperturaAuditoriaService.showMessageError("No se recibio ningun parametro de Id de servicio de auditoria");
            }
        });
        this.programaForm = this.formBuilder.group({});
    }
    mostrarSitios() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            console.log("llamando a mostrar sitios");
        });
    }
    editarCiclo(ciclo, index) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            console.log("editamos ciclo", ciclo);
            const popover = yield this.popoverController.create({
                component: src_app_components_custom_input_custom_input_component__WEBPACK_IMPORTED_MODULE_6__["CustomInputComponent"],
                componentProps: {
                    formGruop: this.programaForm,
                    label: "Referencia",
                    name: "referencia",
                    type: "text",
                    form: "form",
                    defaultValue: ciclo.referencia,
                },
                event: event,
                mode: "ios",
                backdropDismiss: false,
            });
            yield popover.present();
            const info = yield popover.onDidDismiss();
            console.log("Padre", info);
            ciclo.referencia = info.data.item;
        });
    }
    guardarPrograma() {
        this.aperturaAuditoriaService
            .RegisterProgramaAuditoria(this.currentPraprogramasdeauditorium)
            .subscribe((x) => {
            this.aperturaAuditoriaService.showMessageResponse(x);
            if (x.state === 1) {
                x.object.praciclosprogauditoria.forEach((x) => {
                    //copiamos los estaodos del ciclo al cronoramoa
                    x.praciclocronogramas[0].estado = x.estadoDescripcion;
                    //deseralizamos los cargos
                    if (x.pracicloparticipantes) {
                        x.pracicloparticipantes.forEach((yy) => {
                            yy._cargo = JSON.parse(yy.cargoDetalleWs);
                            if (yy._cargo["cod_tipoauditor"]) {
                                yy._cargo.idCargoPuesto = yy._cargo["cod_tipoauditor"];
                                yy._cargo.cargoPuesto = yy._cargo["descripcion"];
                            }
                            if (yy.participanteDetalleWs) {
                                yy._personal = JSON.parse(yy.participanteDetalleWs);
                            }
                        });
                    }
                });
                this.currentPraprogramasdeauditorium = x.object;
                this.currentCliente = JSON.parse(x.object.organizacionContentWs);
                this.currentDatosServicio = JSON.parse(x.object.detalleServicioWs);
                this.mode = this.currentDatosServicio.area;
            }
        });
    }
    VerDesignacion(ciclo) {
        let nombrePlantilla = this.mode === "TCS" ? "REG-PRO-TCS-03-01" : "REG-PRO-TCP-03-01";
        this.docmentosServicesService.GenerarDocumento(ciclo.idPrAcicloProgAuditoria, nombrePlantilla);
        /*this.aperturaAuditoriaService
          .GenerarDesignacion(
            ciclo.idPrAcicloProgAuditoria,
            "REG-PRO-TCS-03-01 Designación auditoria TCS Ver 1.0.doc"
          )
          .subscribe((x) => {
            console.log(x);
            //this.presentToast(x.message);
            this.aperturaAuditoriaService.ObtenerArchivoDesignacion(x.message);
          });*/
    }
    mostrarOrganismo() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            console.log("mostramos las organizaciones");
            const popover = yield this.popoverController.create({
                component: src_app_components_param_organismos_certificadores_param_organismos_certificadores_component__WEBPACK_IMPORTED_MODULE_9__["ParamOrganismosCertificadoresComponent"],
                componentProps: {
                    defaultValue: this.currentPraprogramasdeauditorium
                        .organismoCertificador,
                },
                event: event,
                mode: "ios",
                backdropDismiss: false,
            });
            yield popover.present();
            const info = yield popover.onDidDismiss();
            console.log("Padre", info);
            this.currentPraprogramasdeauditorium.organismoCertificador = info.data.item;
        });
    }
};
ProgramaAuditoriaPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["PopoverController"] },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_7__["DatePipe"] },
    { type: src_app_services_apertura_auditoria_service__WEBPACK_IMPORTED_MODULE_8__["AperturaAuditoriaService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__["ActivatedRoute"] },
    { type: src_app_services_docmentos_services_service__WEBPACK_IMPORTED_MODULE_11__["DocmentosServicesService"] }
];
ProgramaAuditoriaPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: "app-programa-auditoria",
        template: _raw_loader_programa_auditoria_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_programa_auditoria_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ProgramaAuditoriaPage);



/***/ })

}]);
//# sourceMappingURL=pages-apertura_auditoria-programa-auditoria-programa-auditoria-module-es2015.js.map