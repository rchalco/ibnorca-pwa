(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-elaboracion_auditoria-list-ciclos-list-ciclos-module"],{

/***/ "286E":
/*!*******************************************************************************!*\
  !*** ./src/app/pages/elaboracion_auditoria/list-ciclos/list-ciclos.module.ts ***!
  \*******************************************************************************/
/*! exports provided: ListCiclosPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListCiclosPageModule", function() { return ListCiclosPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _list_ciclos_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./list-ciclos-routing.module */ "rRX0");
/* harmony import */ var _list_ciclos_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./list-ciclos.page */ "RLxy");
/* harmony import */ var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/components/components.module */ "j1ZV");








let ListCiclosPageModule = class ListCiclosPageModule {
};
ListCiclosPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _list_ciclos_routing_module__WEBPACK_IMPORTED_MODULE_5__["ListCiclosPageRoutingModule"],
            src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"],
        ],
        declarations: [_list_ciclos_page__WEBPACK_IMPORTED_MODULE_6__["ListCiclosPage"]],
    })
], ListCiclosPageModule);



/***/ }),

/***/ "RLxy":
/*!*****************************************************************************!*\
  !*** ./src/app/pages/elaboracion_auditoria/list-ciclos/list-ciclos.page.ts ***!
  \*****************************************************************************/
/*! exports provided: ListCiclosPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListCiclosPage", function() { return ListCiclosPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_list_ciclos_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./list-ciclos.page.html */ "wb26");
/* harmony import */ var _list_ciclos_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./list-ciclos.page.scss */ "Y/6G");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var src_app_services_elaboracion_auditoria_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/elaboracion-auditoria.service */ "6V/C");






let ListCiclosPage = class ListCiclosPage {
    constructor(elaboracionAuditoriaService, route, router) {
        this.elaboracionAuditoriaService = elaboracionAuditoriaService;
        this.route = route;
        this.router = router;
        this.idAuditor = 0;
    }
    ngOnInit() {
        this.route.queryParams.subscribe((params) => {
            console.log(params);
            if (params.idAuditor) {
                this.idAuditor = params.idAuditor;
                this.elaboracionAuditoriaService
                    .ObtenerCiclosPorIdAuditor(this.idAuditor)
                    .subscribe((x) => (this.listCiclos = x.listEntities));
            }
            else {
                this.elaboracionAuditoriaService.showMessageError("No se recibio ningun parametro de Id de auditor");
            }
        });
    }
    navMasterPlanAuditoria(_idCiclo) {
        this.router.navigateByUrl("master-elaboracion-auditoria?idCicloAuditoria=" + _idCiclo);
    }
};
ListCiclosPage.ctorParameters = () => [
    { type: src_app_services_elaboracion_auditoria_service__WEBPACK_IMPORTED_MODULE_5__["ElaboracionAuditoriaService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] }
];
ListCiclosPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: "app-list-ciclos",
        template: _raw_loader_list_ciclos_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_list_ciclos_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ListCiclosPage);



/***/ }),

/***/ "Y/6G":
/*!*******************************************************************************!*\
  !*** ./src/app/pages/elaboracion_auditoria/list-ciclos/list-ciclos.page.scss ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".container-product-list {\n  margin-top: 0em;\n}\n\n.popover-content.sc-ion-popover-md {\n  width: 500px !important;\n}\n\n.my-custom-modal-css .modal-wrapper {\n  width: 600px;\n  height: 650px !important;\n}\n\n.normas {\n  font-size: 12px;\n  color: #1b192c;\n}\n\n.title-normas {\n  color: #0b480f;\n  font-size: 1em;\n  text-align: left;\n}\n\n.norma-block {\n  background-color: #c6e8e6;\n  padding: 10px;\n  margin: 1.5px;\n  min-width: 100%;\n}\n\n.big-icon {\n  font-size: 1.2em;\n  margin-left: 3px;\n  cursor: -webkit-grab;\n  cursor: grab;\n}\n\n.detail-paragraph {\n  font-size: 11px;\n  color: #3d3c44;\n}\n\n.sub-title {\n  /*font-style: italic;*/\n  font-size: 13px;\n  color: #055a0f;\n  font-family: sans-serif;\n}\n\n.direccion-block {\n  background-color: #c1ebd6;\n  padding: 10px;\n  margin: 1.5px;\n  min-width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcbGlzdC1jaWNsb3MucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZUFBQTtBQUNKOztBQUNFO0VBQ0ksdUJBQUE7QUFFTjs7QUFDRTtFQUNFLFlBQUE7RUFDQSx3QkFBQTtBQUVKOztBQUFFO0VBQ0UsZUFBQTtFQUNBLGNBQUE7QUFHSjs7QUFERTtFQUNFLGNBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7QUFJSjs7QUFGRTtFQUNFLHlCQUFBO0VBQ0EsYUFBQTtFQUNBLGFBQUE7RUFDQSxlQUFBO0FBS0o7O0FBSEU7RUFDRSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0Esb0JBQUE7RUFBQSxZQUFBO0FBTUo7O0FBSkU7RUFDRSxlQUFBO0VBQ0EsY0FBQTtBQU9KOztBQUxFO0VBQ0Usc0JBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLHVCQUFBO0FBUUo7O0FBTkU7RUFDRSx5QkFBQTtFQUNBLGFBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtBQVNKIiwiZmlsZSI6Imxpc3QtY2ljbG9zLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXItcHJvZHVjdC1saXN0IHtcclxuICAgIG1hcmdpbi10b3A6IDBlbTtcclxuICB9XHJcbiAgLnBvcG92ZXItY29udGVudC5zYy1pb24tcG9wb3Zlci1tZCB7XHJcbiAgICAgIHdpZHRoOiA1MDBweCAhaW1wb3J0YW50O1xyXG4gIH1cclxuICBcclxuICAubXktY3VzdG9tLW1vZGFsLWNzcyAubW9kYWwtd3JhcHBlciB7XHJcbiAgICB3aWR0aDogNjAwcHg7XHJcbiAgICBoZWlnaHQ6IDY1MHB4ICFpbXBvcnRhbnQ7XHJcbiAgfSBcclxuICAubm9ybWFzIHtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIGNvbG9yOiAjMWIxOTJjO1xyXG4gIH1cclxuICAudGl0bGUtbm9ybWFzIHtcclxuICAgIGNvbG9yOiAjMGI0ODBmO1xyXG4gICAgZm9udC1zaXplOiAxZW07XHJcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gIH1cclxuICAubm9ybWEtYmxvY2sge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2M2ZThlNjtcclxuICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICBtYXJnaW46IDEuNXB4O1xyXG4gICAgbWluLXdpZHRoOiAxMDAlO1xyXG4gIH1cclxuICAuYmlnLWljb24ge1xyXG4gICAgZm9udC1zaXplOiAxLjJlbTtcclxuICAgIG1hcmdpbi1sZWZ0OiAzcHg7XHJcbiAgICBjdXJzb3I6IGdyYWI7XHJcbiAgfVxyXG4gIC5kZXRhaWwtcGFyYWdyYXBoIHtcclxuICAgIGZvbnQtc2l6ZTogMTFweDtcclxuICAgIGNvbG9yOiAjM2QzYzQ0O1xyXG4gIH1cclxuICAuc3ViLXRpdGxlIHtcclxuICAgIC8qZm9udC1zdHlsZTogaXRhbGljOyovXHJcbiAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICBjb2xvcjogIzA1NWEwZjtcclxuICAgIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xyXG4gIH1cclxuICAuZGlyZWNjaW9uLWJsb2NrIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNjMWViZDY7XHJcbiAgICBwYWRkaW5nOiAxMHB4O1xyXG4gICAgbWFyZ2luOiAxLjVweDtcclxuICAgIG1pbi13aWR0aDogMTAwJTtcclxuICB9Il19 */");

/***/ }),

/***/ "rRX0":
/*!***************************************************************************************!*\
  !*** ./src/app/pages/elaboracion_auditoria/list-ciclos/list-ciclos-routing.module.ts ***!
  \***************************************************************************************/
/*! exports provided: ListCiclosPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListCiclosPageRoutingModule", function() { return ListCiclosPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _list_ciclos_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./list-ciclos.page */ "RLxy");




const routes = [
    {
        path: '',
        component: _list_ciclos_page__WEBPACK_IMPORTED_MODULE_3__["ListCiclosPage"]
    }
];
let ListCiclosPageRoutingModule = class ListCiclosPageRoutingModule {
};
ListCiclosPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ListCiclosPageRoutingModule);



/***/ }),

/***/ "wb26":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/elaboracion_auditoria/list-ciclos/list-ciclos.page.html ***!
  \*********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-custom-header\n  title=\"Lista de Audiorias Pendientes\"\n  icon_name=\"clipboard\"\n></app-custom-header>\n<ion-content>\n  <ion-list>\n    <ion-item *ngFor=\"let ciclo of listCiclos; let i = index\">\n      <ion-icon\n        name=\"pencil-sharp\"\n        slot=\"start\"\n        (click)=\"navMasterPlanAuditoria(ciclo.idCicloAuditoria)\"\n        class=\"big-icon\"\n      ></ion-icon>\n      <div class=\"norma-block\">\n        <h2>Cliente: {{ ciclo.nombreCliente }}</h2>\n        <p>\n          Tipo Auditoría\n          <span class=\"sub-title\">{{ ciclo.referenciaCiclo }}</span>\n          | Codigo Servicio\n          <span class=\"sub-title\">{{ ciclo.codigoServicio }}</span>\n          | Id Ciclo\n          <span class=\"sub-title\">{{ ciclo.idCicloAuditoria }}</span>\n        </p>\n        <p class=\"detail-paragraph\">\n          Fecha Auditoria {{ ciclo.fechaAuditoria }} | Responsable {{\n          ciclo.responsable }}\n        </p>\n      </div>\n    </ion-item>\n  </ion-list>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=pages-elaboracion_auditoria-list-ciclos-list-ciclos-module-es2015.js.map