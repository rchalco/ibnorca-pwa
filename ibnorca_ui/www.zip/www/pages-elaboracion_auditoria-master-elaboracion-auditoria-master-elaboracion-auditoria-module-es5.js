(function () {
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-elaboracion_auditoria-master-elaboracion-auditoria-master-elaboracion-auditoria-module"], {
    /***/
    "G6Kd":
    /*!***************************************************************************************************************!*\
      !*** ./src/app/pages/elaboracion_auditoria/master-elaboracion-auditoria/master-elaboracion-auditoria.page.ts ***!
      \***************************************************************************************************************/

    /*! exports provided: MasterElaboracionAuditoriaPage */

    /***/
    function G6Kd(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "MasterElaboracionAuditoriaPage", function () {
        return MasterElaboracionAuditoriaPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_master_elaboracion_auditoria_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./master-elaboracion-auditoria.page.html */
      "LvnO");
      /* harmony import */


      var _master_elaboracion_auditoria_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./master-elaboracion-auditoria.page.scss */
      "nU7e");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/router */
      "iInd");
      /* harmony import */


      var src_app_services_elaboracion_auditoria_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! src/app/services/elaboracion-auditoria.service */
      "6V/C");

      var MasterElaboracionAuditoriaPage = /*#__PURE__*/function () {
        function MasterElaboracionAuditoriaPage(route, elaboracionAuditoriaService) {
          _classCallCheck(this, MasterElaboracionAuditoriaPage);

          this.route = route;
          this.elaboracionAuditoriaService = elaboracionAuditoriaService;
          this.select_component = "plan_auditoria";
          this.idCicloAuditoria = 0;
          this.listaDirecciones = [];
          this.area = "";
          this.proceso = "ELABORACION";
        }

        _createClass(MasterElaboracionAuditoriaPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this = this;

            this.route.queryParams.subscribe(function (params) {
              console.log(params);

              if (params.idCicloAuditoria) {
                _this.idCicloAuditoria = params.idCicloAuditoria;
                console.log("Id de ciclo", _this.idCicloAuditoria);

                _this.elaboracionAuditoriaService.ObtenerPlanAuditoria(_this.idCicloAuditoria).subscribe(function (x) {
                  console.log("resul service master", x);
                  _this.currentPlanAuditoriaDTO = x.object;

                  _this.cargarObjetosAuxiliares();

                  if (x.state != 1) {
                    _this.elaboracionAuditoriaService.showMessageError(x.message);
                  } else {
                    console.log(_this.currentPlanAuditoriaDTO.pracicloparticipante);
                    _this.area = _this.currentPlanAuditoriaDTO.area;
                  }
                });
              } else {
                _this.elaboracionAuditoriaService.showMessageError("No se recibio ningun parametro de Id de Ciclo de auditoria");
              }
            });
          }
        }, {
          key: "cargarObjetosAuxiliares",
          value: function cargarObjetosAuxiliares() {
            var _this2 = this;

            var _a, _b, _c;

            this.currentPlanAuditoriaDTO["listaParticipantes"] = new Array(); //se asgina el check de seleccionado a la auditoria

            (_a = this.currentPlanAuditoriaDTO.elaauditorium.elacontenidoauditoria) === null || _a === void 0 ? void 0 : _a.forEach(function (contenido) {
              if (contenido.seleccionado === 1) {
                contenido["select"] = true;
              }
            }); //asignamos los objetos de cargos y participantes

            this.currentPlanAuditoriaDTO.pracicloparticipante.forEach(function (yy) {
              yy._cargo = JSON.parse(yy.cargoDetalleWs);

              if (yy._cargo["cod_tipoauditor"]) {
                yy._cargo.idCargoPuesto = yy._cargo["cod_tipoauditor"];
                yy._cargo.cargoPuesto = yy._cargo["descripcion"];
              }

              if (yy.participanteDetalleWs) {
                yy._personal = JSON.parse(yy.participanteDetalleWs);

                _this2.currentPlanAuditoriaDTO["listaParticipantes"].push(yy._personal);
              }
            }); //asignamos a las listas de crongramas a los sistemas y productos

            (_b = this.currentPlanAuditoriaDTO.pradireccionespaproducto) === null || _b === void 0 ? void 0 : _b.forEach(function (x) {
              x["listaCronograma"] = _this2.currentPlanAuditoriaDTO.elaauditorium.elacronogamas.filter(function (cronograma) {
                return cronograma.idDireccionPaproducto === x.idDireccionPaproducto;
              });
            });
            (_c = this.currentPlanAuditoriaDTO.pradireccionespasistema) === null || _c === void 0 ? void 0 : _c.forEach(function (x) {
              x["listaCronograma"] = _this2.currentPlanAuditoriaDTO.elaauditorium.elacronogamas.filter(function (cronograma) {
                return cronograma.idDireccionPasistema === x.idDireccionPasistema;
              });
            });
            this.currentPlanAuditoriaDTO.pradireccionespaproducto.forEach(function (x) {
              if (_this2.listaDirecciones.indexOf(x.direccion) === -1) {
                _this2.listaDirecciones.push(x.direccion);
              }
            });
            this.currentPlanAuditoriaDTO.pradireccionespasistema.forEach(function (x) {
              if (x.dias > 0 && _this2.listaDirecciones.indexOf(x.direccion) === -1) {
                _this2.listaDirecciones.push(x.direccion);
              }
            });
          }
        }, {
          key: "guardarCronograma",
          value: function guardarCronograma(event) {
            var _this3 = this;

            console.log("llego al lista de crongrma", event);

            if (!this.currentPlanAuditoriaDTO.elaauditorium.elacronogamas) {
              this.currentPlanAuditoriaDTO.elaauditorium.elacronogamas = new Array();
              this.currentPlanAuditoriaDTO.elaauditorium.elacronogamas = this.currentPlanAuditoriaDTO.elaauditorium.elacronogamas.concat(event);
            } else {
              //modificamos o adicionamos
              event.forEach(function (element) {
                var indexFindElement = _this3.currentPlanAuditoriaDTO.elaauditorium.elacronogamas.findIndex(function (x) {
                  return x.idElAcronograma === element.idElAcronograma;
                });

                if (indexFindElement >= 0) {
                  _this3.currentPlanAuditoriaDTO.elaauditorium.elacronogamas[indexFindElement] = element;
                } else {
                  _this3.currentPlanAuditoriaDTO.elaauditorium.elacronogamas.push(element);
                }
              });
            }

            console.log("antes de enviar al registro", this.currentPlanAuditoriaDTO);
            this.elaboracionAuditoriaService.RegistrarPlanAuditoria(this.currentPlanAuditoriaDTO).subscribe(function (x) {
              console.log("resul  RegistrarPlanAuditoria", x);

              _this3.elaboracionAuditoriaService.showMessageResponse(x);
            });
          }
        }, {
          key: "eliminarElmentCronograma",
          value: function eliminarElmentCronograma(pIdElaCronograma) {
            var _this4 = this;

            console.log("eleminar cronograma id:", pIdElaCronograma);
            var indexFindElement = this.currentPlanAuditoriaDTO.elaauditorium.elacronogamas.findIndex(function (x) {
              return x.idElAcronograma === pIdElaCronograma;
            });

            if (indexFindElement >= 0) {
              this.currentPlanAuditoriaDTO.elaauditorium.elacronogamas.splice(indexFindElement, 1);
              this.elaboracionAuditoriaService.RegistrarPlanAuditoria(this.currentPlanAuditoriaDTO).subscribe(function (x) {
                console.log("resul  RegistrarPlanAuditoria", x);

                _this4.elaboracionAuditoriaService.showMessageResponse(x);
              });
            }
          }
        }, {
          key: "guardarHallazgo",
          value: function guardarHallazgo(event) {
            var _this5 = this;

            this.currentPlanAuditoriaDTO.elaauditorium.elahallazgos = event;
            this.elaboracionAuditoriaService.RegistrarPlanAuditoria(this.currentPlanAuditoriaDTO).subscribe(function (x) {
              if (x.state === 1) {
                _this5.currentPlanAuditoriaDTO = x.object;

                _this5.cargarObjetosAuxiliares();
              }

              _this5.elaboracionAuditoriaService.showMessageResponse(x);
            });
          }
        }, {
          key: "guardarAdp",
          value: function guardarAdp(event) {
            var _this6 = this;

            this.currentPlanAuditoriaDTO.elaauditorium.elaadps = event;
            console.log("guardamos adp", this.currentPlanAuditoriaDTO);
            this.elaboracionAuditoriaService.RegistrarPlanAuditoria(this.currentPlanAuditoriaDTO).subscribe(function (x) {
              if (x.state === 1) {
                _this6.currentPlanAuditoriaDTO = x.object;

                _this6.cargarObjetosAuxiliares();
              }

              _this6.elaboracionAuditoriaService.showMessageResponse(x);
            });
          }
        }, {
          key: "guardarContenido",
          value: function guardarContenido(event) {
            var _this7 = this;

            this.currentPlanAuditoriaDTO.elaauditorium.elacontenidoauditoria = event;
            console.log("guardamos contenido", this.currentPlanAuditoriaDTO);
            this.elaboracionAuditoriaService.RegistrarPlanAuditoria(this.currentPlanAuditoriaDTO).subscribe(function (x) {
              if (x.state === 1) {
                _this7.currentPlanAuditoriaDTO = x.object;

                _this7.cargarObjetosAuxiliares();
              }

              _this7.elaboracionAuditoriaService.showMessageResponse(x);
            });
          }
        }, {
          key: "guardarPlanMuestreo",
          value: function guardarPlanMuestreo(event) {
            var _this8 = this;

            this.currentPlanAuditoriaDTO.elaauditorium.elacontenidoauditoria = event;
            this.elaboracionAuditoriaService.RegistrarPlanAuditoria(this.currentPlanAuditoriaDTO).subscribe(function (x) {
              if (x.state === 1) {
                _this8.currentPlanAuditoriaDTO = x.object;

                _this8.cargarObjetosAuxiliares();
              }

              _this8.elaboracionAuditoriaService.showMessageResponse(x);
            });
          }
        }, {
          key: "segmentChanged",
          value: function segmentChanged(event) {
            this.select_component = event.detail.value;
          }
        }]);

        return MasterElaboracionAuditoriaPage;
      }();

      MasterElaboracionAuditoriaPage.ctorParameters = function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"]
        }, {
          type: src_app_services_elaboracion_auditoria_service__WEBPACK_IMPORTED_MODULE_5__["ElaboracionAuditoriaService"]
        }];
      };

      MasterElaboracionAuditoriaPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: "app-master-elaboracion-auditoria",
        template: _raw_loader_master_elaboracion_auditoria_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_master_elaboracion_auditoria_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], MasterElaboracionAuditoriaPage);
      /***/
    },

    /***/
    "LvnO":
    /*!*******************************************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/elaboracion_auditoria/master-elaboracion-auditoria/master-elaboracion-auditoria.page.html ***!
      \*******************************************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function LvnO(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-toolbar>\r\n  <ion-segment #segment1 (ionChange)=\"segmentChanged($event)\" color=\"tertiary\">\r\n    <ion-segment-button value=\"plan_auditoria\">\r\n      <ion-label>Plan Auditoria</ion-label>\r\n    </ion-segment-button>\r\n    <ion-segment-button value=\"list_hallazgo\">\r\n      <ion-label>Registro de Hallazgos</ion-label>\r\n    </ion-segment-button>\r\n    <ion-segment-button\r\n      value=\"list_areas\"\r\n      *ngIf=\"currentPlanAuditoriaDTO && currentPlanAuditoriaDTO.area== 'TCS'\">\r\n      <ion-label>Areas de Preocupacion</ion-label>\r\n    </ion-segment-button>\r\n\r\n    <ion-segment-button\r\n      value=\"plan_muestreo\"\r\n      *ngIf=\"currentPlanAuditoriaDTO && currentPlanAuditoriaDTO.area== 'TCP'\">\r\n      <ion-label>PLAN MUESTREO</ion-label>\r\n    </ion-segment-button>\r\n\r\n    <!-- <ion-segment-button value=\"list_contenido\">\r\n      <ion-label>Contenido</ion-label>\r\n    </ion-segment-button> -->\r\n    <ion-segment-button value=\"list_documentos\">\r\n      <ion-label>Documentación</ion-label>\r\n    </ion-segment-button>\r\n  </ion-segment>\r\n</ion-toolbar>\r\n<ion-content>\r\n\r\n  <div *ngIf=\"select_component === 'plan_auditoria' && currentPlanAuditoriaDTO\">\r\n    <app-plan-auditoria\r\n      [currentPlanAuditoriaDTO]=\"currentPlanAuditoriaDTO\"\r\n      (guardarCronogramaEmitter)=\"guardarCronograma($event)\"\r\n      (eliminarCronogramaEmitter)=\"eliminarElmentCronograma($event)\">\r\n    </app-plan-auditoria>\r\n    <app-ela-plan-muestreo\r\n      [listaContenido]=\"currentPlanAuditoriaDTO.elaauditorium.elacontenidoauditoria\"\r\n      titulo=\"OBJETIVOS\"\r\n      nemotico=\"PLAN_OBJETIVOS\"\r\n      (guardarPlanMuestreo)=\"guardarPlanMuestreo($event)\"\r\n      *ngIf=\"currentPlanAuditoriaDTO && currentPlanAuditoriaDTO.area== 'TCS'\">\r\n    </app-ela-plan-muestreo>\r\n    <app-ela-plan-muestreo\r\n      [listaContenido]=\"currentPlanAuditoriaDTO.elaauditorium.elacontenidoauditoria\"\r\n      titulo=\"DOCUMENTOS DE REFERENCIA\"\r\n      nemotico=\"PLAN_CRITERIO\"\r\n      (guardarPlanMuestreo)=\"guardarPlanMuestreo($event)\"\r\n      *ngIf=\"currentPlanAuditoriaDTO && currentPlanAuditoriaDTO.area== 'TCP'\">\r\n    </app-ela-plan-muestreo>\r\n    <app-ela-cronograma-list\r\n      [listaParticipantes]=\"currentPlanAuditoriaDTO['listaParticipantes']\"\r\n      [listCronograma]=\"currentPlanAuditoriaDTO.elaauditorium.elacronogamas\"\r\n      [listaDirecciones]=\"listaDirecciones\"\r\n      (guardarCronogramaEmitter)=\"guardarCronograma($event)\"\r\n      (eliminarCronogramaEmitter)=\"eliminarElmentCronograma($event)\"></app-ela-cronograma-list>\r\n  </div>\r\n\r\n\r\n  <app-ela-registro-hallazgos\r\n    *ngIf=\"select_component === 'list_hallazgo'\"\r\n    [listaHallazgos]=\"currentPlanAuditoriaDTO.elaauditorium.elahallazgos\"\r\n    [lNormas]=\"currentPlanAuditoriaDTO.normas\"\r\n    (guardarHallazgoEmitter)=\"guardarHallazgo($event)\"></app-ela-registro-hallazgos>\r\n  <app-ela-objetivos\r\n    *ngIf=\"select_component === 'list_contenido'\"\r\n    [listContenido]=\"currentPlanAuditoriaDTO.elaauditorium.elacontenidoauditoria\"\r\n    (guardarContenidoEmitter)=\"guardarContenido($event)\"\r\n    [area]=\"area\">\r\n  </app-ela-objetivos>\r\n\r\n  <app-ela-registro-areapreocupacion\r\n    *ngIf=\"select_component === 'list_areas'\"\r\n    [listaAdp]=\"currentPlanAuditoriaDTO.elaauditorium.elaadps\"\r\n    (guardarAdpEmitter)=\"guardarAdp($event)\">\r\n  </app-ela-registro-areapreocupacion>\r\n\r\n  <app-param-documentos\r\n    [area]=\"currentPlanAuditoriaDTO.area\"\r\n    [IdCiclo]=\"idCicloAuditoria\"\r\n    [proceso]=\"proceso\"\r\n    *ngIf=\"select_component === 'list_documentos'\">\r\n  </app-param-documentos>\r\n\r\n  <app-ela-plan-muestreo\r\n    [listaContenido]=\"currentPlanAuditoriaDTO.elaauditorium.elacontenidoauditoria\"\r\n    titulo=\"REGISTRO DE PLAN DE AUDITORIA\"\r\n    nemotico=\"ACTAMUESTREO_PLAN\"\r\n    (guardarPlanMuestreo)=\"guardarPlanMuestreo($event)\"\r\n    *ngIf=\"select_component === 'plan_muestreo'\">\r\n  </app-ela-plan-muestreo>\r\n</ion-content>\r\n";
      /***/
    },

    /***/
    "mAE4":
    /*!*****************************************************************************************************************!*\
      !*** ./src/app/pages/elaboracion_auditoria/master-elaboracion-auditoria/master-elaboracion-auditoria.module.ts ***!
      \*****************************************************************************************************************/

    /*! exports provided: MasterElaboracionAuditoriaPageModule */

    /***/
    function mAE4(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "MasterElaboracionAuditoriaPageModule", function () {
        return MasterElaboracionAuditoriaPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "SVse");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "sZkV");
      /* harmony import */


      var _master_elaboracion_auditoria_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./master-elaboracion-auditoria-routing.module */
      "qSeu");
      /* harmony import */


      var _master_elaboracion_auditoria_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./master-elaboracion-auditoria.page */
      "G6Kd");
      /* harmony import */


      var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! src/app/components/components.module */
      "j1ZV");

      var MasterElaboracionAuditoriaPageModule = function MasterElaboracionAuditoriaPageModule() {
        _classCallCheck(this, MasterElaboracionAuditoriaPageModule);
      };

      MasterElaboracionAuditoriaPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _master_elaboracion_auditoria_routing_module__WEBPACK_IMPORTED_MODULE_5__["MasterElaboracionAuditoriaPageRoutingModule"], src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"]],
        declarations: [_master_elaboracion_auditoria_page__WEBPACK_IMPORTED_MODULE_6__["MasterElaboracionAuditoriaPage"]]
      })], MasterElaboracionAuditoriaPageModule);
      /***/
    },

    /***/
    "nU7e":
    /*!*****************************************************************************************************************!*\
      !*** ./src/app/pages/elaboracion_auditoria/master-elaboracion-auditoria/master-elaboracion-auditoria.page.scss ***!
      \*****************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function nU7e(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtYXN0ZXItZWxhYm9yYWNpb24tYXVkaXRvcmlhLnBhZ2Uuc2NzcyJ9 */";
      /***/
    },

    /***/
    "qSeu":
    /*!*************************************************************************************************************************!*\
      !*** ./src/app/pages/elaboracion_auditoria/master-elaboracion-auditoria/master-elaboracion-auditoria-routing.module.ts ***!
      \*************************************************************************************************************************/

    /*! exports provided: MasterElaboracionAuditoriaPageRoutingModule */

    /***/
    function qSeu(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "MasterElaboracionAuditoriaPageRoutingModule", function () {
        return MasterElaboracionAuditoriaPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "iInd");
      /* harmony import */


      var _master_elaboracion_auditoria_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./master-elaboracion-auditoria.page */
      "G6Kd");

      var routes = [{
        path: '',
        component: _master_elaboracion_auditoria_page__WEBPACK_IMPORTED_MODULE_3__["MasterElaboracionAuditoriaPage"]
      }];

      var MasterElaboracionAuditoriaPageRoutingModule = function MasterElaboracionAuditoriaPageRoutingModule() {
        _classCallCheck(this, MasterElaboracionAuditoriaPageRoutingModule);
      };

      MasterElaboracionAuditoriaPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], MasterElaboracionAuditoriaPageRoutingModule);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-elaboracion_auditoria-master-elaboracion-auditoria-master-elaboracion-auditoria-module-es5.js.map