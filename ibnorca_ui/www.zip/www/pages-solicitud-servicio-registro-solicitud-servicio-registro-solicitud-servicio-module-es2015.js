(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-solicitud-servicio-registro-solicitud-servicio-registro-solicitud-servicio-module"],{

/***/ "DNCf":
/*!************************************************************************************************************!*\
  !*** ./src/app/pages/solicitud-servicio/registro-solicitud-servicio/registro-solicitud-servicio.page.scss ***!
  \************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyZWdpc3Ryby1zb2xpY2l0dWQtc2VydmljaW8ucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "RTKG":
/*!************************************************************************************************************!*\
  !*** ./src/app/pages/solicitud-servicio/registro-solicitud-servicio/registro-solicitud-servicio.module.ts ***!
  \************************************************************************************************************/
/*! exports provided: RegistroSolicitudServicioPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegistroSolicitudServicioPageModule", function() { return RegistroSolicitudServicioPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _registro_solicitud_servicio_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./registro-solicitud-servicio-routing.module */ "qdyl");
/* harmony import */ var _registro_solicitud_servicio_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./registro-solicitud-servicio.page */ "sNTw");







let RegistroSolicitudServicioPageModule = class RegistroSolicitudServicioPageModule {
};
RegistroSolicitudServicioPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _registro_solicitud_servicio_routing_module__WEBPACK_IMPORTED_MODULE_5__["RegistroSolicitudServicioPageRoutingModule"]
        ],
        declarations: [_registro_solicitud_servicio_page__WEBPACK_IMPORTED_MODULE_6__["RegistroSolicitudServicioPage"]]
    })
], RegistroSolicitudServicioPageModule);



/***/ }),

/***/ "m2I4":
/*!**************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/solicitud-servicio/registro-solicitud-servicio/registro-solicitud-servicio.page.html ***!
  \**************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-title>Registro de solicitud de servicio</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <ion-list >    \n      <ion-item *ngIf=\"!procesoFinalizado\">\n        <ion-label>\n          Elija un archivo excel para subir la solicitud\n        </ion-label>\n        <ion-input type=\"file\" id=\"file\" (change)=\"handleFileInput($event.target.files)\"></ion-input>\n      </ion-item>    \n      <ion-item *ngIf=\"procesoFinalizado\" [routerLink]=\"['/']\">        \n        <ion-label>\n            Proceso finalizado, regresar\n          </ion-label>\n      </ion-item>    \n  </ion-list>  \n</ion-content>\n");

/***/ }),

/***/ "qdyl":
/*!********************************************************************************************************************!*\
  !*** ./src/app/pages/solicitud-servicio/registro-solicitud-servicio/registro-solicitud-servicio-routing.module.ts ***!
  \********************************************************************************************************************/
/*! exports provided: RegistroSolicitudServicioPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegistroSolicitudServicioPageRoutingModule", function() { return RegistroSolicitudServicioPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _registro_solicitud_servicio_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./registro-solicitud-servicio.page */ "sNTw");




const routes = [
    {
        path: '',
        component: _registro_solicitud_servicio_page__WEBPACK_IMPORTED_MODULE_3__["RegistroSolicitudServicioPage"]
    }
];
let RegistroSolicitudServicioPageRoutingModule = class RegistroSolicitudServicioPageRoutingModule {
};
RegistroSolicitudServicioPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], RegistroSolicitudServicioPageRoutingModule);



/***/ }),

/***/ "sNTw":
/*!**********************************************************************************************************!*\
  !*** ./src/app/pages/solicitud-servicio/registro-solicitud-servicio/registro-solicitud-servicio.page.ts ***!
  \**********************************************************************************************************/
/*! exports provided: RegistroSolicitudServicioPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegistroSolicitudServicioPage", function() { return RegistroSolicitudServicioPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_registro_solicitud_servicio_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./registro-solicitud-servicio.page.html */ "m2I4");
/* harmony import */ var _registro_solicitud_servicio_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./registro-solicitud-servicio.page.scss */ "DNCf");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var src_app_services_apertura_auditoria_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/apertura-auditoria.service */ "Aoky");





let RegistroSolicitudServicioPage = class RegistroSolicitudServicioPage {
    constructor(aperturaAuditoriaService) {
        this.aperturaAuditoriaService = aperturaAuditoriaService;
        this.fileToUpload = null;
        this.procesoFinalizado = false;
    }
    ngOnInit() {
    }
    handleFileInput(files) {
        this.fileToUpload = files.item(0);
        this.aperturaAuditoriaService.CargarSolicitud(this.fileToUpload).subscribe(x => {
            console.log(x);
            this.aperturaAuditoriaService.showMessageResponse(x);
            this.procesoFinalizado = true;
            //this.aperturaAuditoriaService.showMessageSucess("Solcitud cargada correctamente");
        });
    }
};
RegistroSolicitudServicioPage.ctorParameters = () => [
    { type: src_app_services_apertura_auditoria_service__WEBPACK_IMPORTED_MODULE_4__["AperturaAuditoriaService"] }
];
RegistroSolicitudServicioPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-registro-solicitud-servicio',
        template: _raw_loader_registro_solicitud_servicio_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_registro_solicitud_servicio_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], RegistroSolicitudServicioPage);



/***/ })

}]);
//# sourceMappingURL=pages-solicitud-servicio-registro-solicitud-servicio-registro-solicitud-servicio-module-es2015.js.map