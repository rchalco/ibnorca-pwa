(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-solicitud-servicio-registro-solicitud-servicio-registro-solicitud-servicio-module"], {
    /***/
    "DNCf":
    /*!************************************************************************************************************!*\
      !*** ./src/app/pages/solicitud-servicio/registro-solicitud-servicio/registro-solicitud-servicio.page.scss ***!
      \************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function DNCf(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyZWdpc3Ryby1zb2xpY2l0dWQtc2VydmljaW8ucGFnZS5zY3NzIn0= */";
      /***/
    },

    /***/
    "RTKG":
    /*!************************************************************************************************************!*\
      !*** ./src/app/pages/solicitud-servicio/registro-solicitud-servicio/registro-solicitud-servicio.module.ts ***!
      \************************************************************************************************************/

    /*! exports provided: RegistroSolicitudServicioPageModule */

    /***/
    function RTKG(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RegistroSolicitudServicioPageModule", function () {
        return RegistroSolicitudServicioPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "SVse");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "sZkV");
      /* harmony import */


      var _registro_solicitud_servicio_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./registro-solicitud-servicio-routing.module */
      "qdyl");
      /* harmony import */


      var _registro_solicitud_servicio_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./registro-solicitud-servicio.page */
      "sNTw");

      var RegistroSolicitudServicioPageModule = function RegistroSolicitudServicioPageModule() {
        _classCallCheck(this, RegistroSolicitudServicioPageModule);
      };

      RegistroSolicitudServicioPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _registro_solicitud_servicio_routing_module__WEBPACK_IMPORTED_MODULE_5__["RegistroSolicitudServicioPageRoutingModule"]],
        declarations: [_registro_solicitud_servicio_page__WEBPACK_IMPORTED_MODULE_6__["RegistroSolicitudServicioPage"]]
      })], RegistroSolicitudServicioPageModule);
      /***/
    },

    /***/
    "m2I4":
    /*!**************************************************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/solicitud-servicio/registro-solicitud-servicio/registro-solicitud-servicio.page.html ***!
      \**************************************************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function m2I4(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-title>Registro de solicitud de servicio</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <ion-list >    \n      <ion-item *ngIf=\"!procesoFinalizado\">\n        <ion-label>\n          Elija un archivo excel para subir la solicitud\n        </ion-label>\n        <ion-input type=\"file\" id=\"file\" (change)=\"handleFileInput($event.target.files)\"></ion-input>\n      </ion-item>    \n      <ion-item *ngIf=\"procesoFinalizado\" [routerLink]=\"['/']\">        \n        <ion-label>\n            Proceso finalizado, regresar\n          </ion-label>\n      </ion-item>    \n  </ion-list>  \n</ion-content>\n";
      /***/
    },

    /***/
    "qdyl":
    /*!********************************************************************************************************************!*\
      !*** ./src/app/pages/solicitud-servicio/registro-solicitud-servicio/registro-solicitud-servicio-routing.module.ts ***!
      \********************************************************************************************************************/

    /*! exports provided: RegistroSolicitudServicioPageRoutingModule */

    /***/
    function qdyl(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RegistroSolicitudServicioPageRoutingModule", function () {
        return RegistroSolicitudServicioPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "iInd");
      /* harmony import */


      var _registro_solicitud_servicio_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./registro-solicitud-servicio.page */
      "sNTw");

      var routes = [{
        path: '',
        component: _registro_solicitud_servicio_page__WEBPACK_IMPORTED_MODULE_3__["RegistroSolicitudServicioPage"]
      }];

      var RegistroSolicitudServicioPageRoutingModule = function RegistroSolicitudServicioPageRoutingModule() {
        _classCallCheck(this, RegistroSolicitudServicioPageRoutingModule);
      };

      RegistroSolicitudServicioPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], RegistroSolicitudServicioPageRoutingModule);
      /***/
    },

    /***/
    "sNTw":
    /*!**********************************************************************************************************!*\
      !*** ./src/app/pages/solicitud-servicio/registro-solicitud-servicio/registro-solicitud-servicio.page.ts ***!
      \**********************************************************************************************************/

    /*! exports provided: RegistroSolicitudServicioPage */

    /***/
    function sNTw(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RegistroSolicitudServicioPage", function () {
        return RegistroSolicitudServicioPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_registro_solicitud_servicio_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./registro-solicitud-servicio.page.html */
      "m2I4");
      /* harmony import */


      var _registro_solicitud_servicio_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./registro-solicitud-servicio.page.scss */
      "DNCf");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var src_app_services_apertura_auditoria_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! src/app/services/apertura-auditoria.service */
      "Aoky");

      var RegistroSolicitudServicioPage = /*#__PURE__*/function () {
        function RegistroSolicitudServicioPage(aperturaAuditoriaService) {
          _classCallCheck(this, RegistroSolicitudServicioPage);

          this.aperturaAuditoriaService = aperturaAuditoriaService;
          this.fileToUpload = null;
          this.procesoFinalizado = false;
        }

        _createClass(RegistroSolicitudServicioPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "handleFileInput",
          value: function handleFileInput(files) {
            var _this = this;

            this.fileToUpload = files.item(0);
            this.aperturaAuditoriaService.CargarSolicitud(this.fileToUpload).subscribe(function (x) {
              console.log(x);

              _this.aperturaAuditoriaService.showMessageResponse(x);

              _this.procesoFinalizado = true; //this.aperturaAuditoriaService.showMessageSucess("Solcitud cargada correctamente");
            });
          }
        }]);

        return RegistroSolicitudServicioPage;
      }();

      RegistroSolicitudServicioPage.ctorParameters = function () {
        return [{
          type: src_app_services_apertura_auditoria_service__WEBPACK_IMPORTED_MODULE_4__["AperturaAuditoriaService"]
        }];
      };

      RegistroSolicitudServicioPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-registro-solicitud-servicio',
        template: _raw_loader_registro_solicitud_servicio_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_registro_solicitud_servicio_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], RegistroSolicitudServicioPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-solicitud-servicio-registro-solicitud-servicio-registro-solicitud-servicio-module-es5.js.map