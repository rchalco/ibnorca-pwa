(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-test-myke-myke-module"],{

/***/ "ZjdJ":
/*!**********************************************!*\
  !*** ./src/app/pages/test/myke/myke.page.ts ***!
  \**********************************************/
/*! exports provided: MykePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MykePage", function() { return MykePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_myke_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./myke.page.html */ "y5GA");
/* harmony import */ var _myke_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./myke.page.scss */ "m1be");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var src_app_interfaces_apertura_auditoria_Praprogramasdeauditorium__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/interfaces/apertura_auditoria/Praprogramasdeauditorium */ "Z1IW");





let MykePage = class MykePage {
    constructor() { }
    ngOnInit() {
        this.currentPradireccionespasistema = new src_app_interfaces_apertura_auditoria_Praprogramasdeauditorium__WEBPACK_IMPORTED_MODULE_4__["Pradireccionespasistema"]();
        this.currentPradireccionespasistema.ciudad = "La Paz";
        this.currentPracicloparticipante = new src_app_interfaces_apertura_auditoria_Praprogramasdeauditorium__WEBPACK_IMPORTED_MODULE_4__["Pracicloparticipante"]();
    }
};
MykePage.ctorParameters = () => [];
MykePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-myke',
        template: _raw_loader_myke_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_myke_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], MykePage);



/***/ }),

/***/ "anak":
/*!************************************************!*\
  !*** ./src/app/pages/test/myke/myke.module.ts ***!
  \************************************************/
/*! exports provided: MykePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MykePageModule", function() { return MykePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _myke_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./myke-routing.module */ "dp7T");
/* harmony import */ var _myke_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./myke.page */ "ZjdJ");
/* harmony import */ var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/components/components.module */ "j1ZV");








let MykePageModule = class MykePageModule {
};
MykePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _myke_routing_module__WEBPACK_IMPORTED_MODULE_5__["MykePageRoutingModule"],
            src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"]
        ],
        declarations: [_myke_page__WEBPACK_IMPORTED_MODULE_6__["MykePage"]]
    })
], MykePageModule);



/***/ }),

/***/ "dp7T":
/*!********************************************************!*\
  !*** ./src/app/pages/test/myke/myke-routing.module.ts ***!
  \********************************************************/
/*! exports provided: MykePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MykePageRoutingModule", function() { return MykePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _myke_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./myke.page */ "ZjdJ");




const routes = [
    {
        path: '',
        component: _myke_page__WEBPACK_IMPORTED_MODULE_3__["MykePage"]
    }
];
let MykePageRoutingModule = class MykePageRoutingModule {
};
MykePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MykePageRoutingModule);



/***/ }),

/***/ "m1be":
/*!************************************************!*\
  !*** ./src/app/pages/test/myke/myke.page.scss ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJteWtlLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "y5GA":
/*!**************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/test/myke/myke.page.html ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\r\n<ion-content>\r\n \r\n  <!-- <app-pra-direccion-sistema [pradireccionespasistema]=\"currentPradireccionespasistema\"\r\n  >\r\n  </app-pra-direccion-sistema> -->\r\n\r\n  <app-ciclo-participante\r\n  [currentPracicloparticipantes]=\"currentPracicloparticipante\"\r\n></app-ciclo-participante>\r\n\r\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=pages-test-myke-myke-module-es2015.js.map