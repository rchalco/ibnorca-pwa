(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-toma-decision-panel-documentos-panel-documentos-module"], {
    /***/
    "KlG+":
    /*!*********************************************************************************!*\
      !*** ./src/app/pages/toma-decision/panel-documentos/panel-documentos.module.ts ***!
      \*********************************************************************************/

    /*! exports provided: PanelDocumentosPageModule */

    /***/
    function KlG(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PanelDocumentosPageModule", function () {
        return PanelDocumentosPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "SVse");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "sZkV");
      /* harmony import */


      var _panel_documentos_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./panel-documentos-routing.module */
      "fUbs");
      /* harmony import */


      var _panel_documentos_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./panel-documentos.page */
      "mt1m");
      /* harmony import */


      var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! src/app/components/components.module */
      "j1ZV");

      var PanelDocumentosPageModule = function PanelDocumentosPageModule() {
        _classCallCheck(this, PanelDocumentosPageModule);
      };

      PanelDocumentosPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _panel_documentos_routing_module__WEBPACK_IMPORTED_MODULE_5__["PanelDocumentosPageRoutingModule"], src_app_components_components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"]],
        declarations: [_panel_documentos_page__WEBPACK_IMPORTED_MODULE_6__["PanelDocumentosPage"]]
      })], PanelDocumentosPageModule);
      /***/
    },

    /***/
    "Wjjq":
    /*!***********************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/toma-decision/panel-documentos/panel-documentos.page.html ***!
      \***********************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function Wjjq(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<!-- <ion-toolbar>\r\n  <ion-segment #segment1 (ionChange)=\"segmentChanged($event)\" color=\"tertiary\">\r\n    <ion-segment-button value=\"acta\">\r\n      <ion-label>ACTA</ion-label>\r\n    </ion-segment-button>\r\n    <ion-segment-button value=\"resoluion\">\r\n      <ion-label>RESOLUCIÓN ADM</ion-label>\r\n    </ion-segment-button>\r\n    <ion-segment-button value=\"dec_cert\">\r\n      <ion-label>DECISION CERT.</ion-label>\r\n    </ion-segment-button>\r\n    <ion-segment-button value=\"dec_nocert\">\r\n      <ion-label>DECISION CONF. REG.</ion-label>\r\n    </ion-segment-button>\r\n    <ion-segment-button value=\"nota_suspencion\">\r\n      <ion-label>NOTA SUSPENSION</ion-label>\r\n    </ion-segment-button>\r\n    <ion-segment-button value=\"nota_retiro\">\r\n      <ion-label>NOTA RETIRO</ion-label>\r\n    </ion-segment-button>\r\n  </ion-segment>\r\n</ion-toolbar>\r\n<ion-content>\r\n  <div *ngIf=\"select_component === 'acta'\">\r\n    <app-tm-acta-reunion></app-tm-acta-reunion>\r\n  </div>\r\n  <div *ngIf=\"select_component === 'resoluion'\">\r\n    <app-editor-documento\r\n      titulo=\"Resolución Adminsitrativa\"\r\n    ></app-editor-documento>\r\n  </div>\r\n  <div *ngIf=\"select_component === 'dec_cert'\">\r\n    <app-editor-documento\r\n      titulo=\"Decision de Certificacion\"\r\n    ></app-editor-documento>\r\n  </div>\r\n  <div *ngIf=\"select_component === 'dec_nocert'\">\r\n    <app-editor-documento\r\n      titulo=\"Decision de No Certificacion\"\r\n    ></app-editor-documento>\r\n  </div>\r\n  <div *ngIf=\"select_component === 'nota_suspencion'\">\r\n    <app-editor-documento titulo=\"Nota de Suspensión\"></app-editor-documento>\r\n  </div>\r\n  <div *ngIf=\"select_component === 'nota_retiro'\">\r\n    <app-editor-documento titulo=\"Nota de Retiro\"></app-editor-documento>\r\n  </div>\r\n</ion-content> -->\r\n\r\n<app-param-documentos\r\n[area]=\"area\"\r\n[IdCiclo]=\"idCiclo\"\r\n[proceso]=\"proceso\"\r\n>";
      /***/
    },

    /***/
    "fUbs":
    /*!*****************************************************************************************!*\
      !*** ./src/app/pages/toma-decision/panel-documentos/panel-documentos-routing.module.ts ***!
      \*****************************************************************************************/

    /*! exports provided: PanelDocumentosPageRoutingModule */

    /***/
    function fUbs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PanelDocumentosPageRoutingModule", function () {
        return PanelDocumentosPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "iInd");
      /* harmony import */


      var _panel_documentos_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./panel-documentos.page */
      "mt1m");

      var routes = [{
        path: '',
        component: _panel_documentos_page__WEBPACK_IMPORTED_MODULE_3__["PanelDocumentosPage"]
      }];

      var PanelDocumentosPageRoutingModule = function PanelDocumentosPageRoutingModule() {
        _classCallCheck(this, PanelDocumentosPageRoutingModule);
      };

      PanelDocumentosPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], PanelDocumentosPageRoutingModule);
      /***/
    },

    /***/
    "hbjR":
    /*!*********************************************************************************!*\
      !*** ./src/app/pages/toma-decision/panel-documentos/panel-documentos.page.scss ***!
      \*********************************************************************************/

    /*! exports provided: default */

    /***/
    function hbjR(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwYW5lbC1kb2N1bWVudG9zLnBhZ2Uuc2NzcyJ9 */";
      /***/
    },

    /***/
    "mt1m":
    /*!*******************************************************************************!*\
      !*** ./src/app/pages/toma-decision/panel-documentos/panel-documentos.page.ts ***!
      \*******************************************************************************/

    /*! exports provided: PanelDocumentosPage */

    /***/
    function mt1m(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PanelDocumentosPage", function () {
        return PanelDocumentosPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_panel_documentos_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./panel-documentos.page.html */
      "Wjjq");
      /* harmony import */


      var _panel_documentos_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./panel-documentos.page.scss */
      "hbjR");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/router */
      "iInd");

      var PanelDocumentosPage = /*#__PURE__*/function () {
        function PanelDocumentosPage(route) {
          _classCallCheck(this, PanelDocumentosPage);

          this.route = route;
          this.select_component = "acta";
          this.idCiclo = 166;
          this.area = "TCS";
          this.proceso = "TOMA_DECISION";
        }

        _createClass(PanelDocumentosPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this = this;

            this.route.queryParams.subscribe(function (params) {
              _this.idCiclo = params.idCiclo;
              _this.area = params.area;
            });
          }
        }, {
          key: "segmentChanged",
          value: function segmentChanged(event) {
            this.select_component = event.detail.value;
          }
        }]);

        return PanelDocumentosPage;
      }();

      PanelDocumentosPage.ctorParameters = function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"]
        }];
      };

      PanelDocumentosPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: "app-panel-documentos",
        template: _raw_loader_panel_documentos_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_panel_documentos_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], PanelDocumentosPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-toma-decision-panel-documentos-panel-documentos-module-es5.js.map