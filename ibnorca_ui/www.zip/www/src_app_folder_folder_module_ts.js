"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_folder_folder_module_ts"],{

/***/ 9771:
/*!*************************************************!*\
  !*** ./src/app/folder/folder-routing.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FolderPageRoutingModule": () => (/* binding */ FolderPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _folder_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./folder.page */ 8470);




const routes = [
    {
        path: '',
        component: _folder_page__WEBPACK_IMPORTED_MODULE_0__.FolderPage
    }
];
let FolderPageRoutingModule = class FolderPageRoutingModule {
};
FolderPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], FolderPageRoutingModule);



/***/ }),

/***/ 3412:
/*!*****************************************!*\
  !*** ./src/app/folder/folder.module.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FolderPageModule": () => (/* binding */ FolderPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _folder_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./folder-routing.module */ 9771);
/* harmony import */ var _folder_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./folder.page */ 8470);
/* harmony import */ var _components_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/components.module */ 5642);








let FolderPageModule = class FolderPageModule {
};
FolderPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _folder_routing_module__WEBPACK_IMPORTED_MODULE_0__.FolderPageRoutingModule,
            _components_components_module__WEBPACK_IMPORTED_MODULE_2__.ComponentsModule
        ],
        declarations: [_folder_page__WEBPACK_IMPORTED_MODULE_1__.FolderPage]
    })
], FolderPageModule);



/***/ }),

/***/ 8470:
/*!***************************************!*\
  !*** ./src/app/folder/folder.page.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FolderPage": () => (/* binding */ FolderPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _folder_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./folder.page.html?ngResource */ 4394);
/* harmony import */ var _folder_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./folder.page.scss?ngResource */ 6518);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _services_database_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/database.service */ 4382);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _interfaces_cross_ui_ValidationControl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../interfaces/cross-ui/ValidationControl */ 7115);
/* harmony import */ var _interfaces_Test_data_test__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../interfaces/Test/data-test */ 9421);
/* harmony import */ var _interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../interfaces/cross-ui/ConvertFormToObject */ 9788);










let FolderPage = class FolderPage {
    constructor(activatedRoute, databaseService, formBuilder) {
        this.activatedRoute = activatedRoute;
        this.databaseService = databaseService;
        this.formBuilder = formBuilder;
        this.defaultDate = "1987-07-30";
        this.nombreValidation = [
            new _interfaces_cross_ui_ValidationControl__WEBPACK_IMPORTED_MODULE_3__.ValidationControl(_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required, "El nombre es requerido"),
            new _interfaces_cross_ui_ValidationControl__WEBPACK_IMPORTED_MODULE_3__.ValidationControl(_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.minLength(2), "El nombre debe tener al menos dos caracteres"),
        ];
        this.mailValidation = [
            new _interfaces_cross_ui_ValidationControl__WEBPACK_IMPORTED_MODULE_3__.ValidationControl(_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required, "El e-mail es requerido"),
            new _interfaces_cross_ui_ValidationControl__WEBPACK_IMPORTED_MODULE_3__.ValidationControl(_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$'), "El mail no tiene el formato correcto"),
        ];
        this.celularValidation = [
            new _interfaces_cross_ui_ValidationControl__WEBPACK_IMPORTED_MODULE_3__.ValidationControl(_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.required, "El celular es requerido"),
            new _interfaces_cross_ui_ValidationControl__WEBPACK_IMPORTED_MODULE_3__.ValidationControl(_angular_forms__WEBPACK_IMPORTED_MODULE_6__.Validators.pattern('^[0-9]+$'), "El celular no tiene el formato correcto"),
        ];
        this.data = {
            name: '',
            mail: ''
        };
    }
    ngOnInit() {
        this.folder = this.activatedRoute.snapshot.paramMap.get("id");
        this.databaseService.testDB();
        this.ionicForm = this.formBuilder.group({});
    }
    get errorControl() {
        return this.ionicForm.controls;
    }
    enviarForm() {
        if (!this.ionicForm.valid) {
            console.log('datos invalidos!');
            return false;
        }
        else {
            console.log(this.ionicForm.value);
            let dataTest = new _interfaces_Test_data_test__WEBPACK_IMPORTED_MODULE_4__.DataTest();
            _interfaces_cross_ui_ConvertFormToObject__WEBPACK_IMPORTED_MODULE_5__.ConvertFormToObject.convert(this.ionicForm, dataTest);
            console.log(dataTest);
        }
    }
    getDate(e) {
        console.log("se llamo la funcion de cambio", e);
    }
};
FolderPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute },
    { type: _services_database_service__WEBPACK_IMPORTED_MODULE_2__.DatabaseService },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormBuilder }
];
FolderPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: "app-folder",
        template: _folder_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_folder_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], FolderPage);



/***/ }),

/***/ 9421:
/*!**********************************************!*\
  !*** ./src/app/interfaces/Test/data-test.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DataTest": () => (/* binding */ DataTest)
/* harmony export */ });
class DataTest {
}


/***/ }),

/***/ 7115:
/*!**********************************************************!*\
  !*** ./src/app/interfaces/cross-ui/ValidationControl.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ValidationControl": () => (/* binding */ ValidationControl)
/* harmony export */ });
class ValidationControl {
    constructor(_validator, _message) {
        this.validator = _validator;
        this.message = _message;
    }
}


/***/ }),

/***/ 6518:
/*!****************************************************!*\
  !*** ./src/app/folder/folder.page.scss?ngResource ***!
  \****************************************************/
/***/ ((module) => {

module.exports = "ion-menu-button {\n  color: var(--ion-color-primary);\n}\n\n#container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n\n.container-detail-certificacion {\n  margin-bottom: 15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZvbGRlci5wYWdlLnNjc3MiLCIuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcQmNrRGVsbCUyMCUyMDE1JTIwNTUwMFxcZVxcUFJPWUVDVE9TXFxpYm5vcmNhXFxpYm5vcmNhLXB3YVxcaWJub3JjYS1wd2FcXGlibm9yY2FfdWlcXHNyY1xcYXBwXFxmb2xkZXJcXGZvbGRlci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSwrQkFBQTtBQ0NGOztBREVBO0VBQ0Usa0JBQUE7RUFDQSxrQkFBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0EsUUFBQTtFQUNBLDJCQUFBO0FDQ0Y7O0FERUE7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7QUNDRjs7QURFQTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxTQUFBO0FDQ0Y7O0FERUE7RUFDRSxxQkFBQTtBQ0NGOztBRENBO0VBQ0UsbUJBQUE7QUNFRiIsImZpbGUiOiJmb2xkZXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLW1lbnUtYnV0dG9uIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbn1cblxuI2NvbnRhaW5lciB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBsZWZ0OiAwO1xuICByaWdodDogMDtcbiAgdG9wOiA1MCU7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtNTAlKTtcbn1cblxuI2NvbnRhaW5lciBzdHJvbmcge1xuICBmb250LXNpemU6IDIwcHg7XG4gIGxpbmUtaGVpZ2h0OiAyNnB4O1xufVxuXG4jY29udGFpbmVyIHAge1xuICBmb250LXNpemU6IDE2cHg7XG4gIGxpbmUtaGVpZ2h0OiAyMnB4O1xuICBjb2xvcjogIzhjOGM4YztcbiAgbWFyZ2luOiAwO1xufVxuXG4jY29udGFpbmVyIGEge1xuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG59XG4uY29udGFpbmVyLWRldGFpbC1jZXJ0aWZpY2FjaW9ue1xuICBtYXJnaW4tYm90dG9tOiAxNXB4O1xufSIsImlvbi1tZW51LWJ1dHRvbiB7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG59XG5cbiNjb250YWluZXIge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogMDtcbiAgcmlnaHQ6IDA7XG4gIHRvcDogNTAlO1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTUwJSk7XG59XG5cbiNjb250YWluZXIgc3Ryb25nIHtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBsaW5lLWhlaWdodDogMjZweDtcbn1cblxuI2NvbnRhaW5lciBwIHtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBsaW5lLWhlaWdodDogMjJweDtcbiAgY29sb3I6ICM4YzhjOGM7XG4gIG1hcmdpbjogMDtcbn1cblxuI2NvbnRhaW5lciBhIHtcbiAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xufVxuXG4uY29udGFpbmVyLWRldGFpbC1jZXJ0aWZpY2FjaW9uIHtcbiAgbWFyZ2luLWJvdHRvbTogMTVweDtcbn0iXX0= */";

/***/ }),

/***/ 4394:
/*!****************************************************!*\
  !*** ./src/app/folder/folder.page.html?ngResource ***!
  \****************************************************/
/***/ ((module) => {

module.exports = "<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>{{ folder }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <form [formGroup]=\"ionicForm\" (ngSubmit)=\"enviarForm()\" #form=\"ngForm\">\n    <app-custom-input\n      label=\"nombre\"\n      name=\"nombre\"\n      type=\"text\"\n      [formGruop]=\"ionicForm\"\n      [form]=\"form\"\n      [Validations]=\"nombreValidation\"\n    ></app-custom-input>\n\n    <app-custom-input\n      label=\"e-mail\"\n      name=\"mail\"\n      type=\"text\"\n      [formGruop]=\"ionicForm\"\n      [form]=\"form\"\n      [Validations]=\"mailValidation\"\n      defaultValue=\"mail@outlool.com\"\n    ></app-custom-input>\n\n    <app-custom-input\n      label=\"fecha de nacimiento\"\n      name=\"fechaNacimiento\"\n      type=\"datetime\"\n      [formGruop]=\"ionicForm\"\n      [form]=\"form\"\n      (_ionChange)=\"getDate($event)\"\n      [defaultValue]=\"defaultDate\"\n    ></app-custom-input>\n\n    <app-custom-input\n      label=\"telefono celular\"\n      name=\"celular\"\n      type=\"text\"\n      [formGruop]=\"ionicForm\"\n      [form]=\"form\"\n      [Validations]=\"celularValidation\"\n      [brmasker]=\"{mask: '00000000', type:'num', len:8}\"\n    ></app-custom-input>\n\n    <ion-row>\n      <ion-col>\n        <ion-button type=\"submit\" color=\"danger\" expand=\"block\"\n          >Submit</ion-button\n        >\n      </ion-col>\n    </ion-row>\n  </form>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_folder_folder_module_ts.js.map