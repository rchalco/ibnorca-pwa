"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_apertura_auditoria_programa-auditoria_programa-auditoria_module_ts"],{

/***/ 6211:
/*!**************************************************************************************************!*\
  !*** ./src/app/pages/apertura_auditoria/programa-auditoria/programa-auditoria-routing.module.ts ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProgramaAuditoriaPageRoutingModule": () => (/* binding */ ProgramaAuditoriaPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _programa_auditoria_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./programa-auditoria.page */ 4725);




const routes = [
    {
        path: '',
        component: _programa_auditoria_page__WEBPACK_IMPORTED_MODULE_0__.ProgramaAuditoriaPage
    }
];
let ProgramaAuditoriaPageRoutingModule = class ProgramaAuditoriaPageRoutingModule {
};
ProgramaAuditoriaPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ProgramaAuditoriaPageRoutingModule);



/***/ }),

/***/ 5372:
/*!******************************************************************************************!*\
  !*** ./src/app/pages/apertura_auditoria/programa-auditoria/programa-auditoria.module.ts ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProgramaAuditoriaPageModule": () => (/* binding */ ProgramaAuditoriaPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _programa_auditoria_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./programa-auditoria-routing.module */ 6211);
/* harmony import */ var _programa_auditoria_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./programa-auditoria.page */ 4725);
/* harmony import */ var _components_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../../../components/components.module */ 5642);








let ProgramaAuditoriaPageModule = class ProgramaAuditoriaPageModule {
};
ProgramaAuditoriaPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.ReactiveFormsModule,
            _programa_auditoria_routing_module__WEBPACK_IMPORTED_MODULE_0__.ProgramaAuditoriaPageRoutingModule,
            _components_components_module__WEBPACK_IMPORTED_MODULE_2__.ComponentsModule,
        ],
        declarations: [_programa_auditoria_page__WEBPACK_IMPORTED_MODULE_1__.ProgramaAuditoriaPage],
    })
], ProgramaAuditoriaPageModule);



/***/ }),

/***/ 4725:
/*!****************************************************************************************!*\
  !*** ./src/app/pages/apertura_auditoria/programa-auditoria/programa-auditoria.page.ts ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProgramaAuditoriaPage": () => (/* binding */ ProgramaAuditoriaPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _programa_auditoria_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./programa-auditoria.page.html?ngResource */ 1894);
/* harmony import */ var _programa_auditoria_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./programa-auditoria.page.scss?ngResource */ 6205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var src_app_components_custom_input_custom_input_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/custom-input/custom-input.component */ 3082);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var src_app_services_apertura_auditoria_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/apertura-auditoria.service */ 7583);
/* harmony import */ var src_app_components_param_organismos_certificadores_param_organismos_certificadores_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/components/param-organismos-certificadores/param-organismos-certificadores.component */ 3566);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var src_app_services_docmentos_services_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/docmentos-services.service */ 5749);



/* eslint-disable no-underscore-dangle */









let ProgramaAuditoriaPage = class ProgramaAuditoriaPage {
    constructor(modalController, formBuilder, popoverController, datepipe, aperturaAuditoriaService, route, docmentosServicesService) {
        this.modalController = modalController;
        this.formBuilder = formBuilder;
        this.popoverController = popoverController;
        this.datepipe = datepipe;
        this.aperturaAuditoriaService = aperturaAuditoriaService;
        this.route = route;
        this.docmentosServicesService = docmentosServicesService;
        this.mode = 'TCS';
        this.ciclosVisbles = {};
    }
    ngOnInit() {
        this.route.queryParams.subscribe((params) => {
            console.log(params);
            if (params.currentIdService) {
                this.currentIdService = params.currentIdService;
                console.log('Id servicio', this.currentIdService);
                ///TDO : convocacmos al servicio para obtner la informacion globla de los servicios TCS TCP
                this.aperturaAuditoriaService
                    .ObtenerProgramaAuditoria(this.currentIdService)
                    .subscribe((resul) => {
                    console.log(resul);
                    if (resul.state === 1) {
                        this.currentPraprogramasdeauditorium = resul.object;
                        this.currentCliente = JSON.parse(resul.object.organizacionContentWs);
                        this.currentDatosServicio = JSON.parse(resul.object.detalleServicioWs);
                        this.currentPraprogramasdeauditorium.praciclosprogauditoria.forEach((x) => {
                            //copiamos los estaodos del ciclo al cronoramoa
                            x.praciclocronogramas[0].estado = x.estadoDescripcion;
                            //deseralizamos los cargos
                            if (x.pracicloparticipantes) {
                                x.pracicloparticipantes.forEach((yy) => {
                                    yy._cargo = JSON.parse(yy.cargoDetalleWs);
                                    if (yy._cargo['cod_tipoauditor']) {
                                        yy._cargo.idCargoPuesto = yy._cargo['cod_tipoauditor'];
                                        yy._cargo.cargoPuesto = yy._cargo['descripcion'];
                                    }
                                    if (yy.participanteDetalleWs) {
                                        yy._personal = JSON.parse(yy.participanteDetalleWs);
                                    }
                                });
                            }
                        });
                        if (this.currentPraprogramasdeauditorium.praciclosprogauditoria
                            .length > 0) {
                            this.ciclosVisbles[this.currentPraprogramasdeauditorium.praciclosprogauditoria[0].idPrAcicloProgAuditoria] = true;
                        }
                        this.mode = this.currentDatosServicio.area;
                    }
                    else {
                        this.aperturaAuditoriaService.showMessageResponse(resul);
                    }
                });
            }
            else {
                this.aperturaAuditoriaService.showMessageError('No se recibio ningun parametro de Id de servicio de auditoria');
            }
        });
        this.programaForm = this.formBuilder.group({});
    }
    mostrarSitios() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            console.log('llamando a mostrar sitios');
        });
    }
    editarCiclo(ciclo, index) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            console.log('editamos ciclo', ciclo);
            const popover = yield this.popoverController.create({
                component: src_app_components_custom_input_custom_input_component__WEBPACK_IMPORTED_MODULE_2__.CustomInputComponent,
                componentProps: {
                    formGruop: this.programaForm,
                    label: 'Referencia',
                    name: 'referencia',
                    type: 'text',
                    form: 'form',
                    defaultValue: ciclo.referencia,
                },
                mode: 'ios',
                backdropDismiss: false,
            });
            yield popover.present();
            const info = yield popover.onDidDismiss();
            console.log('Padre', info);
            ciclo.referencia = info.data.item;
        });
    }
    guardarPrograma() {
        this.aperturaAuditoriaService
            .RegisterProgramaAuditoria(this.currentPraprogramasdeauditorium)
            .subscribe((x) => {
            this.aperturaAuditoriaService.showMessageResponse(x);
            if (x.state === 1) {
                // eslint-disable-next-line @typescript-eslint/no-shadow
                x.object.praciclosprogauditoria.forEach((x) => {
                    //copiamos los estaodos del ciclo al cronoramoa
                    x.praciclocronogramas[0].estado = x.estadoDescripcion;
                    //deseralizamos los cargos
                    if (x.pracicloparticipantes) {
                        x.pracicloparticipantes.forEach((yy) => {
                            yy._cargo = JSON.parse(yy.cargoDetalleWs);
                            if (yy._cargo.cod_tipoauditor) {
                                yy._cargo.idCargoPuesto = yy._cargo.cod_tipoauditor;
                                yy._cargo.cargoPuesto = yy._cargo.descripcion;
                            }
                            if (yy.participanteDetalleWs) {
                                yy._personal = JSON.parse(yy.participanteDetalleWs);
                            }
                        });
                    }
                });
                this.currentPraprogramasdeauditorium = x.object;
                this.currentCliente = JSON.parse(x.object.organizacionContentWs);
                this.currentDatosServicio = JSON.parse(x.object.detalleServicioWs);
                this.mode = this.currentDatosServicio.area;
            }
        });
    }
    VerDesignacion(ciclo) {
        let nombrePlantilla = this.mode === 'TCS' ? 'REG-PRO-TCS-03-01' : 'REG-PRO-TCP-03-01';
        this.docmentosServicesService.GenerarDocumento(ciclo.idPrAcicloProgAuditoria, nombrePlantilla);
        /*this.aperturaAuditoriaService
          .GenerarDesignacion(
            ciclo.idPrAcicloProgAuditoria,
            "REG-PRO-TCS-03-01 Designación auditoria TCS Ver 1.0.doc"
          )
          .subscribe((x) => {
            console.log(x);
            //this.presentToast(x.message);
            this.aperturaAuditoriaService.ObtenerArchivoDesignacion(x.message);
          });*/
    }
    mostrarOrganismo() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            console.log('mostramos las organizaciones');
            const popover = yield this.popoverController.create({
                component: src_app_components_param_organismos_certificadores_param_organismos_certificadores_component__WEBPACK_IMPORTED_MODULE_4__.ParamOrganismosCertificadoresComponent,
                componentProps: {
                    defaultValue: this.currentPraprogramasdeauditorium.organismoCertificador,
                },
                event: event,
                mode: 'ios',
                backdropDismiss: false,
            });
            yield popover.present();
            const info = yield popover.onDidDismiss();
            console.log('Padre', info);
            this.currentPraprogramasdeauditorium.organismoCertificador = info.data.item;
        });
    }
    segmentChanged(event) {
        this.currentPraprogramasdeauditorium.praciclosprogauditoria.forEach((x) => {
            this.ciclosVisbles[x.idPrAcicloProgAuditoria] = false;
        });
        this.ciclosVisbles[event.detail.value] = true;
    }
};
ProgramaAuditoriaPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.ModalController },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormBuilder },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.PopoverController },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_9__.DatePipe },
    { type: src_app_services_apertura_auditoria_service__WEBPACK_IMPORTED_MODULE_3__.AperturaAuditoriaService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.ActivatedRoute },
    { type: src_app_services_docmentos_services_service__WEBPACK_IMPORTED_MODULE_5__.DocmentosServicesService }
];
ProgramaAuditoriaPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
        selector: 'app-programa-auditoria',
        template: _programa_auditoria_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_programa_auditoria_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ProgramaAuditoriaPage);



/***/ }),

/***/ 6205:
/*!*****************************************************************************************************!*\
  !*** ./src/app/pages/apertura_auditoria/programa-auditoria/programa-auditoria.page.scss?ngResource ***!
  \*****************************************************************************************************/
/***/ ((module) => {

module.exports = ".ciclo-header {\n  background-color: #3bb8bd;\n  color: #e626d6;\n  font-weight: 300;\n  font-size: 16px;\n}\n\n.slider .slider-pager {\n  color: blue;\n}\n\n.slide-full {\n  width: 100% !important;\n}\n\n.avatar {\n  width: 50px;\n  display: block;\n  margin-left: auto;\n  margin-right: auto;\n}\n\nion-card-content {\n  text-align: left;\n}\n\n.ion-content-small-font {\n  font-family: \"Calibri Light\";\n  font-size: 12px;\n  color: #093537;\n}\n\n.container-detail-auditoria {\n  width: 100%;\n}\n\n.container-detail-certificacion {\n  margin-bottom: 15px;\n}\n\n.buttons-group {\n  margin-top: 5px;\n}\n\n.title-medium-font {\n  font-family: \"Courier New\";\n  font-weight: bold;\n}\n\n.big-icon {\n  font-size: 1.2em;\n  margin-left: 3px;\n  cursor: grab;\n}\n\n.box-click {\n  min-width: 100px;\n  min-height: 20px;\n  border-bottom: solid;\n  border-color: #778e8f;\n  border-width: 1px;\n  padding: 2px;\n  margin-left: 3px;\n  display: inline-block;\n}\n\n.edit-item {\n  cursor: grab;\n}\n\n.edit-item:hover {\n  background-color: #9dd8dc;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2dyYW1hLWF1ZGl0b3JpYS5wYWdlLnNjc3MiLCIuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFxCY2tEZWxsJTIwJTIwMTUlMjA1NTAwXFxlXFxQUk9ZRUNUT1NcXGlibm9yY2FcXGlibm9yY2EtcHdhXFxpYm5vcmNhLXB3YVxcaWJub3JjYV91aVxcc3JjXFxhcHBcXHBhZ2VzXFxhcGVydHVyYV9hdWRpdG9yaWFcXHByb2dyYW1hLWF1ZGl0b3JpYVxccHJvZ3JhbWEtYXVkaXRvcmlhLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHlCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQ0NGOztBRENBO0VBQ0UsV0FBQTtBQ0VGOztBREFBO0VBQ0Usc0JBQUE7QUNHRjs7QURBQTtFQUNFLFdBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtBQ0dGOztBRERBO0VBQ0UsZ0JBQUE7QUNJRjs7QUREQTtFQUNFLDRCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUNJRjs7QURGQTtFQUNJLFdBQUE7QUNLSjs7QURIQTtFQUNJLG1CQUFBO0FDTUo7O0FESkE7RUFDSSxlQUFBO0FDT0o7O0FETEE7RUFDSSwwQkFBQTtFQUNBLGlCQUFBO0FDUUo7O0FETkE7RUFDRSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtBQ1NGOztBRFBBO0VBQ0UsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLG9CQUFBO0VBQ0EscUJBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLHFCQUFBO0FDVUY7O0FEUkE7RUFDRSxZQUFBO0FDV0Y7O0FEVEE7RUFDRSx5QkFBQTtBQ1lGIiwiZmlsZSI6InByb2dyYW1hLWF1ZGl0b3JpYS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY2ljbG8taGVhZGVyIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjM2JiOGJkO1xyXG4gIGNvbG9yOiAjZTYyNmQ2O1xyXG4gIGZvbnQtd2VpZ2h0OiAzMDA7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG59XHJcbi5zbGlkZXIgLnNsaWRlci1wYWdlciB7XHJcbiAgY29sb3I6IGJsdWU7XHJcbn1cclxuLnNsaWRlLWZ1bGwge1xyXG4gIHdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5hdmF0YXIge1xyXG4gIHdpZHRoOiA1MHB4O1xyXG4gIGRpc3BsYXk6IGJsb2NrO1xyXG4gIG1hcmdpbi1sZWZ0OiBhdXRvO1xyXG4gIG1hcmdpbi1yaWdodDogYXV0bztcclxufVxyXG5pb24tY2FyZC1jb250ZW50IHtcclxuICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG59XHJcblxyXG4uaW9uLWNvbnRlbnQtc21hbGwtZm9udCB7XHJcbiAgZm9udC1mYW1pbHk6IFwiQ2FsaWJyaSBMaWdodFwiO1xyXG4gIGZvbnQtc2l6ZTogMTJweDtcclxuICBjb2xvcjogIzA5MzUzNztcclxufVxyXG4uY29udGFpbmVyLWRldGFpbC1hdWRpdG9yaWF7XHJcbiAgICB3aWR0aDogMTAwJTtcclxufVxyXG4uY29udGFpbmVyLWRldGFpbC1jZXJ0aWZpY2FjaW9ue1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMTVweDtcclxufVxyXG4uYnV0dG9ucy1ncm91cHtcclxuICAgIG1hcmdpbi10b3A6NXB4O1xyXG59XHJcbi50aXRsZS1tZWRpdW0tZm9udHtcclxuICAgIGZvbnQtZmFtaWx5OiBcIkNvdXJpZXIgTmV3XCI7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxufVxyXG4uYmlnLWljb24ge1xyXG4gIGZvbnQtc2l6ZTogMS4yZW07XHJcbiAgbWFyZ2luLWxlZnQ6IDNweDtcclxuICBjdXJzb3I6IGdyYWI7XHJcbn1cclxuLmJveC1jbGljayB7XHJcbiAgbWluLXdpZHRoOiAxMDBweDtcclxuICBtaW4taGVpZ2h0OiAyMHB4O1xyXG4gIGJvcmRlci1ib3R0b206IHNvbGlkO1xyXG4gIGJvcmRlci1jb2xvcjogIzc3OGU4ZjtcclxuICBib3JkZXItd2lkdGg6IDFweDtcclxuICBwYWRkaW5nOiAycHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDNweDtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbn1cclxuLmVkaXQtaXRlbSB7XHJcbiAgY3Vyc29yOiBncmFiO1xyXG59XHJcbi5lZGl0LWl0ZW06aG92ZXIge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICM5ZGQ4ZGM7XHJcbn0iLCIuY2ljbG8taGVhZGVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzNiYjhiZDtcbiAgY29sb3I6ICNlNjI2ZDY7XG4gIGZvbnQtd2VpZ2h0OiAzMDA7XG4gIGZvbnQtc2l6ZTogMTZweDtcbn1cblxuLnNsaWRlciAuc2xpZGVyLXBhZ2VyIHtcbiAgY29sb3I6IGJsdWU7XG59XG5cbi5zbGlkZS1mdWxsIHtcbiAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcbn1cblxuLmF2YXRhciB7XG4gIHdpZHRoOiA1MHB4O1xuICBkaXNwbGF5OiBibG9jaztcbiAgbWFyZ2luLWxlZnQ6IGF1dG87XG4gIG1hcmdpbi1yaWdodDogYXV0bztcbn1cblxuaW9uLWNhcmQtY29udGVudCB7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG59XG5cbi5pb24tY29udGVudC1zbWFsbC1mb250IHtcbiAgZm9udC1mYW1pbHk6IFwiQ2FsaWJyaSBMaWdodFwiO1xuICBmb250LXNpemU6IDEycHg7XG4gIGNvbG9yOiAjMDkzNTM3O1xufVxuXG4uY29udGFpbmVyLWRldGFpbC1hdWRpdG9yaWEge1xuICB3aWR0aDogMTAwJTtcbn1cblxuLmNvbnRhaW5lci1kZXRhaWwtY2VydGlmaWNhY2lvbiB7XG4gIG1hcmdpbi1ib3R0b206IDE1cHg7XG59XG5cbi5idXR0b25zLWdyb3VwIHtcbiAgbWFyZ2luLXRvcDogNXB4O1xufVxuXG4udGl0bGUtbWVkaXVtLWZvbnQge1xuICBmb250LWZhbWlseTogXCJDb3VyaWVyIE5ld1wiO1xuICBmb250LXdlaWdodDogYm9sZDtcbn1cblxuLmJpZy1pY29uIHtcbiAgZm9udC1zaXplOiAxLjJlbTtcbiAgbWFyZ2luLWxlZnQ6IDNweDtcbiAgY3Vyc29yOiBncmFiO1xufVxuXG4uYm94LWNsaWNrIHtcbiAgbWluLXdpZHRoOiAxMDBweDtcbiAgbWluLWhlaWdodDogMjBweDtcbiAgYm9yZGVyLWJvdHRvbTogc29saWQ7XG4gIGJvcmRlci1jb2xvcjogIzc3OGU4ZjtcbiAgYm9yZGVyLXdpZHRoOiAxcHg7XG4gIHBhZGRpbmc6IDJweDtcbiAgbWFyZ2luLWxlZnQ6IDNweDtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xufVxuXG4uZWRpdC1pdGVtIHtcbiAgY3Vyc29yOiBncmFiO1xufVxuXG4uZWRpdC1pdGVtOmhvdmVyIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzlkZDhkYztcbn0iXX0= */";

/***/ }),

/***/ 1894:
/*!*****************************************************************************************************!*\
  !*** ./src/app/pages/apertura_auditoria/programa-auditoria/programa-auditoria.page.html?ngResource ***!
  \*****************************************************************************************************/
/***/ ((module) => {

module.exports = "<app-custom-header\n  title=\"Programa de Auditoria\"\n  icon_name=\"calendar-number-outline\"\n></app-custom-header>\n\n<ion-content>\n  <ion-card *ngIf=\"currentCliente\">\n    <ion-card-header color=\"primary\">\n      <ion-card-subtitle\n        >ID CLIENTE: {{currentCliente.IdCliente}}\n      </ion-card-subtitle>\n      <ion-item color=\"primary\">\n        <ion-icon color=\"light\" name=\"server-outline\" slot=\"start\"></ion-icon>\n        <ion-label>CLIENTE: {{currentCliente.NombreRazon}}</ion-label>\n      </ion-item>\n      <ion-item color=\"certificacion\">\n        <ion-label\n          >CÓDIGO DE SERVICIO:\n          {{currentPraprogramasdeauditorium.codigoServicioWs}}</ion-label\n        >\n      </ion-item>\n    </ion-card-header>\n    <ion-card-content>\n      <ion-row>\n        <ion-col size=\"12\">\n          <div class=\"container-detail-certificacion ion-content-small-font\">\n            CODIGO IAF: {{currentPraprogramasdeauditorium.codigoIafws}}<br />\n            Organismo Certificador:\n            <span class=\"box-click edit-item\" (click)=\"mostrarOrganismo()\"\n              >{{currentPraprogramasdeauditorium.organismoCertificador}}</span\n            >\n          </div>\n\n          <ion-segment\n            #segment1\n            color=\"tertiary\"\n            (ionChange)=\"segmentChanged($event)\"\n          >\n            <ion-segment-button\n              *ngFor=\"let ciclo of currentPraprogramasdeauditorium.praciclosprogauditoria; let i=index\"\n              [value]=\"ciclo.idPrAcicloProgAuditoria\"\n            >\n              <ion-label> AÑO {{ciclo.anio}}</ion-label>\n            </ion-segment-button>\n          </ion-segment>\n          <div\n            class=\"container-detail-auditoria\"\n            *ngFor=\"let ciclo of currentPraprogramasdeauditorium.praciclosprogauditoria; let i=index\"\n          >\n            <div *ngIf=\"ciclosVisbles[ciclo.idPrAcicloProgAuditoria]\">\n              <ion-item color=\"title-medium\">\n                <ion-label class=\"title-medium-font\">\n                  <ion-icon\n                    name=\"pencil-sharp\"\n                    slot=\"end\"\n                    (click)=\"editarCiclo(ciclo, i)\"\n                    class=\"big-icon\"\n                  ></ion-icon>\n                  AÑO {{ciclo.anio}} {{ciclo.referencia}}\n                </ion-label>\n              </ion-item>\n              <ion-row>\n                <ion-col\n                  size=\"6\"\n                  size-lg=\"6\"\n                  size-md=\"6\"\n                  size-sm=\"6\"\n                  size-xs=\"12\"\n                >\n                  <app-pra-cronograma\n                    [currentPraciclocronogramas]=\"ciclo.praciclocronogramas[0]\"\n                  ></app-pra-cronograma>\n                </ion-col>\n                <ion-col\n                  size=\"6\"\n                  size-lg=\"6\"\n                  size-md=\"6\"\n                  size-sm=\"6\"\n                  size-xs=\"12\"\n                >\n                  <app-ciclo-participante\n                    [currentPracicloparticipantes]=\"ciclo.pracicloparticipantes\"\n                  ></app-ciclo-participante>\n                </ion-col>\n              </ion-row>\n              <app-tcp-list-products\n                [productList]=\"ciclo.pradireccionespaproductos\"\n                [nombreOrganizacion]=\"ciclo.nombreOrganizacionCertificado\"\n                *ngIf=\"mode === 'TCP'\"\n              ></app-tcp-list-products>\n              <app-tcs-list-systems\n                [nombreOrganizacion]=\"ciclo.nombreOrganizacionCertificado\"\n                [direccionesSistema]=\"ciclo.pradireccionespasistemas\"\n                [normasSistema]=\"ciclo.praciclonormassistemas\"\n                *ngIf=\"mode === 'TCS'\"\n              ></app-tcs-list-systems>\n              <ion-buttons slot=\"start\" class=\"buttons-group\">\n                <ion-button\n                  size=\"small\"\n                  fill=\"outline\"\n                  color=\"success\"\n                  (click)=\"guardarPrograma()\"\n                >\n                  <ion-icon slot=\"start\" name=\"save\"></ion-icon>\n                  Guardar\n                </ion-button>\n                <ion-button\n                  size=\"small\"\n                  fill=\"outline\"\n                  color=\"tertiary\"\n                  (click)=\"VerDesignacion(ciclo)\"\n                >\n                  <ion-icon slot=\"start\" name=\"document\"></ion-icon>\n                  Ver Designacion\n                </ion-button>\n              </ion-buttons>\n            </div>\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-card-content>\n  </ion-card>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_apertura_auditoria_programa-auditoria_programa-auditoria_module_ts.js.map