"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_elaboracion_auditoria_list-ciclos_list-ciclos_module_ts"],{

/***/ 9958:
/*!***************************************************************************************!*\
  !*** ./src/app/pages/elaboracion_auditoria/list-ciclos/list-ciclos-routing.module.ts ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ListCiclosPageRoutingModule": () => (/* binding */ ListCiclosPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _list_ciclos_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./list-ciclos.page */ 826);




const routes = [
    {
        path: '',
        component: _list_ciclos_page__WEBPACK_IMPORTED_MODULE_0__.ListCiclosPage
    }
];
let ListCiclosPageRoutingModule = class ListCiclosPageRoutingModule {
};
ListCiclosPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ListCiclosPageRoutingModule);



/***/ }),

/***/ 5996:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/elaboracion_auditoria/list-ciclos/list-ciclos.module.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ListCiclosPageModule": () => (/* binding */ ListCiclosPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _list_ciclos_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./list-ciclos-routing.module */ 9958);
/* harmony import */ var _list_ciclos_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./list-ciclos.page */ 826);
/* harmony import */ var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/components.module */ 5642);








let ListCiclosPageModule = class ListCiclosPageModule {
};
ListCiclosPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _list_ciclos_routing_module__WEBPACK_IMPORTED_MODULE_0__.ListCiclosPageRoutingModule,
            src_app_components_components_module__WEBPACK_IMPORTED_MODULE_2__.ComponentsModule,
        ],
        declarations: [_list_ciclos_page__WEBPACK_IMPORTED_MODULE_1__.ListCiclosPage],
    })
], ListCiclosPageModule);



/***/ }),

/***/ 826:
/*!*****************************************************************************!*\
  !*** ./src/app/pages/elaboracion_auditoria/list-ciclos/list-ciclos.page.ts ***!
  \*****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ListCiclosPage": () => (/* binding */ ListCiclosPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _list_ciclos_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./list-ciclos.page.html?ngResource */ 4280);
/* harmony import */ var _list_ciclos_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./list-ciclos.page.scss?ngResource */ 2628);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var src_app_services_elaboracion_auditoria_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/elaboracion-auditoria.service */ 1264);






let ListCiclosPage = class ListCiclosPage {
    constructor(elaboracionAuditoriaService, route, router) {
        this.elaboracionAuditoriaService = elaboracionAuditoriaService;
        this.route = route;
        this.router = router;
        this.idAuditor = 0;
    }
    ngOnInit() {
        this.route.queryParams.subscribe((params) => {
            console.log(params);
            if (params.idAuditor) {
                this.idAuditor = params.idAuditor;
                this.elaboracionAuditoriaService
                    .ObtenerCiclosPorIdAuditor(this.idAuditor)
                    .subscribe((x) => (this.listCiclos = x.listEntities));
            }
            else {
                this.elaboracionAuditoriaService.showMessageError("No se recibio ningun parametro de Id de auditor");
            }
        });
    }
    navMasterPlanAuditoria(_idCiclo) {
        this.router.navigateByUrl("master-elaboracion-auditoria?idCicloAuditoria=" + _idCiclo);
    }
};
ListCiclosPage.ctorParameters = () => [
    { type: src_app_services_elaboracion_auditoria_service__WEBPACK_IMPORTED_MODULE_2__.ElaboracionAuditoriaService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.ActivatedRoute },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router }
];
ListCiclosPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: "app-list-ciclos",
        template: _list_ciclos_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_list_ciclos_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ListCiclosPage);



/***/ }),

/***/ 2628:
/*!******************************************************************************************!*\
  !*** ./src/app/pages/elaboracion_auditoria/list-ciclos/list-ciclos.page.scss?ngResource ***!
  \******************************************************************************************/
/***/ ((module) => {

module.exports = ".container-product-list {\n  margin-top: 0em;\n}\n\n.popover-content.sc-ion-popover-md {\n  width: 500px !important;\n}\n\n.my-custom-modal-css .modal-wrapper {\n  width: 600px;\n  height: 650px !important;\n}\n\n.normas {\n  font-size: 12px;\n  color: #1b192c;\n}\n\n.title-normas {\n  color: #0b480f;\n  font-size: 1em;\n  text-align: left;\n}\n\n.norma-block {\n  background-color: #c6e8e6;\n  padding: 10px;\n  margin: 1.5px;\n  min-width: 100%;\n}\n\n.big-icon {\n  font-size: 1.2em;\n  margin-left: 3px;\n  cursor: grab;\n}\n\n.detail-paragraph {\n  font-size: 11px;\n  color: #3d3c44;\n}\n\n.sub-title {\n  /*font-style: italic;*/\n  font-size: 13px;\n  color: #055a0f;\n  font-family: sans-serif;\n}\n\n.direccion-block {\n  background-color: #c1ebd6;\n  padding: 10px;\n  margin: 1.5px;\n  min-width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxpc3QtY2ljbG9zLnBhZ2Uuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXEJja0RlbGwlMjAlMjAxNSUyMDU1MDBcXGVcXFBST1lFQ1RPU1xcaWJub3JjYVxcaWJub3JjYS1wd2FcXGlibm9yY2EtcHdhXFxpYm5vcmNhX3VpXFxzcmNcXGFwcFxccGFnZXNcXGVsYWJvcmFjaW9uX2F1ZGl0b3JpYVxcbGlzdC1jaWNsb3NcXGxpc3QtY2ljbG9zLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGVBQUE7QUNDSjs7QURDRTtFQUNJLHVCQUFBO0FDRU47O0FEQ0U7RUFDRSxZQUFBO0VBQ0Esd0JBQUE7QUNFSjs7QURBRTtFQUNFLGVBQUE7RUFDQSxjQUFBO0FDR0o7O0FEREU7RUFDRSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0FDSUo7O0FERkU7RUFDRSx5QkFBQTtFQUNBLGFBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtBQ0tKOztBREhFO0VBQ0UsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7QUNNSjs7QURKRTtFQUNFLGVBQUE7RUFDQSxjQUFBO0FDT0o7O0FETEU7RUFDRSxzQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsdUJBQUE7QUNRSjs7QURORTtFQUNFLHlCQUFBO0VBQ0EsYUFBQTtFQUNBLGFBQUE7RUFDQSxlQUFBO0FDU0oiLCJmaWxlIjoibGlzdC1jaWNsb3MucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRhaW5lci1wcm9kdWN0LWxpc3Qge1xyXG4gICAgbWFyZ2luLXRvcDogMGVtO1xyXG4gIH1cclxuICAucG9wb3Zlci1jb250ZW50LnNjLWlvbi1wb3BvdmVyLW1kIHtcclxuICAgICAgd2lkdGg6IDUwMHB4ICFpbXBvcnRhbnQ7XHJcbiAgfVxyXG4gIFxyXG4gIC5teS1jdXN0b20tbW9kYWwtY3NzIC5tb2RhbC13cmFwcGVyIHtcclxuICAgIHdpZHRoOiA2MDBweDtcclxuICAgIGhlaWdodDogNjUwcHggIWltcG9ydGFudDtcclxuICB9IFxyXG4gIC5ub3JtYXMge1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgY29sb3I6ICMxYjE5MmM7XHJcbiAgfVxyXG4gIC50aXRsZS1ub3JtYXMge1xyXG4gICAgY29sb3I6ICMwYjQ4MGY7XHJcbiAgICBmb250LXNpemU6IDFlbTtcclxuICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgfVxyXG4gIC5ub3JtYS1ibG9jayB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjYzZlOGU2O1xyXG4gICAgcGFkZGluZzogMTBweDtcclxuICAgIG1hcmdpbjogMS41cHg7XHJcbiAgICBtaW4td2lkdGg6IDEwMCU7XHJcbiAgfVxyXG4gIC5iaWctaWNvbiB7XHJcbiAgICBmb250LXNpemU6IDEuMmVtO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDNweDtcclxuICAgIGN1cnNvcjogZ3JhYjtcclxuICB9XHJcbiAgLmRldGFpbC1wYXJhZ3JhcGgge1xyXG4gICAgZm9udC1zaXplOiAxMXB4O1xyXG4gICAgY29sb3I6ICMzZDNjNDQ7XHJcbiAgfVxyXG4gIC5zdWItdGl0bGUge1xyXG4gICAgLypmb250LXN0eWxlOiBpdGFsaWM7Ki9cclxuICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgIGNvbG9yOiAjMDU1YTBmO1xyXG4gICAgZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XHJcbiAgfVxyXG4gIC5kaXJlY2Npb24tYmxvY2sge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2MxZWJkNjtcclxuICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICBtYXJnaW46IDEuNXB4O1xyXG4gICAgbWluLXdpZHRoOiAxMDAlO1xyXG4gIH0iLCIuY29udGFpbmVyLXByb2R1Y3QtbGlzdCB7XG4gIG1hcmdpbi10b3A6IDBlbTtcbn1cblxuLnBvcG92ZXItY29udGVudC5zYy1pb24tcG9wb3Zlci1tZCB7XG4gIHdpZHRoOiA1MDBweCAhaW1wb3J0YW50O1xufVxuXG4ubXktY3VzdG9tLW1vZGFsLWNzcyAubW9kYWwtd3JhcHBlciB7XG4gIHdpZHRoOiA2MDBweDtcbiAgaGVpZ2h0OiA2NTBweCAhaW1wb3J0YW50O1xufVxuXG4ubm9ybWFzIHtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBjb2xvcjogIzFiMTkyYztcbn1cblxuLnRpdGxlLW5vcm1hcyB7XG4gIGNvbG9yOiAjMGI0ODBmO1xuICBmb250LXNpemU6IDFlbTtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbn1cblxuLm5vcm1hLWJsb2NrIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2M2ZThlNjtcbiAgcGFkZGluZzogMTBweDtcbiAgbWFyZ2luOiAxLjVweDtcbiAgbWluLXdpZHRoOiAxMDAlO1xufVxuXG4uYmlnLWljb24ge1xuICBmb250LXNpemU6IDEuMmVtO1xuICBtYXJnaW4tbGVmdDogM3B4O1xuICBjdXJzb3I6IGdyYWI7XG59XG5cbi5kZXRhaWwtcGFyYWdyYXBoIHtcbiAgZm9udC1zaXplOiAxMXB4O1xuICBjb2xvcjogIzNkM2M0NDtcbn1cblxuLnN1Yi10aXRsZSB7XG4gIC8qZm9udC1zdHlsZTogaXRhbGljOyovXG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgY29sb3I6ICMwNTVhMGY7XG4gIGZvbnQtZmFtaWx5OiBzYW5zLXNlcmlmO1xufVxuXG4uZGlyZWNjaW9uLWJsb2NrIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2MxZWJkNjtcbiAgcGFkZGluZzogMTBweDtcbiAgbWFyZ2luOiAxLjVweDtcbiAgbWluLXdpZHRoOiAxMDAlO1xufSJdfQ== */";

/***/ }),

/***/ 4280:
/*!******************************************************************************************!*\
  !*** ./src/app/pages/elaboracion_auditoria/list-ciclos/list-ciclos.page.html?ngResource ***!
  \******************************************************************************************/
/***/ ((module) => {

module.exports = "<app-custom-header\n  title=\"Lista de Audiorias Pendientes\"\n  icon_name=\"clipboard\"\n></app-custom-header>\n<ion-content>\n  <ion-list>\n    <ion-item *ngFor=\"let ciclo of listCiclos; let i = index\">\n      <ion-icon\n        name=\"pencil-sharp\"\n        slot=\"start\"\n        (click)=\"navMasterPlanAuditoria(ciclo.idCicloAuditoria)\"\n        class=\"big-icon\"\n      ></ion-icon>\n      <div class=\"norma-block\">\n        <h2>Cliente: {{ ciclo.nombreCliente }}</h2>\n        <p>\n          Tipo Auditoría\n          <span class=\"sub-title\">{{ ciclo.referenciaCiclo }}</span>\n          | Codigo Servicio\n          <span class=\"sub-title\">{{ ciclo.codigoServicio }}</span>\n          | Id Ciclo\n          <span class=\"sub-title\">{{ ciclo.idCicloAuditoria }}</span>\n        </p>\n        <p class=\"detail-paragraph\">\n          Fecha Auditoria {{ ciclo.fechaAuditoria }} | Responsable {{\n          ciclo.responsable }}\n        </p>\n      </div>\n    </ion-item>\n  </ion-list>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_elaboracion_auditoria_list-ciclos_list-ciclos_module_ts.js.map