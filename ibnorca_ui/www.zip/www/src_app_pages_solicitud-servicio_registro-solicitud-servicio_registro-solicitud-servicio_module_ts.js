"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_solicitud-servicio_registro-solicitud-servicio_registro-solicitud-servicio_module_ts"],{

/***/ 1784:
/*!********************************************************************************************************************!*\
  !*** ./src/app/pages/solicitud-servicio/registro-solicitud-servicio/registro-solicitud-servicio-routing.module.ts ***!
  \********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegistroSolicitudServicioPageRoutingModule": () => (/* binding */ RegistroSolicitudServicioPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _registro_solicitud_servicio_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./registro-solicitud-servicio.page */ 3302);




const routes = [
    {
        path: '',
        component: _registro_solicitud_servicio_page__WEBPACK_IMPORTED_MODULE_0__.RegistroSolicitudServicioPage
    }
];
let RegistroSolicitudServicioPageRoutingModule = class RegistroSolicitudServicioPageRoutingModule {
};
RegistroSolicitudServicioPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], RegistroSolicitudServicioPageRoutingModule);



/***/ }),

/***/ 573:
/*!************************************************************************************************************!*\
  !*** ./src/app/pages/solicitud-servicio/registro-solicitud-servicio/registro-solicitud-servicio.module.ts ***!
  \************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegistroSolicitudServicioPageModule": () => (/* binding */ RegistroSolicitudServicioPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _registro_solicitud_servicio_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./registro-solicitud-servicio-routing.module */ 1784);
/* harmony import */ var _registro_solicitud_servicio_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./registro-solicitud-servicio.page */ 3302);







let RegistroSolicitudServicioPageModule = class RegistroSolicitudServicioPageModule {
};
RegistroSolicitudServicioPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _registro_solicitud_servicio_routing_module__WEBPACK_IMPORTED_MODULE_0__.RegistroSolicitudServicioPageRoutingModule
        ],
        declarations: [_registro_solicitud_servicio_page__WEBPACK_IMPORTED_MODULE_1__.RegistroSolicitudServicioPage]
    })
], RegistroSolicitudServicioPageModule);



/***/ }),

/***/ 3302:
/*!**********************************************************************************************************!*\
  !*** ./src/app/pages/solicitud-servicio/registro-solicitud-servicio/registro-solicitud-servicio.page.ts ***!
  \**********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegistroSolicitudServicioPage": () => (/* binding */ RegistroSolicitudServicioPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _registro_solicitud_servicio_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./registro-solicitud-servicio.page.html?ngResource */ 4584);
/* harmony import */ var _registro_solicitud_servicio_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./registro-solicitud-servicio.page.scss?ngResource */ 7037);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_services_apertura_auditoria_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/apertura-auditoria.service */ 7583);





let RegistroSolicitudServicioPage = class RegistroSolicitudServicioPage {
    constructor(aperturaAuditoriaService) {
        this.aperturaAuditoriaService = aperturaAuditoriaService;
        this.fileToUpload = null;
        this.procesoFinalizado = false;
    }
    ngOnInit() {
    }
    handleFileInput(files) {
        this.fileToUpload = files.item(0);
        this.aperturaAuditoriaService.CargarSolicitud(this.fileToUpload).subscribe(x => {
            console.log(x);
            this.aperturaAuditoriaService.showMessageResponse(x);
            this.procesoFinalizado = true;
            //this.aperturaAuditoriaService.showMessageSucess("Solcitud cargada correctamente");
        });
    }
};
RegistroSolicitudServicioPage.ctorParameters = () => [
    { type: src_app_services_apertura_auditoria_service__WEBPACK_IMPORTED_MODULE_2__.AperturaAuditoriaService }
];
RegistroSolicitudServicioPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-registro-solicitud-servicio',
        template: _registro_solicitud_servicio_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_registro_solicitud_servicio_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], RegistroSolicitudServicioPage);



/***/ }),

/***/ 7037:
/*!***********************************************************************************************************************!*\
  !*** ./src/app/pages/solicitud-servicio/registro-solicitud-servicio/registro-solicitud-servicio.page.scss?ngResource ***!
  \***********************************************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyZWdpc3Ryby1zb2xpY2l0dWQtc2VydmljaW8ucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 4584:
/*!***********************************************************************************************************************!*\
  !*** ./src/app/pages/solicitud-servicio/registro-solicitud-servicio/registro-solicitud-servicio.page.html?ngResource ***!
  \***********************************************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>Registro de solicitud de servicio</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <ion-list >    \n      <ion-item *ngIf=\"!procesoFinalizado\">\n        <ion-label>\n          Elija un archivo excel para subir la solicitud\n        </ion-label>\n        <ion-input type=\"file\" id=\"file\" (change)=\"handleFileInput($event.target.files)\"></ion-input>\n      </ion-item>    \n      <ion-item *ngIf=\"procesoFinalizado\" [routerLink]=\"['/']\">        \n        <ion-label>\n            Proceso finalizado, regresar\n          </ion-label>\n      </ion-item>    \n  </ion-list>  \n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_solicitud-servicio_registro-solicitud-servicio_registro-solicitud-servicio_module_ts.js.map