"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_test_ivo_ivo_module_ts"],{

/***/ 4390:
/*!******************************************************!*\
  !*** ./src/app/pages/test/ivo/ivo-routing.module.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IvoPageRoutingModule": () => (/* binding */ IvoPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _ivo_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ivo.page */ 5619);




const routes = [
    {
        path: '',
        component: _ivo_page__WEBPACK_IMPORTED_MODULE_0__.IvoPage
    }
];
let IvoPageRoutingModule = class IvoPageRoutingModule {
};
IvoPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], IvoPageRoutingModule);



/***/ }),

/***/ 3648:
/*!**********************************************!*\
  !*** ./src/app/pages/test/ivo/ivo.module.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IvoPageModule": () => (/* binding */ IvoPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _ivo_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ivo-routing.module */ 4390);
/* harmony import */ var _ivo_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ivo.page */ 5619);
/* harmony import */ var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/components.module */ 5642);








let IvoPageModule = class IvoPageModule {
};
IvoPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _ivo_routing_module__WEBPACK_IMPORTED_MODULE_0__.IvoPageRoutingModule,
            src_app_components_components_module__WEBPACK_IMPORTED_MODULE_2__.ComponentsModule,
        ],
        declarations: [_ivo_page__WEBPACK_IMPORTED_MODULE_1__.IvoPage]
    })
], IvoPageModule);



/***/ }),

/***/ 5619:
/*!********************************************!*\
  !*** ./src/app/pages/test/ivo/ivo.page.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IvoPage": () => (/* binding */ IvoPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ivo_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ivo.page.html?ngResource */ 3258);
/* harmony import */ var _ivo_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ivo.page.scss?ngResource */ 1116);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_services_elaboracion_auditoria_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/elaboracion-auditoria.service */ 1264);





let IvoPage = class IvoPage {
    constructor(elaboracionAuditoriaService) {
        this.elaboracionAuditoriaService = elaboracionAuditoriaService;
    }
    ngOnInit() {
        /*console.log("Ingresando a INit");
    
        this.elaboracionAuditoriaService.GetListasVerificacion(1).subscribe((resul) =>{
          console.log(resul);
        });*/
    }
};
IvoPage.ctorParameters = () => [
    { type: src_app_services_elaboracion_auditoria_service__WEBPACK_IMPORTED_MODULE_2__.ElaboracionAuditoriaService }
];
IvoPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: "app-ivo",
        template: _ivo_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_ivo_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], IvoPage);



/***/ }),

/***/ 1116:
/*!*********************************************************!*\
  !*** ./src/app/pages/test/ivo/ivo.page.scss?ngResource ***!
  \*********************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJpdm8ucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 3258:
/*!*********************************************************!*\
  !*** ./src/app/pages/test/ivo/ivo.page.html?ngResource ***!
  \*********************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>ivo</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content color=\"primary\">\r\n\r\n\r\n<!-- <app-tcs-lista-verificacion-reunion-cierre>\r\n</app-tcs-lista-verificacion-reunion-cierre> -->\r\n<!-- <app-tcs-lista-verificacion-reunion-apertura>\r\n</app-tcs-lista-verificacion-reunion-apertura> -->\r\n\r\n<!-- \r\n<app-buscar-norma (selectNorma)=\"cambiarNorma($event)\"\r\n    *ngIf=\"showBuscadorNormas\">\r\n</app-buscar-norma>\r\n<app-param-paices>\r\n</app-param-paices>\r\n -->\r\n\r\n<app-pra-direccion-sistema>\r\n</app-pra-direccion-sistema>\r\n\r\n\r\n<!-- <app-param-estados-departamentos>\r\n</app-param-estados-departamentos>\r\n\r\n<app-param-cuidades>\r\n</app-param-cuidades> -->\r\n\r\n<!-- \r\n<ion-grid>\r\n  <ion-row color=\"primary\" justify-content-center>\r\n    <ion-col align-self-center size-md=\"6\" size-lg=\"5\" size-xs=\"12\">\r\n      <div text-center>\r\n        <h3>Ingreso</h3>\r\n      </div>\r\n      <div padding>\r\n        <ion-item>\r\n          <ion-input name=\"email\" type=\"email\" placeholder=\"Usuario\" ngModel required></ion-input>\r\n        </ion-item>\r\n        <ion-item>\r\n          <ion-input name=\"password\" type=\"password\" placeholder=\"Clave\" ngModel required></ion-input>\r\n        </ion-item>\r\n      </div>\r\n      <div padding>\r\n        <ion-button size=\"large\" type=\"submit\" [enable]=\"form.invalid\" expand=\"block\" (click) =\"register()\">Ingresar</ion-button>\r\n      </div>\r\n      <div padding>\r\n        <ion-button size=\"large\" expand=\"block\" (click)=\"clickMethod($event)\">Cancelar</ion-button>\r\n      </div>\r\n    </ion-col>\r\n  </ion-row>\r\n</ion-grid>\r\n -->\r\n\r\n</ion-content>\r\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_test_ivo_ivo_module_ts.js.map