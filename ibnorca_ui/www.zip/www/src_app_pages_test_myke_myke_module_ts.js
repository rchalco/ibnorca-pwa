"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_test_myke_myke_module_ts"],{

/***/ 1704:
/*!********************************************************!*\
  !*** ./src/app/pages/test/myke/myke-routing.module.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MykePageRoutingModule": () => (/* binding */ MykePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _myke_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./myke.page */ 6740);




const routes = [
    {
        path: '',
        component: _myke_page__WEBPACK_IMPORTED_MODULE_0__.MykePage
    }
];
let MykePageRoutingModule = class MykePageRoutingModule {
};
MykePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MykePageRoutingModule);



/***/ }),

/***/ 2201:
/*!************************************************!*\
  !*** ./src/app/pages/test/myke/myke.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MykePageModule": () => (/* binding */ MykePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _myke_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./myke-routing.module */ 1704);
/* harmony import */ var _myke_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./myke.page */ 6740);
/* harmony import */ var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/components.module */ 5642);








let MykePageModule = class MykePageModule {
};
MykePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _myke_routing_module__WEBPACK_IMPORTED_MODULE_0__.MykePageRoutingModule,
            src_app_components_components_module__WEBPACK_IMPORTED_MODULE_2__.ComponentsModule
        ],
        declarations: [_myke_page__WEBPACK_IMPORTED_MODULE_1__.MykePage]
    })
], MykePageModule);



/***/ }),

/***/ 6740:
/*!**********************************************!*\
  !*** ./src/app/pages/test/myke/myke.page.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MykePage": () => (/* binding */ MykePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _myke_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./myke.page.html?ngResource */ 1954);
/* harmony import */ var _myke_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./myke.page.scss?ngResource */ 9725);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_interfaces_apertura_auditoria_Praprogramasdeauditorium__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/interfaces/apertura_auditoria/Praprogramasdeauditorium */ 3996);





let MykePage = class MykePage {
    constructor() { }
    ngOnInit() {
        this.currentPradireccionespasistema = new src_app_interfaces_apertura_auditoria_Praprogramasdeauditorium__WEBPACK_IMPORTED_MODULE_2__.Pradireccionespasistema();
        this.currentPradireccionespasistema.ciudad = "La Paz";
        this.currentPracicloparticipante = new src_app_interfaces_apertura_auditoria_Praprogramasdeauditorium__WEBPACK_IMPORTED_MODULE_2__.Pracicloparticipante();
    }
};
MykePage.ctorParameters = () => [];
MykePage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-myke',
        template: _myke_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_myke_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], MykePage);



/***/ }),

/***/ 9725:
/*!***********************************************************!*\
  !*** ./src/app/pages/test/myke/myke.page.scss?ngResource ***!
  \***********************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJteWtlLnBhZ2Uuc2NzcyJ9 */";

/***/ }),

/***/ 1954:
/*!***********************************************************!*\
  !*** ./src/app/pages/test/myke/myke.page.html?ngResource ***!
  \***********************************************************/
/***/ ((module) => {

module.exports = "\r\n<ion-content>\r\n \r\n  <!-- <app-pra-direccion-sistema [pradireccionespasistema]=\"currentPradireccionespasistema\"\r\n  >\r\n  </app-pra-direccion-sistema> -->\r\n\r\n  <app-ciclo-participante\r\n  [currentPracicloparticipantes]=\"currentPracicloparticipante\"\r\n></app-ciclo-participante>\r\n\r\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_test_myke_myke_module_ts.js.map