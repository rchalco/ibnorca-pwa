"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_test_ruben_ruben_module_ts"],{

/***/ 1543:
/*!**********************************************************!*\
  !*** ./src/app/pages/test/ruben/ruben-routing.module.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RubenPageRoutingModule": () => (/* binding */ RubenPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _ruben_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ruben.page */ 5421);




const routes = [
    {
        path: '',
        component: _ruben_page__WEBPACK_IMPORTED_MODULE_0__.RubenPage
    }
];
let RubenPageRoutingModule = class RubenPageRoutingModule {
};
RubenPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], RubenPageRoutingModule);



/***/ }),

/***/ 5827:
/*!**************************************************!*\
  !*** ./src/app/pages/test/ruben/ruben.module.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RubenPageModule": () => (/* binding */ RubenPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _ruben_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ruben-routing.module */ 1543);
/* harmony import */ var _ruben_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ruben.page */ 5421);







let RubenPageModule = class RubenPageModule {
};
RubenPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _ruben_routing_module__WEBPACK_IMPORTED_MODULE_0__.RubenPageRoutingModule
        ],
        declarations: [_ruben_page__WEBPACK_IMPORTED_MODULE_1__.RubenPage]
    })
], RubenPageModule);



/***/ }),

/***/ 5421:
/*!************************************************!*\
  !*** ./src/app/pages/test/ruben/ruben.page.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RubenPage": () => (/* binding */ RubenPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ruben_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ruben.page.html?ngResource */ 7484);
/* harmony import */ var _ruben_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ruben.page.scss?ngResource */ 880);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_services_apertura_auditoria_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/apertura-auditoria.service */ 7583);





let RubenPage = class RubenPage {
    constructor(aperturaAuditoriaService) {
        this.aperturaAuditoriaService = aperturaAuditoriaService;
    }
    ngOnInit() {
        this.aperturaAuditoriaService.ObtenerProgramaAuditoria(1).subscribe((resul) => {
            console.log("llamaa al servicio", resul);
        });
    }
};
RubenPage.ctorParameters = () => [
    { type: src_app_services_apertura_auditoria_service__WEBPACK_IMPORTED_MODULE_2__.AperturaAuditoriaService }
];
RubenPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-ruben',
        template: _ruben_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_ruben_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], RubenPage);



/***/ }),

/***/ 880:
/*!*************************************************************!*\
  !*** ./src/app/pages/test/ruben/ruben.page.scss?ngResource ***!
  \*************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJydWJlbi5wYWdlLnNjc3MifQ== */";

/***/ }),

/***/ 7484:
/*!*************************************************************!*\
  !*** ./src/app/pages/test/ruben/ruben.page.html?ngResource ***!
  \*************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>ruben</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_test_ruben_ruben_module_ts.js.map