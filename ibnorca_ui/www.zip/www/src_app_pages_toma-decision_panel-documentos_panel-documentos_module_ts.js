"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_toma-decision_panel-documentos_panel-documentos_module_ts"],{

/***/ 8942:
/*!*****************************************************************************************!*\
  !*** ./src/app/pages/toma-decision/panel-documentos/panel-documentos-routing.module.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PanelDocumentosPageRoutingModule": () => (/* binding */ PanelDocumentosPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _panel_documentos_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./panel-documentos.page */ 5228);




const routes = [
    {
        path: '',
        component: _panel_documentos_page__WEBPACK_IMPORTED_MODULE_0__.PanelDocumentosPage
    }
];
let PanelDocumentosPageRoutingModule = class PanelDocumentosPageRoutingModule {
};
PanelDocumentosPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PanelDocumentosPageRoutingModule);



/***/ }),

/***/ 513:
/*!*********************************************************************************!*\
  !*** ./src/app/pages/toma-decision/panel-documentos/panel-documentos.module.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PanelDocumentosPageModule": () => (/* binding */ PanelDocumentosPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _panel_documentos_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./panel-documentos-routing.module */ 8942);
/* harmony import */ var _panel_documentos_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./panel-documentos.page */ 5228);
/* harmony import */ var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/components.module */ 5642);








let PanelDocumentosPageModule = class PanelDocumentosPageModule {
};
PanelDocumentosPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _panel_documentos_routing_module__WEBPACK_IMPORTED_MODULE_0__.PanelDocumentosPageRoutingModule,
            src_app_components_components_module__WEBPACK_IMPORTED_MODULE_2__.ComponentsModule
        ],
        declarations: [_panel_documentos_page__WEBPACK_IMPORTED_MODULE_1__.PanelDocumentosPage]
    })
], PanelDocumentosPageModule);



/***/ }),

/***/ 5228:
/*!*******************************************************************************!*\
  !*** ./src/app/pages/toma-decision/panel-documentos/panel-documentos.page.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PanelDocumentosPage": () => (/* binding */ PanelDocumentosPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _panel_documentos_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./panel-documentos.page.html?ngResource */ 557);
/* harmony import */ var _panel_documentos_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./panel-documentos.page.scss?ngResource */ 1532);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 2816);





let PanelDocumentosPage = class PanelDocumentosPage {
    constructor(route) {
        this.route = route;
        this.select_component = "acta";
        this.idCiclo = 166;
        this.area = "TCS";
        this.proceso = "TOMA_DECISION";
    }
    ngOnInit() {
        this.route.queryParams.subscribe((params) => {
            this.idCiclo = params.idCiclo;
            this.area = params.area;
        });
    }
    segmentChanged(event) {
        this.select_component = event.detail.value;
    }
};
PanelDocumentosPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.ActivatedRoute }
];
PanelDocumentosPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: "app-panel-documentos",
        template: _panel_documentos_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_panel_documentos_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], PanelDocumentosPage);



/***/ }),

/***/ 1532:
/*!********************************************************************************************!*\
  !*** ./src/app/pages/toma-decision/panel-documentos/panel-documentos.page.scss?ngResource ***!
  \********************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwYW5lbC1kb2N1bWVudG9zLnBhZ2Uuc2NzcyJ9 */";

/***/ }),

/***/ 557:
/*!********************************************************************************************!*\
  !*** ./src/app/pages/toma-decision/panel-documentos/panel-documentos.page.html?ngResource ***!
  \********************************************************************************************/
/***/ ((module) => {

module.exports = "<!-- <ion-toolbar>\r\n  <ion-segment #segment1 (ionChange)=\"segmentChanged($event)\" color=\"tertiary\">\r\n    <ion-segment-button value=\"acta\">\r\n      <ion-label>ACTA</ion-label>\r\n    </ion-segment-button>\r\n    <ion-segment-button value=\"resoluion\">\r\n      <ion-label>RESOLUCIÓN ADM</ion-label>\r\n    </ion-segment-button>\r\n    <ion-segment-button value=\"dec_cert\">\r\n      <ion-label>DECISION CERT.</ion-label>\r\n    </ion-segment-button>\r\n    <ion-segment-button value=\"dec_nocert\">\r\n      <ion-label>DECISION CONF. REG.</ion-label>\r\n    </ion-segment-button>\r\n    <ion-segment-button value=\"nota_suspencion\">\r\n      <ion-label>NOTA SUSPENSION</ion-label>\r\n    </ion-segment-button>\r\n    <ion-segment-button value=\"nota_retiro\">\r\n      <ion-label>NOTA RETIRO</ion-label>\r\n    </ion-segment-button>\r\n  </ion-segment>\r\n</ion-toolbar>\r\n<ion-content>\r\n  <div *ngIf=\"select_component === 'acta'\">\r\n    <app-tm-acta-reunion></app-tm-acta-reunion>\r\n  </div>\r\n  <div *ngIf=\"select_component === 'resoluion'\">\r\n    <app-editor-documento\r\n      titulo=\"Resolución Adminsitrativa\"\r\n    ></app-editor-documento>\r\n  </div>\r\n  <div *ngIf=\"select_component === 'dec_cert'\">\r\n    <app-editor-documento\r\n      titulo=\"Decision de Certificacion\"\r\n    ></app-editor-documento>\r\n  </div>\r\n  <div *ngIf=\"select_component === 'dec_nocert'\">\r\n    <app-editor-documento\r\n      titulo=\"Decision de No Certificacion\"\r\n    ></app-editor-documento>\r\n  </div>\r\n  <div *ngIf=\"select_component === 'nota_suspencion'\">\r\n    <app-editor-documento titulo=\"Nota de Suspensión\"></app-editor-documento>\r\n  </div>\r\n  <div *ngIf=\"select_component === 'nota_retiro'\">\r\n    <app-editor-documento titulo=\"Nota de Retiro\"></app-editor-documento>\r\n  </div>\r\n</ion-content> -->\r\n\r\n<app-param-documentos\r\n[area]=\"area\"\r\n[IdCiclo]=\"idCiclo\"\r\n[proceso]=\"proceso\"\r\n>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_toma-decision_panel-documentos_panel-documentos_module_ts.js.map